// Auto-generated Spanish frequency analysis
// Source: Hermit Dave's FrequencyWords (OpenSubtitles corpus)
// Generated: 2025-06-15T20:21:08.062Z
// Total words: 49420

export const SPANISH_FREQUENCY_DATA = [
  {
    "word": "que",
    "rank": 1,
    "frequency": 14421005,
    "originalRank": 2
  },
  {
    "word": "qué",
    "rank": 2,
    "frequency": 4166708,
    "originalRank": 13
  },
  {
    "word": "está",
    "rank": 3,
    "frequency": 2433246,
    "originalRank": 21
  },
  {
    "word": "bien",
    "rank": 4,
    "frequency": 2045290,
    "originalRank": 26
  },
  {
    "word": "eso",
    "rank": 5,
    "frequency": 2029720,
    "originalRank": 27
  },
  {
    "word": "del",
    "rank": 6,
    "frequency": 1647872,
    "originalRank": 31
  },
  {
    "word": "como",
    "rank": 7,
    "frequency": 1630651,
    "originalRank": 32
  },
  {
    "word": "aquí",
    "rank": 8,
    "frequency": 1625090,
    "originalRank": 33
  },
  {
    "word": "más",
    "rank": 9,
    "frequency": 1503527,
    "originalRank": 36
  },
  {
    "word": "esto",
    "rank": 10,
    "frequency": 1297847,
    "originalRank": 38
  },
  {
    "word": "todo",
    "rank": 11,
    "frequency": 1296897,
    "originalRank": 39
  },
  {
    "word": "estoy",
    "rank": 12,
    "frequency": 1092574,
    "originalRank": 41
  },
  {
    "word": "ahora",
    "rank": 13,
    "frequency": 1088174,
    "originalRank": 42
  },
  {
    "word": "muy",
    "rank": 14,
    "frequency": 1086248,
    "originalRank": 43
  },
  {
    "word": "esta",
    "rank": 15,
    "frequency": 1051900,
    "originalRank": 45
  },
  {
    "word": "así",
    "rank": 16,
    "frequency": 1050332,
    "originalRank": 46
  },
  {
    "word": "vamos",
    "rank": 17,
    "frequency": 1049315,
    "originalRank": 47
  },
  {
    "word": "algo",
    "rank": 18,
    "frequency": 1039192,
    "originalRank": 48
  },
  {
    "word": "hay",
    "rank": 19,
    "frequency": 1014288,
    "originalRank": 49
  },
  {
    "word": "bueno",
    "rank": 20,
    "frequency": 1012700,
    "originalRank": 50
  },
  {
    "word": "tengo",
    "rank": 21,
    "frequency": 954371,
    "originalRank": 51
  },
  {
    "word": "cuando",
    "rank": 22,
    "frequency": 931329,
    "originalRank": 53
  },
  {
    "word": "estás",
    "rank": 23,
    "frequency": 917354,
    "originalRank": 54
  },
  {
    "word": "nada",
    "rank": 24,
    "frequency": 863844,
    "originalRank": 58
  },
  {
    "word": "cómo",
    "rank": 25,
    "frequency": 862349,
    "originalRank": 59
  },
  {
    "word": "este",
    "rank": 26,
    "frequency": 858931,
    "originalRank": 60
  },
  {
    "word": "ser",
    "rank": 27,
    "frequency": 819688,
    "originalRank": 63
  },
  {
    "word": "tiene",
    "rank": 28,
    "frequency": 807065,
    "originalRank": 64
  },
  {
    "word": "puedo",
    "rank": 29,
    "frequency": 806048,
    "originalRank": 65
  },
  {
    "word": "quiero",
    "rank": 30,
    "frequency": 798831,
    "originalRank": 67
  },
  {
    "word": "hacer",
    "rank": 31,
    "frequency": 794408,
    "originalRank": 68
  },
  {
    "word": "fue",
    "rank": 32,
    "frequency": 781449,
    "originalRank": 69
  },
  {
    "word": "gracias",
    "rank": 33,
    "frequency": 779503,
    "originalRank": 70
  },
  {
    "word": "vez",
    "rank": 34,
    "frequency": 767227,
    "originalRank": 71
  },
  {
    "word": "era",
    "rank": 35,
    "frequency": 765725,
    "originalRank": 72
  },
  {
    "word": "soy",
    "rank": 36,
    "frequency": 745166,
    "originalRank": 73
  },
  {
    "word": "sólo",
    "rank": 37,
    "frequency": 741588,
    "originalRank": 74
  },
  {
    "word": "todos",
    "rank": 38,
    "frequency": 686692,
    "originalRank": 75
  },
  {
    "word": "porque",
    "rank": 39,
    "frequency": 685059,
    "originalRank": 76
  },
  {
    "word": "son",
    "rank": 40,
    "frequency": 671394,
    "originalRank": 77
  },
  {
    "word": "tienes",
    "rank": 41,
    "frequency": 670767,
    "originalRank": 78
  },
  {
    "word": "creo",
    "rank": 42,
    "frequency": 651433,
    "originalRank": 79
  },
  {
    "word": "voy",
    "rank": 43,
    "frequency": 639418,
    "originalRank": 80
  },
  {
    "word": "sabes",
    "rank": 44,
    "frequency": 636739,
    "originalRank": 81
  },
  {
    "word": "estaba",
    "rank": 45,
    "frequency": 636659,
    "originalRank": 82
  },
  {
    "word": "puede",
    "rank": 46,
    "frequency": 631326,
    "originalRank": 83
  },
  {
    "word": "eres",
    "rank": 47,
    "frequency": 630024,
    "originalRank": 84
  },
  {
    "word": "ese",
    "rank": 48,
    "frequency": 624205,
    "originalRank": 85
  },
  {
    "word": "usted",
    "rank": 49,
    "frequency": 618844,
    "originalRank": 86
  },
  {
    "word": "entonces",
    "rank": 50,
    "frequency": 609938,
    "originalRank": 87
  },
  {
    "word": "hola",
    "rank": 51,
    "frequency": 601523,
    "originalRank": 88
  },
  {
    "word": "solo",
    "rank": 52,
    "frequency": 590343,
    "originalRank": 89
  },
  {
    "word": "verdad",
    "rank": 53,
    "frequency": 589565,
    "originalRank": 90
  },
  {
    "word": "casa",
    "rank": 54,
    "frequency": 587832,
    "originalRank": 91
  },
  {
    "word": "tan",
    "rank": 55,
    "frequency": 573916,
    "originalRank": 92
  },
  {
    "word": "quién",
    "rank": 56,
    "frequency": 566465,
    "originalRank": 93
  },
  {
    "word": "sus",
    "rank": 57,
    "frequency": 562087,
    "originalRank": 94
  },
  {
    "word": "tiempo",
    "rank": 58,
    "frequency": 556996,
    "originalRank": 95
  },
  {
    "word": "dos",
    "rank": 59,
    "frequency": 556427,
    "originalRank": 96
  },
  {
    "word": "esa",
    "rank": 60,
    "frequency": 553442,
    "originalRank": 97
  },
  {
    "word": "nunca",
    "rank": 61,
    "frequency": 549997,
    "originalRank": 98
  },
  {
    "word": "dónde",
    "rank": 62,
    "frequency": 539643,
    "originalRank": 99
  },
  {
    "word": "favor",
    "rank": 63,
    "frequency": 527629,
    "originalRank": 102
  },
  {
    "word": "mucho",
    "rank": 64,
    "frequency": 516361,
    "originalRank": 103
  },
  {
    "word": "quieres",
    "rank": 65,
    "frequency": 515465,
    "originalRank": 105
  },
  {
    "word": "siento",
    "rank": 66,
    "frequency": 512907,
    "originalRank": 106
  },
  {
    "word": "señor",
    "rank": 67,
    "frequency": 507728,
    "originalRank": 107
  },
  {
    "word": "mejor",
    "rank": 68,
    "frequency": 500478,
    "originalRank": 108
  },
  {
    "word": "hace",
    "rank": 69,
    "frequency": 495352,
    "originalRank": 109
  },
  {
    "word": "has",
    "rank": 70,
    "frequency": 492533,
    "originalRank": 110
  },
  {
    "word": "decir",
    "rank": 71,
    "frequency": 492098,
    "originalRank": 111
  },
  {
    "word": "también",
    "rank": 72,
    "frequency": 488057,
    "originalRank": 112
  },
  {
    "word": "sobre",
    "rank": 73,
    "frequency": 478020,
    "originalRank": 113
  },
  {
    "word": "dios",
    "rank": 74,
    "frequency": 476939,
    "originalRank": 114
  },
  {
    "word": "sin",
    "rank": 75,
    "frequency": 474770,
    "originalRank": 115
  },
  {
    "word": "tenemos",
    "rank": 76,
    "frequency": 473895,
    "originalRank": 116
  },
  {
    "word": "están",
    "rank": 77,
    "frequency": 471887,
    "originalRank": 117
  },
  {
    "word": "puedes",
    "rank": 78,
    "frequency": 463318,
    "originalRank": 119
  },
  {
    "word": "ver",
    "rank": 79,
    "frequency": 462775,
    "originalRank": 120
  },
  {
    "word": "hombre",
    "rank": 80,
    "frequency": 460084,
    "originalRank": 121
  },
  {
    "word": "vida",
    "rank": 81,
    "frequency": 453649,
    "originalRank": 122
  },
  {
    "word": "alguien",
    "rank": 82,
    "frequency": 447141,
    "originalRank": 123
  },
  {
    "word": "cosas",
    "rank": 83,
    "frequency": 424801,
    "originalRank": 124
  },
  {
    "word": "siempre",
    "rank": 84,
    "frequency": 424363,
    "originalRank": 125
  },
  {
    "word": "hasta",
    "rank": 85,
    "frequency": 423321,
    "originalRank": 126
  },
  {
    "word": "ahí",
    "rank": 86,
    "frequency": 422871,
    "originalRank": 127
  },
  {
    "word": "años",
    "rank": 87,
    "frequency": 408547,
    "originalRank": 129
  },
  {
    "word": "antes",
    "rank": 88,
    "frequency": 405555,
    "originalRank": 130
  },
  {
    "word": "estar",
    "rank": 89,
    "frequency": 402369,
    "originalRank": 131
  },
  {
    "word": "poco",
    "rank": 90,
    "frequency": 397739,
    "originalRank": 133
  },
  {
    "word": "día",
    "rank": 91,
    "frequency": 395131,
    "originalRank": 134
  },
  {
    "word": "uno",
    "rank": 92,
    "frequency": 393047,
    "originalRank": 135
  },
  {
    "word": "noche",
    "rank": 93,
    "frequency": 391078,
    "originalRank": 136
  },
  {
    "word": "hecho",
    "rank": 94,
    "frequency": 391011,
    "originalRank": 137
  },
  {
    "word": "mis",
    "rank": 95,
    "frequency": 385798,
    "originalRank": 138
  },
  {
    "word": "estamos",
    "rank": 96,
    "frequency": 376563,
    "originalRank": 139
  },
  {
    "word": "otra",
    "rank": 97,
    "frequency": 368984,
    "originalRank": 140
  },
  {
    "word": "acuerdo",
    "rank": 98,
    "frequency": 367329,
    "originalRank": 141
  },
  {
    "word": "trabajo",
    "rank": 99,
    "frequency": 363747,
    "originalRank": 142
  },
  {
    "word": "parece",
    "rank": 100,
    "frequency": 355615,
    "originalRank": 144
  },
  {
    "word": "gente",
    "rank": 101,
    "frequency": 354586,
    "originalRank": 145
  },
  {
    "word": "sea",
    "rank": 102,
    "frequency": 352790,
    "originalRank": 146
  },
  {
    "word": "padre",
    "rank": 103,
    "frequency": 351051,
    "originalRank": 147
  },
  {
    "word": "mira",
    "rank": 104,
    "frequency": 349779,
    "originalRank": 148
  },
  {
    "word": "mismo",
    "rank": 105,
    "frequency": 347834,
    "originalRank": 149
  },
  {
    "word": "dijo",
    "rank": 106,
    "frequency": 342900,
    "originalRank": 150
  },
  {
    "word": "nadie",
    "rank": 107,
    "frequency": 339772,
    "originalRank": 151
  },
  {
    "word": "quiere",
    "rank": 108,
    "frequency": 332148,
    "originalRank": 152
  },
  {
    "word": "podría",
    "rank": 109,
    "frequency": 329332,
    "originalRank": 153
  },
  {
    "word": "hablar",
    "rank": 110,
    "frequency": 327201,
    "originalRank": 154
  },
  {
    "word": "vas",
    "rank": 111,
    "frequency": 327127,
    "originalRank": 155
  },
  {
    "word": "tal",
    "rank": 112,
    "frequency": 317926,
    "originalRank": 158
  },
  {
    "word": "pasa",
    "rank": 113,
    "frequency": 315529,
    "originalRank": 159
  },
  {
    "word": "fuera",
    "rank": 114,
    "frequency": 311571,
    "originalRank": 160
  },
  {
    "word": "después",
    "rank": 115,
    "frequency": 311500,
    "originalRank": 161
  },
  {
    "word": "han",
    "rank": 116,
    "frequency": 308501,
    "originalRank": 162
  },
  {
    "word": "desde",
    "rank": 117,
    "frequency": 303620,
    "originalRank": 163
  },
  {
    "word": "dinero",
    "rank": 118,
    "frequency": 300518,
    "originalRank": 164
  },
  {
    "word": "mundo",
    "rank": 119,
    "frequency": 298208,
    "originalRank": 165
  },
  {
    "word": "claro",
    "rank": 120,
    "frequency": 296584,
    "originalRank": 166
  },
  {
    "word": "momento",
    "rank": 121,
    "frequency": 294559,
    "originalRank": 167
  },
  {
    "word": "tener",
    "rank": 122,
    "frequency": 292932,
    "originalRank": 169
  },
  {
    "word": "estado",
    "rank": 123,
    "frequency": 292015,
    "originalRank": 170
  },
  {
    "word": "otro",
    "rank": 124,
    "frequency": 290565,
    "originalRank": 171
  },
  {
    "word": "había",
    "rank": 125,
    "frequency": 289157,
    "originalRank": 172
  },
  {
    "word": "mañana",
    "rank": 126,
    "frequency": 283391,
    "originalRank": 173
  },
  {
    "word": "tenía",
    "rank": 127,
    "frequency": 282966,
    "originalRank": 174
  },
  {
    "word": "madre",
    "rank": 128,
    "frequency": 281646,
    "originalRank": 175
  },
  {
    "word": "vale",
    "rank": 129,
    "frequency": 280447,
    "originalRank": 176
  },
  {
    "word": "lugar",
    "rank": 130,
    "frequency": 280315,
    "originalRank": 177
  },
  {
    "word": "haciendo",
    "rank": 131,
    "frequency": 278317,
    "originalRank": 178
  },
  {
    "word": "donde",
    "rank": 132,
    "frequency": 277524,
    "originalRank": 179
  },
  {
    "word": "seguro",
    "rank": 133,
    "frequency": 277231,
    "originalRank": 180
  },
  {
    "word": "sabe",
    "rank": 134,
    "frequency": 273895,
    "originalRank": 181
  },
  {
    "word": "podemos",
    "rank": 135,
    "frequency": 272425,
    "originalRank": 182
  },
  {
    "word": "tus",
    "rank": 136,
    "frequency": 271677,
    "originalRank": 183
  },
  {
    "word": "espera",
    "rank": 137,
    "frequency": 270741,
    "originalRank": 184
  },
  {
    "word": "nuevo",
    "rank": 138,
    "frequency": 269895,
    "originalRank": 185
  },
  {
    "word": "sido",
    "rank": 139,
    "frequency": 269505,
    "originalRank": 186
  },
  {
    "word": "cosa",
    "rank": 140,
    "frequency": 269054,
    "originalRank": 187
  },
  {
    "word": "hijo",
    "rank": 141,
    "frequency": 267856,
    "originalRank": 188
  },
  {
    "word": "allí",
    "rank": 142,
    "frequency": 267215,
    "originalRank": 189
  },
  {
    "word": "menos",
    "rank": 143,
    "frequency": 263837,
    "originalRank": 190
  },
  {
    "word": "tipo",
    "rank": 144,
    "frequency": 262340,
    "originalRank": 191
  },
  {
    "word": "amigo",
    "rank": 145,
    "frequency": 258356,
    "originalRank": 192
  },
  {
    "word": "gran",
    "rank": 146,
    "frequency": 257648,
    "originalRank": 193
  },
  {
    "word": "nuestro",
    "rank": 147,
    "frequency": 254046,
    "originalRank": 194
  },
  {
    "word": "mujer",
    "rank": 148,
    "frequency": 249627,
    "originalRank": 195
  },
  {
    "word": "mamá",
    "rank": 149,
    "frequency": 247700,
    "originalRank": 196
  },
  {
    "word": "luego",
    "rank": 150,
    "frequency": 245811,
    "originalRank": 197
  },
  {
    "word": "papá",
    "rank": 151,
    "frequency": 243251,
    "originalRank": 198
  },
  {
    "word": "días",
    "rank": 152,
    "frequency": 243003,
    "originalRank": 199
  },
  {
    "word": "dice",
    "rank": 153,
    "frequency": 240795,
    "originalRank": 200
  },
  {
    "word": "hoy",
    "rank": 154,
    "frequency": 240395,
    "originalRank": 201
  },
  {
    "word": "tres",
    "rank": 155,
    "frequency": 239782,
    "originalRank": 202
  },
  {
    "word": "buena",
    "rank": 156,
    "frequency": 238330,
    "originalRank": 203
  },
  {
    "word": "necesito",
    "rank": 157,
    "frequency": 237654,
    "originalRank": 204
  },
  {
    "word": "dije",
    "rank": 158,
    "frequency": 235936,
    "originalRank": 205
  },
  {
    "word": "oye",
    "rank": 159,
    "frequency": 234324,
    "originalRank": 206
  },
  {
    "word": "gusta",
    "rank": 160,
    "frequency": 233367,
    "originalRank": 207
  },
  {
    "word": "quería",
    "rank": 161,
    "frequency": 230602,
    "originalRank": 208
  },
  {
    "word": "será",
    "rank": 162,
    "frequency": 230159,
    "originalRank": 209
  },
  {
    "word": "haber",
    "rank": 163,
    "frequency": 229602,
    "originalRank": 210
  },
  {
    "word": "parte",
    "rank": 164,
    "frequency": 229038,
    "originalRank": 211
  },
  {
    "word": "todas",
    "rank": 165,
    "frequency": 227146,
    "originalRank": 212
  },
  {
    "word": "crees",
    "rank": 166,
    "frequency": 225748,
    "originalRank": 213
  },
  {
    "word": "buen",
    "rank": 167,
    "frequency": 224802,
    "originalRank": 214
  },
  {
    "word": "conmigo",
    "rank": 168,
    "frequency": 224527,
    "originalRank": 215
  },
  {
    "word": "nombre",
    "rank": 169,
    "frequency": 222406,
    "originalRank": 216
  },
  {
    "word": "mierda",
    "rank": 170,
    "frequency": 221567,
    "originalRank": 217
  },
  {
    "word": "nuestra",
    "rank": 171,
    "frequency": 221503,
    "originalRank": 218
  },
  {
    "word": "mal",
    "rank": 172,
    "frequency": 220024,
    "originalRank": 219
  },
  {
    "word": "debe",
    "rank": 173,
    "frequency": 218223,
    "originalRank": 220
  },
  {
    "word": "realmente",
    "rank": 174,
    "frequency": 217847,
    "originalRank": 221
  },
  {
    "word": "estas",
    "rank": 175,
    "frequency": 216844,
    "originalRank": 222
  },
  {
    "word": "aún",
    "rank": 176,
    "frequency": 215129,
    "originalRank": 223
  },
  {
    "word": "mío",
    "rank": 177,
    "frequency": 212096,
    "originalRank": 224
  },
  {
    "word": "toda",
    "rank": 178,
    "frequency": 211746,
    "originalRank": 225
  },
  {
    "word": "hacerlo",
    "rank": 179,
    "frequency": 209901,
    "originalRank": 226
  },
  {
    "word": "cada",
    "rank": 180,
    "frequency": 209674,
    "originalRank": 227
  },
  {
    "word": "visto",
    "rank": 181,
    "frequency": 206949,
    "originalRank": 228
  },
  {
    "word": "importa",
    "rank": 182,
    "frequency": 203118,
    "originalRank": 229
  },
  {
    "word": "contigo",
    "rank": 183,
    "frequency": 202208,
    "originalRank": 230
  },
  {
    "word": "tienen",
    "rank": 184,
    "frequency": 200708,
    "originalRank": 231
  },
  {
    "word": "hemos",
    "rank": 185,
    "frequency": 200028,
    "originalRank": 232
  },
  {
    "word": "razón",
    "rank": 186,
    "frequency": 198832,
    "originalRank": 233
  },
  {
    "word": "alguna",
    "rank": 187,
    "frequency": 198263,
    "originalRank": 234
  },
  {
    "word": "tanto",
    "rank": 188,
    "frequency": 197519,
    "originalRank": 235
  },
  {
    "word": "saber",
    "rank": 189,
    "frequency": 196610,
    "originalRank": 236
  },
  {
    "word": "hizo",
    "rank": 190,
    "frequency": 196192,
    "originalRank": 237
  },
  {
    "word": "veces",
    "rank": 191,
    "frequency": 195756,
    "originalRank": 238
  },
  {
    "word": "serio",
    "rank": 192,
    "frequency": 194846,
    "originalRank": 239
  },
  {
    "word": "ven",
    "rank": 193,
    "frequency": 193452,
    "originalRank": 240
  },
  {
    "word": "idea",
    "rank": 194,
    "frequency": 193369,
    "originalRank": 241
  },
  {
    "word": "tarde",
    "rank": 195,
    "frequency": 191883,
    "originalRank": 243
  },
  {
    "word": "problema",
    "rank": 196,
    "frequency": 189963,
    "originalRank": 244
  },
  {
    "word": "hora",
    "rank": 197,
    "frequency": 189851,
    "originalRank": 245
  },
  {
    "word": "cierto",
    "rank": 198,
    "frequency": 189653,
    "originalRank": 246
  },
  {
    "word": "dicho",
    "rank": 199,
    "frequency": 187895,
    "originalRank": 247
  },
  {
    "word": "quien",
    "rank": 200,
    "frequency": 187133,
    "originalRank": 248
  },
  {
    "word": "demasiado",
    "rank": 201,
    "frequency": 182668,
    "originalRank": 249
  },
  {
    "word": "amor",
    "rank": 202,
    "frequency": 182326,
    "originalRank": 250
  },
  {
    "word": "entre",
    "rank": 203,
    "frequency": 181114,
    "originalRank": 251
  },
  {
    "word": "pasado",
    "rank": 204,
    "frequency": 178763,
    "originalRank": 253
  },
  {
    "word": "familia",
    "rank": 205,
    "frequency": 177748,
    "originalRank": 254
  },
  {
    "word": "estos",
    "rank": 206,
    "frequency": 176532,
    "originalRank": 255
  },
  {
    "word": "policía",
    "rank": 207,
    "frequency": 175471,
    "originalRank": 256
  },
  {
    "word": "debería",
    "rank": 208,
    "frequency": 175394,
    "originalRank": 257
  },
  {
    "word": "ustedes",
    "rank": 209,
    "frequency": 174241,
    "originalRank": 258
  },
  {
    "word": "chica",
    "rank": 210,
    "frequency": 173210,
    "originalRank": 259
  },
  {
    "word": "esos",
    "rank": 211,
    "frequency": 171237,
    "originalRank": 260
  },
  {
    "word": "chicos",
    "rank": 212,
    "frequency": 170008,
    "originalRank": 261
  },
  {
    "word": "cuenta",
    "rank": 213,
    "frequency": 169714,
    "originalRank": 262
  },
  {
    "word": "haces",
    "rank": 214,
    "frequency": 166985,
    "originalRank": 263
  },
  {
    "word": "todavía",
    "rank": 215,
    "frequency": 166624,
    "originalRank": 264
  },
  {
    "word": "salir",
    "rank": 216,
    "frequency": 165591,
    "originalRank": 265
  },
  {
    "word": "algún",
    "rank": 217,
    "frequency": 163790,
    "originalRank": 266
  },
  {
    "word": "vaya",
    "rank": 218,
    "frequency": 162833,
    "originalRank": 267
  },
  {
    "word": "veo",
    "rank": 219,
    "frequency": 162326,
    "originalRank": 269
  },
  {
    "word": "amigos",
    "rank": 220,
    "frequency": 160684,
    "originalRank": 270
  },
  {
    "word": "hermano",
    "rank": 221,
    "frequency": 159678,
    "originalRank": 271
  },
  {
    "word": "pensé",
    "rank": 222,
    "frequency": 159438,
    "originalRank": 272
  },
  {
    "word": "sabía",
    "rank": 223,
    "frequency": 156439,
    "originalRank": 273
  },
  {
    "word": "cabeza",
    "rank": 224,
    "frequency": 156069,
    "originalRank": 274
  },
  {
    "word": "cariño",
    "rank": 225,
    "frequency": 153353,
    "originalRank": 276
  },
  {
    "word": "digo",
    "rank": 226,
    "frequency": 153149,
    "originalRank": 277
  },
  {
    "word": "van",
    "rank": 227,
    "frequency": 153024,
    "originalRank": 278
  },
  {
    "word": "hombres",
    "rank": 228,
    "frequency": 151647,
    "originalRank": 279
  },
  {
    "word": "buenas",
    "rank": 229,
    "frequency": 151571,
    "originalRank": 280
  },
  {
    "word": "somos",
    "rank": 230,
    "frequency": 151256,
    "originalRank": 281
  },
  {
    "word": "cualquier",
    "rank": 231,
    "frequency": 150946,
    "originalRank": 282
  },
  {
    "word": "forma",
    "rank": 232,
    "frequency": 150750,
    "originalRank": 283
  },
  {
    "word": "mientras",
    "rank": 233,
    "frequency": 150383,
    "originalRank": 284
  },
  {
    "word": "lado",
    "rank": 234,
    "frequency": 149162,
    "originalRank": 285
  },
  {
    "word": "debo",
    "rank": 235,
    "frequency": 148975,
    "originalRank": 286
  },
  {
    "word": "sería",
    "rank": 236,
    "frequency": 148309,
    "originalRank": 287
  },
  {
    "word": "caso",
    "rank": 237,
    "frequency": 148273,
    "originalRank": 288
  },
  {
    "word": "pueden",
    "rank": 238,
    "frequency": 148183,
    "originalRank": 289
  },
  {
    "word": "pasó",
    "rank": 239,
    "frequency": 145810,
    "originalRank": 290
  },
  {
    "word": "primera",
    "rank": 240,
    "frequency": 145110,
    "originalRank": 291
  },
  {
    "word": "genial",
    "rank": 241,
    "frequency": 145028,
    "originalRank": 292
  },
  {
    "word": "chico",
    "rank": 242,
    "frequency": 145009,
    "originalRank": 293
  },
  {
    "word": "supuesto",
    "rank": 243,
    "frequency": 144428,
    "originalRank": 294
  },
  {
    "word": "hice",
    "rank": 244,
    "frequency": 144174,
    "originalRank": 295
  },
  {
    "word": "pues",
    "rank": 245,
    "frequency": 143870,
    "originalRank": 296
  },
  {
    "word": "adiós",
    "rank": 246,
    "frequency": 143677,
    "originalRank": 297
  },
  {
    "word": "muchas",
    "rank": 247,
    "frequency": 143007,
    "originalRank": 298
  },
  {
    "word": "personas",
    "rank": 248,
    "frequency": 141945,
    "originalRank": 299
  },
  {
    "word": "señora",
    "rank": 249,
    "frequency": 141893,
    "originalRank": 300
  },
  {
    "word": "volver",
    "rank": 250,
    "frequency": 141009,
    "originalRank": 301
  },
  {
    "word": "esas",
    "rank": 251,
    "frequency": 140885,
    "originalRank": 302
  },
  {
    "word": "quizá",
    "rank": 252,
    "frequency": 140794,
    "originalRank": 303
  },
  {
    "word": "contra",
    "rank": 253,
    "frequency": 140485,
    "originalRank": 304
  },
  {
    "word": "camino",
    "rank": 254,
    "frequency": 140092,
    "originalRank": 305
  },
  {
    "word": "durante",
    "rank": 255,
    "frequency": 139987,
    "originalRank": 306
  },
  {
    "word": "hablando",
    "rank": 256,
    "frequency": 139007,
    "originalRank": 307
  },
  {
    "word": "manera",
    "rank": 257,
    "frequency": 137722,
    "originalRank": 308
  },
  {
    "word": "muerto",
    "rank": 258,
    "frequency": 137301,
    "originalRank": 309
  },
  {
    "word": "persona",
    "rank": 259,
    "frequency": 136985,
    "originalRank": 310
  },
  {
    "word": "rápido",
    "rank": 260,
    "frequency": 136953,
    "originalRank": 311
  },
  {
    "word": "cuál",
    "rank": 261,
    "frequency": 136406,
    "originalRank": 312
  },
  {
    "word": "ayuda",
    "rank": 262,
    "frequency": 136155,
    "originalRank": 313
  },
  {
    "word": "historia",
    "rank": 263,
    "frequency": 135924,
    "originalRank": 314
  },
  {
    "word": "iba",
    "rank": 264,
    "frequency": 135256,
    "originalRank": 315
  },
  {
    "word": "supongo",
    "rank": 265,
    "frequency": 134885,
    "originalRank": 316
  },
  {
    "word": "nueva",
    "rank": 266,
    "frequency": 134490,
    "originalRank": 317
  },
  {
    "word": "entiendo",
    "rank": 267,
    "frequency": 134138,
    "originalRank": 318
  },
  {
    "word": "dentro",
    "rank": 268,
    "frequency": 133954,
    "originalRank": 319
  },
  {
    "word": "casi",
    "rank": 269,
    "frequency": 133614,
    "originalRank": 320
  },
  {
    "word": "puerta",
    "rank": 270,
    "frequency": 133533,
    "originalRank": 321
  },
  {
    "word": "ves",
    "rank": 271,
    "frequency": 133094,
    "originalRank": 322
  },
  {
    "word": "pasar",
    "rank": 272,
    "frequency": 131693,
    "originalRank": 323
  },
  {
    "word": "primero",
    "rank": 273,
    "frequency": 131298,
    "originalRank": 324
  },
  {
    "word": "significa",
    "rank": 274,
    "frequency": 130774,
    "originalRank": 325
  },
  {
    "word": "semana",
    "rank": 275,
    "frequency": 130555,
    "originalRank": 326
  },
  {
    "word": "hacia",
    "rank": 276,
    "frequency": 130000,
    "originalRank": 327
  },
  {
    "word": "quizás",
    "rank": 277,
    "frequency": 129544,
    "originalRank": 328
  },
  {
    "word": "espero",
    "rank": 278,
    "frequency": 129454,
    "originalRank": 329
  },
  {
    "word": "juntos",
    "rank": 279,
    "frequency": 129353,
    "originalRank": 330
  },
  {
    "word": "año",
    "rank": 280,
    "frequency": 128910,
    "originalRank": 331
  },
  {
    "word": "niños",
    "rank": 281,
    "frequency": 128856,
    "originalRank": 332
  },
  {
    "word": "pronto",
    "rank": 282,
    "frequency": 128135,
    "originalRank": 333
  },
  {
    "word": "tío",
    "rank": 283,
    "frequency": 127895,
    "originalRank": 334
  },
  {
    "word": "suerte",
    "rank": 284,
    "frequency": 127246,
    "originalRank": 335
  },
  {
    "word": "ciudad",
    "rank": 285,
    "frequency": 126710,
    "originalRank": 336
  },
  {
    "word": "siquiera",
    "rank": 286,
    "frequency": 126506,
    "originalRank": 337
  },
  {
    "word": "feliz",
    "rank": 287,
    "frequency": 125692,
    "originalRank": 338
  },
  {
    "word": "venir",
    "rank": 288,
    "frequency": 124376,
    "originalRank": 339
  },
  {
    "word": "hija",
    "rank": 289,
    "frequency": 124289,
    "originalRank": 340
  },
  {
    "word": "gustaría",
    "rank": 290,
    "frequency": 124196,
    "originalRank": 341
  },
  {
    "word": "minutos",
    "rank": 291,
    "frequency": 123912,
    "originalRank": 342
  },
  {
    "word": "cuánto",
    "rank": 292,
    "frequency": 123138,
    "originalRank": 343
  },
  {
    "word": "hey",
    "rank": 293,
    "frequency": 122432,
    "originalRank": 345
  },
  {
    "word": "muerte",
    "rank": 294,
    "frequency": 122057,
    "originalRank": 346
  },
  {
    "word": "dejar",
    "rank": 295,
    "frequency": 121779,
    "originalRank": 347
  },
  {
    "word": "realidad",
    "rank": 296,
    "frequency": 121027,
    "originalRank": 348
  },
  {
    "word": "deja",
    "rank": 297,
    "frequency": 120259,
    "originalRank": 349
  },
  {
    "word": "problemas",
    "rank": 298,
    "frequency": 120138,
    "originalRank": 350
  },
  {
    "word": "importante",
    "rank": 299,
    "frequency": 119177,
    "originalRank": 353
  },
  {
    "word": "dijiste",
    "rank": 300,
    "frequency": 119038,
    "originalRank": 354
  },
  {
    "word": "corazón",
    "rank": 301,
    "frequency": 118685,
    "originalRank": 355
  },
  {
    "word": "miedo",
    "rank": 302,
    "frequency": 118624,
    "originalRank": 356
  },
  {
    "word": "jefe",
    "rank": 303,
    "frequency": 118458,
    "originalRank": 357
  },
  {
    "word": "agua",
    "rank": 304,
    "frequency": 117654,
    "originalRank": 358
  },
  {
    "word": "haré",
    "rank": 305,
    "frequency": 117579,
    "originalRank": 359
  },
  {
    "word": "justo",
    "rank": 306,
    "frequency": 117044,
    "originalRank": 360
  },
  {
    "word": "horas",
    "rank": 307,
    "frequency": 116873,
    "originalRank": 361
  },
  {
    "word": "poder",
    "rank": 308,
    "frequency": 115246,
    "originalRank": 362
  },
  {
    "word": "buenos",
    "rank": 309,
    "frequency": 115064,
    "originalRank": 363
  },
  {
    "word": "esposa",
    "rank": 310,
    "frequency": 114925,
    "originalRank": 364
  },
  {
    "word": "manos",
    "rank": 311,
    "frequency": 114921,
    "originalRank": 365
  },
  {
    "word": "debes",
    "rank": 312,
    "frequency": 114812,
    "originalRank": 366
  },
  {
    "word": "viene",
    "rank": 313,
    "frequency": 114395,
    "originalRank": 367
  },
  {
    "word": "venga",
    "rank": 314,
    "frequency": 114109,
    "originalRank": 368
  },
  {
    "word": "nuestros",
    "rank": 315,
    "frequency": 114018,
    "originalRank": 369
  },
  {
    "word": "ojos",
    "rank": 316,
    "frequency": 113772,
    "originalRank": 370
  },
  {
    "word": "adelante",
    "rank": 317,
    "frequency": 113192,
    "originalRank": 371
  },
  {
    "word": "encontrar",
    "rank": 318,
    "frequency": 113028,
    "originalRank": 372
  },
  {
    "word": "mano",
    "rank": 319,
    "frequency": 112665,
    "originalRank": 373
  },
  {
    "word": "cinco",
    "rank": 320,
    "frequency": 112532,
    "originalRank": 374
  },
  {
    "word": "niño",
    "rank": 321,
    "frequency": 112512,
    "originalRank": 375
  },
  {
    "word": "ninguna",
    "rank": 322,
    "frequency": 112227,
    "originalRank": 376
  },
  {
    "word": "otros",
    "rank": 323,
    "frequency": 112169,
    "originalRank": 377
  },
  {
    "word": "cara",
    "rank": 324,
    "frequency": 111953,
    "originalRank": 378
  },
  {
    "word": "cuidado",
    "rank": 325,
    "frequency": 111524,
    "originalRank": 379
  },
  {
    "word": "bajo",
    "rank": 326,
    "frequency": 111241,
    "originalRank": 380
  },
  {
    "word": "cerca",
    "rank": 327,
    "frequency": 110690,
    "originalRank": 381
  },
  {
    "word": "viejo",
    "rank": 328,
    "frequency": 110403,
    "originalRank": 382
  },
  {
    "word": "déjame",
    "rank": 329,
    "frequency": 109679,
    "originalRank": 383
  },
  {
    "word": "noches",
    "rank": 330,
    "frequency": 109592,
    "originalRank": 384
  },
  {
    "word": "bastante",
    "rank": 331,
    "frequency": 109431,
    "originalRank": 385
  },
  {
    "word": "fin",
    "rank": 332,
    "frequency": 109402,
    "originalRank": 386
  },
  {
    "word": "tomar",
    "rank": 333,
    "frequency": 109183,
    "originalRank": 387
  },
  {
    "word": "único",
    "rank": 334,
    "frequency": 108435,
    "originalRank": 388
  },
  {
    "word": "misma",
    "rank": 335,
    "frequency": 108033,
    "originalRank": 389
  },
  {
    "word": "escucha",
    "rank": 336,
    "frequency": 107286,
    "originalRank": 390
  },
  {
    "word": "ningún",
    "rank": 337,
    "frequency": 107193,
    "originalRank": 391
  },
  {
    "word": "suficiente",
    "rank": 338,
    "frequency": 107106,
    "originalRank": 392
  },
  {
    "word": "punto",
    "rank": 339,
    "frequency": 106940,
    "originalRank": 393
  },
  {
    "word": "cuándo",
    "rank": 340,
    "frequency": 106920,
    "originalRank": 394
  },
  {
    "word": "sigue",
    "rank": 341,
    "frequency": 106764,
    "originalRank": 395
  },
  {
    "word": "haya",
    "rank": 342,
    "frequency": 106729,
    "originalRank": 396
  },
  {
    "word": "equipo",
    "rank": 343,
    "frequency": 106584,
    "originalRank": 397
  },
  {
    "word": "grande",
    "rank": 344,
    "frequency": 106057,
    "originalRank": 398
  },
  {
    "word": "necesita",
    "rank": 345,
    "frequency": 105889,
    "originalRank": 399
  },
  {
    "word": "llegar",
    "rank": 346,
    "frequency": 105719,
    "originalRank": 400
  },
  {
    "word": "incluso",
    "rank": 347,
    "frequency": 105304,
    "originalRank": 401
  },
  {
    "word": "algunos",
    "rank": 348,
    "frequency": 105052,
    "originalRank": 402
  },
  {
    "word": "doctor",
    "rank": 349,
    "frequency": 104991,
    "originalRank": 403
  },
  {
    "word": "difícil",
    "rank": 350,
    "frequency": 104985,
    "originalRank": 404
  },
  {
    "word": "aunque",
    "rank": 351,
    "frequency": 104655,
    "originalRank": 405
  },
  {
    "word": "hubiera",
    "rank": 352,
    "frequency": 104473,
    "originalRank": 406
  },
  {
    "word": "primer",
    "rank": 353,
    "frequency": 104138,
    "originalRank": 407
  },
  {
    "word": "coche",
    "rank": 354,
    "frequency": 103946,
    "originalRank": 408
  },
  {
    "word": "hago",
    "rank": 355,
    "frequency": 103901,
    "originalRank": 409
  },
  {
    "word": "clase",
    "rank": 356,
    "frequency": 103827,
    "originalRank": 410
  },
  {
    "word": "cuatro",
    "rank": 357,
    "frequency": 103805,
    "originalRank": 411
  },
  {
    "word": "mas",
    "rank": 358,
    "frequency": 103445,
    "originalRank": 412
  },
  {
    "word": "dices",
    "rank": 359,
    "frequency": 103279,
    "originalRank": 413
  },
  {
    "word": "pequeño",
    "rank": 360,
    "frequency": 103016,
    "originalRank": 414
  },
  {
    "word": "llama",
    "rank": 361,
    "frequency": 102848,
    "originalRank": 415
  },
  {
    "word": "toma",
    "rank": 362,
    "frequency": 102733,
    "originalRank": 416
  },
  {
    "word": "hiciste",
    "rank": 363,
    "frequency": 102722,
    "originalRank": 417
  },
  {
    "word": "allá",
    "rank": 364,
    "frequency": 102642,
    "originalRank": 418
  },
  {
    "word": "última",
    "rank": 365,
    "frequency": 102333,
    "originalRank": 419
  },
  {
    "word": "arriba",
    "rank": 366,
    "frequency": 102254,
    "originalRank": 420
  },
  {
    "word": "tierra",
    "rank": 367,
    "frequency": 102197,
    "originalRank": 421
  },
  {
    "word": "guerra",
    "rank": 368,
    "frequency": 101887,
    "originalRank": 422
  },
  {
    "word": "pensar",
    "rank": 369,
    "frequency": 101695,
    "originalRank": 423
  },
  {
    "word": "pueda",
    "rank": 370,
    "frequency": 101487,
    "originalRank": 424
  },
  {
    "word": "igual",
    "rank": 371,
    "frequency": 101272,
    "originalRank": 425
  },
  {
    "word": "loco",
    "rank": 372,
    "frequency": 100021,
    "originalRank": 426
  },
  {
    "word": "sangre",
    "rank": 373,
    "frequency": 99844,
    "originalRank": 427
  },
  {
    "word": "mujeres",
    "rank": 374,
    "frequency": 99536,
    "originalRank": 428
  },
  {
    "word": "vuelta",
    "rank": 375,
    "frequency": 99529,
    "originalRank": 429
  },
  {
    "word": "fui",
    "rank": 376,
    "frequency": 99366,
    "originalRank": 430
  },
  {
    "word": "trabajar",
    "rank": 377,
    "frequency": 99262,
    "originalRank": 431
  },
  {
    "word": "tenido",
    "rank": 378,
    "frequency": 99237,
    "originalRank": 432
  },
  {
    "word": "juego",
    "rank": 379,
    "frequency": 99041,
    "originalRank": 433
  },
  {
    "word": "deberías",
    "rank": 380,
    "frequency": 98960,
    "originalRank": 434
  },
  {
    "word": "cuerpo",
    "rank": 381,
    "frequency": 98410,
    "originalRank": 435
  },
  {
    "word": "algunas",
    "rank": 382,
    "frequency": 96075,
    "originalRank": 437
  },
  {
    "word": "entrar",
    "rank": 383,
    "frequency": 95899,
    "originalRank": 438
  },
  {
    "word": "cree",
    "rank": 384,
    "frequency": 95859,
    "originalRank": 439
  },
  {
    "word": "podía",
    "rank": 385,
    "frequency": 95527,
    "originalRank": 440
  },
  {
    "word": "debemos",
    "rank": 386,
    "frequency": 95445,
    "originalRank": 441
  },
  {
    "word": "oportunidad",
    "rank": 387,
    "frequency": 95375,
    "originalRank": 442
  },
  {
    "word": "teléfono",
    "rank": 388,
    "frequency": 95015,
    "originalRank": 443
  },
  {
    "word": "necesitamos",
    "rank": 389,
    "frequency": 94964,
    "originalRank": 444
  },
  {
    "word": "final",
    "rank": 390,
    "frequency": 94883,
    "originalRank": 445
  },
  {
    "word": "listo",
    "rank": 391,
    "frequency": 94769,
    "originalRank": 446
  },
  {
    "word": "fiesta",
    "rank": 392,
    "frequency": 94739,
    "originalRank": 447
  },
  {
    "word": "muchos",
    "rank": 393,
    "frequency": 94250,
    "originalRank": 448
  },
  {
    "word": "estabas",
    "rank": 394,
    "frequency": 94097,
    "originalRank": 449
  },
  {
    "word": "quieren",
    "rank": 395,
    "frequency": 94018,
    "originalRank": 450
  },
  {
    "word": "vete",
    "rank": 396,
    "frequency": 93782,
    "originalRank": 451
  },
  {
    "word": "auto",
    "rank": 397,
    "frequency": 93654,
    "originalRank": 452
  },
  {
    "word": "dar",
    "rank": 398,
    "frequency": 92706,
    "originalRank": 453
  },
  {
    "word": "vivir",
    "rank": 399,
    "frequency": 92629,
    "originalRank": 454
  },
  {
    "word": "posible",
    "rank": 400,
    "frequency": 92449,
    "originalRank": 455
  },
  {
    "word": "hermana",
    "rank": 401,
    "frequency": 92291,
    "originalRank": 457
  },
  {
    "word": "número",
    "rank": 402,
    "frequency": 92183,
    "originalRank": 458
  },
  {
    "word": "meses",
    "rank": 403,
    "frequency": 92062,
    "originalRank": 459
  },
  {
    "word": "exactamente",
    "rank": 404,
    "frequency": 91598,
    "originalRank": 460
  },
  {
    "word": "culpa",
    "rank": 405,
    "frequency": 91506,
    "originalRank": 461
  },
  {
    "word": "abajo",
    "rank": 406,
    "frequency": 91298,
    "originalRank": 462
  },
  {
    "word": "escuela",
    "rank": 407,
    "frequency": 90725,
    "originalRank": 463
  },
  {
    "word": "ido",
    "rank": 408,
    "frequency": 90670,
    "originalRank": 464
  },
  {
    "word": "fuerte",
    "rank": 409,
    "frequency": 90226,
    "originalRank": 465
  },
  {
    "word": "diciendo",
    "rank": 410,
    "frequency": 90048,
    "originalRank": 466
  },
  {
    "word": "habla",
    "rank": 411,
    "frequency": 90023,
    "originalRank": 467
  },
  {
    "word": "esté",
    "rank": 412,
    "frequency": 89826,
    "originalRank": 468
  },
  {
    "word": "ello",
    "rank": 413,
    "frequency": 89741,
    "originalRank": 469
  },
  {
    "word": "pregunta",
    "rank": 414,
    "frequency": 89617,
    "originalRank": 470
  },
  {
    "word": "chicas",
    "rank": 415,
    "frequency": 89467,
    "originalRank": 471
  },
  {
    "word": "eran",
    "rank": 416,
    "frequency": 89418,
    "originalRank": 472
  },
  {
    "word": "pasando",
    "rank": 417,
    "frequency": 88887,
    "originalRank": 474
  },
  {
    "word": "atrás",
    "rank": 418,
    "frequency": 88877,
    "originalRank": 475
  },
  {
    "word": "malo",
    "rank": 419,
    "frequency": 88555,
    "originalRank": 476
  },
  {
    "word": "capitán",
    "rank": 420,
    "frequency": 88550,
    "originalRank": 477
  },
  {
    "word": "bebé",
    "rank": 421,
    "frequency": 88307,
    "originalRank": 479
  },
  {
    "word": "segundo",
    "rank": 422,
    "frequency": 88232,
    "originalRank": 480
  },
  {
    "word": "sabemos",
    "rank": 423,
    "frequency": 87714,
    "originalRank": 481
  },
  {
    "word": "mayor",
    "rank": 424,
    "frequency": 87707,
    "originalRank": 482
  },
  {
    "word": "comida",
    "rank": 425,
    "frequency": 87661,
    "originalRank": 483
  },
  {
    "word": "morir",
    "rank": 426,
    "frequency": 87614,
    "originalRank": 484
  },
  {
    "word": "conozco",
    "rank": 427,
    "frequency": 87429,
    "originalRank": 485
  },
  {
    "word": "dame",
    "rank": 428,
    "frequency": 87200,
    "originalRank": 486
  },
  {
    "word": "fácil",
    "rank": 429,
    "frequency": 87099,
    "originalRank": 487
  },
  {
    "word": "comer",
    "rank": 430,
    "frequency": 86671,
    "originalRank": 488
  },
  {
    "word": "vino",
    "rank": 431,
    "frequency": 86406,
    "originalRank": 489
  },
  {
    "word": "lista",
    "rank": 432,
    "frequency": 86033,
    "originalRank": 490
  },
  {
    "word": "haga",
    "rank": 433,
    "frequency": 85884,
    "originalRank": 491
  },
  {
    "word": "necesitas",
    "rank": 434,
    "frequency": 85706,
    "originalRank": 492
  },
  {
    "word": "hijos",
    "rank": 435,
    "frequency": 85020,
    "originalRank": 493
  },
  {
    "word": "probablemente",
    "rank": 436,
    "frequency": 84911,
    "originalRank": 494
  },
  {
    "word": "padres",
    "rank": 437,
    "frequency": 84855,
    "originalRank": 495
  },
  {
    "word": "habitación",
    "rank": 438,
    "frequency": 84704,
    "originalRank": 496
  },
  {
    "word": "creer",
    "rank": 439,
    "frequency": 84624,
    "originalRank": 497
  },
  {
    "word": "pensando",
    "rank": 440,
    "frequency": 84438,
    "originalRank": 498
  },
  {
    "word": "fueron",
    "rank": 441,
    "frequency": 84181,
    "originalRank": 499
  },
  {
    "word": "dime",
    "rank": 442,
    "frequency": 84079,
    "originalRank": 500
  },
  {
    "word": "trata",
    "rank": 443,
    "frequency": 83906,
    "originalRank": 501
  },
  {
    "word": "buscando",
    "rank": 444,
    "frequency": 83655,
    "originalRank": 502
  },
  {
    "word": "tuve",
    "rank": 445,
    "frequency": 83608,
    "originalRank": 503
  },
  {
    "word": "tampoco",
    "rank": 446,
    "frequency": 83595,
    "originalRank": 504
  },
  {
    "word": "amo",
    "rank": 447,
    "frequency": 83156,
    "originalRank": 505
  },
  {
    "word": "joven",
    "rank": 448,
    "frequency": 82919,
    "originalRank": 506
  },
  {
    "word": "podrías",
    "rank": 449,
    "frequency": 82328,
    "originalRank": 507
  },
  {
    "word": "sola",
    "rank": 450,
    "frequency": 82229,
    "originalRank": 508
  },
  {
    "word": "par",
    "rank": 451,
    "frequency": 81901,
    "originalRank": 509
  },
  {
    "word": "única",
    "rank": 452,
    "frequency": 81808,
    "originalRank": 510
  },
  {
    "word": "hacen",
    "rank": 453,
    "frequency": 81807,
    "originalRank": 511
  },
  {
    "word": "seguir",
    "rank": 454,
    "frequency": 81723,
    "originalRank": 512
  },
  {
    "word": "simplemente",
    "rank": 455,
    "frequency": 80350,
    "originalRank": 514
  },
  {
    "word": "dicen",
    "rank": 456,
    "frequency": 80310,
    "originalRank": 515
  },
  {
    "word": "medio",
    "rank": 457,
    "frequency": 80278,
    "originalRank": 516
  },
  {
    "word": "puta",
    "rank": 458,
    "frequency": 80176,
    "originalRank": 517
  },
  {
    "word": "saben",
    "rank": 459,
    "frequency": 79988,
    "originalRank": 518
  },
  {
    "word": "sentido",
    "rank": 460,
    "frequency": 79686,
    "originalRank": 519
  },
  {
    "word": "hagas",
    "rank": 461,
    "frequency": 79398,
    "originalRank": 520
  },
  {
    "word": "segura",
    "rank": 462,
    "frequency": 79393,
    "originalRank": 521
  },
  {
    "word": "esperar",
    "rank": 463,
    "frequency": 79115,
    "originalRank": 522
  },
  {
    "word": "lejos",
    "rank": 464,
    "frequency": 79091,
    "originalRank": 523
  },
  {
    "word": "arma",
    "rank": 465,
    "frequency": 78974,
    "originalRank": 524
  },
  {
    "word": "alto",
    "rank": 466,
    "frequency": 78496,
    "originalRank": 525
  },
  {
    "word": "pequeña",
    "rank": 467,
    "frequency": 78191,
    "originalRank": 526
  },
  {
    "word": "dólares",
    "rank": 468,
    "frequency": 77319,
    "originalRank": 527
  },
  {
    "word": "seis",
    "rank": 469,
    "frequency": 77064,
    "originalRank": 528
  },
  {
    "word": "estaban",
    "rank": 470,
    "frequency": 76916,
    "originalRank": 529
  },
  {
    "word": "seguridad",
    "rank": 471,
    "frequency": 76807,
    "originalRank": 530
  },
  {
    "word": "maldita",
    "rank": 472,
    "frequency": 76765,
    "originalRank": 531
  },
  {
    "word": "estuvo",
    "rank": 473,
    "frequency": 76639,
    "originalRank": 532
  },
  {
    "word": "preocupes",
    "rank": 474,
    "frequency": 76606,
    "originalRank": 533
  },
  {
    "word": "palabra",
    "rank": 475,
    "frequency": 76589,
    "originalRank": 534
  },
  {
    "word": "esperando",
    "rank": 476,
    "frequency": 76353,
    "originalRank": 535
  },
  {
    "word": "queda",
    "rank": 477,
    "frequency": 76150,
    "originalRank": 536
  },
  {
    "word": "oficina",
    "rank": 478,
    "frequency": 75697,
    "originalRank": 537
  },
  {
    "word": "matar",
    "rank": 479,
    "frequency": 75652,
    "originalRank": 538
  },
  {
    "word": "iré",
    "rank": 480,
    "frequency": 75521,
    "originalRank": 539
  },
  {
    "word": "cama",
    "rank": 481,
    "frequency": 75441,
    "originalRank": 540
  },
  {
    "word": "además",
    "rank": 482,
    "frequency": 75259,
    "originalRank": 541
  },
  {
    "word": "último",
    "rank": 483,
    "frequency": 75205,
    "originalRank": 542
  },
  {
    "word": "oído",
    "rank": 484,
    "frequency": 75123,
    "originalRank": 543
  },
  {
    "word": "habría",
    "rank": 485,
    "frequency": 74848,
    "originalRank": 544
  },
  {
    "word": "estará",
    "rank": 486,
    "frequency": 74836,
    "originalRank": 545
  },
  {
    "word": "dio",
    "rank": 487,
    "frequency": 74745,
    "originalRank": 546
  },
  {
    "word": "recuerdo",
    "rank": 488,
    "frequency": 74344,
    "originalRank": 547
  },
  {
    "word": "siendo",
    "rank": 489,
    "frequency": 74265,
    "originalRank": 548
  },
  {
    "word": "acerca",
    "rank": 490,
    "frequency": 74051,
    "originalRank": 549
  },
  {
    "word": "tenga",
    "rank": 491,
    "frequency": 73994,
    "originalRank": 550
  },
  {
    "word": "luz",
    "rank": 492,
    "frequency": 73886,
    "originalRank": 551
  },
  {
    "word": "correcto",
    "rank": 493,
    "frequency": 73881,
    "originalRank": 552
  },
  {
    "word": "demonios",
    "rank": 494,
    "frequency": 73485,
    "originalRank": 554
  },
  {
    "word": "nuestras",
    "rank": 495,
    "frequency": 73354,
    "originalRank": 555
  },
  {
    "word": "verte",
    "rank": 496,
    "frequency": 73227,
    "originalRank": 556
  },
  {
    "word": "dormir",
    "rank": 497,
    "frequency": 73064,
    "originalRank": 557
  },
  {
    "word": "sitio",
    "rank": 498,
    "frequency": 73036,
    "originalRank": 558
  },
  {
    "word": "ayudar",
    "rank": 499,
    "frequency": 72837,
    "originalRank": 559
  },
  {
    "word": "conseguir",
    "rank": 500,
    "frequency": 72697,
    "originalRank": 560
  },
  {
    "word": "marido",
    "rank": 501,
    "frequency": 72210,
    "originalRank": 562
  },
  {
    "word": "paz",
    "rank": 502,
    "frequency": 72000,
    "originalRank": 563
  },
  {
    "word": "idiota",
    "rank": 503,
    "frequency": 71856,
    "originalRank": 564
  },
  {
    "word": "plan",
    "rank": 504,
    "frequency": 71640,
    "originalRank": 565
  },
  {
    "word": "dado",
    "rank": 505,
    "frequency": 71249,
    "originalRank": 566
  },
  {
    "word": "cuanto",
    "rank": 506,
    "frequency": 71197,
    "originalRank": 567
  },
  {
    "word": "peor",
    "rank": 507,
    "frequency": 70692,
    "originalRank": 568
  },
  {
    "word": "murió",
    "rank": 508,
    "frequency": 70466,
    "originalRank": 569
  },
  {
    "word": "pueblo",
    "rank": 509,
    "frequency": 70465,
    "originalRank": 570
  },
  {
    "word": "vivo",
    "rank": 510,
    "frequency": 70329,
    "originalRank": 571
  },
  {
    "word": "venido",
    "rank": 511,
    "frequency": 70151,
    "originalRank": 572
  },
  {
    "word": "john",
    "rank": 512,
    "frequency": 69978,
    "originalRank": 573
  },
  {
    "word": "basta",
    "rank": 513,
    "frequency": 69973,
    "originalRank": 574
  },
  {
    "word": "paso",
    "rank": 514,
    "frequency": 69865,
    "originalRank": 575
  },
  {
    "word": "deberíamos",
    "rank": 515,
    "frequency": 69574,
    "originalRank": 576
  },
  {
    "word": "música",
    "rank": 516,
    "frequency": 69241,
    "originalRank": 577
  },
  {
    "word": "diga",
    "rank": 517,
    "frequency": 68941,
    "originalRank": 578
  },
  {
    "word": "minuto",
    "rank": 518,
    "frequency": 68878,
    "originalRank": 579
  },
  {
    "word": "anoche",
    "rank": 519,
    "frequency": 68870,
    "originalRank": 580
  },
  {
    "word": "llamar",
    "rank": 520,
    "frequency": 68861,
    "originalRank": 581
  },
  {
    "word": "piensa",
    "rank": 521,
    "frequency": 68552,
    "originalRank": 582
  },
  {
    "word": "país",
    "rank": 522,
    "frequency": 68539,
    "originalRank": 583
  },
  {
    "word": "digas",
    "rank": 523,
    "frequency": 68227,
    "originalRank": 584
  },
  {
    "word": "rey",
    "rank": 524,
    "frequency": 67803,
    "originalRank": 585
  },
  {
    "word": "perdón",
    "rank": 525,
    "frequency": 67516,
    "originalRank": 586
  },
  {
    "word": "mucha",
    "rank": 526,
    "frequency": 67426,
    "originalRank": 587
  },
  {
    "word": "falta",
    "rank": 527,
    "frequency": 67152,
    "originalRank": 588
  },
  {
    "word": "pienso",
    "rank": 528,
    "frequency": 67140,
    "originalRank": 589
  },
  {
    "word": "diablos",
    "rank": 529,
    "frequency": 67119,
    "originalRank": 590
  },
  {
    "word": "perdido",
    "rank": 530,
    "frequency": 66882,
    "originalRank": 591
  },
  {
    "word": "niña",
    "rank": 531,
    "frequency": 66672,
    "originalRank": 592
  },
  {
    "word": "señorita",
    "rank": 532,
    "frequency": 66491,
    "originalRank": 593
  },
  {
    "word": "diez",
    "rank": 533,
    "frequency": 66429,
    "originalRank": 594
  },
  {
    "word": "lleva",
    "rank": 534,
    "frequency": 66407,
    "originalRank": 595
  },
  {
    "word": "hospital",
    "rank": 535,
    "frequency": 66316,
    "originalRank": 596
  },
  {
    "word": "grandes",
    "rank": 536,
    "frequency": 66186,
    "originalRank": 597
  },
  {
    "word": "maldito",
    "rank": 537,
    "frequency": 66025,
    "originalRank": 598
  },
  {
    "word": "otras",
    "rank": 538,
    "frequency": 65924,
    "originalRank": 599
  },
  {
    "word": "llamado",
    "rank": 539,
    "frequency": 65650,
    "originalRank": 600
  },
  {
    "word": "hacemos",
    "rank": 540,
    "frequency": 65535,
    "originalRank": 601
  },
  {
    "word": "llevar",
    "rank": 541,
    "frequency": 65446,
    "originalRank": 602
  },
  {
    "word": "fuego",
    "rank": 542,
    "frequency": 65442,
    "originalRank": 603
  },
  {
    "word": "aqui",
    "rank": 543,
    "frequency": 65202,
    "originalRank": 604
  },
  {
    "word": "tuvo",
    "rank": 544,
    "frequency": 65130,
    "originalRank": 605
  },
  {
    "word": "poner",
    "rank": 545,
    "frequency": 64740,
    "originalRank": 606
  },
  {
    "word": "calle",
    "rank": 546,
    "frequency": 64675,
    "originalRank": 607
  },
  {
    "word": "acaba",
    "rank": 547,
    "frequency": 64600,
    "originalRank": 608
  },
  {
    "word": "prueba",
    "rank": 548,
    "frequency": 64593,
    "originalRank": 609
  },
  {
    "word": "increíble",
    "rank": 549,
    "frequency": 64527,
    "originalRank": 610
  },
  {
    "word": "real",
    "rank": 550,
    "frequency": 64511,
    "originalRank": 611
  },
  {
    "word": "libro",
    "rank": 551,
    "frequency": 64445,
    "originalRank": 612
  },
  {
    "word": "orden",
    "rank": 552,
    "frequency": 64437,
    "originalRank": 613
  },
  {
    "word": "semanas",
    "rank": 553,
    "frequency": 64300,
    "originalRank": 614
  },
  {
    "word": "especial",
    "rank": 554,
    "frequency": 64240,
    "originalRank": 615
  },
  {
    "word": "mía",
    "rank": 555,
    "frequency": 64132,
    "originalRank": 616
  },
  {
    "word": "café",
    "rank": 556,
    "frequency": 63914,
    "originalRank": 617
  },
  {
    "word": "duro",
    "rank": 557,
    "frequency": 63800,
    "originalRank": 618
  },
  {
    "word": "empezar",
    "rank": 558,
    "frequency": 63463,
    "originalRank": 619
  },
  {
    "word": "afuera",
    "rank": 559,
    "frequency": 63387,
    "originalRank": 620
  },
  {
    "word": "queremos",
    "rank": 560,
    "frequency": 63319,
    "originalRank": 621
  },
  {
    "word": "perro",
    "rank": 561,
    "frequency": 63070,
    "originalRank": 622
  },
  {
    "word": "cielo",
    "rank": 562,
    "frequency": 62981,
    "originalRank": 623
  },
  {
    "word": "jack",
    "rank": 563,
    "frequency": 62965,
    "originalRank": 624
  },
  {
    "word": "puesto",
    "rank": 564,
    "frequency": 62949,
    "originalRank": 625
  },
  {
    "word": "viaje",
    "rank": 565,
    "frequency": 62667,
    "originalRank": 626
  },
  {
    "word": "detrás",
    "rank": 566,
    "frequency": 62621,
    "originalRank": 627
  },
  {
    "word": "cuarto",
    "rank": 567,
    "frequency": 62590,
    "originalRank": 628
  },
  {
    "word": "querida",
    "rank": 568,
    "frequency": 62549,
    "originalRank": 629
  },
  {
    "word": "haría",
    "rank": 569,
    "frequency": 62547,
    "originalRank": 630
  },
  {
    "word": "preguntas",
    "rank": 570,
    "frequency": 62505,
    "originalRank": 631
  },
  {
    "word": "piensas",
    "rank": 571,
    "frequency": 62433,
    "originalRank": 632
  },
  {
    "word": "querido",
    "rank": 572,
    "frequency": 62425,
    "originalRank": 633
  },
  {
    "word": "libre",
    "rank": 573,
    "frequency": 62421,
    "originalRank": 634
  },
  {
    "word": "buscar",
    "rank": 574,
    "frequency": 62319,
    "originalRank": 635
  },
  {
    "word": "cual",
    "rank": 575,
    "frequency": 62288,
    "originalRank": 636
  },
  {
    "word": "diré",
    "rank": 576,
    "frequency": 62193,
    "originalRank": 637
  },
  {
    "word": "suena",
    "rank": 577,
    "frequency": 62170,
    "originalRank": 638
  },
  {
    "word": "jugar",
    "rank": 578,
    "frequency": 62132,
    "originalRank": 639
  },
  {
    "word": "cambio",
    "rank": 579,
    "frequency": 62106,
    "originalRank": 640
  },
  {
    "word": "película",
    "rank": 580,
    "frequency": 61985,
    "originalRank": 641
  },
  {
    "word": "millones",
    "rank": 581,
    "frequency": 61876,
    "originalRank": 642
  },
  {
    "word": "habrá",
    "rank": 582,
    "frequency": 61821,
    "originalRank": 643
  },
  {
    "word": "llamada",
    "rank": 583,
    "frequency": 61791,
    "originalRank": 644
  },
  {
    "word": "resto",
    "rank": 584,
    "frequency": 61752,
    "originalRank": 645
  },
  {
    "word": "vemos",
    "rank": 585,
    "frequency": 61545,
    "originalRank": 646
  },
  {
    "word": "extraño",
    "rank": 586,
    "frequency": 61249,
    "originalRank": 647
  },
  {
    "word": "mala",
    "rank": 587,
    "frequency": 61177,
    "originalRank": 648
  },
  {
    "word": "presidente",
    "rank": 588,
    "frequency": 61090,
    "originalRank": 649
  },
  {
    "word": "irme",
    "rank": 589,
    "frequency": 60622,
    "originalRank": 651
  },
  {
    "word": "ropa",
    "rank": 590,
    "frequency": 60542,
    "originalRank": 652
  },
  {
    "word": "perder",
    "rank": 591,
    "frequency": 60378,
    "originalRank": 653
  },
  {
    "word": "vuelve",
    "rank": 592,
    "frequency": 60172,
    "originalRank": 654
  },
  {
    "word": "agente",
    "rank": 593,
    "frequency": 60171,
    "originalRank": 655
  },
  {
    "word": "palabras",
    "rank": 594,
    "frequency": 60090,
    "originalRank": 656
  },
  {
    "word": "información",
    "rank": 595,
    "frequency": 60090,
    "originalRank": 657
  },
  {
    "word": "raro",
    "rank": 596,
    "frequency": 60086,
    "originalRank": 658
  },
  {
    "word": "hará",
    "rank": 597,
    "frequency": 59965,
    "originalRank": 659
  },
  {
    "word": "entiendes",
    "rank": 598,
    "frequency": 59914,
    "originalRank": 660
  },
  {
    "word": "éste",
    "rank": 599,
    "frequency": 59792,
    "originalRank": 661
  },
  {
    "word": "trabajando",
    "rank": 600,
    "frequency": 59674,
    "originalRank": 662
  },
  {
    "word": "tratando",
    "rank": 601,
    "frequency": 59643,
    "originalRank": 663
  },
  {
    "word": "general",
    "rank": 602,
    "frequency": 59593,
    "originalRank": 664
  },
  {
    "word": "trato",
    "rank": 603,
    "frequency": 59469,
    "originalRank": 665
  },
  {
    "word": "usar",
    "rank": 604,
    "frequency": 59267,
    "originalRank": 666
  },
  {
    "word": "perfecto",
    "rank": 605,
    "frequency": 59208,
    "originalRank": 667
  },
  {
    "word": "derecho",
    "rank": 606,
    "frequency": 59164,
    "originalRank": 668
  },
  {
    "word": "modo",
    "rank": 607,
    "frequency": 59041,
    "originalRank": 669
  },
  {
    "word": "ayer",
    "rank": 608,
    "frequency": 59013,
    "originalRank": 670
  },
  {
    "word": "conoces",
    "rank": 609,
    "frequency": 58941,
    "originalRank": 671
  },
  {
    "word": "demás",
    "rank": 610,
    "frequency": 58811,
    "originalRank": 672
  },
  {
    "word": "quieras",
    "rank": 611,
    "frequency": 58704,
    "originalRank": 673
  },
  {
    "word": "podríamos",
    "rank": 612,
    "frequency": 58548,
    "originalRank": 674
  },
  {
    "word": "noticias",
    "rank": 613,
    "frequency": 58530,
    "originalRank": 675
  },
  {
    "word": "asesino",
    "rank": 614,
    "frequency": 58507,
    "originalRank": 676
  },
  {
    "word": "encontrado",
    "rank": 615,
    "frequency": 57581,
    "originalRank": 677
  },
  {
    "word": "control",
    "rank": 616,
    "frequency": 57479,
    "originalRank": 678
  },
  {
    "word": "odio",
    "rank": 617,
    "frequency": 57427,
    "originalRank": 679
  },
  {
    "word": "frente",
    "rank": 618,
    "frequency": 57371,
    "originalRank": 680
  },
  {
    "word": "sexo",
    "rank": 619,
    "frequency": 57281,
    "originalRank": 681
  },
  {
    "word": "decirle",
    "rank": 620,
    "frequency": 57135,
    "originalRank": 682
  },
  {
    "word": "estaré",
    "rank": 621,
    "frequency": 57085,
    "originalRank": 683
  },
  {
    "word": "divertido",
    "rank": 622,
    "frequency": 56908,
    "originalRank": 684
  },
  {
    "word": "armas",
    "rank": 623,
    "frequency": 56785,
    "originalRank": 685
  },
  {
    "word": "recuerdas",
    "rank": 624,
    "frequency": 56669,
    "originalRank": 686
  },
  {
    "word": "amiga",
    "rank": 625,
    "frequency": 56665,
    "originalRank": 687
  },
  {
    "word": "grupo",
    "rank": 626,
    "frequency": 56638,
    "originalRank": 688
  },
  {
    "word": "asunto",
    "rank": 627,
    "frequency": 56622,
    "originalRank": 689
  },
  {
    "word": "acabo",
    "rank": 628,
    "frequency": 56586,
    "originalRank": 690
  },
  {
    "word": "mensaje",
    "rank": 629,
    "frequency": 56126,
    "originalRank": 691
  },
  {
    "word": "encima",
    "rank": 630,
    "frequency": 56110,
    "originalRank": 692
  },
  {
    "word": "atención",
    "rank": 631,
    "frequency": 56092,
    "originalRank": 693
  },
  {
    "word": "diferente",
    "rank": 632,
    "frequency": 56028,
    "originalRank": 694
  },
  {
    "word": "cállate",
    "rank": 633,
    "frequency": 55856,
    "originalRank": 696
  },
  {
    "word": "daño",
    "rank": 634,
    "frequency": 55599,
    "originalRank": 697
  },
  {
    "word": "sucede",
    "rank": 635,
    "frequency": 55572,
    "originalRank": 698
  },
  {
    "word": "cambiar",
    "rank": 636,
    "frequency": 55360,
    "originalRank": 699
  },
  {
    "word": "siguiente",
    "rank": 637,
    "frequency": 55300,
    "originalRank": 700
  },
  {
    "word": "sino",
    "rank": 638,
    "frequency": 55136,
    "originalRank": 701
  },
  {
    "word": "the",
    "rank": 639,
    "frequency": 54966,
    "originalRank": 702
  },
  {
    "word": "seas",
    "rank": 640,
    "frequency": 54799,
    "originalRank": 703
  },
  {
    "word": "médico",
    "rank": 641,
    "frequency": 54547,
    "originalRank": 704
  },
  {
    "word": "boca",
    "rank": 642,
    "frequency": 54512,
    "originalRank": 705
  },
  {
    "word": "dejó",
    "rank": 643,
    "frequency": 54435,
    "originalRank": 706
  },
  {
    "word": "error",
    "rank": 644,
    "frequency": 54414,
    "originalRank": 707
  },
  {
    "word": "jamás",
    "rank": 645,
    "frequency": 54158,
    "originalRank": 708
  },
  {
    "word": "largo",
    "rank": 646,
    "frequency": 53833,
    "originalRank": 709
  },
  {
    "word": "pena",
    "rank": 647,
    "frequency": 53618,
    "originalRank": 710
  },
  {
    "word": "voz",
    "rank": 648,
    "frequency": 53574,
    "originalRank": 711
  },
  {
    "word": "futuro",
    "rank": 649,
    "frequency": 53557,
    "originalRank": 712
  },
  {
    "word": "siente",
    "rank": 650,
    "frequency": 53518,
    "originalRank": 713
  },
  {
    "word": "secreto",
    "rank": 651,
    "frequency": 53504,
    "originalRank": 714
  },
  {
    "word": "baño",
    "rank": 652,
    "frequency": 53455,
    "originalRank": 715
  },
  {
    "word": "mil",
    "rank": 653,
    "frequency": 53364,
    "originalRank": 716
  },
  {
    "word": "decirte",
    "rank": 654,
    "frequency": 53207,
    "originalRank": 717
  },
  {
    "word": "sam",
    "rank": 655,
    "frequency": 53082,
    "originalRank": 718
  },
  {
    "word": "pensaba",
    "rank": 656,
    "frequency": 53018,
    "originalRank": 719
  },
  {
    "word": "novia",
    "rank": 657,
    "frequency": 52984,
    "originalRank": 720
  },
  {
    "word": "propia",
    "rank": 658,
    "frequency": 52973,
    "originalRank": 721
  },
  {
    "word": "sueño",
    "rank": 659,
    "frequency": 52956,
    "originalRank": 722
  },
  {
    "word": "haz",
    "rank": 660,
    "frequency": 52344,
    "originalRank": 723
  },
  {
    "word": "fuerza",
    "rank": 661,
    "frequency": 52316,
    "originalRank": 724
  },
  {
    "word": "deben",
    "rank": 662,
    "frequency": 52297,
    "originalRank": 725
  },
  {
    "word": "supone",
    "rank": 663,
    "frequency": 52250,
    "originalRank": 726
  },
  {
    "word": "estábamos",
    "rank": 664,
    "frequency": 52003,
    "originalRank": 727
  },
  {
    "word": "ambos",
    "rank": 665,
    "frequency": 51916,
    "originalRank": 728
  },
  {
    "word": "estuve",
    "rank": 666,
    "frequency": 51592,
    "originalRank": 730
  },
  {
    "word": "encontré",
    "rank": 667,
    "frequency": 51507,
    "originalRank": 731
  },
  {
    "word": "vuelto",
    "rank": 668,
    "frequency": 51505,
    "originalRank": 732
  },
  {
    "word": "dolor",
    "rank": 669,
    "frequency": 51283,
    "originalRank": 733
  },
  {
    "word": "dile",
    "rank": 670,
    "frequency": 51271,
    "originalRank": 734
  },
  {
    "word": "encanta",
    "rank": 671,
    "frequency": 51240,
    "originalRank": 735
  },
  {
    "word": "edad",
    "rank": 672,
    "frequency": 51163,
    "originalRank": 736
  },
  {
    "word": "darle",
    "rank": 673,
    "frequency": 51120,
    "originalRank": 737
  },
  {
    "word": "pie",
    "rank": 674,
    "frequency": 51066,
    "originalRank": 738
  },
  {
    "word": "negro",
    "rank": 675,
    "frequency": 50987,
    "originalRank": 739
  },
  {
    "word": "ganar",
    "rank": 676,
    "frequency": 50970,
    "originalRank": 740
  },
  {
    "word": "york",
    "rank": 677,
    "frequency": 50964,
    "originalRank": 741
  },
  {
    "word": "aire",
    "rank": 678,
    "frequency": 50788,
    "originalRank": 742
  },
  {
    "word": "lamento",
    "rank": 679,
    "frequency": 50766,
    "originalRank": 743
  },
  {
    "word": "verlo",
    "rank": 680,
    "frequency": 50765,
    "originalRank": 744
  },
  {
    "word": "asesinato",
    "rank": 681,
    "frequency": 50759,
    "originalRank": 745
  },
  {
    "word": "vio",
    "rank": 682,
    "frequency": 50756,
    "originalRank": 746
  },
  {
    "word": "adónde",
    "rank": 683,
    "frequency": 50674,
    "originalRank": 747
  },
  {
    "word": "llegado",
    "rank": 684,
    "frequency": 50534,
    "originalRank": 748
  },
  {
    "word": "disculpe",
    "rank": 685,
    "frequency": 50520,
    "originalRank": 749
  },
  {
    "word": "cita",
    "rank": 686,
    "frequency": 50399,
    "originalRank": 751
  },
  {
    "word": "estaría",
    "rank": 687,
    "frequency": 50270,
    "originalRank": 752
  },
  {
    "word": "fuiste",
    "rank": 688,
    "frequency": 50201,
    "originalRank": 753
  },
  {
    "word": "sistema",
    "rank": 689,
    "frequency": 50050,
    "originalRank": 754
  },
  {
    "word": "gusto",
    "rank": 690,
    "frequency": 50039,
    "originalRank": 755
  },
  {
    "word": "pobre",
    "rank": 691,
    "frequency": 50019,
    "originalRank": 756
  },
  {
    "word": "negocio",
    "rank": 692,
    "frequency": 49896,
    "originalRank": 757
  },
  {
    "word": "mente",
    "rank": 693,
    "frequency": 49842,
    "originalRank": 758
  },
  {
    "word": "tuyo",
    "rank": 694,
    "frequency": 49799,
    "originalRank": 759
  },
  {
    "word": "campo",
    "rank": 695,
    "frequency": 49614,
    "originalRank": 760
  },
  {
    "word": "mire",
    "rank": 696,
    "frequency": 49575,
    "originalRank": 761
  },
  {
    "word": "situación",
    "rank": 697,
    "frequency": 49426,
    "originalRank": 762
  },
  {
    "word": "tras",
    "rank": 698,
    "frequency": 49345,
    "originalRank": 763
  },
  {
    "word": "hotel",
    "rank": 699,
    "frequency": 49177,
    "originalRank": 764
  },
  {
    "word": "funciona",
    "rank": 700,
    "frequency": 48956,
    "originalRank": 766
  },
  {
    "word": "foto",
    "rank": 701,
    "frequency": 48915,
    "originalRank": 767
  },
  {
    "word": "abogado",
    "rank": 702,
    "frequency": 48914,
    "originalRank": 768
  },
  {
    "word": "loca",
    "rank": 703,
    "frequency": 48859,
    "originalRank": 769
  },
  {
    "word": "propio",
    "rank": 704,
    "frequency": 48844,
    "originalRank": 770
  },
  {
    "word": "alrededor",
    "rank": 705,
    "frequency": 48767,
    "originalRank": 771
  },
  {
    "word": "próxima",
    "rank": 706,
    "frequency": 48701,
    "originalRank": 772
  },
  {
    "word": "terminado",
    "rank": 707,
    "frequency": 48673,
    "originalRank": 773
  },
  {
    "word": "hablas",
    "rank": 708,
    "frequency": 48652,
    "originalRank": 774
  },
  {
    "word": "pagar",
    "rank": 709,
    "frequency": 48636,
    "originalRank": 775
  },
  {
    "word": "mató",
    "rank": 710,
    "frequency": 48583,
    "originalRank": 776
  },
  {
    "word": "llamo",
    "rank": 711,
    "frequency": 48473,
    "originalRank": 777
  },
  {
    "word": "personal",
    "rank": 712,
    "frequency": 48419,
    "originalRank": 778
  },
  {
    "word": "sientes",
    "rank": 713,
    "frequency": 48410,
    "originalRank": 779
  },
  {
    "word": "ocurre",
    "rank": 714,
    "frequency": 48364,
    "originalRank": 780
  },
  {
    "word": "ésta",
    "rank": 715,
    "frequency": 48338,
    "originalRank": 781
  },
  {
    "word": "recuerda",
    "rank": 716,
    "frequency": 48335,
    "originalRank": 782
  },
  {
    "word": "mitad",
    "rank": 717,
    "frequency": 48317,
    "originalRank": 783
  },
  {
    "word": "quiera",
    "rank": 718,
    "frequency": 48299,
    "originalRank": 784
  },
  {
    "word": "pelo",
    "rank": 719,
    "frequency": 48293,
    "originalRank": 785
  },
  {
    "word": "tenías",
    "rank": 720,
    "frequency": 48183,
    "originalRank": 786
  },
  {
    "word": "viste",
    "rank": 721,
    "frequency": 47962,
    "originalRank": 787
  },
  {
    "word": "oficial",
    "rank": 722,
    "frequency": 47960,
    "originalRank": 788
  },
  {
    "word": "llegó",
    "rank": 723,
    "frequency": 47852,
    "originalRank": 789
  },
  {
    "word": "compañía",
    "rank": 724,
    "frequency": 47842,
    "originalRank": 790
  },
  {
    "word": "relación",
    "rank": 725,
    "frequency": 47824,
    "originalRank": 791
  },
  {
    "word": "conoce",
    "rank": 726,
    "frequency": 47688,
    "originalRank": 792
  },
  {
    "word": "pase",
    "rank": 727,
    "frequency": 47622,
    "originalRank": 793
  },
  {
    "word": "montón",
    "rank": 728,
    "frequency": 47610,
    "originalRank": 794
  },
  {
    "word": "mejores",
    "rank": 729,
    "frequency": 47509,
    "originalRank": 795
  },
  {
    "word": "creí",
    "rank": 730,
    "frequency": 47494,
    "originalRank": 796
  },
  {
    "word": "cena",
    "rank": 731,
    "frequency": 47357,
    "originalRank": 797
  },
  {
    "word": "sentir",
    "rank": 732,
    "frequency": 47337,
    "originalRank": 798
  },
  {
    "word": "través",
    "rank": 733,
    "frequency": 47295,
    "originalRank": 799
  },
  {
    "word": "accidente",
    "rank": 734,
    "frequency": 47117,
    "originalRank": 800
  },
  {
    "word": "caja",
    "rank": 735,
    "frequency": 46635,
    "originalRank": 803
  },
  {
    "word": "tranquilo",
    "rank": 736,
    "frequency": 46587,
    "originalRank": 804
  },
  {
    "word": "bonito",
    "rank": 737,
    "frequency": 46554,
    "originalRank": 805
  },
  {
    "word": "eras",
    "rank": 738,
    "frequency": 46544,
    "originalRank": 806
  },
  {
    "word": "asi",
    "rank": 739,
    "frequency": 46535,
    "originalRank": 807
  },
  {
    "word": "pudo",
    "rank": 740,
    "frequency": 46533,
    "originalRank": 808
  },
  {
    "word": "vive",
    "rank": 741,
    "frequency": 46462,
    "originalRank": 809
  },
  {
    "word": "vista",
    "rank": 742,
    "frequency": 46461,
    "originalRank": 810
  },
  {
    "word": "estúpido",
    "rank": 743,
    "frequency": 46441,
    "originalRank": 811
  },
  {
    "word": "línea",
    "rank": 744,
    "frequency": 46341,
    "originalRank": 812
  },
  {
    "word": "caballeros",
    "rank": 745,
    "frequency": 46158,
    "originalRank": 813
  },
  {
    "word": "haremos",
    "rank": 746,
    "frequency": 46119,
    "originalRank": 814
  },
  {
    "word": "dan",
    "rank": 747,
    "frequency": 46063,
    "originalRank": 815
  },
  {
    "word": "quédate",
    "rank": 748,
    "frequency": 46054,
    "originalRank": 816
  },
  {
    "word": "tienda",
    "rank": 749,
    "frequency": 45913,
    "originalRank": 817
  },
  {
    "word": "comprar",
    "rank": 750,
    "frequency": 45899,
    "originalRank": 818
  },
  {
    "word": "entendido",
    "rank": 751,
    "frequency": 45877,
    "originalRank": 819
  },
  {
    "word": "centro",
    "rank": 752,
    "frequency": 45864,
    "originalRank": 820
  },
  {
    "word": "salvo",
    "rank": 753,
    "frequency": 45755,
    "originalRank": 821
  },
  {
    "word": "mes",
    "rank": 754,
    "frequency": 45648,
    "originalRank": 822
  },
  {
    "word": "joe",
    "rank": 755,
    "frequency": 45615,
    "originalRank": 823
  },
  {
    "word": "sol",
    "rank": 756,
    "frequency": 45567,
    "originalRank": 824
  },
  {
    "word": "tonto",
    "rank": 757,
    "frequency": 45479,
    "originalRank": 825
  },
  {
    "word": "hambre",
    "rank": 758,
    "frequency": 45455,
    "originalRank": 826
  },
  {
    "word": "michael",
    "rank": 759,
    "frequency": 45411,
    "originalRank": 827
  },
  {
    "word": "mesa",
    "rank": 760,
    "frequency": 45409,
    "originalRank": 828
  },
  {
    "word": "respuesta",
    "rank": 761,
    "frequency": 45345,
    "originalRank": 829
  },
  {
    "word": "completamente",
    "rank": 762,
    "frequency": 45342,
    "originalRank": 830
  },
  {
    "word": "david",
    "rank": 763,
    "frequency": 45220,
    "originalRank": 831
  },
  {
    "word": "carta",
    "rank": 764,
    "frequency": 45152,
    "originalRank": 832
  },
  {
    "word": "totalmente",
    "rank": 765,
    "frequency": 45016,
    "originalRank": 833
  },
  {
    "word": "imposible",
    "rank": 766,
    "frequency": 44898,
    "originalRank": 834
  },
  {
    "word": "pruebas",
    "rank": 767,
    "frequency": 44861,
    "originalRank": 835
  },
  {
    "word": "novio",
    "rank": 768,
    "frequency": 44832,
    "originalRank": 836
  },
  {
    "word": "normal",
    "rank": 769,
    "frequency": 44793,
    "originalRank": 837
  },
  {
    "word": "gustan",
    "rank": 770,
    "frequency": 44761,
    "originalRank": 838
  },
  {
    "word": "frank",
    "rank": 771,
    "frequency": 44615,
    "originalRank": 839
  },
  {
    "word": "pude",
    "rank": 772,
    "frequency": 44614,
    "originalRank": 840
  },
  {
    "word": "charlie",
    "rank": 773,
    "frequency": 44589,
    "originalRank": 841
  },
  {
    "word": "traje",
    "rank": 774,
    "frequency": 44234,
    "originalRank": 842
  },
  {
    "word": "dirección",
    "rank": 775,
    "frequency": 44229,
    "originalRank": 843
  },
  {
    "word": "siete",
    "rank": 776,
    "frequency": 44169,
    "originalRank": 844
  },
  {
    "word": "dijeron",
    "rank": 777,
    "frequency": 44151,
    "originalRank": 845
  },
  {
    "word": "placer",
    "rank": 778,
    "frequency": 44038,
    "originalRank": 846
  },
  {
    "word": "sean",
    "rank": 779,
    "frequency": 43979,
    "originalRank": 847
  },
  {
    "word": "tendrá",
    "rank": 780,
    "frequency": 43656,
    "originalRank": 848
  },
  {
    "word": "barco",
    "rank": 781,
    "frequency": 43597,
    "originalRank": 849
  },
  {
    "word": "blanco",
    "rank": 782,
    "frequency": 43530,
    "originalRank": 850
  },
  {
    "word": "tom",
    "rank": 783,
    "frequency": 43467,
    "originalRank": 851
  },
  {
    "word": "profesor",
    "rank": 784,
    "frequency": 43370,
    "originalRank": 852
  },
  {
    "word": "servicio",
    "rank": 785,
    "frequency": 43358,
    "originalRank": 853
  },
  {
    "word": "muchacho",
    "rank": 786,
    "frequency": 43295,
    "originalRank": 854
  },
  {
    "word": "reunión",
    "rank": 787,
    "frequency": 43217,
    "originalRank": 855
  },
  {
    "word": "dejado",
    "rank": 788,
    "frequency": 43162,
    "originalRank": 856
  },
  {
    "word": "ley",
    "rank": 789,
    "frequency": 43043,
    "originalRank": 857
  },
  {
    "word": "quisiera",
    "rank": 790,
    "frequency": 42974,
    "originalRank": 858
  },
  {
    "word": "hubo",
    "rank": 791,
    "frequency": 42830,
    "originalRank": 859
  },
  {
    "word": "george",
    "rank": 792,
    "frequency": 42765,
    "originalRank": 860
  },
  {
    "word": "programa",
    "rank": 793,
    "frequency": 42763,
    "originalRank": 861
  },
  {
    "word": "carrera",
    "rank": 794,
    "frequency": 42759,
    "originalRank": 862
  },
  {
    "word": "cumpleaños",
    "rank": 795,
    "frequency": 42596,
    "originalRank": 863
  },
  {
    "word": "muchachos",
    "rank": 796,
    "frequency": 42571,
    "originalRank": 864
  },
  {
    "word": "culo",
    "rank": 797,
    "frequency": 42470,
    "originalRank": 865
  },
  {
    "word": "canción",
    "rank": 798,
    "frequency": 42468,
    "originalRank": 866
  },
  {
    "word": "hermosa",
    "rank": 799,
    "frequency": 42438,
    "originalRank": 867
  },
  {
    "word": "universidad",
    "rank": 800,
    "frequency": 42412,
    "originalRank": 868
  },
  {
    "word": "boda",
    "rank": 801,
    "frequency": 42403,
    "originalRank": 869
  },
  {
    "word": "decirme",
    "rank": 802,
    "frequency": 42378,
    "originalRank": 870
  },
  {
    "word": "cualquiera",
    "rank": 803,
    "frequency": 42369,
    "originalRank": 871
  },
  {
    "word": "tengas",
    "rank": 804,
    "frequency": 42271,
    "originalRank": 872
  },
  {
    "word": "hacía",
    "rank": 805,
    "frequency": 42256,
    "originalRank": 873
  },
  {
    "word": "estés",
    "rank": 806,
    "frequency": 42240,
    "originalRank": 874
  },
  {
    "word": "sala",
    "rank": 807,
    "frequency": 42122,
    "originalRank": 875
  },
  {
    "word": "llevo",
    "rank": 808,
    "frequency": 42084,
    "originalRank": 876
  },
  {
    "word": "decisión",
    "rank": 809,
    "frequency": 42011,
    "originalRank": 877
  },
  {
    "word": "espere",
    "rank": 810,
    "frequency": 42008,
    "originalRank": 878
  },
  {
    "word": "don",
    "rank": 811,
    "frequency": 41978,
    "originalRank": 879
  },
  {
    "word": "necesario",
    "rank": 812,
    "frequency": 41752,
    "originalRank": 880
  },
  {
    "word": "sal",
    "rank": 813,
    "frequency": 41725,
    "originalRank": 881
  },
  {
    "word": "entra",
    "rank": 814,
    "frequency": 41706,
    "originalRank": 882
  },
  {
    "word": "prisa",
    "rank": 815,
    "frequency": 41706,
    "originalRank": 883
  },
  {
    "word": "carajo",
    "rank": 816,
    "frequency": 41656,
    "originalRank": 884
  },
  {
    "word": "embargo",
    "rank": 817,
    "frequency": 41642,
    "originalRank": 885
  },
  {
    "word": "interesante",
    "rank": 818,
    "frequency": 41640,
    "originalRank": 886
  },
  {
    "word": "tendrás",
    "rank": 819,
    "frequency": 41583,
    "originalRank": 887
  },
  {
    "word": "escuchar",
    "rank": 820,
    "frequency": 41472,
    "originalRank": 888
  },
  {
    "word": "abuela",
    "rank": 821,
    "frequency": 41377,
    "originalRank": 889
  },
  {
    "word": "hicieron",
    "rank": 822,
    "frequency": 41321,
    "originalRank": 890
  },
  {
    "word": "detective",
    "rank": 823,
    "frequency": 41299,
    "originalRank": 891
  },
  {
    "word": "horrible",
    "rank": 824,
    "frequency": 41259,
    "originalRank": 892
  },
  {
    "word": "suelo",
    "rank": 825,
    "frequency": 41247,
    "originalRank": 893
  },
  {
    "word": "fotos",
    "rank": 826,
    "frequency": 41245,
    "originalRank": 894
  },
  {
    "word": "cárcel",
    "rank": 827,
    "frequency": 41152,
    "originalRank": 895
  },
  {
    "word": "acá",
    "rank": 828,
    "frequency": 41151,
    "originalRank": 896
  },
  {
    "word": "mike",
    "rank": 829,
    "frequency": 41066,
    "originalRank": 898
  },
  {
    "word": "siéntate",
    "rank": 830,
    "frequency": 40993,
    "originalRank": 899
  },
  {
    "word": "decía",
    "rank": 831,
    "frequency": 40982,
    "originalRank": 900
  },
  {
    "word": "intentando",
    "rank": 832,
    "frequency": 40706,
    "originalRank": 901
  },
  {
    "word": "vámonos",
    "rank": 833,
    "frequency": 40700,
    "originalRank": 902
  },
  {
    "word": "maldición",
    "rank": 834,
    "frequency": 40681,
    "originalRank": 903
  },
  {
    "word": "silencio",
    "rank": 835,
    "frequency": 40675,
    "originalRank": 904
  },
  {
    "word": "muerta",
    "rank": 836,
    "frequency": 40660,
    "originalRank": 905
  },
  {
    "word": "capaz",
    "rank": 837,
    "frequency": 40541,
    "originalRank": 906
  },
  {
    "word": "salió",
    "rank": 838,
    "frequency": 40377,
    "originalRank": 907
  },
  {
    "word": "club",
    "rank": 839,
    "frequency": 40360,
    "originalRank": 908
  },
  {
    "word": "terminar",
    "rank": 840,
    "frequency": 40338,
    "originalRank": 909
  },
  {
    "word": "temo",
    "rank": 841,
    "frequency": 40288,
    "originalRank": 910
  },
  {
    "word": "broma",
    "rank": 842,
    "frequency": 40281,
    "originalRank": 911
  },
  {
    "word": "gobierno",
    "rank": 843,
    "frequency": 40236,
    "originalRank": 912
  },
  {
    "word": "prometo",
    "rank": 844,
    "frequency": 40224,
    "originalRank": 913
  },
  {
    "word": "cámara",
    "rank": 845,
    "frequency": 40045,
    "originalRank": 914
  },
  {
    "word": "media",
    "rank": 846,
    "frequency": 39998,
    "originalRank": 915
  },
  {
    "word": "terrible",
    "rank": 847,
    "frequency": 39993,
    "originalRank": 916
  },
  {
    "word": "llamó",
    "rank": 848,
    "frequency": 39922,
    "originalRank": 917
  },
  {
    "word": "regalo",
    "rank": 849,
    "frequency": 39903,
    "originalRank": 918
  },
  {
    "word": "amable",
    "rank": 850,
    "frequency": 39841,
    "originalRank": 919
  },
  {
    "word": "dulce",
    "rank": 851,
    "frequency": 39818,
    "originalRank": 920
  },
  {
    "word": "muertos",
    "rank": 852,
    "frequency": 39809,
    "originalRank": 921
  },
  {
    "word": "querías",
    "rank": 853,
    "frequency": 39797,
    "originalRank": 922
  },
  {
    "word": "ataque",
    "rank": 854,
    "frequency": 39782,
    "originalRank": 923
  },
  {
    "word": "das",
    "rank": 855,
    "frequency": 39589,
    "originalRank": 924
  },
  {
    "word": "navidad",
    "rank": 856,
    "frequency": 39589,
    "originalRank": 925
  },
  {
    "word": "negocios",
    "rank": 857,
    "frequency": 39553,
    "originalRank": 926
  },
  {
    "word": "pudiera",
    "rank": 858,
    "frequency": 39528,
    "originalRank": 927
  },
  {
    "word": "ocho",
    "rank": 859,
    "frequency": 39524,
    "originalRank": 928
  },
  {
    "word": "avión",
    "rank": 860,
    "frequency": 39484,
    "originalRank": 929
  },
  {
    "word": "investigación",
    "rank": 861,
    "frequency": 39465,
    "originalRank": 930
  },
  {
    "word": "acabó",
    "rank": 862,
    "frequency": 39429,
    "originalRank": 931
  },
  {
    "word": "juro",
    "rank": 863,
    "frequency": 39329,
    "originalRank": 932
  },
  {
    "word": "mantener",
    "rank": 864,
    "frequency": 39327,
    "originalRank": 933
  },
  {
    "word": "ejército",
    "rank": 865,
    "frequency": 39290,
    "originalRank": 934
  },
  {
    "word": "papel",
    "rank": 866,
    "frequency": 39262,
    "originalRank": 935
  },
  {
    "word": "partes",
    "rank": 867,
    "frequency": 39255,
    "originalRank": 936
  },
  {
    "word": "ten",
    "rank": 868,
    "frequency": 39243,
    "originalRank": 937
  },
  {
    "word": "gracioso",
    "rank": 869,
    "frequency": 39166,
    "originalRank": 938
  },
  {
    "word": "diría",
    "rank": 870,
    "frequency": 39163,
    "originalRank": 939
  },
  {
    "word": "principio",
    "rank": 871,
    "frequency": 39155,
    "originalRank": 940
  },
  {
    "word": "delante",
    "rank": 872,
    "frequency": 38898,
    "originalRank": 941
  },
  {
    "word": "teniente",
    "rank": 873,
    "frequency": 38628,
    "originalRank": 942
  },
  {
    "word": "deseo",
    "rank": 874,
    "frequency": 38627,
    "originalRank": 943
  },
  {
    "word": "vayas",
    "rank": 875,
    "frequency": 38593,
    "originalRank": 944
  },
  {
    "word": "nave",
    "rank": 876,
    "frequency": 38459,
    "originalRank": 945
  },
  {
    "word": "sale",
    "rank": 877,
    "frequency": 38407,
    "originalRank": 946
  },
  {
    "word": "basura",
    "rank": 878,
    "frequency": 38280,
    "originalRank": 947
  },
  {
    "word": "vine",
    "rank": 879,
    "frequency": 38168,
    "originalRank": 948
  },
  {
    "word": "contacto",
    "rank": 880,
    "frequency": 38028,
    "originalRank": 949
  },
  {
    "word": "esposo",
    "rank": 881,
    "frequency": 38011,
    "originalRank": 950
  },
  {
    "word": "tren",
    "rank": 882,
    "frequency": 37976,
    "originalRank": 951
  },
  {
    "word": "encontramos",
    "rank": 883,
    "frequency": 37952,
    "originalRank": 952
  },
  {
    "word": "dale",
    "rank": 884,
    "frequency": 37876,
    "originalRank": 953
  },
  {
    "word": "verdadero",
    "rank": 885,
    "frequency": 37844,
    "originalRank": 954
  },
  {
    "word": "tuya",
    "rank": 886,
    "frequency": 37837,
    "originalRank": 955
  },
  {
    "word": "alma",
    "rank": 887,
    "frequency": 37824,
    "originalRank": 956
  },
  {
    "word": "hazlo",
    "rank": 888,
    "frequency": 37804,
    "originalRank": 957
  },
  {
    "word": "disculpa",
    "rank": 889,
    "frequency": 37801,
    "originalRank": 958
  },
  {
    "word": "junto",
    "rank": 890,
    "frequency": 37794,
    "originalRank": 959
  },
  {
    "word": "anda",
    "rank": 891,
    "frequency": 37779,
    "originalRank": 960
  },
  {
    "word": "tendré",
    "rank": 892,
    "frequency": 37662,
    "originalRank": 961
  },
  {
    "word": "matrimonio",
    "rank": 893,
    "frequency": 37656,
    "originalRank": 962
  },
  {
    "word": "saberlo",
    "rank": 894,
    "frequency": 37540,
    "originalRank": 963
  },
  {
    "word": "locura",
    "rank": 895,
    "frequency": 37525,
    "originalRank": 964
  },
  {
    "word": "oro",
    "rank": 896,
    "frequency": 37500,
    "originalRank": 965
  },
  {
    "word": "permiso",
    "rank": 897,
    "frequency": 37465,
    "originalRank": 966
  },
  {
    "word": "director",
    "rank": 898,
    "frequency": 37428,
    "originalRank": 967
  },
  {
    "word": "peligro",
    "rank": 899,
    "frequency": 37415,
    "originalRank": 968
  },
  {
    "word": "libertad",
    "rank": 900,
    "frequency": 37412,
    "originalRank": 969
  },
  {
    "word": "alegro",
    "rank": 901,
    "frequency": 37403,
    "originalRank": 970
  },
  {
    "word": "baja",
    "rank": 902,
    "frequency": 37298,
    "originalRank": 971
  },
  {
    "word": "tendremos",
    "rank": 903,
    "frequency": 37262,
    "originalRank": 972
  },
  {
    "word": "derecha",
    "rank": 904,
    "frequency": 37262,
    "originalRank": 973
  },
  {
    "word": "encuentra",
    "rank": 905,
    "frequency": 37241,
    "originalRank": 974
  },
  {
    "word": "pies",
    "rank": 906,
    "frequency": 37222,
    "originalRank": 975
  },
  {
    "word": "segunda",
    "rank": 907,
    "frequency": 37192,
    "originalRank": 976
  },
  {
    "word": "maravilloso",
    "rank": 908,
    "frequency": 37115,
    "originalRank": 977
  },
  {
    "word": "espacio",
    "rank": 909,
    "frequency": 37114,
    "originalRank": 978
  },
  {
    "word": "rato",
    "rank": 910,
    "frequency": 37101,
    "originalRank": 979
  },
  {
    "word": "abuelo",
    "rank": 911,
    "frequency": 37062,
    "originalRank": 980
  },
  {
    "word": "esperaba",
    "rank": 912,
    "frequency": 37031,
    "originalRank": 981
  },
  {
    "word": "mirando",
    "rank": 913,
    "frequency": 37030,
    "originalRank": 982
  },
  {
    "word": "salud",
    "rank": 914,
    "frequency": 37016,
    "originalRank": 983
  },
  {
    "word": "sorpresa",
    "rank": 915,
    "frequency": 37012,
    "originalRank": 984
  },
  {
    "word": "ninguno",
    "rank": 916,
    "frequency": 37007,
    "originalRank": 985
  },
  {
    "word": "miren",
    "rank": 917,
    "frequency": 37000,
    "originalRank": 986
  },
  {
    "word": "triste",
    "rank": 918,
    "frequency": 36968,
    "originalRank": 987
  },
  {
    "word": "aun",
    "rank": 919,
    "frequency": 36908,
    "originalRank": 988
  },
  {
    "word": "pensado",
    "rank": 920,
    "frequency": 36904,
    "originalRank": 989
  },
  {
    "word": "maestro",
    "rank": 921,
    "frequency": 36887,
    "originalRank": 990
  },
  {
    "word": "según",
    "rank": 922,
    "frequency": 36882,
    "originalRank": 991
  },
  {
    "word": "infierno",
    "rank": 923,
    "frequency": 36835,
    "originalRank": 992
  },
  {
    "word": "podrían",
    "rank": 924,
    "frequency": 36824,
    "originalRank": 993
  },
  {
    "word": "tipos",
    "rank": 925,
    "frequency": 36703,
    "originalRank": 994
  },
  {
    "word": "tía",
    "rank": 926,
    "frequency": 36607,
    "originalRank": 995
  },
  {
    "word": "crimen",
    "rank": 927,
    "frequency": 36579,
    "originalRank": 996
  },
  {
    "word": "conocido",
    "rank": 928,
    "frequency": 36564,
    "originalRank": 997
  },
  {
    "word": "consejo",
    "rank": 929,
    "frequency": 36446,
    "originalRank": 998
  },
  {
    "word": "ante",
    "rank": 930,
    "frequency": 36426,
    "originalRank": 999
  },
  {
    "word": "iglesia",
    "rank": 931,
    "frequency": 36300,
    "originalRank": 1000
  },
  {
    "word": "intento",
    "rank": 932,
    "frequency": 36197,
    "originalRank": 1001
  },
  {
    "word": "mayoría",
    "rank": 933,
    "frequency": 36167,
    "originalRank": 1002
  },
  {
    "word": "doy",
    "rank": 934,
    "frequency": 36153,
    "originalRank": 1003
  },
  {
    "word": "peter",
    "rank": 935,
    "frequency": 36107,
    "originalRank": 1004
  },
  {
    "word": "hicimos",
    "rank": 936,
    "frequency": 36096,
    "originalRank": 1005
  },
  {
    "word": "escena",
    "rank": 937,
    "frequency": 36065,
    "originalRank": 1006
  },
  {
    "word": "piso",
    "rank": 938,
    "frequency": 36054,
    "originalRank": 1007
  },
  {
    "word": "señal",
    "rank": 939,
    "frequency": 36012,
    "originalRank": 1008
  },
  {
    "word": "honor",
    "rank": 940,
    "frequency": 35990,
    "originalRank": 1009
  },
  {
    "word": "llamas",
    "rank": 941,
    "frequency": 35985,
    "originalRank": 1010
  },
  {
    "word": "abre",
    "rank": 942,
    "frequency": 35915,
    "originalRank": 1011
  },
  {
    "word": "cerebro",
    "rank": 943,
    "frequency": 35820,
    "originalRank": 1012
  },
  {
    "word": "veras",
    "rank": 944,
    "frequency": 35817,
    "originalRank": 1013
  },
  {
    "word": "viendo",
    "rank": 945,
    "frequency": 35814,
    "originalRank": 1014
  },
  {
    "word": "pone",
    "rank": 946,
    "frequency": 35812,
    "originalRank": 1015
  },
  {
    "word": "pregunto",
    "rank": 947,
    "frequency": 35802,
    "originalRank": 1016
  },
  {
    "word": "cocina",
    "rank": 948,
    "frequency": 35715,
    "originalRank": 1017
  },
  {
    "word": "vestido",
    "rank": 949,
    "frequency": 35669,
    "originalRank": 1018
  },
  {
    "word": "inteligente",
    "rank": 950,
    "frequency": 35632,
    "originalRank": 1019
  },
  {
    "word": "vieja",
    "rank": 951,
    "frequency": 35616,
    "originalRank": 1020
  },
  {
    "word": "caballo",
    "rank": 952,
    "frequency": 35585,
    "originalRank": 1021
  },
  {
    "word": "vienen",
    "rank": 953,
    "frequency": 35533,
    "originalRank": 1022
  },
  {
    "word": "vidas",
    "rank": 954,
    "frequency": 35477,
    "originalRank": 1023
  },
  {
    "word": "bar",
    "rank": 955,
    "frequency": 35461,
    "originalRank": 1024
  },
  {
    "word": "corte",
    "rank": 956,
    "frequency": 35435,
    "originalRank": 1025
  },
  {
    "word": "sucedió",
    "rank": 957,
    "frequency": 35426,
    "originalRank": 1026
  },
  {
    "word": "adentro",
    "rank": 958,
    "frequency": 35406,
    "originalRank": 1027
  },
  {
    "word": "drogas",
    "rank": 959,
    "frequency": 35396,
    "originalRank": 1028
  },
  {
    "word": "enseguida",
    "rank": 960,
    "frequency": 35331,
    "originalRank": 1029
  },
  {
    "word": "busca",
    "rank": 961,
    "frequency": 35289,
    "originalRank": 1030
  },
  {
    "word": "agradable",
    "rank": 962,
    "frequency": 35267,
    "originalRank": 1031
  },
  {
    "word": "carne",
    "rank": 963,
    "frequency": 35253,
    "originalRank": 1032
  },
  {
    "word": "parecía",
    "rank": 964,
    "frequency": 35223,
    "originalRank": 1033
  },
  {
    "word": "departamento",
    "rank": 965,
    "frequency": 35214,
    "originalRank": 1034
  },
  {
    "word": "lindo",
    "rank": 966,
    "frequency": 35195,
    "originalRank": 1035
  },
  {
    "word": "mar",
    "rank": 967,
    "frequency": 35149,
    "originalRank": 1036
  },
  {
    "word": "duda",
    "rank": 968,
    "frequency": 35145,
    "originalRank": 1037
  },
  {
    "word": "edificio",
    "rank": 969,
    "frequency": 35098,
    "originalRank": 1038
  },
  {
    "word": "conocer",
    "rank": 970,
    "frequency": 35058,
    "originalRank": 1039
  },
  {
    "word": "cargo",
    "rank": 971,
    "frequency": 35050,
    "originalRank": 1040
  },
  {
    "word": "víctima",
    "rank": 972,
    "frequency": 35048,
    "originalRank": 1041
  },
  {
    "word": "luna",
    "rank": 973,
    "frequency": 34997,
    "originalRank": 1042
  },
  {
    "word": "energía",
    "rank": 974,
    "frequency": 34997,
    "originalRank": 1043
  },
  {
    "word": "frío",
    "rank": 975,
    "frequency": 34936,
    "originalRank": 1044
  },
  {
    "word": "hablo",
    "rank": 976,
    "frequency": 34863,
    "originalRank": 1045
  },
  {
    "word": "baile",
    "rank": 977,
    "frequency": 34771,
    "originalRank": 1046
  },
  {
    "word": "trabaja",
    "rank": 978,
    "frequency": 34740,
    "originalRank": 1047
  },
  {
    "word": "misión",
    "rank": 979,
    "frequency": 34729,
    "originalRank": 1048
  },
  {
    "word": "listos",
    "rank": 980,
    "frequency": 34703,
    "originalRank": 1049
  },
  {
    "word": "ayudarte",
    "rank": 981,
    "frequency": 34637,
    "originalRank": 1050
  },
  {
    "word": "izquierda",
    "rank": 982,
    "frequency": 34629,
    "originalRank": 1051
  },
  {
    "word": "paul",
    "rank": 983,
    "frequency": 34600,
    "originalRank": 1052
  },
  {
    "word": "beber",
    "rank": 984,
    "frequency": 34576,
    "originalRank": 1053
  },
  {
    "word": "deje",
    "rank": 985,
    "frequency": 34568,
    "originalRank": 1054
  },
  {
    "word": "finalmente",
    "rank": 986,
    "frequency": 34516,
    "originalRank": 1055
  },
  {
    "word": "simple",
    "rank": 987,
    "frequency": 34511,
    "originalRank": 1056
  },
  {
    "word": "daré",
    "rank": 988,
    "frequency": 34496,
    "originalRank": 1057
  },
  {
    "word": "sabías",
    "rank": 989,
    "frequency": 34453,
    "originalRank": 1058
  },
  {
    "word": "puedas",
    "rank": 990,
    "frequency": 34446,
    "originalRank": 1059
  },
  {
    "word": "puso",
    "rank": 991,
    "frequency": 34438,
    "originalRank": 1060
  },
  {
    "word": "creía",
    "rank": 992,
    "frequency": 34319,
    "originalRank": 1061
  },
  {
    "word": "regresar",
    "rank": 993,
    "frequency": 34314,
    "originalRank": 1062
  },
  {
    "word": "llega",
    "rank": 994,
    "frequency": 34263,
    "originalRank": 1063
  },
  {
    "word": "entender",
    "rank": 995,
    "frequency": 34253,
    "originalRank": 1064
  },
  {
    "word": "mirar",
    "rank": 996,
    "frequency": 34206,
    "originalRank": 1065
  },
  {
    "word": "sacar",
    "rank": 997,
    "frequency": 34188,
    "originalRank": 1066
  },
  {
    "word": "cambiado",
    "rank": 998,
    "frequency": 34095,
    "originalRank": 1067
  },
  {
    "word": "trae",
    "rank": 999,
    "frequency": 34072,
    "originalRank": 1068
  },
  {
    "word": "hermoso",
    "rank": 1000,
    "frequency": 34066,
    "originalRank": 1069
  },
  {
    "word": "opinión",
    "rank": 1001,
    "frequency": 34009,
    "originalRank": 1070
  },
  {
    "word": "verás",
    "rank": 1002,
    "frequency": 34007,
    "originalRank": 1071
  },
  {
    "word": "linda",
    "rank": 1003,
    "frequency": 34005,
    "originalRank": 1072
  },
  {
    "word": "apenas",
    "rank": 1004,
    "frequency": 33969,
    "originalRank": 1073
  },
  {
    "word": "segundos",
    "rank": 1005,
    "frequency": 33905,
    "originalRank": 1074
  },
  {
    "word": "cerveza",
    "rank": 1006,
    "frequency": 33902,
    "originalRank": 1075
  },
  {
    "word": "harás",
    "rank": 1007,
    "frequency": 33809,
    "originalRank": 1076
  },
  {
    "word": "estuviera",
    "rank": 1008,
    "frequency": 33794,
    "originalRank": 1077
  },
  {
    "word": "creen",
    "rank": 1009,
    "frequency": 33728,
    "originalRank": 1078
  },
  {
    "word": "oír",
    "rank": 1010,
    "frequency": 33646,
    "originalRank": 1079
  },
  {
    "word": "tendría",
    "rank": 1011,
    "frequency": 33574,
    "originalRank": 1080
  },
  {
    "word": "cuántos",
    "rank": 1012,
    "frequency": 33572,
    "originalRank": 1081
  },
  {
    "word": "hablado",
    "rank": 1013,
    "frequency": 33561,
    "originalRank": 1082
  },
  {
    "word": "hablamos",
    "rank": 1014,
    "frequency": 33532,
    "originalRank": 1083
  },
  {
    "word": "reina",
    "rank": 1015,
    "frequency": 33477,
    "originalRank": 1084
  },
  {
    "word": "temprano",
    "rank": 1016,
    "frequency": 33465,
    "originalRank": 1085
  },
  {
    "word": "tema",
    "rank": 1017,
    "frequency": 33446,
    "originalRank": 1086
  },
  {
    "word": "prisión",
    "rank": 1018,
    "frequency": 33396,
    "originalRank": 1087
  },
  {
    "word": "porqué",
    "rank": 1019,
    "frequency": 33393,
    "originalRank": 1088
  },
  {
    "word": "vuelva",
    "rank": 1020,
    "frequency": 33350,
    "originalRank": 1089
  },
  {
    "word": "público",
    "rank": 1021,
    "frequency": 33347,
    "originalRank": 1090
  },
  {
    "word": "ocurrió",
    "rank": 1022,
    "frequency": 33319,
    "originalRank": 1091
  },
  {
    "word": "veré",
    "rank": 1023,
    "frequency": 33305,
    "originalRank": 1092
  },
  {
    "word": "salvar",
    "rank": 1024,
    "frequency": 33301,
    "originalRank": 1093
  },
  {
    "word": "partido",
    "rank": 1025,
    "frequency": 33291,
    "originalRank": 1094
  },
  {
    "word": "bonita",
    "rank": 1026,
    "frequency": 33286,
    "originalRank": 1095
  },
  {
    "word": "joder",
    "rank": 1027,
    "frequency": 33283,
    "originalRank": 1096
  },
  {
    "word": "causa",
    "rank": 1028,
    "frequency": 33279,
    "originalRank": 1097
  },
  {
    "word": "caliente",
    "rank": 1029,
    "frequency": 33249,
    "originalRank": 1098
  },
  {
    "word": "sargento",
    "rank": 1030,
    "frequency": 33179,
    "originalRank": 1099
  },
  {
    "word": "cenar",
    "rank": 1031,
    "frequency": 33146,
    "originalRank": 1100
  },
  {
    "word": "compañero",
    "rank": 1032,
    "frequency": 32947,
    "originalRank": 1101
  },
  {
    "word": "llevó",
    "rank": 1033,
    "frequency": 32910,
    "originalRank": 1102
  },
  {
    "word": "banco",
    "rank": 1034,
    "frequency": 32880,
    "originalRank": 1103
  },
  {
    "word": "existe",
    "rank": 1035,
    "frequency": 32874,
    "originalRank": 1104
  },
  {
    "word": "ben",
    "rank": 1036,
    "frequency": 32858,
    "originalRank": 1105
  },
  {
    "word": "zona",
    "rank": 1037,
    "frequency": 32787,
    "originalRank": 1106
  },
  {
    "word": "destino",
    "rank": 1038,
    "frequency": 32785,
    "originalRank": 1107
  },
  {
    "word": "base",
    "rank": 1039,
    "frequency": 32757,
    "originalRank": 1108
  },
  {
    "word": "solía",
    "rank": 1040,
    "frequency": 32665,
    "originalRank": 1109
  },
  {
    "word": "cliente",
    "rank": 1041,
    "frequency": 32665,
    "originalRank": 1110
  },
  {
    "word": "irse",
    "rank": 1042,
    "frequency": 32623,
    "originalRank": 1111
  },
  {
    "word": "perra",
    "rank": 1043,
    "frequency": 32592,
    "originalRank": 1112
  },
  {
    "word": "james",
    "rank": 1044,
    "frequency": 32572,
    "originalRank": 1113
  },
  {
    "word": "encuentro",
    "rank": 1045,
    "frequency": 32557,
    "originalRank": 1114
  },
  {
    "word": "encontró",
    "rank": 1046,
    "frequency": 32539,
    "originalRank": 1115
  },
  {
    "word": "pelea",
    "rank": 1047,
    "frequency": 32497,
    "originalRank": 1116
  },
  {
    "word": "san",
    "rank": 1048,
    "frequency": 32450,
    "originalRank": 1117
  },
  {
    "word": "norte",
    "rank": 1049,
    "frequency": 32319,
    "originalRank": 1118
  },
  {
    "word": "quise",
    "rank": 1050,
    "frequency": 32250,
    "originalRank": 1119
  },
  {
    "word": "coronel",
    "rank": 1051,
    "frequency": 32219,
    "originalRank": 1120
  },
  {
    "word": "apuesto",
    "rank": 1052,
    "frequency": 32213,
    "originalRank": 1121
  },
  {
    "word": "peligroso",
    "rank": 1053,
    "frequency": 32210,
    "originalRank": 1122
  },
  {
    "word": "viva",
    "rank": 1054,
    "frequency": 32204,
    "originalRank": 1123
  },
  {
    "word": "max",
    "rank": 1055,
    "frequency": 32182,
    "originalRank": 1124
  },
  {
    "word": "vienes",
    "rank": 1056,
    "frequency": 32150,
    "originalRank": 1125
  },
  {
    "word": "necesitan",
    "rank": 1057,
    "frequency": 32121,
    "originalRank": 1126
  },
  {
    "word": "excepto",
    "rank": 1058,
    "frequency": 32005,
    "originalRank": 1128
  },
  {
    "word": "juicio",
    "rank": 1059,
    "frequency": 31961,
    "originalRank": 1129
  },
  {
    "word": "podamos",
    "rank": 1060,
    "frequency": 31904,
    "originalRank": 1130
  },
  {
    "word": "llave",
    "rank": 1061,
    "frequency": 31899,
    "originalRank": 1131
  },
  {
    "word": "equivocado",
    "rank": 1062,
    "frequency": 31851,
    "originalRank": 1132
  },
  {
    "word": "posición",
    "rank": 1063,
    "frequency": 31835,
    "originalRank": 1133
  },
  {
    "word": "trasero",
    "rank": 1064,
    "frequency": 31796,
    "originalRank": 1134
  },
  {
    "word": "irnos",
    "rank": 1065,
    "frequency": 31731,
    "originalRank": 1135
  },
  {
    "word": "espalda",
    "rank": 1066,
    "frequency": 31618,
    "originalRank": 1136
  },
  {
    "word": "excelente",
    "rank": 1067,
    "frequency": 31576,
    "originalRank": 1137
  },
  {
    "word": "éxito",
    "rank": 1068,
    "frequency": 31546,
    "originalRank": 1138
  },
  {
    "word": "modos",
    "rank": 1069,
    "frequency": 31533,
    "originalRank": 1139
  },
  {
    "word": "ventana",
    "rank": 1070,
    "frequency": 31521,
    "originalRank": 1140
  },
  {
    "word": "veamos",
    "rank": 1071,
    "frequency": 31449,
    "originalRank": 1141
  },
  {
    "word": "especie",
    "rank": 1072,
    "frequency": 31439,
    "originalRank": 1142
  },
  {
    "word": "teníamos",
    "rank": 1073,
    "frequency": 31438,
    "originalRank": 1143
  },
  {
    "word": "diferencia",
    "rank": 1074,
    "frequency": 31428,
    "originalRank": 1144
  },
  {
    "word": "formas",
    "rank": 1075,
    "frequency": 31423,
    "originalRank": 1145
  },
  {
    "word": "pedir",
    "rank": 1076,
    "frequency": 31418,
    "originalRank": 1146
  },
  {
    "word": "últimos",
    "rank": 1077,
    "frequency": 31416,
    "originalRank": 1147
  },
  {
    "word": "escúchame",
    "rank": 1078,
    "frequency": 31386,
    "originalRank": 1148
  },
  {
    "word": "ejemplo",
    "rank": 1079,
    "frequency": 31354,
    "originalRank": 1149
  },
  {
    "word": "ése",
    "rank": 1080,
    "frequency": 31352,
    "originalRank": 1150
  },
  {
    "word": "radio",
    "rank": 1081,
    "frequency": 31316,
    "originalRank": 1151
  },
  {
    "word": "lee",
    "rank": 1082,
    "frequency": 31272,
    "originalRank": 1152
  },
  {
    "word": "calma",
    "rank": 1083,
    "frequency": 31202,
    "originalRank": 1153
  },
  {
    "word": "hogar",
    "rank": 1084,
    "frequency": 31190,
    "originalRank": 1154
  },
  {
    "word": "volveré",
    "rank": 1085,
    "frequency": 31148,
    "originalRank": 1155
  },
  {
    "word": "fondo",
    "rank": 1086,
    "frequency": 31017,
    "originalRank": 1156
  },
  {
    "word": "humano",
    "rank": 1087,
    "frequency": 30936,
    "originalRank": 1157
  },
  {
    "word": "henry",
    "rank": 1088,
    "frequency": 30924,
    "originalRank": 1158
  },
  {
    "word": "iremos",
    "rank": 1089,
    "frequency": 30871,
    "originalRank": 1160
  },
  {
    "word": "unidos",
    "rank": 1090,
    "frequency": 30863,
    "originalRank": 1161
  },
  {
    "word": "habían",
    "rank": 1091,
    "frequency": 30746,
    "originalRank": 1162
  },
  {
    "word": "jesús",
    "rank": 1092,
    "frequency": 30720,
    "originalRank": 1163
  },
  {
    "word": "planeta",
    "rank": 1093,
    "frequency": 30672,
    "originalRank": 1164
  },
  {
    "word": "verme",
    "rank": 1094,
    "frequency": 30657,
    "originalRank": 1165
  },
  {
    "word": "respecto",
    "rank": 1095,
    "frequency": 30525,
    "originalRank": 1166
  },
  {
    "word": "regreso",
    "rank": 1096,
    "frequency": 30519,
    "originalRank": 1167
  },
  {
    "word": "debido",
    "rank": 1097,
    "frequency": 30518,
    "originalRank": 1168
  },
  {
    "word": "seré",
    "rank": 1098,
    "frequency": 30505,
    "originalRank": 1169
  },
  {
    "word": "tenían",
    "rank": 1099,
    "frequency": 30390,
    "originalRank": 1170
  },
  {
    "word": "leer",
    "rank": 1100,
    "frequency": 30383,
    "originalRank": 1171
  },
  {
    "word": "parar",
    "rank": 1101,
    "frequency": 30341,
    "originalRank": 1172
  },
  {
    "word": "lleno",
    "rank": 1102,
    "frequency": 30333,
    "originalRank": 1173
  },
  {
    "word": "dejé",
    "rank": 1103,
    "frequency": 30321,
    "originalRank": 1174
  },
  {
    "word": "respeto",
    "rank": 1104,
    "frequency": 30274,
    "originalRank": 1175
  },
  {
    "word": "debajo",
    "rank": 1105,
    "frequency": 30209,
    "originalRank": 1176
  },
  {
    "word": "harry",
    "rank": 1106,
    "frequency": 30134,
    "originalRank": 1177
  },
  {
    "word": "escribir",
    "rank": 1107,
    "frequency": 30111,
    "originalRank": 1178
  },
  {
    "word": "estación",
    "rank": 1108,
    "frequency": 30100,
    "originalRank": 1179
  },
  {
    "word": "pidió",
    "rank": 1109,
    "frequency": 30100,
    "originalRank": 1180
  },
  {
    "word": "alta",
    "rank": 1110,
    "frequency": 30046,
    "originalRank": 1181
  },
  {
    "word": "pista",
    "rank": 1111,
    "frequency": 30000,
    "originalRank": 1182
  },
  {
    "word": "estrella",
    "rank": 1112,
    "frequency": 29938,
    "originalRank": 1183
  },
  {
    "word": "enfermo",
    "rank": 1113,
    "frequency": 29931,
    "originalRank": 1184
  },
  {
    "word": "duele",
    "rank": 1114,
    "frequency": 29808,
    "originalRank": 1185
  },
  {
    "word": "sueños",
    "rank": 1115,
    "frequency": 29807,
    "originalRank": 1186
  },
  {
    "word": "veremos",
    "rank": 1116,
    "frequency": 29783,
    "originalRank": 1187
  },
  {
    "word": "miles",
    "rank": 1117,
    "frequency": 29772,
    "originalRank": 1188
  },
  {
    "word": "darme",
    "rank": 1118,
    "frequency": 29767,
    "originalRank": 1189
  },
  {
    "word": "órdenes",
    "rank": 1119,
    "frequency": 29746,
    "originalRank": 1190
  },
  {
    "word": "ocupado",
    "rank": 1120,
    "frequency": 29600,
    "originalRank": 1191
  },
  {
    "word": "sigues",
    "rank": 1121,
    "frequency": 29572,
    "originalRank": 1192
  },
  {
    "word": "corre",
    "rank": 1122,
    "frequency": 29570,
    "originalRank": 1193
  },
  {
    "word": "podido",
    "rank": 1123,
    "frequency": 29555,
    "originalRank": 1194
  },
  {
    "word": "dejes",
    "rank": 1124,
    "frequency": 29536,
    "originalRank": 1195
  },
  {
    "word": "nivel",
    "rank": 1125,
    "frequency": 29519,
    "originalRank": 1196
  },
  {
    "word": "habéis",
    "rank": 1126,
    "frequency": 29518,
    "originalRank": 1197
  },
  {
    "word": "experiencia",
    "rank": 1127,
    "frequency": 29510,
    "originalRank": 1198
  },
  {
    "word": "darte",
    "rank": 1128,
    "frequency": 29480,
    "originalRank": 1199
  },
  {
    "word": "salida",
    "rank": 1129,
    "frequency": 29479,
    "originalRank": 1200
  },
  {
    "word": "decirlo",
    "rank": 1130,
    "frequency": 29456,
    "originalRank": 1201
  },
  {
    "word": "confiar",
    "rank": 1131,
    "frequency": 29427,
    "originalRank": 1202
  },
  {
    "word": "hacerte",
    "rank": 1132,
    "frequency": 29424,
    "originalRank": 1203
  },
  {
    "word": "necesitaba",
    "rank": 1133,
    "frequency": 29377,
    "originalRank": 1204
  },
  {
    "word": "hermanos",
    "rank": 1134,
    "frequency": 29333,
    "originalRank": 1205
  },
  {
    "word": "zapatos",
    "rank": 1135,
    "frequency": 29332,
    "originalRank": 1206
  },
  {
    "word": "color",
    "rank": 1136,
    "frequency": 29320,
    "originalRank": 1207
  },
  {
    "word": "vistazo",
    "rank": 1137,
    "frequency": 29316,
    "originalRank": 1208
  },
  {
    "word": "nena",
    "rank": 1138,
    "frequency": 29309,
    "originalRank": 1209
  },
  {
    "word": "tratar",
    "rank": 1139,
    "frequency": 29257,
    "originalRank": 1210
  },
  {
    "word": "parecer",
    "rank": 1140,
    "frequency": 29249,
    "originalRank": 1211
  },
  {
    "word": "juez",
    "rank": 1141,
    "frequency": 29177,
    "originalRank": 1212
  },
  {
    "word": "próximo",
    "rank": 1142,
    "frequency": 29134,
    "originalRank": 1213
  },
  {
    "word": "paciente",
    "rank": 1143,
    "frequency": 29118,
    "originalRank": 1214
  },
  {
    "word": "hayas",
    "rank": 1144,
    "frequency": 29081,
    "originalRank": 1215
  },
  {
    "word": "bolsa",
    "rank": 1145,
    "frequency": 29042,
    "originalRank": 1216
  },
  {
    "word": "arte",
    "rank": 1146,
    "frequency": 29011,
    "originalRank": 1217
  },
  {
    "word": "mary",
    "rank": 1147,
    "frequency": 28973,
    "originalRank": 1218
  },
  {
    "word": "jugando",
    "rank": 1148,
    "frequency": 28967,
    "originalRank": 1219
  },
  {
    "word": "llevas",
    "rank": 1149,
    "frequency": 28896,
    "originalRank": 1220
  },
  {
    "word": "alegra",
    "rank": 1150,
    "frequency": 28887,
    "originalRank": 1221
  },
  {
    "word": "bailar",
    "rank": 1151,
    "frequency": 28886,
    "originalRank": 1222
  },
  {
    "word": "diablo",
    "rank": 1152,
    "frequency": 28865,
    "originalRank": 1223
  },
  {
    "word": "sepa",
    "rank": 1153,
    "frequency": 28810,
    "originalRank": 1225
  },
  {
    "word": "estarás",
    "rank": 1154,
    "frequency": 28804,
    "originalRank": 1226
  },
  {
    "word": "sur",
    "rank": 1155,
    "frequency": 28775,
    "originalRank": 1227
  },
  {
    "word": "banda",
    "rank": 1156,
    "frequency": 28768,
    "originalRank": 1228
  },
  {
    "word": "aprender",
    "rank": 1157,
    "frequency": 28760,
    "originalRank": 1229
  },
  {
    "word": "precio",
    "rank": 1158,
    "frequency": 28723,
    "originalRank": 1230
  },
  {
    "word": "completo",
    "rank": 1159,
    "frequency": 28715,
    "originalRank": 1231
  },
  {
    "word": "santo",
    "rank": 1160,
    "frequency": 28659,
    "originalRank": 1232
  },
  {
    "word": "culpable",
    "rank": 1161,
    "frequency": 28654,
    "originalRank": 1233
  },
  {
    "word": "ganas",
    "rank": 1162,
    "frequency": 28649,
    "originalRank": 1234
  },
  {
    "word": "tuvimos",
    "rank": 1163,
    "frequency": 28633,
    "originalRank": 1235
  },
  {
    "word": "you",
    "rank": 1164,
    "frequency": 28617,
    "originalRank": 1236
  },
  {
    "word": "verla",
    "rank": 1165,
    "frequency": 28616,
    "originalRank": 1237
  },
  {
    "word": "volvió",
    "rank": 1166,
    "frequency": 28609,
    "originalRank": 1238
  },
  {
    "word": "libros",
    "rank": 1167,
    "frequency": 28603,
    "originalRank": 1239
  },
  {
    "word": "ojo",
    "rank": 1168,
    "frequency": 28589,
    "originalRank": 1240
  },
  {
    "word": "serán",
    "rank": 1169,
    "frequency": 28588,
    "originalRank": 1241
  },
  {
    "word": "cielos",
    "rank": 1170,
    "frequency": 28554,
    "originalRank": 1242
  },
  {
    "word": "matado",
    "rank": 1171,
    "frequency": 28480,
    "originalRank": 1243
  },
  {
    "word": "azul",
    "rank": 1172,
    "frequency": 28477,
    "originalRank": 1244
  },
  {
    "word": "diferentes",
    "rank": 1173,
    "frequency": 28472,
    "originalRank": 1245
  },
  {
    "word": "irte",
    "rank": 1174,
    "frequency": 28442,
    "originalRank": 1246
  },
  {
    "word": "comandante",
    "rank": 1175,
    "frequency": 28382,
    "originalRank": 1248
  },
  {
    "word": "acción",
    "rank": 1176,
    "frequency": 28381,
    "originalRank": 1249
  },
  {
    "word": "reglas",
    "rank": 1177,
    "frequency": 28301,
    "originalRank": 1250
  },
  {
    "word": "obra",
    "rank": 1178,
    "frequency": 28275,
    "originalRank": 1251
  },
  {
    "word": "esperanza",
    "rank": 1179,
    "frequency": 28234,
    "originalRank": 1252
  },
  {
    "word": "cuestión",
    "rank": 1180,
    "frequency": 28230,
    "originalRank": 1253
  },
  {
    "word": "molesta",
    "rank": 1181,
    "frequency": 28230,
    "originalRank": 1254
  },
  {
    "word": "teniendo",
    "rank": 1182,
    "frequency": 28223,
    "originalRank": 1255
  },
  {
    "word": "bill",
    "rank": 1183,
    "frequency": 28210,
    "originalRank": 1256
  },
  {
    "word": "informe",
    "rank": 1184,
    "frequency": 28207,
    "originalRank": 1257
  },
  {
    "word": "jimmy",
    "rank": 1185,
    "frequency": 28145,
    "originalRank": 1258
  },
  {
    "word": "río",
    "rank": 1186,
    "frequency": 28133,
    "originalRank": 1259
  },
  {
    "word": "bienvenido",
    "rank": 1187,
    "frequency": 28108,
    "originalRank": 1260
  },
  {
    "word": "abrir",
    "rank": 1188,
    "frequency": 28090,
    "originalRank": 1261
  },
  {
    "word": "tocar",
    "rank": 1189,
    "frequency": 28076,
    "originalRank": 1262
  },
  {
    "word": "bob",
    "rank": 1190,
    "frequency": 28053,
    "originalRank": 1263
  },
  {
    "word": "contar",
    "rank": 1191,
    "frequency": 28052,
    "originalRank": 1264
  },
  {
    "word": "sigo",
    "rank": 1192,
    "frequency": 28033,
    "originalRank": 1265
  },
  {
    "word": "interior",
    "rank": 1193,
    "frequency": 27979,
    "originalRank": 1266
  },
  {
    "word": "apartamento",
    "rank": 1194,
    "frequency": 27936,
    "originalRank": 1267
  },
  {
    "word": "vea",
    "rank": 1195,
    "frequency": 27885,
    "originalRank": 1268
  },
  {
    "word": "estados",
    "rank": 1196,
    "frequency": 27876,
    "originalRank": 1269
  },
  {
    "word": "estáis",
    "rank": 1197,
    "frequency": 27855,
    "originalRank": 1270
  },
  {
    "word": "preocupa",
    "rank": 1198,
    "frequency": 27847,
    "originalRank": 1271
  },
  {
    "word": "tomó",
    "rank": 1199,
    "frequency": 27846,
    "originalRank": 1272
  },
  {
    "word": "principal",
    "rank": 1200,
    "frequency": 27776,
    "originalRank": 1273
  },
  {
    "word": "empieza",
    "rank": 1201,
    "frequency": 27717,
    "originalRank": 1274
  },
  {
    "word": "londres",
    "rank": 1202,
    "frequency": 27684,
    "originalRank": 1275
  },
  {
    "word": "empezó",
    "rank": 1203,
    "frequency": 27667,
    "originalRank": 1276
  },
  {
    "word": "vayan",
    "rank": 1204,
    "frequency": 27643,
    "originalRank": 1277
  },
  {
    "word": "jim",
    "rank": 1205,
    "frequency": 27640,
    "originalRank": 1278
  },
  {
    "word": "llaman",
    "rank": 1206,
    "frequency": 27639,
    "originalRank": 1279
  },
  {
    "word": "ojalá",
    "rank": 1207,
    "frequency": 27609,
    "originalRank": 1280
  },
  {
    "word": "perdona",
    "rank": 1208,
    "frequency": 27596,
    "originalRank": 1281
  },
  {
    "word": "vuelvo",
    "rank": 1209,
    "frequency": 27583,
    "originalRank": 1282
  },
  {
    "word": "golpe",
    "rank": 1210,
    "frequency": 27552,
    "originalRank": 1283
  },
  {
    "word": "quedarme",
    "rank": 1211,
    "frequency": 27529,
    "originalRank": 1284
  },
  {
    "word": "llamaré",
    "rank": 1212,
    "frequency": 27497,
    "originalRank": 1285
  },
  {
    "word": "acabado",
    "rank": 1213,
    "frequency": 27494,
    "originalRank": 1286
  },
  {
    "word": "estilo",
    "rank": 1214,
    "frequency": 27487,
    "originalRank": 1287
  },
  {
    "word": "nueve",
    "rank": 1215,
    "frequency": 27477,
    "originalRank": 1288
  },
  {
    "word": "definitivamente",
    "rank": 1216,
    "frequency": 27474,
    "originalRank": 1289
  },
  {
    "word": "quedar",
    "rank": 1217,
    "frequency": 27451,
    "originalRank": 1290
  },
  {
    "word": "cartas",
    "rank": 1218,
    "frequency": 27437,
    "originalRank": 1291
  },
  {
    "word": "bomba",
    "rank": 1219,
    "frequency": 27431,
    "originalRank": 1292
  },
  {
    "word": "guardia",
    "rank": 1220,
    "frequency": 27405,
    "originalRank": 1293
  },
  {
    "word": "pistola",
    "rank": 1221,
    "frequency": 27403,
    "originalRank": 1294
  },
  {
    "word": "probar",
    "rank": 1222,
    "frequency": 27381,
    "originalRank": 1295
  },
  {
    "word": "majestad",
    "rank": 1223,
    "frequency": 27352,
    "originalRank": 1296
  },
  {
    "word": "traer",
    "rank": 1224,
    "frequency": 27310,
    "originalRank": 1297
  },
  {
    "word": "marcha",
    "rank": 1225,
    "frequency": 27262,
    "originalRank": 1298
  },
  {
    "word": "pareces",
    "rank": 1226,
    "frequency": 27231,
    "originalRank": 1299
  },
  {
    "word": "común",
    "rank": 1227,
    "frequency": 27165,
    "originalRank": 1300
  },
  {
    "word": "aquel",
    "rank": 1228,
    "frequency": 27160,
    "originalRank": 1301
  },
  {
    "word": "hacerle",
    "rank": 1229,
    "frequency": 27153,
    "originalRank": 1302
  },
  {
    "word": "vuelo",
    "rank": 1230,
    "frequency": 27150,
    "originalRank": 1303
  },
  {
    "word": "nota",
    "rank": 1231,
    "frequency": 27132,
    "originalRank": 1304
  },
  {
    "word": "danny",
    "rank": 1232,
    "frequency": 27097,
    "originalRank": 1305
  },
  {
    "word": "humanos",
    "rank": 1233,
    "frequency": 27056,
    "originalRank": 1306
  },
  {
    "word": "estaremos",
    "rank": 1234,
    "frequency": 27050,
    "originalRank": 1307
  },
  {
    "word": "valor",
    "rank": 1235,
    "frequency": 27034,
    "originalRank": 1308
  },
  {
    "word": "suyo",
    "rank": 1236,
    "frequency": 26925,
    "originalRank": 1309
  },
  {
    "word": "objetivo",
    "rank": 1237,
    "frequency": 26881,
    "originalRank": 1310
  },
  {
    "word": "repente",
    "rank": 1238,
    "frequency": 26871,
    "originalRank": 1311
  },
  {
    "word": "debía",
    "rank": 1239,
    "frequency": 26858,
    "originalRank": 1312
  },
  {
    "word": "rojo",
    "rank": 1240,
    "frequency": 26834,
    "originalRank": 1313
  },
  {
    "word": "bromeando",
    "rank": 1241,
    "frequency": 26828,
    "originalRank": 1314
  },
  {
    "word": "irá",
    "rank": 1242,
    "frequency": 26819,
    "originalRank": 1315
  },
  {
    "word": "entrada",
    "rank": 1243,
    "frequency": 26809,
    "originalRank": 1316
  },
  {
    "word": "doble",
    "rank": 1244,
    "frequency": 26787,
    "originalRank": 1317
  },
  {
    "word": "dejaré",
    "rank": 1245,
    "frequency": 26734,
    "originalRank": 1318
  },
  {
    "word": "evitar",
    "rank": 1246,
    "frequency": 26731,
    "originalRank": 1319
  },
  {
    "word": "máquina",
    "rank": 1247,
    "frequency": 26692,
    "originalRank": 1320
  },
  {
    "word": "cuello",
    "rank": 1248,
    "frequency": 26607,
    "originalRank": 1321
  },
  {
    "word": "conocí",
    "rank": 1249,
    "frequency": 26576,
    "originalRank": 1322
  },
  {
    "word": "tiempos",
    "rank": 1250,
    "frequency": 26575,
    "originalRank": 1323
  },
  {
    "word": "tome",
    "rank": 1251,
    "frequency": 26557,
    "originalRank": 1324
  },
  {
    "word": "nick",
    "rank": 1252,
    "frequency": 26552,
    "originalRank": 1325
  },
  {
    "word": "animales",
    "rank": 1253,
    "frequency": 26546,
    "originalRank": 1326
  },
  {
    "word": "alex",
    "rank": 1254,
    "frequency": 26535,
    "originalRank": 1327
  },
  {
    "word": "acaso",
    "rank": 1255,
    "frequency": 26523,
    "originalRank": 1328
  },
  {
    "word": "tuviera",
    "rank": 1256,
    "frequency": 26513,
    "originalRank": 1329
  },
  {
    "word": "pareja",
    "rank": 1257,
    "frequency": 26503,
    "originalRank": 1330
  },
  {
    "word": "verano",
    "rank": 1258,
    "frequency": 26486,
    "originalRank": 1331
  },
  {
    "word": "escuché",
    "rank": 1259,
    "frequency": 26474,
    "originalRank": 1332
  },
  {
    "word": "ama",
    "rank": 1260,
    "frequency": 26468,
    "originalRank": 1333
  },
  {
    "word": "serás",
    "rank": 1261,
    "frequency": 26457,
    "originalRank": 1334
  },
  {
    "word": "mentira",
    "rank": 1262,
    "frequency": 26429,
    "originalRank": 1335
  },
  {
    "word": "tarjeta",
    "rank": 1263,
    "frequency": 26408,
    "originalRank": 1336
  },
  {
    "word": "hagan",
    "rank": 1264,
    "frequency": 26381,
    "originalRank": 1337
  },
  {
    "word": "perdí",
    "rank": 1265,
    "frequency": 26358,
    "originalRank": 1338
  },
  {
    "word": "correr",
    "rank": 1266,
    "frequency": 26352,
    "originalRank": 1339
  },
  {
    "word": "steve",
    "rank": 1267,
    "frequency": 26340,
    "originalRank": 1340
  },
  {
    "word": "traído",
    "rank": 1268,
    "frequency": 26331,
    "originalRank": 1341
  },
  {
    "word": "llegue",
    "rank": 1269,
    "frequency": 26329,
    "originalRank": 1342
  },
  {
    "word": "preparado",
    "rank": 1270,
    "frequency": 26318,
    "originalRank": 1343
  },
  {
    "word": "haberlo",
    "rank": 1271,
    "frequency": 26304,
    "originalRank": 1344
  },
  {
    "word": "tony",
    "rank": 1272,
    "frequency": 26298,
    "originalRank": 1345
  },
  {
    "word": "usa",
    "rank": 1273,
    "frequency": 26278,
    "originalRank": 1346
  },
  {
    "word": "intentar",
    "rank": 1274,
    "frequency": 26247,
    "originalRank": 1347
  },
  {
    "word": "ayudarme",
    "rank": 1275,
    "frequency": 26237,
    "originalRank": 1348
  },
  {
    "word": "flores",
    "rank": 1276,
    "frequency": 26230,
    "originalRank": 1349
  },
  {
    "word": "dando",
    "rank": 1277,
    "frequency": 26212,
    "originalRank": 1350
  },
  {
    "word": "vos",
    "rank": 1278,
    "frequency": 26194,
    "originalRank": 1351
  },
  {
    "word": "opción",
    "rank": 1279,
    "frequency": 26177,
    "originalRank": 1352
  },
  {
    "word": "isla",
    "rank": 1280,
    "frequency": 26148,
    "originalRank": 1353
  },
  {
    "word": "cierra",
    "rank": 1281,
    "frequency": 26144,
    "originalRank": 1354
  },
  {
    "word": "piel",
    "rank": 1282,
    "frequency": 26126,
    "originalRank": 1355
  },
  {
    "word": "enemigo",
    "rank": 1283,
    "frequency": 26121,
    "originalRank": 1356
  },
  {
    "word": "dejo",
    "rank": 1284,
    "frequency": 26109,
    "originalRank": 1357
  },
  {
    "word": "exacto",
    "rank": 1285,
    "frequency": 26087,
    "originalRank": 1358
  },
  {
    "word": "imbécil",
    "rank": 1286,
    "frequency": 26010,
    "originalRank": 1359
  },
  {
    "word": "jóvenes",
    "rank": 1287,
    "frequency": 26000,
    "originalRank": 1360
  },
  {
    "word": "pedido",
    "rank": 1288,
    "frequency": 25956,
    "originalRank": 1361
  },
  {
    "word": "larga",
    "rank": 1289,
    "frequency": 25955,
    "originalRank": 1362
  },
  {
    "word": "entiende",
    "rank": 1290,
    "frequency": 25917,
    "originalRank": 1363
  },
  {
    "word": "justicia",
    "rank": 1291,
    "frequency": 25899,
    "originalRank": 1364
  },
  {
    "word": "nuevos",
    "rank": 1292,
    "frequency": 25896,
    "originalRank": 1365
  },
  {
    "word": "obviamente",
    "rank": 1293,
    "frequency": 25797,
    "originalRank": 1366
  },
  {
    "word": "despierta",
    "rank": 1294,
    "frequency": 25791,
    "originalRank": 1367
  },
  {
    "word": "pido",
    "rank": 1295,
    "frequency": 25720,
    "originalRank": 1368
  },
  {
    "word": "calor",
    "rank": 1296,
    "frequency": 25680,
    "originalRank": 1369
  },
  {
    "word": "luces",
    "rank": 1297,
    "frequency": 25666,
    "originalRank": 1370
  },
  {
    "word": "refiero",
    "rank": 1298,
    "frequency": 25660,
    "originalRank": 1371
  },
  {
    "word": "fuimos",
    "rank": 1299,
    "frequency": 25657,
    "originalRank": 1372
  },
  {
    "word": "batalla",
    "rank": 1300,
    "frequency": 25619,
    "originalRank": 1373
  },
  {
    "word": "déjalo",
    "rank": 1301,
    "frequency": 25614,
    "originalRank": 1374
  },
  {
    "word": "intenta",
    "rank": 1302,
    "frequency": 25538,
    "originalRank": 1375
  },
  {
    "word": "sarah",
    "rank": 1303,
    "frequency": 25528,
    "originalRank": 1376
  },
  {
    "word": "fantástico",
    "rank": 1304,
    "frequency": 25493,
    "originalRank": 1377
  },
  {
    "word": "brazo",
    "rank": 1305,
    "frequency": 25423,
    "originalRank": 1378
  },
  {
    "word": "absolutamente",
    "rank": 1306,
    "frequency": 25418,
    "originalRank": 1379
  },
  {
    "word": "llena",
    "rank": 1307,
    "frequency": 25341,
    "originalRank": 1380
  },
  {
    "word": "hacerme",
    "rank": 1308,
    "frequency": 25312,
    "originalRank": 1381
  },
  {
    "word": "salga",
    "rank": 1309,
    "frequency": 25286,
    "originalRank": 1382
  },
  {
    "word": "recordar",
    "rank": 1310,
    "frequency": 25282,
    "originalRank": 1383
  },
  {
    "word": "escapar",
    "rank": 1311,
    "frequency": 25248,
    "originalRank": 1384
  },
  {
    "word": "bosque",
    "rank": 1312,
    "frequency": 25245,
    "originalRank": 1385
  },
  {
    "word": "gay",
    "rank": 1313,
    "frequency": 25217,
    "originalRank": 1386
  },
  {
    "word": "señores",
    "rank": 1314,
    "frequency": 25187,
    "originalRank": 1387
  },
  {
    "word": "quedan",
    "rank": 1315,
    "frequency": 25181,
    "originalRank": 1388
  },
  {
    "word": "piernas",
    "rank": 1316,
    "frequency": 25117,
    "originalRank": 1389
  },
  {
    "word": "visita",
    "rank": 1317,
    "frequency": 25113,
    "originalRank": 1390
  },
  {
    "word": "parís",
    "rank": 1318,
    "frequency": 25111,
    "originalRank": 1391
  },
  {
    "word": "usando",
    "rank": 1319,
    "frequency": 25109,
    "originalRank": 1392
  },
  {
    "word": "ganado",
    "rank": 1320,
    "frequency": 25106,
    "originalRank": 1393
  },
  {
    "word": "movimiento",
    "rank": 1321,
    "frequency": 25097,
    "originalRank": 1394
  },
  {
    "word": "blanca",
    "rank": 1322,
    "frequency": 25080,
    "originalRank": 1395
  },
  {
    "word": "rico",
    "rank": 1323,
    "frequency": 25019,
    "originalRank": 1396
  },
  {
    "word": "inocente",
    "rank": 1324,
    "frequency": 24983,
    "originalRank": 1397
  },
  {
    "word": "pesar",
    "rank": 1325,
    "frequency": 24982,
    "originalRank": 1398
  },
  {
    "word": "absoluto",
    "rank": 1326,
    "frequency": 24982,
    "originalRank": 1399
  },
  {
    "word": "vacaciones",
    "rank": 1327,
    "frequency": 24975,
    "originalRank": 1400
  },
  {
    "word": "mismos",
    "rank": 1328,
    "frequency": 24932,
    "originalRank": 1402
  },
  {
    "word": "tomado",
    "rank": 1329,
    "frequency": 24901,
    "originalRank": 1403
  },
  {
    "word": "habías",
    "rank": 1330,
    "frequency": 24885,
    "originalRank": 1404
  },
  {
    "word": "planes",
    "rank": 1331,
    "frequency": 24830,
    "originalRank": 1405
  },
  {
    "word": "cine",
    "rank": 1332,
    "frequency": 24776,
    "originalRank": 1406
  },
  {
    "word": "toca",
    "rank": 1333,
    "frequency": 24753,
    "originalRank": 1407
  },
  {
    "word": "brillante",
    "rank": 1334,
    "frequency": 24750,
    "originalRank": 1408
  },
  {
    "word": "confianza",
    "rank": 1335,
    "frequency": 24733,
    "originalRank": 1409
  },
  {
    "word": "vuestra",
    "rank": 1336,
    "frequency": 24707,
    "originalRank": 1410
  },
  {
    "word": "nombres",
    "rank": 1337,
    "frequency": 24706,
    "originalRank": 1411
  },
  {
    "word": "especialmente",
    "rank": 1338,
    "frequency": 24660,
    "originalRank": 1412
  },
  {
    "word": "fbi",
    "rank": 1339,
    "frequency": 24627,
    "originalRank": 1413
  },
  {
    "word": "embarazada",
    "rank": 1340,
    "frequency": 24625,
    "originalRank": 1414
  },
  {
    "word": "esperen",
    "rank": 1341,
    "frequency": 24616,
    "originalRank": 1415
  },
  {
    "word": "pantalones",
    "rank": 1342,
    "frequency": 24609,
    "originalRank": 1416
  },
  {
    "word": "defensa",
    "rank": 1343,
    "frequency": 24602,
    "originalRank": 1417
  },
  {
    "word": "terminó",
    "rank": 1344,
    "frequency": 24592,
    "originalRank": 1418
  },
  {
    "word": "salido",
    "rank": 1345,
    "frequency": 24556,
    "originalRank": 1419
  },
  {
    "word": "estupendo",
    "rank": 1346,
    "frequency": 24491,
    "originalRank": 1420
  },
  {
    "word": "jane",
    "rank": 1347,
    "frequency": 24469,
    "originalRank": 1421
  },
  {
    "word": "presión",
    "rank": 1348,
    "frequency": 24457,
    "originalRank": 1422
  },
  {
    "word": "inmediatamente",
    "rank": 1349,
    "frequency": 24410,
    "originalRank": 1423
  },
  {
    "word": "testigo",
    "rank": 1350,
    "frequency": 24402,
    "originalRank": 1424
  },
  {
    "word": "deberían",
    "rank": 1351,
    "frequency": 24391,
    "originalRank": 1425
  },
  {
    "word": "olvidado",
    "rank": 1352,
    "frequency": 24378,
    "originalRank": 1426
  },
  {
    "word": "soldados",
    "rank": 1353,
    "frequency": 24372,
    "originalRank": 1427
  },
  {
    "word": "resulta",
    "rank": 1354,
    "frequency": 24353,
    "originalRank": 1428
  },
  {
    "word": "tommy",
    "rank": 1355,
    "frequency": 24300,
    "originalRank": 1429
  },
  {
    "word": "depende",
    "rank": 1356,
    "frequency": 24282,
    "originalRank": 1430
  },
  {
    "word": "motivo",
    "rank": 1357,
    "frequency": 24276,
    "originalRank": 1431
  },
  {
    "word": "inglés",
    "rank": 1358,
    "frequency": 24267,
    "originalRank": 1432
  },
  {
    "word": "suya",
    "rank": 1359,
    "frequency": 24246,
    "originalRank": 1433
  },
  {
    "word": "estudio",
    "rank": 1360,
    "frequency": 24243,
    "originalRank": 1434
  },
  {
    "word": "acabar",
    "rank": 1361,
    "frequency": 24230,
    "originalRank": 1435
  },
  {
    "word": "sentimientos",
    "rank": 1362,
    "frequency": 24182,
    "originalRank": 1436
  },
  {
    "word": "tomando",
    "rank": 1363,
    "frequency": 24154,
    "originalRank": 1437
  },
  {
    "word": "dieron",
    "rank": 1364,
    "frequency": 24125,
    "originalRank": 1438
  },
  {
    "word": "parecen",
    "rank": 1365,
    "frequency": 24063,
    "originalRank": 1439
  },
  {
    "word": "llaves",
    "rank": 1366,
    "frequency": 24052,
    "originalRank": 1440
  },
  {
    "word": "perros",
    "rank": 1367,
    "frequency": 24037,
    "originalRank": 1441
  },
  {
    "word": "propósito",
    "rank": 1368,
    "frequency": 24020,
    "originalRank": 1442
  },
  {
    "word": "noticia",
    "rank": 1369,
    "frequency": 24010,
    "originalRank": 1443
  },
  {
    "word": "partir",
    "rank": 1370,
    "frequency": 23967,
    "originalRank": 1444
  },
  {
    "word": "vuestro",
    "rank": 1371,
    "frequency": 23967,
    "originalRank": 1445
  },
  {
    "word": "metros",
    "rank": 1372,
    "frequency": 23962,
    "originalRank": 1446
  },
  {
    "word": "santa",
    "rank": 1373,
    "frequency": 23959,
    "originalRank": 1447
  },
  {
    "word": "quedarse",
    "rank": 1374,
    "frequency": 23947,
    "originalRank": 1448
  },
  {
    "word": "clientes",
    "rank": 1375,
    "frequency": 23929,
    "originalRank": 1449
  },
  {
    "word": "podrá",
    "rank": 1376,
    "frequency": 23914,
    "originalRank": 1450
  },
  {
    "word": "cuántas",
    "rank": 1377,
    "frequency": 23906,
    "originalRank": 1451
  },
  {
    "word": "ridículo",
    "rank": 1378,
    "frequency": 23895,
    "originalRank": 1452
  },
  {
    "word": "damas",
    "rank": 1379,
    "frequency": 23894,
    "originalRank": 1453
  },
  {
    "word": "estuviste",
    "rank": 1380,
    "frequency": 23886,
    "originalRank": 1454
  },
  {
    "word": "tranquila",
    "rank": 1381,
    "frequency": 23875,
    "originalRank": 1455
  },
  {
    "word": "operación",
    "rank": 1382,
    "frequency": 23863,
    "originalRank": 1456
  },
  {
    "word": "come",
    "rank": 1383,
    "frequency": 23861,
    "originalRank": 1457
  },
  {
    "word": "empresa",
    "rank": 1384,
    "frequency": 23858,
    "originalRank": 1458
  },
  {
    "word": "ayúdame",
    "rank": 1385,
    "frequency": 23854,
    "originalRank": 1459
  },
  {
    "word": "laboratorio",
    "rank": 1386,
    "frequency": 23848,
    "originalRank": 1460
  },
  {
    "word": "elección",
    "rank": 1387,
    "frequency": 23826,
    "originalRank": 1461
  },
  {
    "word": "menudo",
    "rank": 1388,
    "frequency": 23817,
    "originalRank": 1462
  },
  {
    "word": "beso",
    "rank": 1389,
    "frequency": 23794,
    "originalRank": 1463
  },
  {
    "word": "copa",
    "rank": 1390,
    "frequency": 23750,
    "originalRank": 1464
  },
  {
    "word": "conversación",
    "rank": 1391,
    "frequency": 23746,
    "originalRank": 1465
  },
  {
    "word": "brazos",
    "rank": 1392,
    "frequency": 23717,
    "originalRank": 1466
  },
  {
    "word": "espíritu",
    "rank": 1393,
    "frequency": 23706,
    "originalRank": 1467
  },
  {
    "word": "dejas",
    "rank": 1394,
    "frequency": 23660,
    "originalRank": 1468
  },
  {
    "word": "cansado",
    "rank": 1395,
    "frequency": 23628,
    "originalRank": 1469
  },
  {
    "word": "interesa",
    "rank": 1396,
    "frequency": 23602,
    "originalRank": 1470
  },
  {
    "word": "refieres",
    "rank": 1397,
    "frequency": 23567,
    "originalRank": 1471
  },
  {
    "word": "casado",
    "rank": 1398,
    "frequency": 23560,
    "originalRank": 1472
  },
  {
    "word": "enorme",
    "rank": 1399,
    "frequency": 23535,
    "originalRank": 1473
  },
  {
    "word": "asuntos",
    "rank": 1400,
    "frequency": 23521,
    "originalRank": 1474
  },
  {
    "word": "muestra",
    "rank": 1401,
    "frequency": 23509,
    "originalRank": 1476
  },
  {
    "word": "trampa",
    "rank": 1402,
    "frequency": 23494,
    "originalRank": 1477
  },
  {
    "word": "ray",
    "rank": 1403,
    "frequency": 23492,
    "originalRank": 1478
  },
  {
    "word": "billy",
    "rank": 1404,
    "frequency": 23444,
    "originalRank": 1479
  },
  {
    "word": "memoria",
    "rank": 1405,
    "frequency": 23432,
    "originalRank": 1480
  },
  {
    "word": "johnny",
    "rank": 1406,
    "frequency": 23426,
    "originalRank": 1481
  },
  {
    "word": "contrario",
    "rank": 1407,
    "frequency": 23421,
    "originalRank": 1482
  },
  {
    "word": "soldado",
    "rank": 1408,
    "frequency": 23421,
    "originalRank": 1483
  },
  {
    "word": "subir",
    "rank": 1409,
    "frequency": 23413,
    "originalRank": 1484
  },
  {
    "word": "turno",
    "rank": 1410,
    "frequency": 23409,
    "originalRank": 1485
  },
  {
    "word": "encantaría",
    "rank": 1411,
    "frequency": 23397,
    "originalRank": 1486
  },
  {
    "word": "preocupado",
    "rank": 1412,
    "frequency": 23389,
    "originalRank": 1487
  },
  {
    "word": "restaurante",
    "rank": 1413,
    "frequency": 23371,
    "originalRank": 1488
  },
  {
    "word": "saliendo",
    "rank": 1414,
    "frequency": 23368,
    "originalRank": 1489
  },
  {
    "word": "escrito",
    "rank": 1415,
    "frequency": 23334,
    "originalRank": 1490
  },
  {
    "word": "cálmate",
    "rank": 1416,
    "frequency": 23322,
    "originalRank": 1491
  },
  {
    "word": "bienvenida",
    "rank": 1417,
    "frequency": 23320,
    "originalRank": 1492
  },
  {
    "word": "caer",
    "rank": 1418,
    "frequency": 23298,
    "originalRank": 1493
  },
  {
    "word": "llevaré",
    "rank": 1419,
    "frequency": 23274,
    "originalRank": 1494
  },
  {
    "word": "leche",
    "rank": 1420,
    "frequency": 23267,
    "originalRank": 1495
  },
  {
    "word": "estrellas",
    "rank": 1421,
    "frequency": 23265,
    "originalRank": 1496
  },
  {
    "word": "prefiero",
    "rank": 1422,
    "frequency": 23230,
    "originalRank": 1497
  },
  {
    "word": "red",
    "rank": 1423,
    "frequency": 23197,
    "originalRank": 1498
  },
  {
    "word": "viejos",
    "rank": 1424,
    "frequency": 23172,
    "originalRank": 1499
  },
  {
    "word": "solamente",
    "rank": 1425,
    "frequency": 23166,
    "originalRank": 1500
  },
  {
    "word": "oiga",
    "rank": 1426,
    "frequency": 23159,
    "originalRank": 1501
  },
  {
    "word": "estén",
    "rank": 1427,
    "frequency": 23127,
    "originalRank": 1502
  },
  {
    "word": "cuentas",
    "rank": 1428,
    "frequency": 23115,
    "originalRank": 1503
  },
  {
    "word": "taxi",
    "rank": 1429,
    "frequency": 23114,
    "originalRank": 1504
  },
  {
    "word": "anillo",
    "rank": 1430,
    "frequency": 23113,
    "originalRank": 1505
  },
  {
    "word": "richard",
    "rank": 1431,
    "frequency": 23102,
    "originalRank": 1506
  },
  {
    "word": "preguntar",
    "rank": 1432,
    "frequency": 23053,
    "originalRank": 1507
  },
  {
    "word": "victoria",
    "rank": 1433,
    "frequency": 23042,
    "originalRank": 1508
  },
  {
    "word": "quiénes",
    "rank": 1434,
    "frequency": 23032,
    "originalRank": 1509
  },
  {
    "word": "héroe",
    "rank": 1435,
    "frequency": 23032,
    "originalRank": 1510
  },
  {
    "word": "pequeños",
    "rank": 1436,
    "frequency": 23029,
    "originalRank": 1511
  },
  {
    "word": "decidido",
    "rank": 1437,
    "frequency": 23006,
    "originalRank": 1512
  },
  {
    "word": "películas",
    "rank": 1438,
    "frequency": 22995,
    "originalRank": 1513
  },
  {
    "word": "responsable",
    "rank": 1439,
    "frequency": 22954,
    "originalRank": 1514
  },
  {
    "word": "trago",
    "rank": 1440,
    "frequency": 22952,
    "originalRank": 1515
  },
  {
    "word": "volverá",
    "rank": 1441,
    "frequency": 22878,
    "originalRank": 1516
  },
  {
    "word": "árbol",
    "rank": 1442,
    "frequency": 22850,
    "originalRank": 1517
  },
  {
    "word": "ibas",
    "rank": 1443,
    "frequency": 22845,
    "originalRank": 1518
  },
  {
    "word": "dientes",
    "rank": 1444,
    "frequency": 22805,
    "originalRank": 1519
  },
  {
    "word": "encantado",
    "rank": 1445,
    "frequency": 22800,
    "originalRank": 1520
  },
  {
    "word": "camión",
    "rank": 1446,
    "frequency": 22794,
    "originalRank": 1521
  },
  {
    "word": "vender",
    "rank": 1447,
    "frequency": 22769,
    "originalRank": 1522
  },
  {
    "word": "llame",
    "rank": 1448,
    "frequency": 22752,
    "originalRank": 1523
  },
  {
    "word": "detente",
    "rank": 1449,
    "frequency": 22743,
    "originalRank": 1524
  },
  {
    "word": "luchar",
    "rank": 1450,
    "frequency": 22738,
    "originalRank": 1525
  },
  {
    "word": "cabo",
    "rank": 1451,
    "frequency": 22732,
    "originalRank": 1526
  },
  {
    "word": "ruido",
    "rank": 1452,
    "frequency": 22718,
    "originalRank": 1527
  },
  {
    "word": "lucha",
    "rank": 1453,
    "frequency": 22712,
    "originalRank": 1528
  },
  {
    "word": "muere",
    "rank": 1454,
    "frequency": 22695,
    "originalRank": 1529
  },
  {
    "word": "reloj",
    "rank": 1455,
    "frequency": 22691,
    "originalRank": 1530
  },
  {
    "word": "gato",
    "rank": 1456,
    "frequency": 22686,
    "originalRank": 1531
  },
  {
    "word": "averiguar",
    "rank": 1457,
    "frequency": 22670,
    "originalRank": 1532
  },
  {
    "word": "volar",
    "rank": 1458,
    "frequency": 22653,
    "originalRank": 1533
  },
  {
    "word": "vayamos",
    "rank": 1459,
    "frequency": 22640,
    "originalRank": 1534
  },
  {
    "word": "tanta",
    "rank": 1460,
    "frequency": 22574,
    "originalRank": 1535
  },
  {
    "word": "vendrá",
    "rank": 1461,
    "frequency": 22548,
    "originalRank": 1536
  },
  {
    "word": "corriendo",
    "rank": 1462,
    "frequency": 22534,
    "originalRank": 1537
  },
  {
    "word": "yendo",
    "rank": 1463,
    "frequency": 22518,
    "originalRank": 1538
  },
  {
    "word": "colegio",
    "rank": 1464,
    "frequency": 22498,
    "originalRank": 1539
  },
  {
    "word": "sonido",
    "rank": 1465,
    "frequency": 22444,
    "originalRank": 1540
  },
  {
    "word": "caballero",
    "rank": 1466,
    "frequency": 22412,
    "originalRank": 1541
  },
  {
    "word": "pasada",
    "rank": 1467,
    "frequency": 22393,
    "originalRank": 1542
  },
  {
    "word": "código",
    "rank": 1468,
    "frequency": 22378,
    "originalRank": 1543
  },
  {
    "word": "hagamos",
    "rank": 1469,
    "frequency": 22349,
    "originalRank": 1544
  },
  {
    "word": "imagen",
    "rank": 1470,
    "frequency": 22339,
    "originalRank": 1545
  },
  {
    "word": "riesgo",
    "rank": 1471,
    "frequency": 22336,
    "originalRank": 1546
  },
  {
    "word": "llegamos",
    "rank": 1472,
    "frequency": 22327,
    "originalRank": 1547
  },
  {
    "word": "alguno",
    "rank": 1473,
    "frequency": 22317,
    "originalRank": 1548
  },
  {
    "word": "pan",
    "rank": 1474,
    "frequency": 22311,
    "originalRank": 1549
  },
  {
    "word": "millón",
    "rank": 1475,
    "frequency": 22303,
    "originalRank": 1550
  },
  {
    "word": "malas",
    "rank": 1476,
    "frequency": 22295,
    "originalRank": 1551
  },
  {
    "word": "dama",
    "rank": 1477,
    "frequency": 22292,
    "originalRank": 1552
  },
  {
    "word": "hielo",
    "rank": 1478,
    "frequency": 22276,
    "originalRank": 1553
  },
  {
    "word": "coño",
    "rank": 1479,
    "frequency": 22270,
    "originalRank": 1554
  },
  {
    "word": "cayó",
    "rank": 1480,
    "frequency": 22244,
    "originalRank": 1555
  },
  {
    "word": "prensa",
    "rank": 1481,
    "frequency": 22244,
    "originalRank": 1556
  },
  {
    "word": "querer",
    "rank": 1482,
    "frequency": 22219,
    "originalRank": 1557
  },
  {
    "word": "vengan",
    "rank": 1483,
    "frequency": 22202,
    "originalRank": 1558
  },
  {
    "word": "eddie",
    "rank": 1484,
    "frequency": 22197,
    "originalRank": 1559
  },
  {
    "word": "caminar",
    "rank": 1485,
    "frequency": 22142,
    "originalRank": 1560
  },
  {
    "word": "televisión",
    "rank": 1486,
    "frequency": 22129,
    "originalRank": 1561
  },
  {
    "word": "pasará",
    "rank": 1487,
    "frequency": 22111,
    "originalRank": 1562
  },
  {
    "word": "momentos",
    "rank": 1488,
    "frequency": 22109,
    "originalRank": 1563
  },
  {
    "word": "coger",
    "rank": 1489,
    "frequency": 22105,
    "originalRank": 1564
  },
  {
    "word": "posibilidad",
    "rank": 1490,
    "frequency": 22104,
    "originalRank": 1565
  },
  {
    "word": "hubiese",
    "rank": 1491,
    "frequency": 22099,
    "originalRank": 1566
  },
  {
    "word": "mark",
    "rank": 1492,
    "frequency": 22087,
    "originalRank": 1567
  },
  {
    "word": "asiento",
    "rank": 1493,
    "frequency": 22080,
    "originalRank": 1568
  },
  {
    "word": "tuviste",
    "rank": 1494,
    "frequency": 22061,
    "originalRank": 1569
  },
  {
    "word": "herido",
    "rank": 1495,
    "frequency": 22044,
    "originalRank": 1570
  },
  {
    "word": "maría",
    "rank": 1496,
    "frequency": 22039,
    "originalRank": 1571
  },
  {
    "word": "seguramente",
    "rank": 1497,
    "frequency": 22019,
    "originalRank": 1572
  },
  {
    "word": "proyecto",
    "rank": 1498,
    "frequency": 22007,
    "originalRank": 1573
  },
  {
    "word": "pared",
    "rank": 1499,
    "frequency": 21999,
    "originalRank": 1574
  },
  {
    "word": "sentí",
    "rank": 1500,
    "frequency": 21974,
    "originalRank": 1575
  },
  {
    "word": "sospechoso",
    "rank": 1501,
    "frequency": 21933,
    "originalRank": 1576
  },
  {
    "word": "naturaleza",
    "rank": 1502,
    "frequency": 21922,
    "originalRank": 1577
  },
  {
    "word": "ésa",
    "rank": 1503,
    "frequency": 21914,
    "originalRank": 1578
  },
  {
    "word": "silla",
    "rank": 1504,
    "frequency": 21910,
    "originalRank": 1579
  },
  {
    "word": "perdió",
    "rank": 1505,
    "frequency": 21883,
    "originalRank": 1580
  },
  {
    "word": "robert",
    "rank": 1506,
    "frequency": 21882,
    "originalRank": 1581
  },
  {
    "word": "policías",
    "rank": 1507,
    "frequency": 21865,
    "originalRank": 1582
  },
  {
    "word": "arreglar",
    "rank": 1508,
    "frequency": 21854,
    "originalRank": 1583
  },
  {
    "word": "sentado",
    "rank": 1509,
    "frequency": 21849,
    "originalRank": 1584
  },
  {
    "word": "papi",
    "rank": 1510,
    "frequency": 21806,
    "originalRank": 1585
  },
  {
    "word": "ideas",
    "rank": 1511,
    "frequency": 21803,
    "originalRank": 1586
  },
  {
    "word": "obtener",
    "rank": 1512,
    "frequency": 21789,
    "originalRank": 1587
  },
  {
    "word": "felices",
    "rank": 1513,
    "frequency": 21789,
    "originalRank": 1588
  },
  {
    "word": "señoría",
    "rank": 1514,
    "frequency": 21787,
    "originalRank": 1589
  },
  {
    "word": "cantidad",
    "rank": 1515,
    "frequency": 21766,
    "originalRank": 1590
  },
  {
    "word": "bebe",
    "rank": 1516,
    "frequency": 21749,
    "originalRank": 1591
  },
  {
    "word": "mírame",
    "rank": 1517,
    "frequency": 21736,
    "originalRank": 1592
  },
  {
    "word": "chris",
    "rank": 1518,
    "frequency": 21736,
    "originalRank": 1593
  },
  {
    "word": "papa",
    "rank": 1519,
    "frequency": 21732,
    "originalRank": 1594
  },
  {
    "word": "llorar",
    "rank": 1520,
    "frequency": 21694,
    "originalRank": 1595
  },
  {
    "word": "quedó",
    "rank": 1521,
    "frequency": 21686,
    "originalRank": 1596
  },
  {
    "word": "familiar",
    "rank": 1522,
    "frequency": 21678,
    "originalRank": 1597
  },
  {
    "word": "desastre",
    "rank": 1523,
    "frequency": 21670,
    "originalRank": 1598
  },
  {
    "word": "locos",
    "rank": 1524,
    "frequency": 21665,
    "originalRank": 1599
  },
  {
    "word": "escuche",
    "rank": 1525,
    "frequency": 21649,
    "originalRank": 1600
  },
  {
    "word": "quedarte",
    "rank": 1526,
    "frequency": 21600,
    "originalRank": 1601
  },
  {
    "word": "política",
    "rank": 1527,
    "frequency": 21599,
    "originalRank": 1602
  },
  {
    "word": "pedí",
    "rank": 1528,
    "frequency": 21552,
    "originalRank": 1603
  },
  {
    "word": "sois",
    "rank": 1529,
    "frequency": 21542,
    "originalRank": 1604
  },
  {
    "word": "nosotras",
    "rank": 1530,
    "frequency": 21518,
    "originalRank": 1605
  },
  {
    "word": "will",
    "rank": 1531,
    "frequency": 21495,
    "originalRank": 1606
  },
  {
    "word": "enfermedad",
    "rank": 1532,
    "frequency": 21473,
    "originalRank": 1607
  },
  {
    "word": "encontraron",
    "rank": 1533,
    "frequency": 21470,
    "originalRank": 1608
  },
  {
    "word": "colega",
    "rank": 1534,
    "frequency": 21456,
    "originalRank": 1609
  },
  {
    "word": "príncipe",
    "rank": 1535,
    "frequency": 21442,
    "originalRank": 1610
  },
  {
    "word": "verde",
    "rank": 1536,
    "frequency": 21441,
    "originalRank": 1611
  },
  {
    "word": "bajar",
    "rank": 1537,
    "frequency": 21421,
    "originalRank": 1612
  },
  {
    "word": "nervioso",
    "rank": 1538,
    "frequency": 21417,
    "originalRank": 1613
  },
  {
    "word": "vengo",
    "rank": 1539,
    "frequency": 21415,
    "originalRank": 1614
  },
  {
    "word": "inspector",
    "rank": 1540,
    "frequency": 21393,
    "originalRank": 1615
  },
  {
    "word": "sirve",
    "rank": 1541,
    "frequency": 21373,
    "originalRank": 1616
  },
  {
    "word": "puertas",
    "rank": 1542,
    "frequency": 21366,
    "originalRank": 1617
  },
  {
    "word": "fuerzas",
    "rank": 1543,
    "frequency": 21362,
    "originalRank": 1618
  },
  {
    "word": "playa",
    "rank": 1544,
    "frequency": 21337,
    "originalRank": 1619
  },
  {
    "word": "cantar",
    "rank": 1545,
    "frequency": 21325,
    "originalRank": 1620
  },
  {
    "word": "déjeme",
    "rank": 1546,
    "frequency": 21323,
    "originalRank": 1621
  },
  {
    "word": "velocidad",
    "rank": 1547,
    "frequency": 21309,
    "originalRank": 1622
  },
  {
    "word": "total",
    "rank": 1548,
    "frequency": 21272,
    "originalRank": 1623
  },
  {
    "word": "cabello",
    "rank": 1549,
    "frequency": 21256,
    "originalRank": 1624
  },
  {
    "word": "suficientemente",
    "rank": 1550,
    "frequency": 21229,
    "originalRank": 1625
  },
  {
    "word": "huellas",
    "rank": 1551,
    "frequency": 21222,
    "originalRank": 1626
  },
  {
    "word": "haberte",
    "rank": 1552,
    "frequency": 21198,
    "originalRank": 1627
  },
  {
    "word": "debí",
    "rank": 1553,
    "frequency": 21196,
    "originalRank": 1628
  },
  {
    "word": "unidad",
    "rank": 1554,
    "frequency": 21181,
    "originalRank": 1629
  },
  {
    "word": "estan",
    "rank": 1555,
    "frequency": 21171,
    "originalRank": 1630
  },
  {
    "word": "cuchillo",
    "rank": 1556,
    "frequency": 21138,
    "originalRank": 1631
  },
  {
    "word": "oigan",
    "rank": 1557,
    "frequency": 21109,
    "originalRank": 1633
  },
  {
    "word": "quienes",
    "rank": 1558,
    "frequency": 21083,
    "originalRank": 1634
  },
  {
    "word": "gana",
    "rank": 1559,
    "frequency": 21078,
    "originalRank": 1635
  },
  {
    "word": "tonterías",
    "rank": 1560,
    "frequency": 21068,
    "originalRank": 1636
  },
  {
    "word": "emergencia",
    "rank": 1561,
    "frequency": 21060,
    "originalRank": 1637
  },
  {
    "word": "perfecta",
    "rank": 1562,
    "frequency": 21035,
    "originalRank": 1638
  },
  {
    "word": "hable",
    "rank": 1563,
    "frequency": 21026,
    "originalRank": 1639
  },
  {
    "word": "gustaba",
    "rank": 1564,
    "frequency": 21015,
    "originalRank": 1640
  },
  {
    "word": "lugares",
    "rank": 1565,
    "frequency": 21005,
    "originalRank": 1641
  },
  {
    "word": "ryan",
    "rank": 1566,
    "frequency": 20997,
    "originalRank": 1642
  },
  {
    "word": "show",
    "rank": 1567,
    "frequency": 20965,
    "originalRank": 1643
  },
  {
    "word": "robo",
    "rank": 1568,
    "frequency": 20955,
    "originalRank": 1644
  },
  {
    "word": "permite",
    "rank": 1569,
    "frequency": 20946,
    "originalRank": 1645
  },
  {
    "word": "parque",
    "rank": 1570,
    "frequency": 20907,
    "originalRank": 1646
  },
  {
    "word": "roto",
    "rank": 1571,
    "frequency": 20900,
    "originalRank": 1648
  },
  {
    "word": "serie",
    "rank": 1572,
    "frequency": 20857,
    "originalRank": 1649
  },
  {
    "word": "puse",
    "rank": 1573,
    "frequency": 20843,
    "originalRank": 1650
  },
  {
    "word": "nuevas",
    "rank": 1574,
    "frequency": 20833,
    "originalRank": 1651
  },
  {
    "word": "evidencia",
    "rank": 1575,
    "frequency": 20831,
    "originalRank": 1652
  },
  {
    "word": "conocerte",
    "rank": 1576,
    "frequency": 20819,
    "originalRank": 1653
  },
  {
    "word": "estúpida",
    "rank": 1577,
    "frequency": 20818,
    "originalRank": 1654
  },
  {
    "word": "preocupe",
    "rank": 1578,
    "frequency": 20779,
    "originalRank": 1655
  },
  {
    "word": "perdone",
    "rank": 1579,
    "frequency": 20775,
    "originalRank": 1656
  },
  {
    "word": "botella",
    "rank": 1580,
    "frequency": 20774,
    "originalRank": 1657
  },
  {
    "word": "viento",
    "rank": 1581,
    "frequency": 20773,
    "originalRank": 1658
  },
  {
    "word": "mando",
    "rank": 1582,
    "frequency": 20743,
    "originalRank": 1659
  },
  {
    "word": "extraña",
    "rank": 1583,
    "frequency": 20742,
    "originalRank": 1660
  },
  {
    "word": "historias",
    "rank": 1584,
    "frequency": 20732,
    "originalRank": 1661
  },
  {
    "word": "aquella",
    "rank": 1585,
    "frequency": 20688,
    "originalRank": 1662
  },
  {
    "word": "tenéis",
    "rank": 1586,
    "frequency": 20682,
    "originalRank": 1663
  },
  {
    "word": "solos",
    "rank": 1587,
    "frequency": 20664,
    "originalRank": 1664
  },
  {
    "word": "apoyo",
    "rank": 1588,
    "frequency": 20643,
    "originalRank": 1665
  },
  {
    "word": "bala",
    "rank": 1589,
    "frequency": 20634,
    "originalRank": 1666
  },
  {
    "word": "verdadera",
    "rank": 1590,
    "frequency": 20627,
    "originalRank": 1667
  },
  {
    "word": "tiro",
    "rank": 1591,
    "frequency": 20610,
    "originalRank": 1668
  },
  {
    "word": "época",
    "rank": 1592,
    "frequency": 20604,
    "originalRank": 1669
  },
  {
    "word": "puente",
    "rank": 1593,
    "frequency": 20603,
    "originalRank": 1670
  },
  {
    "word": "olvídalo",
    "rank": 1594,
    "frequency": 20576,
    "originalRank": 1671
  },
  {
    "word": "distancia",
    "rank": 1595,
    "frequency": 20553,
    "originalRank": 1672
  },
  {
    "word": "desea",
    "rank": 1596,
    "frequency": 20441,
    "originalRank": 1673
  },
  {
    "word": "dejarlo",
    "rank": 1597,
    "frequency": 20439,
    "originalRank": 1674
  },
  {
    "word": "pelear",
    "rank": 1598,
    "frequency": 20435,
    "originalRank": 1675
  },
  {
    "word": "pierna",
    "rank": 1599,
    "frequency": 20434,
    "originalRank": 1676
  },
  {
    "word": "echar",
    "rank": 1600,
    "frequency": 20410,
    "originalRank": 1677
  },
  {
    "word": "descanso",
    "rank": 1601,
    "frequency": 20410,
    "originalRank": 1678
  },
  {
    "word": "américa",
    "rank": 1602,
    "frequency": 20401,
    "originalRank": 1679
  },
  {
    "word": "área",
    "rank": 1603,
    "frequency": 20386,
    "originalRank": 1680
  },
  {
    "word": "orgulloso",
    "rank": 1604,
    "frequency": 20378,
    "originalRank": 1681
  },
  {
    "word": "datos",
    "rank": 1605,
    "frequency": 20352,
    "originalRank": 1682
  },
  {
    "word": "espectáculo",
    "rank": 1606,
    "frequency": 20331,
    "originalRank": 1683
  },
  {
    "word": "sube",
    "rank": 1607,
    "frequency": 20325,
    "originalRank": 1684
  },
  {
    "word": "dejaste",
    "rank": 1608,
    "frequency": 20322,
    "originalRank": 1685
  },
  {
    "word": "acabas",
    "rank": 1609,
    "frequency": 20315,
    "originalRank": 1686
  },
  {
    "word": "verá",
    "rank": 1610,
    "frequency": 20295,
    "originalRank": 1687
  },
  {
    "word": "magia",
    "rank": 1611,
    "frequency": 20292,
    "originalRank": 1688
  },
  {
    "word": "nacional",
    "rank": 1612,
    "frequency": 20291,
    "originalRank": 1689
  },
  {
    "word": "universo",
    "rank": 1613,
    "frequency": 20289,
    "originalRank": 1690
  },
  {
    "word": "llevaba",
    "rank": 1614,
    "frequency": 20253,
    "originalRank": 1691
  },
  {
    "word": "necesitar",
    "rank": 1615,
    "frequency": 20251,
    "originalRank": 1692
  },
  {
    "word": "nariz",
    "rank": 1616,
    "frequency": 20247,
    "originalRank": 1693
  },
  {
    "word": "aquellos",
    "rank": 1617,
    "frequency": 20238,
    "originalRank": 1694
  },
  {
    "word": "clases",
    "rank": 1618,
    "frequency": 20203,
    "originalRank": 1695
  },
  {
    "word": "jake",
    "rank": 1619,
    "frequency": 20197,
    "originalRank": 1696
  },
  {
    "word": "casas",
    "rank": 1620,
    "frequency": 20193,
    "originalRank": 1697
  },
  {
    "word": "vergüenza",
    "rank": 1621,
    "frequency": 20189,
    "originalRank": 1698
  },
  {
    "word": "estarán",
    "rank": 1622,
    "frequency": 20164,
    "originalRank": 1699
  },
  {
    "word": "monstruo",
    "rank": 1623,
    "frequency": 20156,
    "originalRank": 1700
  },
  {
    "word": "princesa",
    "rank": 1624,
    "frequency": 20154,
    "originalRank": 1701
  },
  {
    "word": "autobús",
    "rank": 1625,
    "frequency": 20079,
    "originalRank": 1702
  },
  {
    "word": "cuidar",
    "rank": 1626,
    "frequency": 20066,
    "originalRank": 1703
  },
  {
    "word": "huevos",
    "rank": 1627,
    "frequency": 20054,
    "originalRank": 1705
  },
  {
    "word": "pocos",
    "rank": 1628,
    "frequency": 20047,
    "originalRank": 1706
  },
  {
    "word": "podrás",
    "rank": 1629,
    "frequency": 20047,
    "originalRank": 1707
  },
  {
    "word": "enferma",
    "rank": 1630,
    "frequency": 20044,
    "originalRank": 1708
  },
  {
    "word": "paseo",
    "rank": 1631,
    "frequency": 20024,
    "originalRank": 1709
  },
  {
    "word": "detalles",
    "rank": 1632,
    "frequency": 20017,
    "originalRank": 1710
  },
  {
    "word": "llamadas",
    "rank": 1633,
    "frequency": 19977,
    "originalRank": 1711
  },
  {
    "word": "belleza",
    "rank": 1634,
    "frequency": 19964,
    "originalRank": 1712
  },
  {
    "word": "francia",
    "rank": 1635,
    "frequency": 19957,
    "originalRank": 1713
  },
  {
    "word": "abierto",
    "rank": 1636,
    "frequency": 19934,
    "originalRank": 1714
  },
  {
    "word": "viviendo",
    "rank": 1637,
    "frequency": 19922,
    "originalRank": 1715
  },
  {
    "word": "envió",
    "rank": 1638,
    "frequency": 19919,
    "originalRank": 1716
  },
  {
    "word": "puntos",
    "rank": 1639,
    "frequency": 19907,
    "originalRank": 1717
  },
  {
    "word": "ministro",
    "rank": 1640,
    "frequency": 19906,
    "originalRank": 1718
  },
  {
    "word": "conducir",
    "rank": 1641,
    "frequency": 19903,
    "originalRank": 1719
  },
  {
    "word": "aceptar",
    "rank": 1642,
    "frequency": 19883,
    "originalRank": 1720
  },
  {
    "word": "borracho",
    "rank": 1643,
    "frequency": 19877,
    "originalRank": 1721
  },
  {
    "word": "animal",
    "rank": 1644,
    "frequency": 19868,
    "originalRank": 1722
  },
  {
    "word": "caballos",
    "rank": 1645,
    "frequency": 19849,
    "originalRank": 1723
  },
  {
    "word": "trajo",
    "rank": 1646,
    "frequency": 19847,
    "originalRank": 1724
  },
  {
    "word": "contrato",
    "rank": 1647,
    "frequency": 19843,
    "originalRank": 1725
  },
  {
    "word": "viernes",
    "rank": 1648,
    "frequency": 19829,
    "originalRank": 1726
  },
  {
    "word": "bobby",
    "rank": 1649,
    "frequency": 19818,
    "originalRank": 1727
  },
  {
    "word": "martin",
    "rank": 1650,
    "frequency": 19801,
    "originalRank": 1728
  },
  {
    "word": "amy",
    "rank": 1651,
    "frequency": 19792,
    "originalRank": 1729
  },
  {
    "word": "bienvenidos",
    "rank": 1652,
    "frequency": 19776,
    "originalRank": 1730
  },
  {
    "word": "hechos",
    "rank": 1653,
    "frequency": 19742,
    "originalRank": 1732
  },
  {
    "word": "sociedad",
    "rank": 1654,
    "frequency": 19735,
    "originalRank": 1733
  },
  {
    "word": "tengan",
    "rank": 1655,
    "frequency": 19713,
    "originalRank": 1735
  },
  {
    "word": "quede",
    "rank": 1656,
    "frequency": 19709,
    "originalRank": 1736
  },
  {
    "word": "inglaterra",
    "rank": 1657,
    "frequency": 19670,
    "originalRank": 1737
  },
  {
    "word": "carga",
    "rank": 1658,
    "frequency": 19641,
    "originalRank": 1738
  },
  {
    "word": "diste",
    "rank": 1659,
    "frequency": 19621,
    "originalRank": 1739
  },
  {
    "word": "puto",
    "rank": 1660,
    "frequency": 19606,
    "originalRank": 1740
  },
  {
    "word": "lleve",
    "rank": 1661,
    "frequency": 19572,
    "originalRank": 1741
  },
  {
    "word": "presente",
    "rank": 1662,
    "frequency": 19563,
    "originalRank": 1742
  },
  {
    "word": "conocía",
    "rank": 1663,
    "frequency": 19553,
    "originalRank": 1743
  },
  {
    "word": "uso",
    "rank": 1664,
    "frequency": 19551,
    "originalRank": 1744
  },
  {
    "word": "dedos",
    "rank": 1665,
    "frequency": 19533,
    "originalRank": 1745
  },
  {
    "word": "oferta",
    "rank": 1666,
    "frequency": 19526,
    "originalRank": 1746
  },
  {
    "word": "sentía",
    "rank": 1667,
    "frequency": 19508,
    "originalRank": 1747
  },
  {
    "word": "proteger",
    "rank": 1668,
    "frequency": 19493,
    "originalRank": 1748
  },
  {
    "word": "daniel",
    "rank": 1669,
    "frequency": 19492,
    "originalRank": 1749
  },
  {
    "word": "date",
    "rank": 1670,
    "frequency": 19473,
    "originalRank": 1750
  },
  {
    "word": "hiciera",
    "rank": 1671,
    "frequency": 19472,
    "originalRank": 1751
  },
  {
    "word": "hablé",
    "rank": 1672,
    "frequency": 19472,
    "originalRank": 1752
  },
  {
    "word": "recibir",
    "rank": 1673,
    "frequency": 19460,
    "originalRank": 1753
  },
  {
    "word": "agradezco",
    "rank": 1674,
    "frequency": 19454,
    "originalRank": 1754
  },
  {
    "word": "robar",
    "rank": 1675,
    "frequency": 19448,
    "originalRank": 1755
  },
  {
    "word": "enamorado",
    "rank": 1676,
    "frequency": 19418,
    "originalRank": 1756
  },
  {
    "word": "sepas",
    "rank": 1677,
    "frequency": 19411,
    "originalRank": 1757
  },
  {
    "word": "oeste",
    "rank": 1678,
    "frequency": 19385,
    "originalRank": 1758
  },
  {
    "word": "herida",
    "rank": 1679,
    "frequency": 19379,
    "originalRank": 1759
  },
  {
    "word": "despacio",
    "rank": 1680,
    "frequency": 19378,
    "originalRank": 1760
  },
  {
    "word": "ayude",
    "rank": 1681,
    "frequency": 19348,
    "originalRank": 1761
  },
  {
    "word": "supe",
    "rank": 1682,
    "frequency": 19311,
    "originalRank": 1762
  },
  {
    "word": "directamente",
    "rank": 1683,
    "frequency": 19298,
    "originalRank": 1763
  },
  {
    "word": "inmediato",
    "rank": 1684,
    "frequency": 19291,
    "originalRank": 1764
  },
  {
    "word": "profesional",
    "rank": 1685,
    "frequency": 19290,
    "originalRank": 1765
  },
  {
    "word": "oscuro",
    "rank": 1686,
    "frequency": 19262,
    "originalRank": 1766
  },
  {
    "word": "mercado",
    "rank": 1687,
    "frequency": 19238,
    "originalRank": 1767
  },
  {
    "word": "cerdo",
    "rank": 1688,
    "frequency": 19233,
    "originalRank": 1768
  },
  {
    "word": "tardes",
    "rank": 1689,
    "frequency": 19219,
    "originalRank": 1769
  },
  {
    "word": "líder",
    "rank": 1690,
    "frequency": 19206,
    "originalRank": 1770
  },
  {
    "word": "grave",
    "rank": 1691,
    "frequency": 19202,
    "originalRank": 1771
  },
  {
    "word": "llegué",
    "rank": 1692,
    "frequency": 19194,
    "originalRank": 1772
  },
  {
    "word": "jurado",
    "rank": 1693,
    "frequency": 19187,
    "originalRank": 1773
  },
  {
    "word": "casos",
    "rank": 1694,
    "frequency": 19157,
    "originalRank": 1774
  },
  {
    "word": "acuerdas",
    "rank": 1695,
    "frequency": 19130,
    "originalRank": 1775
  },
  {
    "word": "ahi",
    "rank": 1696,
    "frequency": 19103,
    "originalRank": 1776
  },
  {
    "word": "desaparecido",
    "rank": 1697,
    "frequency": 19097,
    "originalRank": 1777
  },
  {
    "word": "debió",
    "rank": 1698,
    "frequency": 19085,
    "originalRank": 1778
  },
  {
    "word": "hubieras",
    "rank": 1699,
    "frequency": 19078,
    "originalRank": 1779
  },
  {
    "word": "últimamente",
    "rank": 1700,
    "frequency": 19064,
    "originalRank": 1780
  },
  {
    "word": "piedra",
    "rank": 1701,
    "frequency": 19060,
    "originalRank": 1781
  },
  {
    "word": "éramos",
    "rank": 1702,
    "frequency": 19034,
    "originalRank": 1782
  },
  {
    "word": "habló",
    "rank": 1703,
    "frequency": 19032,
    "originalRank": 1783
  },
  {
    "word": "charles",
    "rank": 1704,
    "frequency": 19029,
    "originalRank": 1784
  },
  {
    "word": "paga",
    "rank": 1705,
    "frequency": 19027,
    "originalRank": 1785
  },
  {
    "word": "secretos",
    "rank": 1706,
    "frequency": 19018,
    "originalRank": 1786
  },
  {
    "word": "digamos",
    "rank": 1707,
    "frequency": 19007,
    "originalRank": 1787
  },
  {
    "word": "intención",
    "rank": 1708,
    "frequency": 18986,
    "originalRank": 1788
  },
  {
    "word": "humor",
    "rank": 1709,
    "frequency": 18982,
    "originalRank": 1789
  },
  {
    "word": "dura",
    "rank": 1710,
    "frequency": 18977,
    "originalRank": 1790
  },
  {
    "word": "dará",
    "rank": 1711,
    "frequency": 18969,
    "originalRank": 1791
  },
  {
    "word": "seguros",
    "rank": 1712,
    "frequency": 18944,
    "originalRank": 1792
  },
  {
    "word": "leo",
    "rank": 1713,
    "frequency": 18940,
    "originalRank": 1793
  },
  {
    "word": "adam",
    "rank": 1714,
    "frequency": 18930,
    "originalRank": 1794
  },
  {
    "word": "and",
    "rank": 1715,
    "frequency": 18928,
    "originalRank": 1795
  },
  {
    "word": "ángeles",
    "rank": 1716,
    "frequency": 18922,
    "originalRank": 1796
  },
  {
    "word": "querría",
    "rank": 1717,
    "frequency": 18897,
    "originalRank": 1797
  },
  {
    "word": "cerrar",
    "rank": 1718,
    "frequency": 18896,
    "originalRank": 1798
  },
  {
    "word": "conseguido",
    "rank": 1719,
    "frequency": 18891,
    "originalRank": 1799
  },
  {
    "word": "peso",
    "rank": 1720,
    "frequency": 18884,
    "originalRank": 1800
  },
  {
    "word": "víctimas",
    "rank": 1721,
    "frequency": 18882,
    "originalRank": 1801
  },
  {
    "word": "asesinado",
    "rank": 1722,
    "frequency": 18877,
    "originalRank": 1802
  },
  {
    "word": "humana",
    "rank": 1723,
    "frequency": 18861,
    "originalRank": 1803
  },
  {
    "word": "directo",
    "rank": 1724,
    "frequency": 18825,
    "originalRank": 1804
  },
  {
    "word": "central",
    "rank": 1725,
    "frequency": 18819,
    "originalRank": 1805
  },
  {
    "word": "termina",
    "rank": 1726,
    "frequency": 18800,
    "originalRank": 1806
  },
  {
    "word": "compañeros",
    "rank": 1727,
    "frequency": 18800,
    "originalRank": 1807
  },
  {
    "word": "escuchado",
    "rank": 1728,
    "frequency": 18797,
    "originalRank": 1808
  },
  {
    "word": "contento",
    "rank": 1729,
    "frequency": 18786,
    "originalRank": 1809
  },
  {
    "word": "llevan",
    "rank": 1730,
    "frequency": 18778,
    "originalRank": 1810
  },
  {
    "word": "podré",
    "rank": 1731,
    "frequency": 18777,
    "originalRank": 1811
  },
  {
    "word": "oscuridad",
    "rank": 1732,
    "frequency": 18776,
    "originalRank": 1812
  },
  {
    "word": "actuar",
    "rank": 1733,
    "frequency": 18776,
    "originalRank": 1813
  },
  {
    "word": "siga",
    "rank": 1734,
    "frequency": 18750,
    "originalRank": 1814
  },
  {
    "word": "llevado",
    "rank": 1735,
    "frequency": 18750,
    "originalRank": 1815
  },
  {
    "word": "comenzó",
    "rank": 1736,
    "frequency": 18749,
    "originalRank": 1816
  },
  {
    "word": "regresa",
    "rank": 1737,
    "frequency": 18683,
    "originalRank": 1817
  },
  {
    "word": "privado",
    "rank": 1738,
    "frequency": 18675,
    "originalRank": 1818
  },
  {
    "word": "mirada",
    "rank": 1739,
    "frequency": 18665,
    "originalRank": 1819
  },
  {
    "word": "demonio",
    "rank": 1740,
    "frequency": 18645,
    "originalRank": 1820
  },
  {
    "word": "abierta",
    "rank": 1741,
    "frequency": 18639,
    "originalRank": 1821
  },
  {
    "word": "kevin",
    "rank": 1742,
    "frequency": 18631,
    "originalRank": 1822
  },
  {
    "word": "llámame",
    "rank": 1743,
    "frequency": 18616,
    "originalRank": 1824
  },
  {
    "word": "siguen",
    "rank": 1744,
    "frequency": 18607,
    "originalRank": 1825
  },
  {
    "word": "romper",
    "rank": 1745,
    "frequency": 18603,
    "originalRank": 1826
  },
  {
    "word": "cambia",
    "rank": 1746,
    "frequency": 18593,
    "originalRank": 1827
  },
  {
    "word": "fiscal",
    "rank": 1747,
    "frequency": 18580,
    "originalRank": 1828
  },
  {
    "word": "jardín",
    "rank": 1748,
    "frequency": 18576,
    "originalRank": 1829
  },
  {
    "word": "natural",
    "rank": 1749,
    "frequency": 18570,
    "originalRank": 1830
  },
  {
    "word": "gratis",
    "rank": 1750,
    "frequency": 18558,
    "originalRank": 1831
  },
  {
    "word": "cuesta",
    "rank": 1751,
    "frequency": 18552,
    "originalRank": 1832
  },
  {
    "word": "amenaza",
    "rank": 1752,
    "frequency": 18551,
    "originalRank": 1833
  },
  {
    "word": "pon",
    "rank": 1753,
    "frequency": 18533,
    "originalRank": 1834
  },
  {
    "word": "marca",
    "rank": 1754,
    "frequency": 18531,
    "originalRank": 1835
  },
  {
    "word": "comenzar",
    "rank": 1755,
    "frequency": 18527,
    "originalRank": 1836
  },
  {
    "word": "ponte",
    "rank": 1756,
    "frequency": 18522,
    "originalRank": 1837
  },
  {
    "word": "medicina",
    "rank": 1757,
    "frequency": 18521,
    "originalRank": 1838
  },
  {
    "word": "podremos",
    "rank": 1758,
    "frequency": 18514,
    "originalRank": 1839
  },
  {
    "word": "tomé",
    "rank": 1759,
    "frequency": 18506,
    "originalRank": 1840
  },
  {
    "word": "preciosa",
    "rank": 1760,
    "frequency": 18505,
    "originalRank": 1841
  },
  {
    "word": "sexual",
    "rank": 1761,
    "frequency": 18471,
    "originalRank": 1842
  },
  {
    "word": "acceso",
    "rank": 1762,
    "frequency": 18465,
    "originalRank": 1843
  },
  {
    "word": "necesidad",
    "rank": 1763,
    "frequency": 18452,
    "originalRank": 1844
  },
  {
    "word": "dueño",
    "rank": 1764,
    "frequency": 18451,
    "originalRank": 1845
  },
  {
    "word": "merece",
    "rank": 1765,
    "frequency": 18449,
    "originalRank": 1846
  },
  {
    "word": "rayos",
    "rank": 1766,
    "frequency": 18443,
    "originalRank": 1847
  },
  {
    "word": "mintiendo",
    "rank": 1767,
    "frequency": 18424,
    "originalRank": 1849
  },
  {
    "word": "tantas",
    "rank": 1768,
    "frequency": 18422,
    "originalRank": 1850
  },
  {
    "word": "imagino",
    "rank": 1769,
    "frequency": 18413,
    "originalRank": 1851
  },
  {
    "word": "fantasma",
    "rank": 1770,
    "frequency": 18394,
    "originalRank": 1852
  },
  {
    "word": "creerlo",
    "rank": 1771,
    "frequency": 18393,
    "originalRank": 1853
  },
  {
    "word": "llamé",
    "rank": 1772,
    "frequency": 18365,
    "originalRank": 1854
  },
  {
    "word": "ponga",
    "rank": 1773,
    "frequency": 18359,
    "originalRank": 1855
  },
  {
    "word": "brian",
    "rank": 1774,
    "frequency": 18329,
    "originalRank": 1856
  },
  {
    "word": "pollo",
    "rank": 1775,
    "frequency": 18307,
    "originalRank": 1858
  },
  {
    "word": "varios",
    "rank": 1776,
    "frequency": 18306,
    "originalRank": 1859
  },
  {
    "word": "efecto",
    "rank": 1777,
    "frequency": 18305,
    "originalRank": 1860
  },
  {
    "word": "felicidad",
    "rank": 1778,
    "frequency": 18269,
    "originalRank": 1861
  },
  {
    "word": "espada",
    "rank": 1779,
    "frequency": 18248,
    "originalRank": 1862
  },
  {
    "word": "relaciones",
    "rank": 1780,
    "frequency": 18244,
    "originalRank": 1863
  },
  {
    "word": "entró",
    "rank": 1781,
    "frequency": 18211,
    "originalRank": 1864
  },
  {
    "word": "resultado",
    "rank": 1782,
    "frequency": 18197,
    "originalRank": 1865
  },
  {
    "word": "sombrero",
    "rank": 1783,
    "frequency": 18197,
    "originalRank": 1866
  },
  {
    "word": "menor",
    "rank": 1784,
    "frequency": 18196,
    "originalRank": 1867
  },
  {
    "word": "recibido",
    "rank": 1785,
    "frequency": 18139,
    "originalRank": 1868
  },
  {
    "word": "negra",
    "rank": 1786,
    "frequency": 18132,
    "originalRank": 1869
  },
  {
    "word": "habido",
    "rank": 1787,
    "frequency": 18114,
    "originalRank": 1871
  },
  {
    "word": "limpio",
    "rank": 1788,
    "frequency": 18098,
    "originalRank": 1872
  },
  {
    "word": "china",
    "rank": 1789,
    "frequency": 18078,
    "originalRank": 1873
  },
  {
    "word": "juegos",
    "rank": 1790,
    "frequency": 18062,
    "originalRank": 1874
  },
  {
    "word": "correo",
    "rank": 1791,
    "frequency": 18059,
    "originalRank": 1875
  },
  {
    "word": "confía",
    "rank": 1792,
    "frequency": 18059,
    "originalRank": 1876
  },
  {
    "word": "video",
    "rank": 1793,
    "frequency": 18044,
    "originalRank": 1877
  },
  {
    "word": "perfectamente",
    "rank": 1794,
    "frequency": 18042,
    "originalRank": 1878
  },
  {
    "word": "harán",
    "rank": 1795,
    "frequency": 18034,
    "originalRank": 1879
  },
  {
    "word": "teatro",
    "rank": 1796,
    "frequency": 18029,
    "originalRank": 1880
  },
  {
    "word": "dormido",
    "rank": 1797,
    "frequency": 18025,
    "originalRank": 1881
  },
  {
    "word": "local",
    "rank": 1798,
    "frequency": 18024,
    "originalRank": 1882
  },
  {
    "word": "quedado",
    "rank": 1799,
    "frequency": 17999,
    "originalRank": 1883
  },
  {
    "word": "lástima",
    "rank": 1800,
    "frequency": 17994,
    "originalRank": 1884
  },
  {
    "word": "calles",
    "rank": 1801,
    "frequency": 17991,
    "originalRank": 1885
  },
  {
    "word": "créeme",
    "rank": 1802,
    "frequency": 17988,
    "originalRank": 1886
  },
  {
    "word": "responsabilidad",
    "rank": 1803,
    "frequency": 17972,
    "originalRank": 1887
  },
  {
    "word": "búsqueda",
    "rank": 1804,
    "frequency": 17965,
    "originalRank": 1888
  },
  {
    "word": "dedo",
    "rank": 1805,
    "frequency": 17941,
    "originalRank": 1889
  },
  {
    "word": "tonta",
    "rank": 1806,
    "frequency": 17924,
    "originalRank": 1890
  },
  {
    "word": "recuerdos",
    "rank": 1807,
    "frequency": 17905,
    "originalRank": 1891
  },
  {
    "word": "razones",
    "rank": 1808,
    "frequency": 17901,
    "originalRank": 1892
  },
  {
    "word": "escuchando",
    "rank": 1809,
    "frequency": 17897,
    "originalRank": 1893
  },
  {
    "word": "eric",
    "rank": 1810,
    "frequency": 17887,
    "originalRank": 1894
  },
  {
    "word": "elegir",
    "rank": 1811,
    "frequency": 17884,
    "originalRank": 1895
  },
  {
    "word": "amas",
    "rank": 1812,
    "frequency": 17874,
    "originalRank": 1896
  },
  {
    "word": "huele",
    "rank": 1813,
    "frequency": 17863,
    "originalRank": 1897
  },
  {
    "word": "almuerzo",
    "rank": 1814,
    "frequency": 17854,
    "originalRank": 1898
  },
  {
    "word": "cien",
    "rank": 1815,
    "frequency": 17845,
    "originalRank": 1899
  },
  {
    "word": "adn",
    "rank": 1816,
    "frequency": 17813,
    "originalRank": 1900
  },
  {
    "word": "tantos",
    "rank": 1817,
    "frequency": 17808,
    "originalRank": 1901
  },
  {
    "word": "pago",
    "rank": 1818,
    "frequency": 17805,
    "originalRank": 1902
  },
  {
    "word": "normalmente",
    "rank": 1819,
    "frequency": 17799,
    "originalRank": 1903
  },
  {
    "word": "pastel",
    "rank": 1820,
    "frequency": 17786,
    "originalRank": 1905
  },
  {
    "word": "bastardo",
    "rank": 1821,
    "frequency": 17758,
    "originalRank": 1906
  },
  {
    "word": "cinta",
    "rank": 1822,
    "frequency": 17744,
    "originalRank": 1907
  },
  {
    "word": "pasé",
    "rank": 1823,
    "frequency": 17724,
    "originalRank": 1908
  },
  {
    "word": "dígame",
    "rank": 1824,
    "frequency": 17694,
    "originalRank": 1909
  },
  {
    "word": "anna",
    "rank": 1825,
    "frequency": 17680,
    "originalRank": 1910
  },
  {
    "word": "costa",
    "rank": 1826,
    "frequency": 17669,
    "originalRank": 1911
  },
  {
    "word": "levántate",
    "rank": 1827,
    "frequency": 17665,
    "originalRank": 1912
  },
  {
    "word": "llamando",
    "rank": 1828,
    "frequency": 17605,
    "originalRank": 1913
  },
  {
    "word": "cerrado",
    "rank": 1829,
    "frequency": 17604,
    "originalRank": 1914
  },
  {
    "word": "interés",
    "rank": 1830,
    "frequency": 17589,
    "originalRank": 1915
  },
  {
    "word": "enfermera",
    "rank": 1831,
    "frequency": 17587,
    "originalRank": 1916
  },
  {
    "word": "comienzo",
    "rank": 1832,
    "frequency": 17585,
    "originalRank": 1917
  },
  {
    "word": "olvidé",
    "rank": 1833,
    "frequency": 17575,
    "originalRank": 1918
  },
  {
    "word": "fuese",
    "rank": 1834,
    "frequency": 17570,
    "originalRank": 1919
  },
  {
    "word": "militar",
    "rank": 1835,
    "frequency": 17570,
    "originalRank": 1920
  },
  {
    "word": "polvo",
    "rank": 1836,
    "frequency": 17564,
    "originalRank": 1921
  },
  {
    "word": "bella",
    "rank": 1837,
    "frequency": 17550,
    "originalRank": 1922
  },
  {
    "word": "quedo",
    "rank": 1838,
    "frequency": 17549,
    "originalRank": 1923
  },
  {
    "word": "kate",
    "rank": 1839,
    "frequency": 17539,
    "originalRank": 1924
  },
  {
    "word": "encontraste",
    "rank": 1840,
    "frequency": 17539,
    "originalRank": 1925
  },
  {
    "word": "voluntad",
    "rank": 1841,
    "frequency": 17537,
    "originalRank": 1926
  },
  {
    "word": "varias",
    "rank": 1842,
    "frequency": 17536,
    "originalRank": 1927
  },
  {
    "word": "teoría",
    "rank": 1843,
    "frequency": 17535,
    "originalRank": 1928
  },
  {
    "word": "roja",
    "rank": 1844,
    "frequency": 17516,
    "originalRank": 1929
  },
  {
    "word": "cuento",
    "rank": 1845,
    "frequency": 17508,
    "originalRank": 1930
  },
  {
    "word": "escenario",
    "rank": 1846,
    "frequency": 17495,
    "originalRank": 1931
  },
  {
    "word": "diario",
    "rank": 1847,
    "frequency": 17489,
    "originalRank": 1932
  },
  {
    "word": "propiedad",
    "rank": 1848,
    "frequency": 17489,
    "originalRank": 1933
  },
  {
    "word": "agujero",
    "rank": 1849,
    "frequency": 17469,
    "originalRank": 1934
  },
  {
    "word": "aspecto",
    "rank": 1850,
    "frequency": 17461,
    "originalRank": 1935
  },
  {
    "word": "campamento",
    "rank": 1851,
    "frequency": 17455,
    "originalRank": 1936
  },
  {
    "word": "descansar",
    "rank": 1852,
    "frequency": 17451,
    "originalRank": 1937
  },
  {
    "word": "matarme",
    "rank": 1853,
    "frequency": 17449,
    "originalRank": 1938
  },
  {
    "word": "metido",
    "rank": 1854,
    "frequency": 17436,
    "originalRank": 1939
  },
  {
    "word": "quiso",
    "rank": 1855,
    "frequency": 17405,
    "originalRank": 1940
  },
  {
    "word": "ángel",
    "rank": 1856,
    "frequency": 17403,
    "originalRank": 1941
  },
  {
    "word": "enviar",
    "rank": 1857,
    "frequency": 17397,
    "originalRank": 1942
  },
  {
    "word": "impresionante",
    "rank": 1858,
    "frequency": 17386,
    "originalRank": 1943
  },
  {
    "word": "proceso",
    "rank": 1859,
    "frequency": 17346,
    "originalRank": 1944
  },
  {
    "word": "intentado",
    "rank": 1860,
    "frequency": 17331,
    "originalRank": 1945
  },
  {
    "word": "mio",
    "rank": 1861,
    "frequency": 17318,
    "originalRank": 1946
  },
  {
    "word": "fuente",
    "rank": 1862,
    "frequency": 17300,
    "originalRank": 1947
  },
  {
    "word": "alcalde",
    "rank": 1863,
    "frequency": 17299,
    "originalRank": 1948
  },
  {
    "word": "ocurrido",
    "rank": 1864,
    "frequency": 17285,
    "originalRank": 1949
  },
  {
    "word": "malos",
    "rank": 1865,
    "frequency": 17276,
    "originalRank": 1950
  },
  {
    "word": "carretera",
    "rank": 1866,
    "frequency": 17275,
    "originalRank": 1951
  },
  {
    "word": "desapareció",
    "rank": 1867,
    "frequency": 17273,
    "originalRank": 1952
  },
  {
    "word": "desayuno",
    "rank": 1868,
    "frequency": 17272,
    "originalRank": 1953
  },
  {
    "word": "débil",
    "rank": 1869,
    "frequency": 17270,
    "originalRank": 1954
  },
  {
    "word": "roma",
    "rank": 1870,
    "frequency": 17267,
    "originalRank": 1955
  },
  {
    "word": "sabido",
    "rank": 1871,
    "frequency": 17265,
    "originalRank": 1956
  },
  {
    "word": "comienza",
    "rank": 1872,
    "frequency": 17253,
    "originalRank": 1957
  },
  {
    "word": "tambien",
    "rank": 1873,
    "frequency": 17234,
    "originalRank": 1958
  },
  {
    "word": "intentarlo",
    "rank": 1874,
    "frequency": 17231,
    "originalRank": 1959
  },
  {
    "word": "miembro",
    "rank": 1875,
    "frequency": 17219,
    "originalRank": 1960
  },
  {
    "word": "perdiendo",
    "rank": 1876,
    "frequency": 17215,
    "originalRank": 1961
  },
  {
    "word": "hayan",
    "rank": 1877,
    "frequency": 17207,
    "originalRank": 1962
  },
  {
    "word": "fueras",
    "rank": 1878,
    "frequency": 17190,
    "originalRank": 1963
  },
  {
    "word": "resultados",
    "rank": 1879,
    "frequency": 17185,
    "originalRank": 1964
  },
  {
    "word": "jerry",
    "rank": 1880,
    "frequency": 17179,
    "originalRank": 1965
  },
  {
    "word": "mata",
    "rank": 1881,
    "frequency": 17178,
    "originalRank": 1966
  },
  {
    "word": "valiente",
    "rank": 1882,
    "frequency": 17107,
    "originalRank": 1968
  },
  {
    "word": "deber",
    "rank": 1883,
    "frequency": 17106,
    "originalRank": 1969
  },
  {
    "word": "pecho",
    "rank": 1884,
    "frequency": 17075,
    "originalRank": 1970
  },
  {
    "word": "gustó",
    "rank": 1885,
    "frequency": 17068,
    "originalRank": 1971
  },
  {
    "word": "oyes",
    "rank": 1886,
    "frequency": 17050,
    "originalRank": 1972
  },
  {
    "word": "thomas",
    "rank": 1887,
    "frequency": 17034,
    "originalRank": 1973
  },
  {
    "word": "periódico",
    "rank": 1888,
    "frequency": 17023,
    "originalRank": 1974
  },
  {
    "word": "mami",
    "rank": 1889,
    "frequency": 17017,
    "originalRank": 1975
  },
  {
    "word": "piensan",
    "rank": 1890,
    "frequency": 17014,
    "originalRank": 1976
  },
  {
    "word": "washington",
    "rank": 1891,
    "frequency": 17008,
    "originalRank": 1977
  },
  {
    "word": "cansada",
    "rank": 1892,
    "frequency": 16982,
    "originalRank": 1979
  },
  {
    "word": "limpiar",
    "rank": 1893,
    "frequency": 16978,
    "originalRank": 1980
  },
  {
    "word": "crear",
    "rank": 1894,
    "frequency": 16958,
    "originalRank": 1981
  },
  {
    "word": "explicar",
    "rank": 1895,
    "frequency": 16956,
    "originalRank": 1982
  },
  {
    "word": "robado",
    "rank": 1896,
    "frequency": 16955,
    "originalRank": 1983
  },
  {
    "word": "resolver",
    "rank": 1897,
    "frequency": 16944,
    "originalRank": 1984
  },
  {
    "word": "maté",
    "rank": 1898,
    "frequency": 16940,
    "originalRank": 1985
  },
  {
    "word": "guapo",
    "rank": 1899,
    "frequency": 16932,
    "originalRank": 1986
  },
  {
    "word": "continuar",
    "rank": 1900,
    "frequency": 16918,
    "originalRank": 1987
  },
  {
    "word": "sheriff",
    "rank": 1901,
    "frequency": 16917,
    "originalRank": 1988
  },
  {
    "word": "funcionar",
    "rank": 1902,
    "frequency": 16915,
    "originalRank": 1989
  },
  {
    "word": "extra",
    "rank": 1903,
    "frequency": 16896,
    "originalRank": 1990
  },
  {
    "word": "primo",
    "rank": 1904,
    "frequency": 16896,
    "originalRank": 1991
  },
  {
    "word": "manejar",
    "rank": 1905,
    "frequency": 16886,
    "originalRank": 1992
  },
  {
    "word": "primeros",
    "rank": 1906,
    "frequency": 16854,
    "originalRank": 1993
  },
  {
    "word": "acto",
    "rank": 1907,
    "frequency": 16848,
    "originalRank": 1994
  },
  {
    "word": "poniendo",
    "rank": 1908,
    "frequency": 16844,
    "originalRank": 1995
  },
  {
    "word": "números",
    "rank": 1909,
    "frequency": 16838,
    "originalRank": 1996
  },
  {
    "word": "kilómetros",
    "rank": 1910,
    "frequency": 16831,
    "originalRank": 1997
  },
  {
    "word": "andy",
    "rank": 1911,
    "frequency": 16826,
    "originalRank": 1998
  },
  {
    "word": "llevará",
    "rank": 1912,
    "frequency": 16823,
    "originalRank": 1999
  },
  {
    "word": "rachel",
    "rank": 1913,
    "frequency": 16812,
    "originalRank": 2000
  },
  {
    "word": "niñas",
    "rank": 1914,
    "frequency": 16789,
    "originalRank": 2001
  },
  {
    "word": "premio",
    "rank": 1915,
    "frequency": 16786,
    "originalRank": 2002
  },
  {
    "word": "internet",
    "rank": 1916,
    "frequency": 16784,
    "originalRank": 2003
  },
  {
    "word": "harías",
    "rank": 1917,
    "frequency": 16773,
    "originalRank": 2004
  },
  {
    "word": "inútil",
    "rank": 1918,
    "frequency": 16772,
    "originalRank": 2005
  },
  {
    "word": "domingo",
    "rank": 1919,
    "frequency": 16770,
    "originalRank": 2006
  },
  {
    "word": "tomas",
    "rank": 1920,
    "frequency": 16764,
    "originalRank": 2007
  },
  {
    "word": "sensación",
    "rank": 1921,
    "frequency": 16758,
    "originalRank": 2008
  },
  {
    "word": "alcohol",
    "rank": 1922,
    "frequency": 16755,
    "originalRank": 2009
  },
  {
    "word": "tercera",
    "rank": 1923,
    "frequency": 16743,
    "originalRank": 2010
  },
  {
    "word": "agentes",
    "rank": 1924,
    "frequency": 16740,
    "originalRank": 2011
  },
  {
    "word": "disculpas",
    "rank": 1925,
    "frequency": 16739,
    "originalRank": 2012
  },
  {
    "word": "antiguo",
    "rank": 1926,
    "frequency": 16733,
    "originalRank": 2013
  },
  {
    "word": "guapa",
    "rank": 1927,
    "frequency": 16700,
    "originalRank": 2014
  },
  {
    "word": "asustado",
    "rank": 1928,
    "frequency": 16676,
    "originalRank": 2015
  },
  {
    "word": "puedan",
    "rank": 1929,
    "frequency": 16675,
    "originalRank": 2016
  },
  {
    "word": "sexy",
    "rank": 1930,
    "frequency": 16674,
    "originalRank": 2017
  },
  {
    "word": "genio",
    "rank": 1931,
    "frequency": 16669,
    "originalRank": 2018
  },
  {
    "word": "recuperar",
    "rank": 1932,
    "frequency": 16651,
    "originalRank": 2019
  },
  {
    "word": "creemos",
    "rank": 1933,
    "frequency": 16646,
    "originalRank": 2020
  },
  {
    "word": "lengua",
    "rank": 1934,
    "frequency": 16632,
    "originalRank": 2021
  },
  {
    "word": "ladrón",
    "rank": 1935,
    "frequency": 16617,
    "originalRank": 2022
  },
  {
    "word": "intenté",
    "rank": 1936,
    "frequency": 16617,
    "originalRank": 2023
  },
  {
    "word": "examen",
    "rank": 1937,
    "frequency": 16611,
    "originalRank": 2024
  },
  {
    "word": "deprisa",
    "rank": 1938,
    "frequency": 16609,
    "originalRank": 2025
  },
  {
    "word": "montaña",
    "rank": 1939,
    "frequency": 16591,
    "originalRank": 2026
  },
  {
    "word": "durmiendo",
    "rank": 1940,
    "frequency": 16587,
    "originalRank": 2027
  },
  {
    "word": "disparar",
    "rank": 1941,
    "frequency": 16583,
    "originalRank": 2028
  },
  {
    "word": "entrenador",
    "rank": 1942,
    "frequency": 16580,
    "originalRank": 2029
  },
  {
    "word": "queso",
    "rank": 1943,
    "frequency": 16571,
    "originalRank": 2030
  },
  {
    "word": "entero",
    "rank": 1944,
    "frequency": 16547,
    "originalRank": 2031
  },
  {
    "word": "papeles",
    "rank": 1945,
    "frequency": 16546,
    "originalRank": 2032
  },
  {
    "word": "pones",
    "rank": 1946,
    "frequency": 16539,
    "originalRank": 2033
  },
  {
    "word": "modelo",
    "rank": 1947,
    "frequency": 16525,
    "originalRank": 2034
  },
  {
    "word": "fútbol",
    "rank": 1948,
    "frequency": 16513,
    "originalRank": 2035
  },
  {
    "word": "detener",
    "rank": 1949,
    "frequency": 16498,
    "originalRank": 2036
  },
  {
    "word": "lados",
    "rank": 1950,
    "frequency": 16476,
    "originalRank": 2037
  },
  {
    "word": "miembros",
    "rank": 1951,
    "frequency": 16465,
    "originalRank": 2038
  },
  {
    "word": "sábado",
    "rank": 1952,
    "frequency": 16462,
    "originalRank": 2039
  },
  {
    "word": "pongo",
    "rank": 1953,
    "frequency": 16459,
    "originalRank": 2040
  },
  {
    "word": "mataron",
    "rank": 1954,
    "frequency": 16455,
    "originalRank": 2041
  },
  {
    "word": "vuelvas",
    "rank": 1955,
    "frequency": 16439,
    "originalRank": 2042
  },
  {
    "word": "talento",
    "rank": 1956,
    "frequency": 16438,
    "originalRank": 2043
  },
  {
    "word": "descubrir",
    "rank": 1957,
    "frequency": 16425,
    "originalRank": 2044
  },
  {
    "word": "gordo",
    "rank": 1958,
    "frequency": 16416,
    "originalRank": 2045
  },
  {
    "word": "tribunal",
    "rank": 1959,
    "frequency": 16411,
    "originalRank": 2046
  },
  {
    "word": "toque",
    "rank": 1960,
    "frequency": 16400,
    "originalRank": 2047
  },
  {
    "word": "wow",
    "rank": 1961,
    "frequency": 16396,
    "originalRank": 2048
  },
  {
    "word": "hables",
    "rank": 1962,
    "frequency": 16393,
    "originalRank": 2049
  },
  {
    "word": "conocemos",
    "rank": 1963,
    "frequency": 16393,
    "originalRank": 2050
  },
  {
    "word": "haberme",
    "rank": 1964,
    "frequency": 16380,
    "originalRank": 2051
  },
  {
    "word": "dispuesto",
    "rank": 1965,
    "frequency": 16375,
    "originalRank": 2052
  },
  {
    "word": "tamaño",
    "rank": 1966,
    "frequency": 16359,
    "originalRank": 2053
  },
  {
    "word": "dejen",
    "rank": 1967,
    "frequency": 16358,
    "originalRank": 2054
  },
  {
    "word": "maravillosa",
    "rank": 1968,
    "frequency": 16347,
    "originalRank": 2055
  },
  {
    "word": "invitado",
    "rank": 1969,
    "frequency": 16345,
    "originalRank": 2056
  },
  {
    "word": "importantes",
    "rank": 1970,
    "frequency": 16344,
    "originalRank": 2057
  },
  {
    "word": "derechos",
    "rank": 1971,
    "frequency": 16339,
    "originalRank": 2058
  },
  {
    "word": "scott",
    "rank": 1972,
    "frequency": 16331,
    "originalRank": 2059
  },
  {
    "word": "declaración",
    "rank": 1973,
    "frequency": 16327,
    "originalRank": 2060
  },
  {
    "word": "claramente",
    "rank": 1974,
    "frequency": 16303,
    "originalRank": 2061
  },
  {
    "word": "pacientes",
    "rank": 1975,
    "frequency": 16295,
    "originalRank": 2062
  },
  {
    "word": "pérdida",
    "rank": 1976,
    "frequency": 16293,
    "originalRank": 2063
  },
  {
    "word": "iban",
    "rank": 1977,
    "frequency": 16271,
    "originalRank": 2065
  },
  {
    "word": "pudiste",
    "rank": 1978,
    "frequency": 16265,
    "originalRank": 2066
  },
  {
    "word": "profundo",
    "rank": 1979,
    "frequency": 16247,
    "originalRank": 2067
  },
  {
    "word": "gas",
    "rank": 1980,
    "frequency": 16238,
    "originalRank": 2068
  },
  {
    "word": "aeropuerto",
    "rank": 1981,
    "frequency": 16235,
    "originalRank": 2069
  },
  {
    "word": "consigue",
    "rank": 1982,
    "frequency": 16233,
    "originalRank": 2070
  },
  {
    "word": "olvidar",
    "rank": 1983,
    "frequency": 16231,
    "originalRank": 2071
  },
  {
    "word": "gloria",
    "rank": 1984,
    "frequency": 16230,
    "originalRank": 2072
  },
  {
    "word": "olvides",
    "rank": 1985,
    "frequency": 16229,
    "originalRank": 2073
  },
  {
    "word": "volviendo",
    "rank": 1986,
    "frequency": 16220,
    "originalRank": 2074
  },
  {
    "word": "coge",
    "rank": 1987,
    "frequency": 16217,
    "originalRank": 2075
  },
  {
    "word": "fué",
    "rank": 1988,
    "frequency": 16211,
    "originalRank": 2076
  },
  {
    "word": "llamaba",
    "rank": 1989,
    "frequency": 16189,
    "originalRank": 2077
  },
  {
    "word": "pete",
    "rank": 1990,
    "frequency": 16182,
    "originalRank": 2078
  },
  {
    "word": "tendrán",
    "rank": 1991,
    "frequency": 16153,
    "originalRank": 2079
  },
  {
    "word": "instituto",
    "rank": 1992,
    "frequency": 16145,
    "originalRank": 2080
  },
  {
    "word": "disparo",
    "rank": 1993,
    "frequency": 16133,
    "originalRank": 2081
  },
  {
    "word": "encuentras",
    "rank": 1994,
    "frequency": 16132,
    "originalRank": 2082
  },
  {
    "word": "querían",
    "rank": 1995,
    "frequency": 16132,
    "originalRank": 2083
  },
  {
    "word": "hablemos",
    "rank": 1996,
    "frequency": 16131,
    "originalRank": 2084
  },
  {
    "word": "dia",
    "rank": 1997,
    "frequency": 16129,
    "originalRank": 2085
  },
  {
    "word": "enviado",
    "rank": 1998,
    "frequency": 16125,
    "originalRank": 2086
  },
  {
    "word": "pertenece",
    "rank": 1999,
    "frequency": 16119,
    "originalRank": 2087
  },
  {
    "word": "sienta",
    "rank": 2000,
    "frequency": 16109,
    "originalRank": 2088
  },
  {
    "word": "pensó",
    "rank": 2001,
    "frequency": 16109,
    "originalRank": 2089
  },
  {
    "word": "cadáver",
    "rank": 2002,
    "frequency": 16085,
    "originalRank": 2090
  },
  {
    "word": "gracia",
    "rank": 2003,
    "frequency": 16082,
    "originalRank": 2091
  },
  {
    "word": "doctora",
    "rank": 2004,
    "frequency": 16058,
    "originalRank": 2092
  },
  {
    "word": "escuchen",
    "rank": 2005,
    "frequency": 16058,
    "originalRank": 2093
  },
  {
    "word": "amante",
    "rank": 2006,
    "frequency": 16058,
    "originalRank": 2094
  },
  {
    "word": "temporada",
    "rank": 2007,
    "frequency": 16055,
    "originalRank": 2095
  },
  {
    "word": "kim",
    "rank": 2008,
    "frequency": 16052,
    "originalRank": 2096
  },
  {
    "word": "cuerpos",
    "rank": 2009,
    "frequency": 16051,
    "originalRank": 2097
  },
  {
    "word": "amigas",
    "rank": 2010,
    "frequency": 16046,
    "originalRank": 2098
  },
  {
    "word": "larry",
    "rank": 2011,
    "frequency": 16045,
    "originalRank": 2099
  },
  {
    "word": "preguntaba",
    "rank": 2012,
    "frequency": 16039,
    "originalRank": 2100
  },
  {
    "word": "francés",
    "rank": 2013,
    "frequency": 16038,
    "originalRank": 2101
  },
  {
    "word": "mataste",
    "rank": 2014,
    "frequency": 16012,
    "originalRank": 2102
  },
  {
    "word": "techo",
    "rank": 2015,
    "frequency": 16010,
    "originalRank": 2103
  },
  {
    "word": "íbamos",
    "rank": 2016,
    "frequency": 15997,
    "originalRank": 2104
  },
  {
    "word": "protección",
    "rank": 2017,
    "frequency": 15995,
    "originalRank": 2105
  },
  {
    "word": "médicos",
    "rank": 2018,
    "frequency": 15989,
    "originalRank": 2106
  },
  {
    "word": "lisa",
    "rank": 2019,
    "frequency": 15984,
    "originalRank": 2107
  },
  {
    "word": "venganza",
    "rank": 2020,
    "frequency": 15966,
    "originalRank": 2108
  },
  {
    "word": "pensamos",
    "rank": 2021,
    "frequency": 15961,
    "originalRank": 2109
  },
  {
    "word": "walter",
    "rank": 2022,
    "frequency": 15957,
    "originalRank": 2110
  },
  {
    "word": "contó",
    "rank": 2023,
    "frequency": 15928,
    "originalRank": 2111
  },
  {
    "word": "discutir",
    "rank": 2024,
    "frequency": 15902,
    "originalRank": 2112
  },
  {
    "word": "comprendo",
    "rank": 2025,
    "frequency": 15901,
    "originalRank": 2113
  },
  {
    "word": "idiotas",
    "rank": 2026,
    "frequency": 15886,
    "originalRank": 2114
  },
  {
    "word": "enemigos",
    "rank": 2027,
    "frequency": 15875,
    "originalRank": 2115
  },
  {
    "word": "camisa",
    "rank": 2028,
    "frequency": 15874,
    "originalRank": 2116
  },
  {
    "word": "superior",
    "rank": 2029,
    "frequency": 15871,
    "originalRank": 2117
  },
  {
    "word": "criminal",
    "rank": 2030,
    "frequency": 15863,
    "originalRank": 2118
  },
  {
    "word": "preocupada",
    "rank": 2031,
    "frequency": 15857,
    "originalRank": 2119
  },
  {
    "word": "bote",
    "rank": 2032,
    "frequency": 15845,
    "originalRank": 2120
  },
  {
    "word": "escribió",
    "rank": 2033,
    "frequency": 15839,
    "originalRank": 2121
  },
  {
    "word": "llevamos",
    "rank": 2034,
    "frequency": 15830,
    "originalRank": 2122
  },
  {
    "word": "testigos",
    "rank": 2035,
    "frequency": 15794,
    "originalRank": 2123
  },
  {
    "word": "recoger",
    "rank": 2036,
    "frequency": 15787,
    "originalRank": 2124
  },
  {
    "word": "emily",
    "rank": 2037,
    "frequency": 15776,
    "originalRank": 2125
  },
  {
    "word": "truco",
    "rank": 2038,
    "frequency": 15752,
    "originalRank": 2126
  },
  {
    "word": "jason",
    "rank": 2039,
    "frequency": 15748,
    "originalRank": 2127
  },
  {
    "word": "original",
    "rank": 2040,
    "frequency": 15725,
    "originalRank": 2128
  },
  {
    "word": "pide",
    "rank": 2041,
    "frequency": 15715,
    "originalRank": 2129
  },
  {
    "word": "jeff",
    "rank": 2042,
    "frequency": 15698,
    "originalRank": 2130
  },
  {
    "word": "rosa",
    "rank": 2043,
    "frequency": 15694,
    "originalRank": 2131
  },
  {
    "word": "mama",
    "rank": 2044,
    "frequency": 15685,
    "originalRank": 2132
  },
  {
    "word": "negros",
    "rank": 2045,
    "frequency": 15682,
    "originalRank": 2133
  },
  {
    "word": "sobrevivir",
    "rank": 2046,
    "frequency": 15678,
    "originalRank": 2134
  },
  {
    "word": "rostro",
    "rank": 2047,
    "frequency": 15674,
    "originalRank": 2135
  },
  {
    "word": "crédito",
    "rank": 2048,
    "frequency": 15668,
    "originalRank": 2136
  },
  {
    "word": "compartir",
    "rank": 2049,
    "frequency": 15667,
    "originalRank": 2137
  },
  {
    "word": "saca",
    "rank": 2050,
    "frequency": 15660,
    "originalRank": 2138
  },
  {
    "word": "irás",
    "rank": 2051,
    "frequency": 15652,
    "originalRank": 2139
  },
  {
    "word": "pequeñas",
    "rank": 2052,
    "frequency": 15646,
    "originalRank": 2140
  },
  {
    "word": "veía",
    "rank": 2053,
    "frequency": 15626,
    "originalRank": 2141
  },
  {
    "word": "empezando",
    "rank": 2054,
    "frequency": 15625,
    "originalRank": 2142
  },
  {
    "word": "registro",
    "rank": 2055,
    "frequency": 15623,
    "originalRank": 2143
  },
  {
    "word": "continúa",
    "rank": 2056,
    "frequency": 15616,
    "originalRank": 2144
  },
  {
    "word": "grandioso",
    "rank": 2057,
    "frequency": 15615,
    "originalRank": 2145
  },
  {
    "word": "viniste",
    "rank": 2058,
    "frequency": 15608,
    "originalRank": 2146
  },
  {
    "word": "esquina",
    "rank": 2059,
    "frequency": 15602,
    "originalRank": 2147
  },
  {
    "word": "contado",
    "rank": 2060,
    "frequency": 15591,
    "originalRank": 2148
  },
  {
    "word": "tengamos",
    "rank": 2061,
    "frequency": 15578,
    "originalRank": 2149
  },
  {
    "word": "cientos",
    "rank": 2062,
    "frequency": 15550,
    "originalRank": 2150
  },
  {
    "word": "tormenta",
    "rank": 2063,
    "frequency": 15543,
    "originalRank": 2151
  },
  {
    "word": "relájate",
    "rank": 2064,
    "frequency": 15540,
    "originalRank": 2152
  },
  {
    "word": "siéntese",
    "rank": 2065,
    "frequency": 15537,
    "originalRank": 2153
  },
  {
    "word": "chocolate",
    "rank": 2066,
    "frequency": 15529,
    "originalRank": 2154
  },
  {
    "word": "matt",
    "rank": 2067,
    "frequency": 15526,
    "originalRank": 2155
  },
  {
    "word": "pedazo",
    "rank": 2068,
    "frequency": 15519,
    "originalRank": 2156
  },
  {
    "word": "tomo",
    "rank": 2069,
    "frequency": 15518,
    "originalRank": 2157
  },
  {
    "word": "olor",
    "rank": 2070,
    "frequency": 15517,
    "originalRank": 2158
  },
  {
    "word": "ciencia",
    "rank": 2071,
    "frequency": 15507,
    "originalRank": 2159
  },
  {
    "word": "kelly",
    "rank": 2072,
    "frequency": 15485,
    "originalRank": 2160
  },
  {
    "word": "conexión",
    "rank": 2073,
    "frequency": 15482,
    "originalRank": 2161
  },
  {
    "word": "vieron",
    "rank": 2074,
    "frequency": 15470,
    "originalRank": 2162
  },
  {
    "word": "salón",
    "rank": 2075,
    "frequency": 15458,
    "originalRank": 2163
  },
  {
    "word": "sucio",
    "rank": 2076,
    "frequency": 15445,
    "originalRank": 2164
  },
  {
    "word": "firma",
    "rank": 2077,
    "frequency": 15442,
    "originalRank": 2165
  },
  {
    "word": "vimos",
    "rank": 2078,
    "frequency": 15427,
    "originalRank": 2166
  },
  {
    "word": "pidiendo",
    "rank": 2079,
    "frequency": 15425,
    "originalRank": 2167
  },
  {
    "word": "casarse",
    "rank": 2080,
    "frequency": 15390,
    "originalRank": 2168
  },
  {
    "word": "bebida",
    "rank": 2081,
    "frequency": 15379,
    "originalRank": 2169
  },
  {
    "word": "tercer",
    "rank": 2082,
    "frequency": 15377,
    "originalRank": 2170
  },
  {
    "word": "propios",
    "rank": 2083,
    "frequency": 15372,
    "originalRank": 2171
  },
  {
    "word": "fuertes",
    "rank": 2084,
    "frequency": 15358,
    "originalRank": 2172
  },
  {
    "word": "lluvia",
    "rank": 2085,
    "frequency": 15355,
    "originalRank": 2173
  },
  {
    "word": "recién",
    "rank": 2086,
    "frequency": 15340,
    "originalRank": 2174
  },
  {
    "word": "tomaré",
    "rank": 2087,
    "frequency": 15333,
    "originalRank": 2175
  },
  {
    "word": "complicado",
    "rank": 2088,
    "frequency": 15303,
    "originalRank": 2176
  },
  {
    "word": "europa",
    "rank": 2089,
    "frequency": 15296,
    "originalRank": 2177
  },
  {
    "word": "toques",
    "rank": 2090,
    "frequency": 15293,
    "originalRank": 2178
  },
  {
    "word": "cámaras",
    "rank": 2091,
    "frequency": 15282,
    "originalRank": 2179
  },
  {
    "word": "visión",
    "rank": 2092,
    "frequency": 15271,
    "originalRank": 2180
  },
  {
    "word": "llego",
    "rank": 2093,
    "frequency": 15267,
    "originalRank": 2181
  },
  {
    "word": "americano",
    "rank": 2094,
    "frequency": 15251,
    "originalRank": 2182
  },
  {
    "word": "diversión",
    "rank": 2095,
    "frequency": 15249,
    "originalRank": 2183
  },
  {
    "word": "pareció",
    "rank": 2096,
    "frequency": 15243,
    "originalRank": 2184
  },
  {
    "word": "libras",
    "rank": 2097,
    "frequency": 15223,
    "originalRank": 2185
  },
  {
    "word": "curso",
    "rank": 2098,
    "frequency": 15211,
    "originalRank": 2186
  },
  {
    "word": "disco",
    "rank": 2099,
    "frequency": 15204,
    "originalRank": 2187
  },
  {
    "word": "probable",
    "rank": 2100,
    "frequency": 15178,
    "originalRank": 2188
  },
  {
    "word": "precioso",
    "rank": 2101,
    "frequency": 15170,
    "originalRank": 2189
  },
  {
    "word": "tenia",
    "rank": 2102,
    "frequency": 15160,
    "originalRank": 2190
  },
  {
    "word": "lago",
    "rank": 2103,
    "frequency": 15143,
    "originalRank": 2191
  },
  {
    "word": "leído",
    "rank": 2104,
    "frequency": 15140,
    "originalRank": 2192
  },
  {
    "word": "consiguió",
    "rank": 2105,
    "frequency": 15111,
    "originalRank": 2193
  },
  {
    "word": "parecido",
    "rank": 2106,
    "frequency": 15111,
    "originalRank": 2194
  },
  {
    "word": "material",
    "rank": 2107,
    "frequency": 15107,
    "originalRank": 2195
  },
  {
    "word": "discurso",
    "rank": 2108,
    "frequency": 15097,
    "originalRank": 2196
  },
  {
    "word": "entera",
    "rank": 2109,
    "frequency": 15096,
    "originalRank": 2197
  },
  {
    "word": "corta",
    "rank": 2110,
    "frequency": 15077,
    "originalRank": 2199
  },
  {
    "word": "completa",
    "rank": 2111,
    "frequency": 15074,
    "originalRank": 2200
  },
  {
    "word": "decirles",
    "rank": 2112,
    "frequency": 15072,
    "originalRank": 2201
  },
  {
    "word": "lunes",
    "rank": 2113,
    "frequency": 15063,
    "originalRank": 2202
  },
  {
    "word": "efectivo",
    "rank": 2114,
    "frequency": 15046,
    "originalRank": 2203
  },
  {
    "word": "cura",
    "rank": 2115,
    "frequency": 15043,
    "originalRank": 2204
  },
  {
    "word": "antigua",
    "rank": 2116,
    "frequency": 15033,
    "originalRank": 2205
  },
  {
    "word": "hablan",
    "rank": 2117,
    "frequency": 15023,
    "originalRank": 2206
  },
  {
    "word": "juntas",
    "rank": 2118,
    "frequency": 15019,
    "originalRank": 2207
  },
  {
    "word": "william",
    "rank": 2119,
    "frequency": 15011,
    "originalRank": 2208
  },
  {
    "word": "cáncer",
    "rank": 2120,
    "frequency": 15005,
    "originalRank": 2209
  },
  {
    "word": "funeral",
    "rank": 2121,
    "frequency": 14989,
    "originalRank": 2210
  },
  {
    "word": "jodido",
    "rank": 2122,
    "frequency": 14984,
    "originalRank": 2211
  },
  {
    "word": "dave",
    "rank": 2123,
    "frequency": 14983,
    "originalRank": 2212
  },
  {
    "word": "artista",
    "rank": 2124,
    "frequency": 14971,
    "originalRank": 2213
  },
  {
    "word": "favorito",
    "rank": 2125,
    "frequency": 14945,
    "originalRank": 2214
  },
  {
    "word": "guste",
    "rank": 2126,
    "frequency": 14942,
    "originalRank": 2215
  },
  {
    "word": "cae",
    "rank": 2127,
    "frequency": 14940,
    "originalRank": 2216
  },
  {
    "word": "termine",
    "rank": 2128,
    "frequency": 14918,
    "originalRank": 2217
  },
  {
    "word": "entrevista",
    "rank": 2129,
    "frequency": 14910,
    "originalRank": 2218
  },
  {
    "word": "sir",
    "rank": 2130,
    "frequency": 14903,
    "originalRank": 2219
  },
  {
    "word": "pintura",
    "rank": 2131,
    "frequency": 14903,
    "originalRank": 2220
  },
  {
    "word": "quieto",
    "rank": 2132,
    "frequency": 14902,
    "originalRank": 2221
  },
  {
    "word": "falso",
    "rank": 2133,
    "frequency": 14892,
    "originalRank": 2222
  },
  {
    "word": "india",
    "rank": 2134,
    "frequency": 14882,
    "originalRank": 2223
  },
  {
    "word": "corto",
    "rank": 2135,
    "frequency": 14875,
    "originalRank": 2224
  },
  {
    "word": "inteligencia",
    "rank": 2136,
    "frequency": 14861,
    "originalRank": 2225
  },
  {
    "word": "destruir",
    "rank": 2137,
    "frequency": 14858,
    "originalRank": 2226
  },
  {
    "word": "cargos",
    "rank": 2138,
    "frequency": 14856,
    "originalRank": 2227
  },
  {
    "word": "podías",
    "rank": 2139,
    "frequency": 14856,
    "originalRank": 2228
  },
  {
    "word": "mentiras",
    "rank": 2140,
    "frequency": 14839,
    "originalRank": 2229
  },
  {
    "word": "señoras",
    "rank": 2141,
    "frequency": 14832,
    "originalRank": 2230
  },
  {
    "word": "helado",
    "rank": 2142,
    "frequency": 14825,
    "originalRank": 2231
  },
  {
    "word": "felicidades",
    "rank": 2143,
    "frequency": 14818,
    "originalRank": 2232
  },
  {
    "word": "camioneta",
    "rank": 2144,
    "frequency": 14818,
    "originalRank": 2233
  },
  {
    "word": "mueve",
    "rank": 2145,
    "frequency": 14810,
    "originalRank": 2234
  },
  {
    "word": "aparte",
    "rank": 2146,
    "frequency": 14807,
    "originalRank": 2235
  },
  {
    "word": "rock",
    "rank": 2147,
    "frequency": 14802,
    "originalRank": 2236
  },
  {
    "word": "tumba",
    "rank": 2148,
    "frequency": 14796,
    "originalRank": 2237
  },
  {
    "word": "seguimos",
    "rank": 2149,
    "frequency": 14793,
    "originalRank": 2238
  },
  {
    "word": "hablaba",
    "rank": 2150,
    "frequency": 14783,
    "originalRank": 2239
  },
  {
    "word": "verle",
    "rank": 2151,
    "frequency": 14781,
    "originalRank": 2240
  },
  {
    "word": "mapa",
    "rank": 2152,
    "frequency": 14760,
    "originalRank": 2241
  },
  {
    "word": "tarea",
    "rank": 2153,
    "frequency": 14744,
    "originalRank": 2242
  },
  {
    "word": "cambió",
    "rank": 2154,
    "frequency": 14741,
    "originalRank": 2243
  },
  {
    "word": "móvil",
    "rank": 2155,
    "frequency": 14734,
    "originalRank": 2244
  },
  {
    "word": "equivocada",
    "rank": 2156,
    "frequency": 14730,
    "originalRank": 2245
  },
  {
    "word": "responder",
    "rank": 2157,
    "frequency": 14723,
    "originalRank": 2246
  },
  {
    "word": "vacío",
    "rank": 2158,
    "frequency": 14710,
    "originalRank": 2247
  },
  {
    "word": "felicitaciones",
    "rank": 2159,
    "frequency": 14695,
    "originalRank": 2248
  },
  {
    "word": "computadora",
    "rank": 2160,
    "frequency": 14689,
    "originalRank": 2249
  },
  {
    "word": "estudiante",
    "rank": 2161,
    "frequency": 14682,
    "originalRank": 2250
  },
  {
    "word": "muriendo",
    "rank": 2162,
    "frequency": 14679,
    "originalRank": 2251
  },
  {
    "word": "construir",
    "rank": 2163,
    "frequency": 14672,
    "originalRank": 2252
  },
  {
    "word": "conocen",
    "rank": 2164,
    "frequency": 14670,
    "originalRank": 2253
  },
  {
    "word": "clara",
    "rank": 2165,
    "frequency": 14668,
    "originalRank": 2254
  },
  {
    "word": "solución",
    "rank": 2166,
    "frequency": 14657,
    "originalRank": 2255
  },
  {
    "word": "mundial",
    "rank": 2167,
    "frequency": 14653,
    "originalRank": 2256
  },
  {
    "word": "plato",
    "rank": 2168,
    "frequency": 14646,
    "originalRank": 2257
  },
  {
    "word": "famoso",
    "rank": 2169,
    "frequency": 14645,
    "originalRank": 2258
  },
  {
    "word": "des",
    "rank": 2170,
    "frequency": 14644,
    "originalRank": 2259
  },
  {
    "word": "dirá",
    "rank": 2171,
    "frequency": 14641,
    "originalRank": 2260
  },
  {
    "word": "ambas",
    "rank": 2172,
    "frequency": 14632,
    "originalRank": 2261
  },
  {
    "word": "tecnología",
    "rank": 2173,
    "frequency": 14612,
    "originalRank": 2262
  },
  {
    "word": "notas",
    "rank": 2174,
    "frequency": 14611,
    "originalRank": 2263
  },
  {
    "word": "malditos",
    "rank": 2175,
    "frequency": 14594,
    "originalRank": 2264
  },
  {
    "word": "cabrón",
    "rank": 2176,
    "frequency": 14594,
    "originalRank": 2265
  },
  {
    "word": "condiciones",
    "rank": 2177,
    "frequency": 14593,
    "originalRank": 2266
  },
  {
    "word": "dudo",
    "rank": 2178,
    "frequency": 14582,
    "originalRank": 2267
  },
  {
    "word": "robó",
    "rank": 2179,
    "frequency": 14578,
    "originalRank": 2268
  },
  {
    "word": "escucho",
    "rank": 2180,
    "frequency": 14574,
    "originalRank": 2269
  },
  {
    "word": "laura",
    "rank": 2181,
    "frequency": 14574,
    "originalRank": 2270
  },
  {
    "word": "rápidamente",
    "rank": 2182,
    "frequency": 14568,
    "originalRank": 2271
  },
  {
    "word": "bordo",
    "rank": 2183,
    "frequency": 14566,
    "originalRank": 2272
  },
  {
    "word": "nieve",
    "rank": 2184,
    "frequency": 14533,
    "originalRank": 2273
  },
  {
    "word": "mensajes",
    "rank": 2185,
    "frequency": 14528,
    "originalRank": 2274
  },
  {
    "word": "fecha",
    "rank": 2186,
    "frequency": 14528,
    "originalRank": 2275
  },
  {
    "word": "violencia",
    "rank": 2187,
    "frequency": 14523,
    "originalRank": 2276
  },
  {
    "word": "sujeto",
    "rank": 2188,
    "frequency": 14500,
    "originalRank": 2278
  },
  {
    "word": "acciones",
    "rank": 2189,
    "frequency": 14496,
    "originalRank": 2279
  },
  {
    "word": "fría",
    "rank": 2190,
    "frequency": 14472,
    "originalRank": 2280
  },
  {
    "word": "droga",
    "rank": 2191,
    "frequency": 14471,
    "originalRank": 2281
  },
  {
    "word": "saldrá",
    "rank": 2192,
    "frequency": 14470,
    "originalRank": 2282
  },
  {
    "word": "suponía",
    "rank": 2193,
    "frequency": 14448,
    "originalRank": 2283
  },
  {
    "word": "empezamos",
    "rank": 2194,
    "frequency": 14432,
    "originalRank": 2284
  },
  {
    "word": "errores",
    "rank": 2195,
    "frequency": 14424,
    "originalRank": 2285
  },
  {
    "word": "grace",
    "rank": 2196,
    "frequency": 14411,
    "originalRank": 2286
  },
  {
    "word": "siglo",
    "rank": 2197,
    "frequency": 14401,
    "originalRank": 2287
  },
  {
    "word": "molesto",
    "rank": 2198,
    "frequency": 14398,
    "originalRank": 2288
  },
  {
    "word": "acabamos",
    "rank": 2199,
    "frequency": 14386,
    "originalRank": 2289
  },
  {
    "word": "sabéis",
    "rank": 2200,
    "frequency": 14385,
    "originalRank": 2290
  },
  {
    "word": "cortar",
    "rank": 2201,
    "frequency": 14379,
    "originalRank": 2291
  },
  {
    "word": "seria",
    "rank": 2202,
    "frequency": 14376,
    "originalRank": 2292
  },
  {
    "word": "muevas",
    "rank": 2203,
    "frequency": 14372,
    "originalRank": 2293
  },
  {
    "word": "fortuna",
    "rank": 2204,
    "frequency": 14364,
    "originalRank": 2294
  },
  {
    "word": "imaginar",
    "rank": 2205,
    "frequency": 14356,
    "originalRank": 2296
  },
  {
    "word": "archivos",
    "rank": 2206,
    "frequency": 14355,
    "originalRank": 2297
  },
  {
    "word": "presencia",
    "rank": 2207,
    "frequency": 14340,
    "originalRank": 2298
  },
  {
    "word": "familias",
    "rank": 2208,
    "frequency": 14336,
    "originalRank": 2299
  },
  {
    "word": "quedas",
    "rank": 2209,
    "frequency": 14328,
    "originalRank": 2301
  },
  {
    "word": "solas",
    "rank": 2210,
    "frequency": 14326,
    "originalRank": 2302
  },
  {
    "word": "oficiales",
    "rank": 2211,
    "frequency": 14325,
    "originalRank": 2303
  },
  {
    "word": "aventura",
    "rank": 2212,
    "frequency": 14321,
    "originalRank": 2304
  },
  {
    "word": "gira",
    "rank": 2213,
    "frequency": 14319,
    "originalRank": 2305
  },
  {
    "word": "social",
    "rank": 2214,
    "frequency": 14316,
    "originalRank": 2306
  },
  {
    "word": "comunidad",
    "rank": 2215,
    "frequency": 14309,
    "originalRank": 2307
  },
  {
    "word": "annie",
    "rank": 2216,
    "frequency": 14309,
    "originalRank": 2308
  },
  {
    "word": "alan",
    "rank": 2217,
    "frequency": 14301,
    "originalRank": 2309
  },
  {
    "word": "cero",
    "rank": 2218,
    "frequency": 14296,
    "originalRank": 2310
  },
  {
    "word": "clark",
    "rank": 2219,
    "frequency": 14280,
    "originalRank": 2311
  },
  {
    "word": "esperamos",
    "rank": 2220,
    "frequency": 14267,
    "originalRank": 2312
  },
  {
    "word": "ocupada",
    "rank": 2221,
    "frequency": 14267,
    "originalRank": 2313
  },
  {
    "word": "muévete",
    "rank": 2222,
    "frequency": 14263,
    "originalRank": 2314
  },
  {
    "word": "convertido",
    "rank": 2223,
    "frequency": 14248,
    "originalRank": 2315
  },
  {
    "word": "carl",
    "rank": 2224,
    "frequency": 14235,
    "originalRank": 2316
  },
  {
    "word": "pieza",
    "rank": 2225,
    "frequency": 14232,
    "originalRank": 2317
  },
  {
    "word": "estómago",
    "rank": 2226,
    "frequency": 14232,
    "originalRank": 2318
  },
  {
    "word": "disparó",
    "rank": 2227,
    "frequency": 14228,
    "originalRank": 2319
  },
  {
    "word": "legal",
    "rank": 2228,
    "frequency": 14219,
    "originalRank": 2320
  },
  {
    "word": "conseguí",
    "rank": 2229,
    "frequency": 14219,
    "originalRank": 2321
  },
  {
    "word": "emma",
    "rank": 2230,
    "frequency": 14211,
    "originalRank": 2322
  },
  {
    "word": "carter",
    "rank": 2231,
    "frequency": 14199,
    "originalRank": 2323
  },
  {
    "word": "california",
    "rank": 2232,
    "frequency": 14198,
    "originalRank": 2324
  },
  {
    "word": "rara",
    "rank": 2233,
    "frequency": 14198,
    "originalRank": 2325
  },
  {
    "word": "estudiantes",
    "rank": 2234,
    "frequency": 14182,
    "originalRank": 2326
  },
  {
    "word": "reino",
    "rank": 2235,
    "frequency": 14176,
    "originalRank": 2327
  },
  {
    "word": "alegría",
    "rank": 2236,
    "frequency": 14160,
    "originalRank": 2328
  },
  {
    "word": "barrio",
    "rank": 2237,
    "frequency": 14134,
    "originalRank": 2329
  },
  {
    "word": "granja",
    "rank": 2238,
    "frequency": 14132,
    "originalRank": 2330
  },
  {
    "word": "podéis",
    "rank": 2239,
    "frequency": 14124,
    "originalRank": 2331
  },
  {
    "word": "esfuerzo",
    "rank": 2240,
    "frequency": 14118,
    "originalRank": 2332
  },
  {
    "word": "trabajaba",
    "rank": 2241,
    "frequency": 14117,
    "originalRank": 2333
  },
  {
    "word": "claire",
    "rank": 2242,
    "frequency": 14107,
    "originalRank": 2334
  },
  {
    "word": "perdóname",
    "rank": 2243,
    "frequency": 14085,
    "originalRank": 2335
  },
  {
    "word": "tesoro",
    "rank": 2244,
    "frequency": 14073,
    "originalRank": 2336
  },
  {
    "word": "empleo",
    "rank": 2245,
    "frequency": 14071,
    "originalRank": 2337
  },
  {
    "word": "compré",
    "rank": 2246,
    "frequency": 14070,
    "originalRank": 2338
  },
  {
    "word": "cirugía",
    "rank": 2247,
    "frequency": 14066,
    "originalRank": 2339
  },
  {
    "word": "dejamos",
    "rank": 2248,
    "frequency": 14061,
    "originalRank": 2340
  },
  {
    "word": "busco",
    "rank": 2249,
    "frequency": 14053,
    "originalRank": 2341
  },
  {
    "word": "trabajas",
    "rank": 2250,
    "frequency": 14051,
    "originalRank": 2342
  },
  {
    "word": "clave",
    "rank": 2251,
    "frequency": 14049,
    "originalRank": 2343
  },
  {
    "word": "aparentemente",
    "rank": 2252,
    "frequency": 14048,
    "originalRank": 2344
  },
  {
    "word": "bravo",
    "rank": 2253,
    "frequency": 14048,
    "originalRank": 2345
  },
  {
    "word": "desearía",
    "rank": 2254,
    "frequency": 14033,
    "originalRank": 2347
  },
  {
    "word": "cerrada",
    "rank": 2255,
    "frequency": 14033,
    "originalRank": 2348
  },
  {
    "word": "new",
    "rank": 2256,
    "frequency": 14030,
    "originalRank": 2349
  },
  {
    "word": "chicago",
    "rank": 2257,
    "frequency": 14028,
    "originalRank": 2350
  },
  {
    "word": "controlar",
    "rank": 2258,
    "frequency": 14027,
    "originalRank": 2351
  },
  {
    "word": "pregunté",
    "rank": 2259,
    "frequency": 14002,
    "originalRank": 2352
  },
  {
    "word": "mostrar",
    "rank": 2260,
    "frequency": 13997,
    "originalRank": 2353
  },
  {
    "word": "piloto",
    "rank": 2261,
    "frequency": 13989,
    "originalRank": 2354
  },
  {
    "word": "pocas",
    "rank": 2262,
    "frequency": 13989,
    "originalRank": 2355
  },
  {
    "word": "tuvieron",
    "rank": 2263,
    "frequency": 13983,
    "originalRank": 2356
  },
  {
    "word": "ayudarle",
    "rank": 2264,
    "frequency": 13979,
    "originalRank": 2357
  },
  {
    "word": "bolso",
    "rank": 2265,
    "frequency": 13969,
    "originalRank": 2358
  },
  {
    "word": "llorando",
    "rank": 2266,
    "frequency": 13957,
    "originalRank": 2359
  },
  {
    "word": "kyle",
    "rank": 2267,
    "frequency": 13935,
    "originalRank": 2360
  },
  {
    "word": "duerme",
    "rank": 2268,
    "frequency": 13931,
    "originalRank": 2361
  },
  {
    "word": "dejarme",
    "rank": 2269,
    "frequency": 13923,
    "originalRank": 2362
  },
  {
    "word": "intentó",
    "rank": 2270,
    "frequency": 13923,
    "originalRank": 2363
  },
  {
    "word": "respirar",
    "rank": 2271,
    "frequency": 13900,
    "originalRank": 2364
  },
  {
    "word": "aparece",
    "rank": 2272,
    "frequency": 13899,
    "originalRank": 2365
  },
  {
    "word": "campaña",
    "rank": 2273,
    "frequency": 13899,
    "originalRank": 2366
  },
  {
    "word": "amistad",
    "rank": 2274,
    "frequency": 13896,
    "originalRank": 2367
  },
  {
    "word": "corriente",
    "rank": 2275,
    "frequency": 13892,
    "originalRank": 2368
  },
  {
    "word": "viven",
    "rank": 2276,
    "frequency": 13891,
    "originalRank": 2369
  },
  {
    "word": "huesos",
    "rank": 2277,
    "frequency": 13880,
    "originalRank": 2370
  },
  {
    "word": "invitados",
    "rank": 2278,
    "frequency": 13878,
    "originalRank": 2371
  },
  {
    "word": "planta",
    "rank": 2279,
    "frequency": 13868,
    "originalRank": 2372
  },
  {
    "word": "ritmo",
    "rank": 2280,
    "frequency": 13862,
    "originalRank": 2373
  },
  {
    "word": "respuestas",
    "rank": 2281,
    "frequency": 13857,
    "originalRank": 2374
  },
  {
    "word": "socio",
    "rank": 2282,
    "frequency": 13831,
    "originalRank": 2375
  },
  {
    "word": "esperas",
    "rank": 2283,
    "frequency": 13828,
    "originalRank": 2376
  },
  {
    "word": "caído",
    "rank": 2284,
    "frequency": 13819,
    "originalRank": 2377
  },
  {
    "word": "motor",
    "rank": 2285,
    "frequency": 13807,
    "originalRank": 2378
  },
  {
    "word": "mono",
    "rank": 2286,
    "frequency": 13802,
    "originalRank": 2379
  },
  {
    "word": "llevaron",
    "rank": 2287,
    "frequency": 13798,
    "originalRank": 2380
  },
  {
    "word": "página",
    "rank": 2288,
    "frequency": 13788,
    "originalRank": 2381
  },
  {
    "word": "poquito",
    "rank": 2289,
    "frequency": 13774,
    "originalRank": 2382
  },
  {
    "word": "habíamos",
    "rank": 2290,
    "frequency": 13746,
    "originalRank": 2384
  },
  {
    "word": "encontraremos",
    "rank": 2291,
    "frequency": 13745,
    "originalRank": 2385
  },
  {
    "word": "ruego",
    "rank": 2292,
    "frequency": 13737,
    "originalRank": 2386
  },
  {
    "word": "dejan",
    "rank": 2293,
    "frequency": 13733,
    "originalRank": 2387
  },
  {
    "word": "aburrido",
    "rank": 2294,
    "frequency": 13720,
    "originalRank": 2388
  },
  {
    "word": "paquete",
    "rank": 2295,
    "frequency": 13720,
    "originalRank": 2389
  },
  {
    "word": "casada",
    "rank": 2296,
    "frequency": 13720,
    "originalRank": 2390
  },
  {
    "word": "llevarte",
    "rank": 2297,
    "frequency": 13696,
    "originalRank": 2391
  },
  {
    "word": "ted",
    "rank": 2298,
    "frequency": 13688,
    "originalRank": 2392
  },
  {
    "word": "combate",
    "rank": 2299,
    "frequency": 13687,
    "originalRank": 2393
  },
  {
    "word": "útil",
    "rank": 2300,
    "frequency": 13685,
    "originalRank": 2394
  },
  {
    "word": "castillo",
    "rank": 2301,
    "frequency": 13685,
    "originalRank": 2395
  },
  {
    "word": "bola",
    "rank": 2302,
    "frequency": 13672,
    "originalRank": 2396
  },
  {
    "word": "canciones",
    "rank": 2303,
    "frequency": 13653,
    "originalRank": 2397
  },
  {
    "word": "mataré",
    "rank": 2304,
    "frequency": 13635,
    "originalRank": 2398
  },
  {
    "word": "muchísimo",
    "rank": 2305,
    "frequency": 13629,
    "originalRank": 2399
  },
  {
    "word": "asistente",
    "rank": 2306,
    "frequency": 13628,
    "originalRank": 2400
  },
  {
    "word": "llegaron",
    "rank": 2307,
    "frequency": 13623,
    "originalRank": 2401
  },
  {
    "word": "correcta",
    "rank": 2308,
    "frequency": 13618,
    "originalRank": 2402
  },
  {
    "word": "pondré",
    "rank": 2309,
    "frequency": 13618,
    "originalRank": 2403
  },
  {
    "word": "simon",
    "rank": 2310,
    "frequency": 13612,
    "originalRank": 2404
  },
  {
    "word": "comido",
    "rank": 2311,
    "frequency": 13610,
    "originalRank": 2405
  },
  {
    "word": "salgan",
    "rank": 2312,
    "frequency": 13593,
    "originalRank": 2406
  },
  {
    "word": "empecé",
    "rank": 2313,
    "frequency": 13581,
    "originalRank": 2407
  },
  {
    "word": "tirar",
    "rank": 2314,
    "frequency": 13579,
    "originalRank": 2408
  },
  {
    "word": "pasan",
    "rank": 2315,
    "frequency": 13578,
    "originalRank": 2409
  },
  {
    "word": "cierta",
    "rank": 2316,
    "frequency": 13578,
    "originalRank": 2410
  },
  {
    "word": "honesto",
    "rank": 2317,
    "frequency": 13577,
    "originalRank": 2411
  },
  {
    "word": "carro",
    "rank": 2318,
    "frequency": 13558,
    "originalRank": 2412
  },
  {
    "word": "limpia",
    "rank": 2319,
    "frequency": 13540,
    "originalRank": 2413
  },
  {
    "word": "volví",
    "rank": 2320,
    "frequency": 13540,
    "originalRank": 2414
  },
  {
    "word": "confío",
    "rank": 2321,
    "frequency": 13534,
    "originalRank": 2415
  },
  {
    "word": "venta",
    "rank": 2322,
    "frequency": 13516,
    "originalRank": 2416
  },
  {
    "word": "huir",
    "rank": 2323,
    "frequency": 13515,
    "originalRank": 2417
  },
  {
    "word": "apareció",
    "rank": 2324,
    "frequency": 13512,
    "originalRank": 2418
  },
  {
    "word": "vais",
    "rank": 2325,
    "frequency": 13512,
    "originalRank": 2419
  },
  {
    "word": "compromiso",
    "rank": 2326,
    "frequency": 13505,
    "originalRank": 2420
  },
  {
    "word": "gustas",
    "rank": 2327,
    "frequency": 13495,
    "originalRank": 2421
  },
  {
    "word": "aseguro",
    "rank": 2328,
    "frequency": 13486,
    "originalRank": 2422
  },
  {
    "word": "ira",
    "rank": 2329,
    "frequency": 13472,
    "originalRank": 2423
  },
  {
    "word": "promesa",
    "rank": 2330,
    "frequency": 13469,
    "originalRank": 2424
  },
  {
    "word": "decírselo",
    "rank": 2331,
    "frequency": 13467,
    "originalRank": 2425
  },
  {
    "word": "cuáles",
    "rank": 2332,
    "frequency": 13461,
    "originalRank": 2426
  },
  {
    "word": "compras",
    "rank": 2333,
    "frequency": 13458,
    "originalRank": 2427
  },
  {
    "word": "importancia",
    "rank": 2334,
    "frequency": 13447,
    "originalRank": 2428
  },
  {
    "word": "lección",
    "rank": 2335,
    "frequency": 13437,
    "originalRank": 2429
  },
  {
    "word": "hablaré",
    "rank": 2336,
    "frequency": 13437,
    "originalRank": 2430
  },
  {
    "word": "hacerse",
    "rank": 2337,
    "frequency": 13428,
    "originalRank": 2431
  },
  {
    "word": "personalmente",
    "rank": 2338,
    "frequency": 13425,
    "originalRank": 2432
  },
  {
    "word": "roger",
    "rank": 2339,
    "frequency": 13423,
    "originalRank": 2433
  },
  {
    "word": "luke",
    "rank": 2340,
    "frequency": 13422,
    "originalRank": 2434
  },
  {
    "word": "bolsillo",
    "rank": 2341,
    "frequency": 13418,
    "originalRank": 2435
  },
  {
    "word": "enojado",
    "rank": 2342,
    "frequency": 13402,
    "originalRank": 2436
  },
  {
    "word": "desgracia",
    "rank": 2343,
    "frequency": 13398,
    "originalRank": 2437
  },
  {
    "word": "artículo",
    "rank": 2344,
    "frequency": 13395,
    "originalRank": 2438
  },
  {
    "word": "labios",
    "rank": 2345,
    "frequency": 13392,
    "originalRank": 2439
  },
  {
    "word": "cola",
    "rank": 2346,
    "frequency": 13390,
    "originalRank": 2440
  },
  {
    "word": "estemos",
    "rank": 2347,
    "frequency": 13377,
    "originalRank": 2441
  },
  {
    "word": "whisky",
    "rank": 2348,
    "frequency": 13374,
    "originalRank": 2442
  },
  {
    "word": "taza",
    "rank": 2349,
    "frequency": 13358,
    "originalRank": 2443
  },
  {
    "word": "despues",
    "rank": 2350,
    "frequency": 13357,
    "originalRank": 2444
  },
  {
    "word": "gary",
    "rank": 2351,
    "frequency": 13354,
    "originalRank": 2445
  },
  {
    "word": "preguntarte",
    "rank": 2352,
    "frequency": 13348,
    "originalRank": 2446
  },
  {
    "word": "pelota",
    "rank": 2353,
    "frequency": 13342,
    "originalRank": 2447
  },
  {
    "word": "caminando",
    "rank": 2354,
    "frequency": 13339,
    "originalRank": 2448
  },
  {
    "word": "andar",
    "rank": 2355,
    "frequency": 13336,
    "originalRank": 2449
  },
  {
    "word": "crea",
    "rank": 2356,
    "frequency": 13333,
    "originalRank": 2450
  },
  {
    "word": "chaqueta",
    "rank": 2357,
    "frequency": 13332,
    "originalRank": 2451
  },
  {
    "word": "importaría",
    "rank": 2358,
    "frequency": 13331,
    "originalRank": 2452
  },
  {
    "word": "den",
    "rank": 2359,
    "frequency": 13322,
    "originalRank": 2453
  },
  {
    "word": "llegará",
    "rank": 2360,
    "frequency": 13320,
    "originalRank": 2454
  },
  {
    "word": "interesado",
    "rank": 2361,
    "frequency": 13318,
    "originalRank": 2455
  },
  {
    "word": "atrapado",
    "rank": 2362,
    "frequency": 13310,
    "originalRank": 2456
  },
  {
    "word": "supiera",
    "rank": 2363,
    "frequency": 13305,
    "originalRank": 2457
  },
  {
    "word": "matarlo",
    "rank": 2364,
    "frequency": 13299,
    "originalRank": 2458
  },
  {
    "word": "árboles",
    "rank": 2365,
    "frequency": 13292,
    "originalRank": 2459
  },
  {
    "word": "obvio",
    "rank": 2366,
    "frequency": 13288,
    "originalRank": 2460
  },
  {
    "word": "amaba",
    "rank": 2367,
    "frequency": 13281,
    "originalRank": 2461
  },
  {
    "word": "hablaremos",
    "rank": 2368,
    "frequency": 13273,
    "originalRank": 2462
  },
  {
    "word": "entrenamiento",
    "rank": 2369,
    "frequency": 13271,
    "originalRank": 2463
  },
  {
    "word": "pescado",
    "rank": 2370,
    "frequency": 13262,
    "originalRank": 2464
  },
  {
    "word": "últimas",
    "rank": 2371,
    "frequency": 13253,
    "originalRank": 2465
  },
  {
    "word": "pobres",
    "rank": 2372,
    "frequency": 13242,
    "originalRank": 2466
  },
  {
    "word": "dioses",
    "rank": 2373,
    "frequency": 13219,
    "originalRank": 2467
  },
  {
    "word": "nerviosa",
    "rank": 2374,
    "frequency": 13205,
    "originalRank": 2468
  },
  {
    "word": "vueltas",
    "rank": 2375,
    "frequency": 13199,
    "originalRank": 2469
  },
  {
    "word": "encontrarlo",
    "rank": 2376,
    "frequency": 13177,
    "originalRank": 2470
  },
  {
    "word": "autos",
    "rank": 2377,
    "frequency": 13175,
    "originalRank": 2471
  },
  {
    "word": "alice",
    "rank": 2378,
    "frequency": 13175,
    "originalRank": 2472
  },
  {
    "word": "preguntarle",
    "rank": 2379,
    "frequency": 13170,
    "originalRank": 2473
  },
  {
    "word": "lucy",
    "rank": 2380,
    "frequency": 13170,
    "originalRank": 2474
  },
  {
    "word": "abrigo",
    "rank": 2381,
    "frequency": 13147,
    "originalRank": 2475
  },
  {
    "word": "okay",
    "rank": 2382,
    "frequency": 13145,
    "originalRank": 2476
  },
  {
    "word": "estudiar",
    "rank": 2383,
    "frequency": 13144,
    "originalRank": 2477
  },
  {
    "word": "sonrisa",
    "rank": 2384,
    "frequency": 13131,
    "originalRank": 2479
  },
  {
    "word": "cobarde",
    "rank": 2385,
    "frequency": 13126,
    "originalRank": 2480
  },
  {
    "word": "olvida",
    "rank": 2386,
    "frequency": 13118,
    "originalRank": 2481
  },
  {
    "word": "secundaria",
    "rank": 2387,
    "frequency": 13102,
    "originalRank": 2482
  },
  {
    "word": "descubierto",
    "rank": 2388,
    "frequency": 13099,
    "originalRank": 2483
  },
  {
    "word": "convirtió",
    "rank": 2389,
    "frequency": 13091,
    "originalRank": 2484
  },
  {
    "word": "coches",
    "rank": 2390,
    "frequency": 13082,
    "originalRank": 2485
  },
  {
    "word": "venía",
    "rank": 2391,
    "frequency": 13074,
    "originalRank": 2486
  },
  {
    "word": "josh",
    "rank": 2392,
    "frequency": 13073,
    "originalRank": 2487
  },
  {
    "word": "charla",
    "rank": 2393,
    "frequency": 13069,
    "originalRank": 2488
  },
  {
    "word": "vives",
    "rank": 2394,
    "frequency": 13062,
    "originalRank": 2489
  },
  {
    "word": "bruja",
    "rank": 2395,
    "frequency": 13054,
    "originalRank": 2490
  },
  {
    "word": "celular",
    "rank": 2396,
    "frequency": 13042,
    "originalRank": 2492
  },
  {
    "word": "rose",
    "rank": 2397,
    "frequency": 13042,
    "originalRank": 2493
  },
  {
    "word": "rompió",
    "rank": 2398,
    "frequency": 13041,
    "originalRank": 2494
  },
  {
    "word": "andando",
    "rank": 2399,
    "frequency": 13028,
    "originalRank": 2495
  },
  {
    "word": "vean",
    "rank": 2400,
    "frequency": 13023,
    "originalRank": 2496
  },
  {
    "word": "conseguiste",
    "rank": 2401,
    "frequency": 13020,
    "originalRank": 2497
  },
  {
    "word": "susan",
    "rank": 2402,
    "frequency": 13018,
    "originalRank": 2498
  },
  {
    "word": "veinte",
    "rank": 2403,
    "frequency": 13015,
    "originalRank": 2499
  },
  {
    "word": "encargo",
    "rank": 2404,
    "frequency": 13007,
    "originalRank": 2500
  },
  {
    "word": "matarte",
    "rank": 2405,
    "frequency": 12999,
    "originalRank": 2501
  },
  {
    "word": "palacio",
    "rank": 2406,
    "frequency": 12999,
    "originalRank": 2502
  },
  {
    "word": "convierte",
    "rank": 2407,
    "frequency": 12995,
    "originalRank": 2503
  },
  {
    "word": "vivos",
    "rank": 2408,
    "frequency": 12990,
    "originalRank": 2505
  },
  {
    "word": "pasamos",
    "rank": 2409,
    "frequency": 12985,
    "originalRank": 2506
  },
  {
    "word": "firme",
    "rank": 2410,
    "frequency": 12980,
    "originalRank": 2507
  },
  {
    "word": "daría",
    "rank": 2411,
    "frequency": 12978,
    "originalRank": 2508
  },
  {
    "word": "piense",
    "rank": 2412,
    "frequency": 12969,
    "originalRank": 2509
  },
  {
    "word": "oigo",
    "rank": 2413,
    "frequency": 12962,
    "originalRank": 2510
  },
  {
    "word": "phil",
    "rank": 2414,
    "frequency": 12951,
    "originalRank": 2511
  },
  {
    "word": "sorprende",
    "rank": 2415,
    "frequency": 12948,
    "originalRank": 2512
  },
  {
    "word": "alemanes",
    "rank": 2416,
    "frequency": 12934,
    "originalRank": 2513
  },
  {
    "word": "milagro",
    "rank": 2417,
    "frequency": 12934,
    "originalRank": 2514
  },
  {
    "word": "soportar",
    "rank": 2418,
    "frequency": 12931,
    "originalRank": 2515
  },
  {
    "word": "dejaron",
    "rank": 2419,
    "frequency": 12928,
    "originalRank": 2516
  },
  {
    "word": "smith",
    "rank": 2420,
    "frequency": 12925,
    "originalRank": 2517
  },
  {
    "word": "disculpen",
    "rank": 2421,
    "frequency": 12923,
    "originalRank": 2518
  },
  {
    "word": "moda",
    "rank": 2422,
    "frequency": 12906,
    "originalRank": 2519
  },
  {
    "word": "despacho",
    "rank": 2423,
    "frequency": 12903,
    "originalRank": 2520
  },
  {
    "word": "vecinos",
    "rank": 2424,
    "frequency": 12900,
    "originalRank": 2521
  },
  {
    "word": "vaso",
    "rank": 2425,
    "frequency": 12895,
    "originalRank": 2522
  },
  {
    "word": "dejarte",
    "rank": 2426,
    "frequency": 12884,
    "originalRank": 2523
  },
  {
    "word": "explosión",
    "rank": 2427,
    "frequency": 12878,
    "originalRank": 2524
  },
  {
    "word": "poderes",
    "rank": 2428,
    "frequency": 12877,
    "originalRank": 2525
  },
  {
    "word": "regla",
    "rank": 2429,
    "frequency": 12875,
    "originalRank": 2526
  },
  {
    "word": "acaban",
    "rank": 2430,
    "frequency": 12874,
    "originalRank": 2527
  },
  {
    "word": "copia",
    "rank": 2431,
    "frequency": 12862,
    "originalRank": 2528
  },
  {
    "word": "siguiendo",
    "rank": 2432,
    "frequency": 12857,
    "originalRank": 2529
  },
  {
    "word": "viajar",
    "rank": 2433,
    "frequency": 12841,
    "originalRank": 2530
  },
  {
    "word": "cadena",
    "rank": 2434,
    "frequency": 12821,
    "originalRank": 2531
  },
  {
    "word": "fábrica",
    "rank": 2435,
    "frequency": 12817,
    "originalRank": 2532
  },
  {
    "word": "mantiene",
    "rank": 2436,
    "frequency": 12817,
    "originalRank": 2533
  },
  {
    "word": "meter",
    "rank": 2437,
    "frequency": 12816,
    "originalRank": 2534
  },
  {
    "word": "contenta",
    "rank": 2438,
    "frequency": 12796,
    "originalRank": 2535
  },
  {
    "word": "comiendo",
    "rank": 2439,
    "frequency": 12783,
    "originalRank": 2536
  },
  {
    "word": "educación",
    "rank": 2440,
    "frequency": 12779,
    "originalRank": 2537
  },
  {
    "word": "maneras",
    "rank": 2441,
    "frequency": 12777,
    "originalRank": 2538
  },
  {
    "word": "fumar",
    "rank": 2442,
    "frequency": 12776,
    "originalRank": 2539
  },
  {
    "word": "encantador",
    "rank": 2443,
    "frequency": 12768,
    "originalRank": 2540
  },
  {
    "word": "cuantos",
    "rank": 2444,
    "frequency": 12760,
    "originalRank": 2541
  },
  {
    "word": "homicidio",
    "rank": 2445,
    "frequency": 12758,
    "originalRank": 2542
  },
  {
    "word": "madera",
    "rank": 2446,
    "frequency": 12752,
    "originalRank": 2543
  },
  {
    "word": "mayores",
    "rank": 2447,
    "frequency": 12750,
    "originalRank": 2544
  },
  {
    "word": "grado",
    "rank": 2448,
    "frequency": 12744,
    "originalRank": 2545
  },
  {
    "word": "tratamiento",
    "rank": 2449,
    "frequency": 12734,
    "originalRank": 2546
  },
  {
    "word": "blancos",
    "rank": 2450,
    "frequency": 12733,
    "originalRank": 2547
  },
  {
    "word": "lord",
    "rank": 2451,
    "frequency": 12726,
    "originalRank": 2548
  },
  {
    "word": "anterior",
    "rank": 2452,
    "frequency": 12725,
    "originalRank": 2549
  },
  {
    "word": "comisario",
    "rank": 2453,
    "frequency": 12723,
    "originalRank": 2550
  },
  {
    "word": "pizza",
    "rank": 2454,
    "frequency": 12719,
    "originalRank": 2551
  },
  {
    "word": "millas",
    "rank": 2455,
    "frequency": 12719,
    "originalRank": 2552
  },
  {
    "word": "tira",
    "rank": 2456,
    "frequency": 12715,
    "originalRank": 2553
  },
  {
    "word": "fueran",
    "rank": 2457,
    "frequency": 12701,
    "originalRank": 2554
  },
  {
    "word": "cumplir",
    "rank": 2458,
    "frequency": 12684,
    "originalRank": 2555
  },
  {
    "word": "plata",
    "rank": 2459,
    "frequency": 12672,
    "originalRank": 2556
  },
  {
    "word": "quedará",
    "rank": 2460,
    "frequency": 12655,
    "originalRank": 2557
  },
  {
    "word": "quedaré",
    "rank": 2461,
    "frequency": 12655,
    "originalRank": 2558
  },
  {
    "word": "aléjate",
    "rank": 2462,
    "frequency": 12653,
    "originalRank": 2559
  },
  {
    "word": "decidir",
    "rank": 2463,
    "frequency": 12652,
    "originalRank": 2560
  },
  {
    "word": "lío",
    "rank": 2464,
    "frequency": 12650,
    "originalRank": 2561
  },
  {
    "word": "preguntó",
    "rank": 2465,
    "frequency": 12649,
    "originalRank": 2562
  },
  {
    "word": "agencia",
    "rank": 2466,
    "frequency": 12648,
    "originalRank": 2563
  },
  {
    "word": "humanidad",
    "rank": 2467,
    "frequency": 12647,
    "originalRank": 2564
  },
  {
    "word": "usado",
    "rank": 2468,
    "frequency": 12645,
    "originalRank": 2565
  },
  {
    "word": "guardias",
    "rank": 2469,
    "frequency": 12635,
    "originalRank": 2566
  },
  {
    "word": "parada",
    "rank": 2470,
    "frequency": 12633,
    "originalRank": 2567
  },
  {
    "word": "leyes",
    "rank": 2471,
    "frequency": 12624,
    "originalRank": 2568
  },
  {
    "word": "funcionó",
    "rank": 2472,
    "frequency": 12616,
    "originalRank": 2569
  },
  {
    "word": "odia",
    "rank": 2473,
    "frequency": 12611,
    "originalRank": 2570
  },
  {
    "word": "levanta",
    "rank": 2474,
    "frequency": 12610,
    "originalRank": 2571
  },
  {
    "word": "mires",
    "rank": 2475,
    "frequency": 12606,
    "originalRank": 2572
  },
  {
    "word": "respira",
    "rank": 2476,
    "frequency": 12602,
    "originalRank": 2573
  },
  {
    "word": "escaleras",
    "rank": 2477,
    "frequency": 12595,
    "originalRank": 2574
  },
  {
    "word": "decisiones",
    "rank": 2478,
    "frequency": 12589,
    "originalRank": 2575
  },
  {
    "word": "queréis",
    "rank": 2479,
    "frequency": 12578,
    "originalRank": 2576
  },
  {
    "word": "salvaje",
    "rank": 2480,
    "frequency": 12576,
    "originalRank": 2577
  },
  {
    "word": "preguntando",
    "rank": 2481,
    "frequency": 12574,
    "originalRank": 2578
  },
  {
    "word": "pasos",
    "rank": 2482,
    "frequency": 12574,
    "originalRank": 2579
  },
  {
    "word": "ambulancia",
    "rank": 2483,
    "frequency": 12573,
    "originalRank": 2580
  },
  {
    "word": "traducción",
    "rank": 2484,
    "frequency": 12568,
    "originalRank": 2581
  },
  {
    "word": "trabajado",
    "rank": 2485,
    "frequency": 12563,
    "originalRank": 2582
  },
  {
    "word": "básicamente",
    "rank": 2486,
    "frequency": 12555,
    "originalRank": 2583
  },
  {
    "word": "tratado",
    "rank": 2487,
    "frequency": 12552,
    "originalRank": 2584
  },
  {
    "word": "parado",
    "rank": 2488,
    "frequency": 12529,
    "originalRank": 2585
  },
  {
    "word": "especiales",
    "rank": 2489,
    "frequency": 12527,
    "originalRank": 2586
  },
  {
    "word": "mentiroso",
    "rank": 2490,
    "frequency": 12526,
    "originalRank": 2587
  },
  {
    "word": "libres",
    "rank": 2491,
    "frequency": 12515,
    "originalRank": 2588
  },
  {
    "word": "servicios",
    "rank": 2492,
    "frequency": 12506,
    "originalRank": 2589
  },
  {
    "word": "pedirle",
    "rank": 2493,
    "frequency": 12491,
    "originalRank": 2590
  },
  {
    "word": "vivía",
    "rank": 2494,
    "frequency": 12487,
    "originalRank": 2591
  },
  {
    "word": "medios",
    "rank": 2495,
    "frequency": 12483,
    "originalRank": 2592
  },
  {
    "word": "compra",
    "rank": 2496,
    "frequency": 12470,
    "originalRank": 2593
  },
  {
    "word": "conocimiento",
    "rank": 2497,
    "frequency": 12469,
    "originalRank": 2594
  },
  {
    "word": "armario",
    "rank": 2498,
    "frequency": 12465,
    "originalRank": 2595
  },
  {
    "word": "lobo",
    "rank": 2499,
    "frequency": 12465,
    "originalRank": 2596
  },
  {
    "word": "quedamos",
    "rank": 2500,
    "frequency": 12464,
    "originalRank": 2597
  },
  {
    "word": "ciertamente",
    "rank": 2501,
    "frequency": 12462,
    "originalRank": 2598
  },
  {
    "word": "permitir",
    "rank": 2502,
    "frequency": 12454,
    "originalRank": 2599
  },
  {
    "word": "tráfico",
    "rank": 2503,
    "frequency": 12452,
    "originalRank": 2600
  },
  {
    "word": "uniforme",
    "rank": 2504,
    "frequency": 12444,
    "originalRank": 2601
  },
  {
    "word": "estuvimos",
    "rank": 2505,
    "frequency": 12442,
    "originalRank": 2602
  },
  {
    "word": "alemania",
    "rank": 2506,
    "frequency": 12440,
    "originalRank": 2603
  },
  {
    "word": "suave",
    "rank": 2507,
    "frequency": 12439,
    "originalRank": 2604
  },
  {
    "word": "propias",
    "rank": 2508,
    "frequency": 12434,
    "originalRank": 2605
  },
  {
    "word": "balas",
    "rank": 2509,
    "frequency": 12431,
    "originalRank": 2606
  },
  {
    "word": "asqueroso",
    "rank": 2510,
    "frequency": 12429,
    "originalRank": 2607
  },
  {
    "word": "ciento",
    "rank": 2511,
    "frequency": 12426,
    "originalRank": 2608
  },
  {
    "word": "invierno",
    "rank": 2512,
    "frequency": 12425,
    "originalRank": 2609
  },
  {
    "word": "consigo",
    "rank": 2513,
    "frequency": 12419,
    "originalRank": 2610
  },
  {
    "word": "encuentre",
    "rank": 2514,
    "frequency": 12408,
    "originalRank": 2611
  },
  {
    "word": "jenny",
    "rank": 2515,
    "frequency": 12399,
    "originalRank": 2612
  },
  {
    "word": "conductor",
    "rank": 2516,
    "frequency": 12376,
    "originalRank": 2613
  },
  {
    "word": "equipos",
    "rank": 2517,
    "frequency": 12375,
    "originalRank": 2614
  },
  {
    "word": "arena",
    "rank": 2518,
    "frequency": 12373,
    "originalRank": 2615
  },
  {
    "word": "park",
    "rank": 2519,
    "frequency": 12363,
    "originalRank": 2616
  },
  {
    "word": "licencia",
    "rank": 2520,
    "frequency": 12360,
    "originalRank": 2617
  },
  {
    "word": "tíos",
    "rank": 2521,
    "frequency": 12342,
    "originalRank": 2618
  },
  {
    "word": "jackson",
    "rank": 2522,
    "frequency": 12341,
    "originalRank": 2619
  },
  {
    "word": "dijera",
    "rank": 2523,
    "frequency": 12333,
    "originalRank": 2620
  },
  {
    "word": "espejo",
    "rank": 2524,
    "frequency": 12332,
    "originalRank": 2621
  },
  {
    "word": "marina",
    "rank": 2525,
    "frequency": 12329,
    "originalRank": 2622
  },
  {
    "word": "matando",
    "rank": 2526,
    "frequency": 12326,
    "originalRank": 2623
  },
  {
    "word": "seres",
    "rank": 2527,
    "frequency": 12321,
    "originalRank": 2624
  },
  {
    "word": "fiestas",
    "rank": 2528,
    "frequency": 12320,
    "originalRank": 2625
  },
  {
    "word": "mover",
    "rank": 2529,
    "frequency": 12320,
    "originalRank": 2626
  },
  {
    "word": "coincidencia",
    "rank": 2530,
    "frequency": 12318,
    "originalRank": 2627
  },
  {
    "word": "análisis",
    "rank": 2531,
    "frequency": 12318,
    "originalRank": 2628
  },
  {
    "word": "llegando",
    "rank": 2532,
    "frequency": 12306,
    "originalRank": 2629
  },
  {
    "word": "azúcar",
    "rank": 2533,
    "frequency": 12304,
    "originalRank": 2630
  },
  {
    "word": "tim",
    "rank": 2534,
    "frequency": 12300,
    "originalRank": 2631
  },
  {
    "word": "casar",
    "rank": 2535,
    "frequency": 12284,
    "originalRank": 2632
  },
  {
    "word": "sótano",
    "rank": 2536,
    "frequency": 12276,
    "originalRank": 2633
  },
  {
    "word": "volvamos",
    "rank": 2537,
    "frequency": 12274,
    "originalRank": 2634
  },
  {
    "word": "sabrá",
    "rank": 2538,
    "frequency": 12265,
    "originalRank": 2635
  },
  {
    "word": "taylor",
    "rank": 2539,
    "frequency": 12255,
    "originalRank": 2636
  },
  {
    "word": "ocasión",
    "rank": 2540,
    "frequency": 12248,
    "originalRank": 2637
  },
  {
    "word": "cheque",
    "rank": 2541,
    "frequency": 12244,
    "originalRank": 2638
  },
  {
    "word": "revisar",
    "rank": 2542,
    "frequency": 12242,
    "originalRank": 2639
  },
  {
    "word": "ponerme",
    "rank": 2543,
    "frequency": 12239,
    "originalRank": 2640
  },
  {
    "word": "suceder",
    "rank": 2544,
    "frequency": 12236,
    "originalRank": 2641
  },
  {
    "word": "acusado",
    "rank": 2545,
    "frequency": 12235,
    "originalRank": 2642
  },
  {
    "word": "dímelo",
    "rank": 2546,
    "frequency": 12235,
    "originalRank": 2643
  },
  {
    "word": "quedé",
    "rank": 2547,
    "frequency": 12220,
    "originalRank": 2644
  },
  {
    "word": "conciencia",
    "rank": 2548,
    "frequency": 12214,
    "originalRank": 2645
  },
  {
    "word": "doc",
    "rank": 2549,
    "frequency": 12213,
    "originalRank": 2646
  },
  {
    "word": "pesadilla",
    "rank": 2550,
    "frequency": 12209,
    "originalRank": 2647
  },
  {
    "word": "sopa",
    "rank": 2551,
    "frequency": 12206,
    "originalRank": 2648
  },
  {
    "word": "saltar",
    "rank": 2552,
    "frequency": 12196,
    "originalRank": 2649
  },
  {
    "word": "heridas",
    "rank": 2553,
    "frequency": 12188,
    "originalRank": 2650
  },
  {
    "word": "pienses",
    "rank": 2554,
    "frequency": 12167,
    "originalRank": 2651
  },
  {
    "word": "suicidio",
    "rank": 2555,
    "frequency": 12163,
    "originalRank": 2652
  },
  {
    "word": "llamarme",
    "rank": 2556,
    "frequency": 12162,
    "originalRank": 2653
  },
  {
    "word": "posibilidades",
    "rank": 2557,
    "frequency": 12159,
    "originalRank": 2654
  },
  {
    "word": "elegido",
    "rank": 2558,
    "frequency": 12155,
    "originalRank": 2655
  },
  {
    "word": "divorcio",
    "rank": 2559,
    "frequency": 12154,
    "originalRank": 2656
  },
  {
    "word": "registros",
    "rank": 2560,
    "frequency": 12154,
    "originalRank": 2657
  },
  {
    "word": "recibí",
    "rank": 2561,
    "frequency": 12152,
    "originalRank": 2658
  },
  {
    "word": "joey",
    "rank": 2562,
    "frequency": 12145,
    "originalRank": 2659
  },
  {
    "word": "escuchas",
    "rank": 2563,
    "frequency": 12140,
    "originalRank": 2660
  },
  {
    "word": "mirad",
    "rank": 2564,
    "frequency": 12137,
    "originalRank": 2661
  },
  {
    "word": "pierde",
    "rank": 2565,
    "frequency": 12133,
    "originalRank": 2662
  },
  {
    "word": "abogados",
    "rank": 2566,
    "frequency": 12132,
    "originalRank": 2663
  },
  {
    "word": "trataba",
    "rank": 2567,
    "frequency": 12127,
    "originalRank": 2664
  },
  {
    "word": "americanos",
    "rank": 2568,
    "frequency": 12122,
    "originalRank": 2665
  },
  {
    "word": "llevando",
    "rank": 2569,
    "frequency": 12119,
    "originalRank": 2666
  },
  {
    "word": "miel",
    "rank": 2570,
    "frequency": 12117,
    "originalRank": 2667
  },
  {
    "word": "regrese",
    "rank": 2571,
    "frequency": 12097,
    "originalRank": 2668
  },
  {
    "word": "dilo",
    "rank": 2572,
    "frequency": 12094,
    "originalRank": 2669
  },
  {
    "word": "hermanas",
    "rank": 2573,
    "frequency": 12094,
    "originalRank": 2670
  },
  {
    "word": "alemán",
    "rank": 2574,
    "frequency": 12091,
    "originalRank": 2671
  },
  {
    "word": "iría",
    "rank": 2575,
    "frequency": 12088,
    "originalRank": 2672
  },
  {
    "word": "lady",
    "rank": 2576,
    "frequency": 12086,
    "originalRank": 2673
  },
  {
    "word": "salí",
    "rank": 2577,
    "frequency": 12083,
    "originalRank": 2674
  },
  {
    "word": "particular",
    "rank": 2578,
    "frequency": 12079,
    "originalRank": 2675
  },
  {
    "word": "miras",
    "rank": 2579,
    "frequency": 12075,
    "originalRank": 2676
  },
  {
    "word": "frontera",
    "rank": 2580,
    "frequency": 12073,
    "originalRank": 2677
  },
  {
    "word": "ventaja",
    "rank": 2581,
    "frequency": 12062,
    "originalRank": 2678
  },
  {
    "word": "alerta",
    "rank": 2582,
    "frequency": 12052,
    "originalRank": 2679
  },
  {
    "word": "piscina",
    "rank": 2583,
    "frequency": 12049,
    "originalRank": 2680
  },
  {
    "word": "regalos",
    "rank": 2584,
    "frequency": 12047,
    "originalRank": 2681
  },
  {
    "word": "comportamiento",
    "rank": 2585,
    "frequency": 12040,
    "originalRank": 2682
  },
  {
    "word": "julia",
    "rank": 2586,
    "frequency": 12040,
    "originalRank": 2683
  },
  {
    "word": "señales",
    "rank": 2587,
    "frequency": 12038,
    "originalRank": 2684
  },
  {
    "word": "salimos",
    "rank": 2588,
    "frequency": 12028,
    "originalRank": 2685
  },
  {
    "word": "revista",
    "rank": 2589,
    "frequency": 12021,
    "originalRank": 2686
  },
  {
    "word": "hecha",
    "rank": 2590,
    "frequency": 12006,
    "originalRank": 2687
  },
  {
    "word": "imágenes",
    "rank": 2591,
    "frequency": 12005,
    "originalRank": 2688
  },
  {
    "word": "llegas",
    "rank": 2592,
    "frequency": 11999,
    "originalRank": 2689
  },
  {
    "word": "rápida",
    "rank": 2593,
    "frequency": 11991,
    "originalRank": 2690
  },
  {
    "word": "canal",
    "rank": 2594,
    "frequency": 11988,
    "originalRank": 2691
  },
  {
    "word": "paciencia",
    "rank": 2595,
    "frequency": 11988,
    "originalRank": 2692
  },
  {
    "word": "sacado",
    "rank": 2596,
    "frequency": 11985,
    "originalRank": 2693
  },
  {
    "word": "echo",
    "rank": 2597,
    "frequency": 11980,
    "originalRank": 2694
  },
  {
    "word": "crisis",
    "rank": 2598,
    "frequency": 11975,
    "originalRank": 2695
  },
  {
    "word": "asesinos",
    "rank": 2599,
    "frequency": 11973,
    "originalRank": 2696
  },
  {
    "word": "oíste",
    "rank": 2600,
    "frequency": 11970,
    "originalRank": 2697
  },
  {
    "word": "dejando",
    "rank": 2601,
    "frequency": 11951,
    "originalRank": 2698
  },
  {
    "word": "estarías",
    "rank": 2602,
    "frequency": 11950,
    "originalRank": 2699
  },
  {
    "word": "anteriormente",
    "rank": 2603,
    "frequency": 11950,
    "originalRank": 2700
  },
  {
    "word": "vigilancia",
    "rank": 2604,
    "frequency": 11948,
    "originalRank": 2701
  },
  {
    "word": "desierto",
    "rank": 2605,
    "frequency": 11945,
    "originalRank": 2702
  },
  {
    "word": "asustada",
    "rank": 2606,
    "frequency": 11945,
    "originalRank": 2703
  },
  {
    "word": "cuerda",
    "rank": 2607,
    "frequency": 11944,
    "originalRank": 2704
  },
  {
    "word": "míos",
    "rank": 2608,
    "frequency": 11941,
    "originalRank": 2705
  },
  {
    "word": "chuck",
    "rank": 2609,
    "frequency": 11938,
    "originalRank": 2706
  },
  {
    "word": "seguido",
    "rank": 2610,
    "frequency": 11937,
    "originalRank": 2707
  },
  {
    "word": "seremos",
    "rank": 2611,
    "frequency": 11936,
    "originalRank": 2708
  },
  {
    "word": "morgan",
    "rank": 2612,
    "frequency": 11906,
    "originalRank": 2709
  },
  {
    "word": "pene",
    "rank": 2613,
    "frequency": 11902,
    "originalRank": 2710
  },
  {
    "word": "despierto",
    "rank": 2614,
    "frequency": 11899,
    "originalRank": 2711
  },
  {
    "word": "gobernador",
    "rank": 2615,
    "frequency": 11882,
    "originalRank": 2712
  },
  {
    "word": "sección",
    "rank": 2616,
    "frequency": 11882,
    "originalRank": 2713
  },
  {
    "word": "casarme",
    "rank": 2617,
    "frequency": 11871,
    "originalRank": 2714
  },
  {
    "word": "trabajos",
    "rank": 2618,
    "frequency": 11862,
    "originalRank": 2715
  },
  {
    "word": "karen",
    "rank": 2619,
    "frequency": 11860,
    "originalRank": 2716
  },
  {
    "word": "preparados",
    "rank": 2620,
    "frequency": 11855,
    "originalRank": 2717
  },
  {
    "word": "murieron",
    "rank": 2621,
    "frequency": 11854,
    "originalRank": 2718
  },
  {
    "word": "oso",
    "rank": 2622,
    "frequency": 11845,
    "originalRank": 2719
  },
  {
    "word": "curiosidad",
    "rank": 2623,
    "frequency": 11843,
    "originalRank": 2720
  },
  {
    "word": "hank",
    "rank": 2624,
    "frequency": 11829,
    "originalRank": 2722
  },
  {
    "word": "impresión",
    "rank": 2625,
    "frequency": 11825,
    "originalRank": 2723
  },
  {
    "word": "pez",
    "rank": 2626,
    "frequency": 11819,
    "originalRank": 2724
  },
  {
    "word": "pasaba",
    "rank": 2627,
    "frequency": 11818,
    "originalRank": 2725
  },
  {
    "word": "escuchaste",
    "rank": 2628,
    "frequency": 11816,
    "originalRank": 2726
  },
  {
    "word": "torre",
    "rank": 2629,
    "frequency": 11814,
    "originalRank": 2727
  },
  {
    "word": "sientas",
    "rank": 2630,
    "frequency": 11813,
    "originalRank": 2728
  },
  {
    "word": "mentir",
    "rank": 2631,
    "frequency": 11810,
    "originalRank": 2729
  },
  {
    "word": "pasillo",
    "rank": 2632,
    "frequency": 11809,
    "originalRank": 2730
  },
  {
    "word": "juega",
    "rank": 2633,
    "frequency": 11807,
    "originalRank": 2731
  },
  {
    "word": "suéltame",
    "rank": 2634,
    "frequency": 11794,
    "originalRank": 2732
  },
  {
    "word": "arresto",
    "rank": 2635,
    "frequency": 11791,
    "originalRank": 2733
  },
  {
    "word": "ricos",
    "rank": 2636,
    "frequency": 11783,
    "originalRank": 2734
  },
  {
    "word": "sencillo",
    "rank": 2637,
    "frequency": 11782,
    "originalRank": 2735
  },
  {
    "word": "ruta",
    "rank": 2638,
    "frequency": 11779,
    "originalRank": 2736
  },
  {
    "word": "documentos",
    "rank": 2639,
    "frequency": 11778,
    "originalRank": 2737
  },
  {
    "word": "enamorada",
    "rank": 2640,
    "frequency": 11777,
    "originalRank": 2738
  },
  {
    "word": "apuesta",
    "rank": 2641,
    "frequency": 11760,
    "originalRank": 2739
  },
  {
    "word": "perdida",
    "rank": 2642,
    "frequency": 11748,
    "originalRank": 2740
  },
  {
    "word": "vinieron",
    "rank": 2643,
    "frequency": 11737,
    "originalRank": 2741
  },
  {
    "word": "ayudarnos",
    "rank": 2644,
    "frequency": 11733,
    "originalRank": 2742
  },
  {
    "word": "presento",
    "rank": 2645,
    "frequency": 11727,
    "originalRank": 2743
  },
  {
    "word": "hazme",
    "rank": 2646,
    "frequency": 11718,
    "originalRank": 2744
  },
  {
    "word": "leí",
    "rank": 2647,
    "frequency": 11710,
    "originalRank": 2745
  },
  {
    "word": "arthur",
    "rank": 2648,
    "frequency": 11706,
    "originalRank": 2746
  },
  {
    "word": "virus",
    "rank": 2649,
    "frequency": 11704,
    "originalRank": 2747
  },
  {
    "word": "lárgate",
    "rank": 2650,
    "frequency": 11702,
    "originalRank": 2748
  },
  {
    "word": "sigan",
    "rank": 2651,
    "frequency": 11701,
    "originalRank": 2749
  },
  {
    "word": "compró",
    "rank": 2652,
    "frequency": 11699,
    "originalRank": 2750
  },
  {
    "word": "servir",
    "rank": 2653,
    "frequency": 11696,
    "originalRank": 2751
  },
  {
    "word": "pongas",
    "rank": 2654,
    "frequency": 11694,
    "originalRank": 2752
  },
  {
    "word": "alarma",
    "rank": 2655,
    "frequency": 11689,
    "originalRank": 2753
  },
  {
    "word": "identidad",
    "rank": 2656,
    "frequency": 11688,
    "originalRank": 2754
  },
  {
    "word": "iguales",
    "rank": 2657,
    "frequency": 11688,
    "originalRank": 2755
  },
  {
    "word": "aviso",
    "rank": 2658,
    "frequency": 11686,
    "originalRank": 2756
  },
  {
    "word": "aprendido",
    "rank": 2659,
    "frequency": 11677,
    "originalRank": 2757
  },
  {
    "word": "caza",
    "rank": 2660,
    "frequency": 11666,
    "originalRank": 2758
  },
  {
    "word": "daba",
    "rank": 2661,
    "frequency": 11653,
    "originalRank": 2759
  },
  {
    "word": "muchacha",
    "rank": 2662,
    "frequency": 11647,
    "originalRank": 2760
  },
  {
    "word": "permanecer",
    "rank": 2663,
    "frequency": 11630,
    "originalRank": 2761
  },
  {
    "word": "bebés",
    "rank": 2664,
    "frequency": 11630,
    "originalRank": 2762
  },
  {
    "word": "opciones",
    "rank": 2665,
    "frequency": 11626,
    "originalRank": 2763
  },
  {
    "word": "responde",
    "rank": 2666,
    "frequency": 11625,
    "originalRank": 2764
  },
  {
    "word": "vernos",
    "rank": 2667,
    "frequency": 11625,
    "originalRank": 2765
  },
  {
    "word": "julie",
    "rank": 2668,
    "frequency": 11623,
    "originalRank": 2766
  },
  {
    "word": "llamaste",
    "rank": 2669,
    "frequency": 11610,
    "originalRank": 2767
  },
  {
    "word": "ponerse",
    "rank": 2670,
    "frequency": 11604,
    "originalRank": 2768
  },
  {
    "word": "sacó",
    "rank": 2671,
    "frequency": 11602,
    "originalRank": 2769
  },
  {
    "word": "orgullo",
    "rank": 2672,
    "frequency": 11596,
    "originalRank": 2770
  },
  {
    "word": "reales",
    "rank": 2673,
    "frequency": 11594,
    "originalRank": 2771
  },
  {
    "word": "esperan",
    "rank": 2674,
    "frequency": 11589,
    "originalRank": 2772
  },
  {
    "word": "vuelves",
    "rank": 2675,
    "frequency": 11587,
    "originalRank": 2773
  },
  {
    "word": "maggie",
    "rank": 2676,
    "frequency": 11582,
    "originalRank": 2774
  },
  {
    "word": "serlo",
    "rank": 2677,
    "frequency": 11578,
    "originalRank": 2775
  },
  {
    "word": "cuantas",
    "rank": 2678,
    "frequency": 11570,
    "originalRank": 2776
  },
  {
    "word": "enfadado",
    "rank": 2679,
    "frequency": 11566,
    "originalRank": 2777
  },
  {
    "word": "ponen",
    "rank": 2680,
    "frequency": 11560,
    "originalRank": 2778
  },
  {
    "word": "altura",
    "rank": 2681,
    "frequency": 11560,
    "originalRank": 2779
  },
  {
    "word": "jones",
    "rank": 2682,
    "frequency": 11544,
    "originalRank": 2780
  },
  {
    "word": "archivo",
    "rank": 2683,
    "frequency": 11541,
    "originalRank": 2781
  },
  {
    "word": "fred",
    "rank": 2684,
    "frequency": 11539,
    "originalRank": 2782
  },
  {
    "word": "ayudará",
    "rank": 2685,
    "frequency": 11535,
    "originalRank": 2783
  },
  {
    "word": "fácilmente",
    "rank": 2686,
    "frequency": 11534,
    "originalRank": 2784
  },
  {
    "word": "criatura",
    "rank": 2687,
    "frequency": 11525,
    "originalRank": 2785
  },
  {
    "word": "saco",
    "rank": 2688,
    "frequency": 11515,
    "originalRank": 2786
  },
  {
    "word": "precisamente",
    "rank": 2689,
    "frequency": 11511,
    "originalRank": 2787
  },
  {
    "word": "máximo",
    "rank": 2690,
    "frequency": 11510,
    "originalRank": 2788
  },
  {
    "word": "viniendo",
    "rank": 2691,
    "frequency": 11506,
    "originalRank": 2789
  },
  {
    "word": "vendría",
    "rank": 2692,
    "frequency": 11503,
    "originalRank": 2790
  },
  {
    "word": "louis",
    "rank": 2693,
    "frequency": 11498,
    "originalRank": 2791
  },
  {
    "word": "ilegal",
    "rank": 2694,
    "frequency": 11497,
    "originalRank": 2792
  },
  {
    "word": "refiere",
    "rank": 2695,
    "frequency": 11481,
    "originalRank": 2793
  },
  {
    "word": "llamamos",
    "rank": 2696,
    "frequency": 11458,
    "originalRank": 2794
  },
  {
    "word": "versión",
    "rank": 2697,
    "frequency": 11452,
    "originalRank": 2795
  },
  {
    "word": "incendio",
    "rank": 2698,
    "frequency": 11443,
    "originalRank": 2796
  },
  {
    "word": "preferiría",
    "rank": 2699,
    "frequency": 11439,
    "originalRank": 2797
  },
  {
    "word": "gritar",
    "rank": 2700,
    "frequency": 11433,
    "originalRank": 2798
  },
  {
    "word": "recibió",
    "rank": 2701,
    "frequency": 11430,
    "originalRank": 2799
  },
  {
    "word": "concierto",
    "rank": 2702,
    "frequency": 11423,
    "originalRank": 2800
  },
  {
    "word": "casualidad",
    "rank": 2703,
    "frequency": 11421,
    "originalRank": 2801
  },
  {
    "word": "excusa",
    "rank": 2704,
    "frequency": 11406,
    "originalRank": 2802
  },
  {
    "word": "rodillas",
    "rank": 2705,
    "frequency": 11388,
    "originalRank": 2803
  },
  {
    "word": "cruz",
    "rank": 2706,
    "frequency": 11388,
    "originalRank": 2804
  },
  {
    "word": "dulces",
    "rank": 2707,
    "frequency": 11387,
    "originalRank": 2805
  },
  {
    "word": "zorra",
    "rank": 2708,
    "frequency": 11386,
    "originalRank": 2806
  },
  {
    "word": "cómodo",
    "rank": 2709,
    "frequency": 11378,
    "originalRank": 2807
  },
  {
    "word": "cruel",
    "rank": 2710,
    "frequency": 11371,
    "originalRank": 2808
  },
  {
    "word": "sofá",
    "rank": 2711,
    "frequency": 11367,
    "originalRank": 2809
  },
  {
    "word": "perdiste",
    "rank": 2712,
    "frequency": 11363,
    "originalRank": 2810
  },
  {
    "word": "encantadora",
    "rank": 2713,
    "frequency": 11363,
    "originalRank": 2811
  },
  {
    "word": "salgamos",
    "rank": 2714,
    "frequency": 11362,
    "originalRank": 2812
  },
  {
    "word": "sombra",
    "rank": 2715,
    "frequency": 11356,
    "originalRank": 2813
  },
  {
    "word": "ganó",
    "rank": 2716,
    "frequency": 11351,
    "originalRank": 2814
  },
  {
    "word": "encantada",
    "rank": 2717,
    "frequency": 11350,
    "originalRank": 2815
  },
  {
    "word": "firmar",
    "rank": 2718,
    "frequency": 11338,
    "originalRank": 2816
  },
  {
    "word": "escritorio",
    "rank": 2719,
    "frequency": 11336,
    "originalRank": 2817
  },
  {
    "word": "muñeca",
    "rank": 2720,
    "frequency": 11336,
    "originalRank": 2818
  },
  {
    "word": "rastro",
    "rank": 2721,
    "frequency": 11335,
    "originalRank": 2819
  },
  {
    "word": "gigante",
    "rank": 2722,
    "frequency": 11313,
    "originalRank": 2820
  },
  {
    "word": "pájaro",
    "rank": 2723,
    "frequency": 11313,
    "originalRank": 2821
  },
  {
    "word": "ducha",
    "rank": 2724,
    "frequency": 11312,
    "originalRank": 2822
  },
  {
    "word": "tomamos",
    "rank": 2725,
    "frequency": 11312,
    "originalRank": 2823
  },
  {
    "word": "déjenme",
    "rank": 2726,
    "frequency": 11307,
    "originalRank": 2824
  },
  {
    "word": "condición",
    "rank": 2727,
    "frequency": 11302,
    "originalRank": 2825
  },
  {
    "word": "recompensa",
    "rank": 2728,
    "frequency": 11285,
    "originalRank": 2826
  },
  {
    "word": "doce",
    "rank": 2729,
    "frequency": 11283,
    "originalRank": 2827
  },
  {
    "word": "actor",
    "rank": 2730,
    "frequency": 11282,
    "originalRank": 2828
  },
  {
    "word": "actitud",
    "rank": 2731,
    "frequency": 11272,
    "originalRank": 2829
  },
  {
    "word": "cuida",
    "rank": 2732,
    "frequency": 11269,
    "originalRank": 2830
  },
  {
    "word": "salsa",
    "rank": 2733,
    "frequency": 11264,
    "originalRank": 2831
  },
  {
    "word": "hubieran",
    "rank": 2734,
    "frequency": 11263,
    "originalRank": 2832
  },
  {
    "word": "carlos",
    "rank": 2735,
    "frequency": 11255,
    "originalRank": 2833
  },
  {
    "word": "personaje",
    "rank": 2736,
    "frequency": 11255,
    "originalRank": 2834
  },
  {
    "word": "dudas",
    "rank": 2737,
    "frequency": 11248,
    "originalRank": 2835
  },
  {
    "word": "jackie",
    "rank": 2738,
    "frequency": 11247,
    "originalRank": 2836
  },
  {
    "word": "cambios",
    "rank": 2739,
    "frequency": 11241,
    "originalRank": 2837
  },
  {
    "word": "votos",
    "rank": 2740,
    "frequency": 11241,
    "originalRank": 2838
  },
  {
    "word": "vivido",
    "rank": 2741,
    "frequency": 11235,
    "originalRank": 2839
  },
  {
    "word": "perdimos",
    "rank": 2742,
    "frequency": 11231,
    "originalRank": 2840
  },
  {
    "word": "suficientes",
    "rank": 2743,
    "frequency": 11230,
    "originalRank": 2841
  },
  {
    "word": "entrega",
    "rank": 2744,
    "frequency": 11229,
    "originalRank": 2842
  },
  {
    "word": "comercial",
    "rank": 2745,
    "frequency": 11227,
    "originalRank": 2843
  },
  {
    "word": "decidí",
    "rank": 2746,
    "frequency": 11223,
    "originalRank": 2844
  },
  {
    "word": "tribu",
    "rank": 2747,
    "frequency": 11221,
    "originalRank": 2845
  },
  {
    "word": "pura",
    "rank": 2748,
    "frequency": 11221,
    "originalRank": 2846
  },
  {
    "word": "volveremos",
    "rank": 2749,
    "frequency": 11220,
    "originalRank": 2847
  },
  {
    "word": "voto",
    "rank": 2750,
    "frequency": 11220,
    "originalRank": 2848
  },
  {
    "word": "méxico",
    "rank": 2751,
    "frequency": 11218,
    "originalRank": 2849
  },
  {
    "word": "amar",
    "rank": 2752,
    "frequency": 11218,
    "originalRank": 2850
  },
  {
    "word": "poderoso",
    "rank": 2753,
    "frequency": 11215,
    "originalRank": 2851
  },
  {
    "word": "traigo",
    "rank": 2754,
    "frequency": 11205,
    "originalRank": 2852
  },
  {
    "word": "asesinatos",
    "rank": 2755,
    "frequency": 11202,
    "originalRank": 2853
  },
  {
    "word": "fresco",
    "rank": 2756,
    "frequency": 11186,
    "originalRank": 2854
  },
  {
    "word": "privada",
    "rank": 2757,
    "frequency": 11174,
    "originalRank": 2855
  },
  {
    "word": "seamos",
    "rank": 2758,
    "frequency": 11160,
    "originalRank": 2856
  },
  {
    "word": "guarda",
    "rank": 2759,
    "frequency": 11159,
    "originalRank": 2857
  },
  {
    "word": "orgullosa",
    "rank": 2760,
    "frequency": 11158,
    "originalRank": 2858
  },
  {
    "word": "vivimos",
    "rank": 2761,
    "frequency": 11155,
    "originalRank": 2859
  },
  {
    "word": "difíciles",
    "rank": 2762,
    "frequency": 11154,
    "originalRank": 2860
  },
  {
    "word": "hagámoslo",
    "rank": 2763,
    "frequency": 11150,
    "originalRank": 2861
  },
  {
    "word": "jefa",
    "rank": 2764,
    "frequency": 11141,
    "originalRank": 2862
  },
  {
    "word": "trató",
    "rank": 2765,
    "frequency": 11140,
    "originalRank": 2863
  },
  {
    "word": "senador",
    "rank": 2766,
    "frequency": 11138,
    "originalRank": 2864
  },
  {
    "word": "ayudando",
    "rank": 2767,
    "frequency": 11133,
    "originalRank": 2865
  },
  {
    "word": "campeón",
    "rank": 2768,
    "frequency": 11130,
    "originalRank": 2866
  },
  {
    "word": "bebiendo",
    "rank": 2769,
    "frequency": 11121,
    "originalRank": 2867
  },
  {
    "word": "adorable",
    "rank": 2770,
    "frequency": 11112,
    "originalRank": 2868
  },
  {
    "word": "ayudó",
    "rank": 2771,
    "frequency": 11111,
    "originalRank": 2869
  },
  {
    "word": "ciego",
    "rank": 2772,
    "frequency": 11110,
    "originalRank": 2870
  },
  {
    "word": "falsa",
    "rank": 2773,
    "frequency": 11108,
    "originalRank": 2871
  },
  {
    "word": "sara",
    "rank": 2774,
    "frequency": 11102,
    "originalRank": 2873
  },
  {
    "word": "bestia",
    "rank": 2775,
    "frequency": 11100,
    "originalRank": 2874
  },
  {
    "word": "alteza",
    "rank": 2776,
    "frequency": 11096,
    "originalRank": 2875
  },
  {
    "word": "deseos",
    "rank": 2777,
    "frequency": 11083,
    "originalRank": 2876
  },
  {
    "word": "episodio",
    "rank": 2778,
    "frequency": 11073,
    "originalRank": 2877
  },
  {
    "word": "celda",
    "rank": 2779,
    "frequency": 11058,
    "originalRank": 2878
  },
  {
    "word": "llevarlo",
    "rank": 2780,
    "frequency": 11043,
    "originalRank": 2879
  },
  {
    "word": "aguanta",
    "rank": 2781,
    "frequency": 11037,
    "originalRank": 2880
  },
  {
    "word": "vengas",
    "rank": 2782,
    "frequency": 11036,
    "originalRank": 2881
  },
  {
    "word": "jueves",
    "rank": 2783,
    "frequency": 11026,
    "originalRank": 2882
  },
  {
    "word": "montañas",
    "rank": 2784,
    "frequency": 11025,
    "originalRank": 2883
  },
  {
    "word": "pensamientos",
    "rank": 2785,
    "frequency": 11020,
    "originalRank": 2884
  },
  {
    "word": "medianoche",
    "rank": 2786,
    "frequency": 11020,
    "originalRank": 2885
  },
  {
    "word": "llevarme",
    "rank": 2787,
    "frequency": 11015,
    "originalRank": 2886
  },
  {
    "word": "garganta",
    "rank": 2788,
    "frequency": 11011,
    "originalRank": 2887
  },
  {
    "word": "sesión",
    "rank": 2789,
    "frequency": 11008,
    "originalRank": 2888
  },
  {
    "word": "pensaste",
    "rank": 2790,
    "frequency": 11003,
    "originalRank": 2889
  },
  {
    "word": "diles",
    "rank": 2791,
    "frequency": 10995,
    "originalRank": 2890
  },
  {
    "word": "muera",
    "rank": 2792,
    "frequency": 10991,
    "originalRank": 2891
  },
  {
    "word": "coma",
    "rank": 2793,
    "frequency": 10987,
    "originalRank": 2892
  },
  {
    "word": "sentimos",
    "rank": 2794,
    "frequency": 10984,
    "originalRank": 2893
  },
  {
    "word": "creas",
    "rank": 2795,
    "frequency": 10984,
    "originalRank": 2894
  },
  {
    "word": "escribe",
    "rank": 2796,
    "frequency": 10984,
    "originalRank": 2895
  },
  {
    "word": "identificación",
    "rank": 2797,
    "frequency": 10980,
    "originalRank": 2896
  },
  {
    "word": "circunstancias",
    "rank": 2798,
    "frequency": 10963,
    "originalRank": 2897
  },
  {
    "word": "preguntado",
    "rank": 2799,
    "frequency": 10963,
    "originalRank": 2898
  },
  {
    "word": "veneno",
    "rank": 2800,
    "frequency": 10950,
    "originalRank": 2899
  },
  {
    "word": "primavera",
    "rank": 2801,
    "frequency": 10950,
    "originalRank": 2900
  },
  {
    "word": "súper",
    "rank": 2802,
    "frequency": 10943,
    "originalRank": 2901
  },
  {
    "word": "vuestros",
    "rank": 2803,
    "frequency": 10942,
    "originalRank": 2902
  },
  {
    "word": "queríamos",
    "rank": 2804,
    "frequency": 10941,
    "originalRank": 2903
  },
  {
    "word": "aquello",
    "rank": 2805,
    "frequency": 10940,
    "originalRank": 2904
  },
  {
    "word": "preocuparse",
    "rank": 2806,
    "frequency": 10940,
    "originalRank": 2905
  },
  {
    "word": "martes",
    "rank": 2807,
    "frequency": 10940,
    "originalRank": 2906
  },
  {
    "word": "feo",
    "rank": 2808,
    "frequency": 10939,
    "originalRank": 2907
  },
  {
    "word": "cristo",
    "rank": 2809,
    "frequency": 10926,
    "originalRank": 2908
  },
  {
    "word": "francisco",
    "rank": 2810,
    "frequency": 10926,
    "originalRank": 2909
  },
  {
    "word": "howard",
    "rank": 2811,
    "frequency": 10920,
    "originalRank": 2910
  },
  {
    "word": "virgen",
    "rank": 2812,
    "frequency": 10917,
    "originalRank": 2911
  },
  {
    "word": "distrito",
    "rank": 2813,
    "frequency": 10915,
    "originalRank": 2912
  },
  {
    "word": "decidió",
    "rank": 2814,
    "frequency": 10910,
    "originalRank": 2913
  },
  {
    "word": "reputación",
    "rank": 2815,
    "frequency": 10910,
    "originalRank": 2914
  },
  {
    "word": "socorro",
    "rank": 2816,
    "frequency": 10899,
    "originalRank": 2915
  },
  {
    "word": "encontraré",
    "rank": 2817,
    "frequency": 10894,
    "originalRank": 2916
  },
  {
    "word": "castigo",
    "rank": 2818,
    "frequency": 10891,
    "originalRank": 2917
  },
  {
    "word": "dígale",
    "rank": 2819,
    "frequency": 10885,
    "originalRank": 2918
  },
  {
    "word": "límite",
    "rank": 2820,
    "frequency": 10874,
    "originalRank": 2919
  },
  {
    "word": "junta",
    "rank": 2821,
    "frequency": 10869,
    "originalRank": 2920
  },
  {
    "word": "ponerte",
    "rank": 2822,
    "frequency": 10859,
    "originalRank": 2921
  },
  {
    "word": "casados",
    "rank": 2823,
    "frequency": 10859,
    "originalRank": 2922
  },
  {
    "word": "líneas",
    "rank": 2824,
    "frequency": 10858,
    "originalRank": 2923
  },
  {
    "word": "estudios",
    "rank": 2825,
    "frequency": 10852,
    "originalRank": 2924
  },
  {
    "word": "muévanse",
    "rank": 2826,
    "frequency": 10850,
    "originalRank": 2925
  },
  {
    "word": "audiencia",
    "rank": 2827,
    "frequency": 10850,
    "originalRank": 2926
  },
  {
    "word": "helen",
    "rank": 2828,
    "frequency": 10845,
    "originalRank": 2927
  },
  {
    "word": "nació",
    "rank": 2829,
    "frequency": 10843,
    "originalRank": 2928
  },
  {
    "word": "mato",
    "rank": 2830,
    "frequency": 10839,
    "originalRank": 2929
  },
  {
    "word": "jugador",
    "rank": 2831,
    "frequency": 10832,
    "originalRank": 2930
  },
  {
    "word": "hmm",
    "rank": 2832,
    "frequency": 10831,
    "originalRank": 2931
  },
  {
    "word": "humo",
    "rank": 2833,
    "frequency": 10828,
    "originalRank": 2932
  },
  {
    "word": "popular",
    "rank": 2834,
    "frequency": 10825,
    "originalRank": 2933
  },
  {
    "word": "nación",
    "rank": 2835,
    "frequency": 10821,
    "originalRank": 2934
  },
  {
    "word": "conocimos",
    "rank": 2836,
    "frequency": 10807,
    "originalRank": 2935
  },
  {
    "word": "tropas",
    "rank": 2837,
    "frequency": 10804,
    "originalRank": 2936
  },
  {
    "word": "sucediendo",
    "rank": 2838,
    "frequency": 10803,
    "originalRank": 2937
  },
  {
    "word": "explicación",
    "rank": 2839,
    "frequency": 10789,
    "originalRank": 2938
  },
  {
    "word": "salen",
    "rank": 2840,
    "frequency": 10774,
    "originalRank": 2939
  },
  {
    "word": "discúlpeme",
    "rank": 2841,
    "frequency": 10772,
    "originalRank": 2940
  },
  {
    "word": "presentar",
    "rank": 2842,
    "frequency": 10770,
    "originalRank": 2941
  },
  {
    "word": "donna",
    "rank": 2843,
    "frequency": 10768,
    "originalRank": 2942
  },
  {
    "word": "celebrar",
    "rank": 2844,
    "frequency": 10761,
    "originalRank": 2943
  },
  {
    "word": "competencia",
    "rank": 2845,
    "frequency": 10759,
    "originalRank": 2944
  },
  {
    "word": "envía",
    "rank": 2846,
    "frequency": 10750,
    "originalRank": 2945
  },
  {
    "word": "mantén",
    "rank": 2847,
    "frequency": 10743,
    "originalRank": 2946
  },
  {
    "word": "verlos",
    "rank": 2848,
    "frequency": 10735,
    "originalRank": 2947
  },
  {
    "word": "biblioteca",
    "rank": 2849,
    "frequency": 10732,
    "originalRank": 2948
  },
  {
    "word": "fila",
    "rank": 2850,
    "frequency": 10728,
    "originalRank": 2949
  },
  {
    "word": "ésto",
    "rank": 2851,
    "frequency": 10720,
    "originalRank": 2950
  },
  {
    "word": "misterio",
    "rank": 2852,
    "frequency": 10719,
    "originalRank": 2951
  },
  {
    "word": "ganador",
    "rank": 2853,
    "frequency": 10715,
    "originalRank": 2952
  },
  {
    "word": "puerto",
    "rank": 2854,
    "frequency": 10711,
    "originalRank": 2953
  },
  {
    "word": "vehículo",
    "rank": 2855,
    "frequency": 10705,
    "originalRank": 2954
  },
  {
    "word": "escapó",
    "rank": 2856,
    "frequency": 10701,
    "originalRank": 2955
  },
  {
    "word": "traeré",
    "rank": 2857,
    "frequency": 10697,
    "originalRank": 2956
  },
  {
    "word": "julio",
    "rank": 2858,
    "frequency": 10691,
    "originalRank": 2957
  },
  {
    "word": "lograr",
    "rank": 2859,
    "frequency": 10687,
    "originalRank": 2958
  },
  {
    "word": "desaparecer",
    "rank": 2860,
    "frequency": 10681,
    "originalRank": 2959
  },
  {
    "word": "muero",
    "rank": 2861,
    "frequency": 10676,
    "originalRank": 2960
  },
  {
    "word": "quítate",
    "rank": 2862,
    "frequency": 10669,
    "originalRank": 2961
  },
  {
    "word": "favorita",
    "rank": 2863,
    "frequency": 10666,
    "originalRank": 2962
  },
  {
    "word": "patio",
    "rank": 2864,
    "frequency": 10664,
    "originalRank": 2963
  },
  {
    "word": "golpeó",
    "rank": 2865,
    "frequency": 10660,
    "originalRank": 2964
  },
  {
    "word": "tontería",
    "rank": 2866,
    "frequency": 10650,
    "originalRank": 2965
  },
  {
    "word": "miss",
    "rank": 2867,
    "frequency": 10650,
    "originalRank": 2966
  },
  {
    "word": "pecado",
    "rank": 2868,
    "frequency": 10648,
    "originalRank": 2967
  },
  {
    "word": "comité",
    "rank": 2869,
    "frequency": 10642,
    "originalRank": 2968
  },
  {
    "word": "preparada",
    "rank": 2870,
    "frequency": 10640,
    "originalRank": 2969
  },
  {
    "word": "comprado",
    "rank": 2871,
    "frequency": 10635,
    "originalRank": 2970
  },
  {
    "word": "parezca",
    "rank": 2872,
    "frequency": 10633,
    "originalRank": 2971
  },
  {
    "word": "emocionante",
    "rank": 2873,
    "frequency": 10632,
    "originalRank": 2972
  },
  {
    "word": "caras",
    "rank": 2874,
    "frequency": 10629,
    "originalRank": 2973
  },
  {
    "word": "rescate",
    "rank": 2875,
    "frequency": 10629,
    "originalRank": 2974
  },
  {
    "word": "título",
    "rank": 2876,
    "frequency": 10617,
    "originalRank": 2975
  },
  {
    "word": "llegaste",
    "rank": 2877,
    "frequency": 10616,
    "originalRank": 2976
  },
  {
    "word": "decírtelo",
    "rank": 2878,
    "frequency": 10615,
    "originalRank": 2977
  },
  {
    "word": "adivina",
    "rank": 2879,
    "frequency": 10611,
    "originalRank": 2978
  },
  {
    "word": "elizabeth",
    "rank": 2880,
    "frequency": 10611,
    "originalRank": 2979
  },
  {
    "word": "pánico",
    "rank": 2881,
    "frequency": 10609,
    "originalRank": 2980
  },
  {
    "word": "barry",
    "rank": 2882,
    "frequency": 10607,
    "originalRank": 2981
  },
  {
    "word": "quieran",
    "rank": 2883,
    "frequency": 10607,
    "originalRank": 2982
  },
  {
    "word": "abby",
    "rank": 2884,
    "frequency": 10606,
    "originalRank": 2983
  },
  {
    "word": "exterior",
    "rank": 2885,
    "frequency": 10601,
    "originalRank": 2984
  },
  {
    "word": "pasión",
    "rank": 2886,
    "frequency": 10592,
    "originalRank": 2985
  },
  {
    "word": "llegan",
    "rank": 2887,
    "frequency": 10579,
    "originalRank": 2986
  },
  {
    "word": "preparar",
    "rank": 2888,
    "frequency": 10572,
    "originalRank": 2987
  },
  {
    "word": "guau",
    "rank": 2889,
    "frequency": 10571,
    "originalRank": 2988
  },
  {
    "word": "patrick",
    "rank": 2890,
    "frequency": 10569,
    "originalRank": 2989
  },
  {
    "word": "tierras",
    "rank": 2891,
    "frequency": 10558,
    "originalRank": 2990
  },
  {
    "word": "demostrar",
    "rank": 2892,
    "frequency": 10551,
    "originalRank": 2991
  },
  {
    "word": "elegante",
    "rank": 2893,
    "frequency": 10551,
    "originalRank": 2992
  },
  {
    "word": "asegurarme",
    "rank": 2894,
    "frequency": 10545,
    "originalRank": 2993
  },
  {
    "word": "visitar",
    "rank": 2895,
    "frequency": 10545,
    "originalRank": 2994
  },
  {
    "word": "asegúrate",
    "rank": 2896,
    "frequency": 10543,
    "originalRank": 2995
  },
  {
    "word": "darles",
    "rank": 2897,
    "frequency": 10542,
    "originalRank": 2996
  },
  {
    "word": "cabezas",
    "rank": 2898,
    "frequency": 10541,
    "originalRank": 2997
  },
  {
    "word": "abra",
    "rank": 2899,
    "frequency": 10537,
    "originalRank": 2998
  },
  {
    "word": "andrew",
    "rank": 2900,
    "frequency": 10534,
    "originalRank": 2999
  },
  {
    "word": "dean",
    "rank": 2901,
    "frequency": 10515,
    "originalRank": 3000
  },
  {
    "word": "ambiente",
    "rank": 2902,
    "frequency": 10514,
    "originalRank": 3001
  },
  {
    "word": "conde",
    "rank": 2903,
    "frequency": 10512,
    "originalRank": 3002
  },
  {
    "word": "urgente",
    "rank": 2904,
    "frequency": 10502,
    "originalRank": 3003
  },
  {
    "word": "impuestos",
    "rank": 2905,
    "frequency": 10494,
    "originalRank": 3004
  },
  {
    "word": "antonio",
    "rank": 2906,
    "frequency": 10489,
    "originalRank": 3005
  },
  {
    "word": "distinto",
    "rank": 2907,
    "frequency": 10486,
    "originalRank": 3006
  },
  {
    "word": "encantan",
    "rank": 2908,
    "frequency": 10476,
    "originalRank": 3007
  },
  {
    "word": "ron",
    "rank": 2909,
    "frequency": 10475,
    "originalRank": 3008
  },
  {
    "word": "marcas",
    "rank": 2910,
    "frequency": 10472,
    "originalRank": 3009
  },
  {
    "word": "ayudarlo",
    "rank": 2911,
    "frequency": 10470,
    "originalRank": 3010
  },
  {
    "word": "leyendo",
    "rank": 2912,
    "frequency": 10467,
    "originalRank": 3011
  },
  {
    "word": "adecuado",
    "rank": 2913,
    "frequency": 10466,
    "originalRank": 3012
  },
  {
    "word": "cajas",
    "rank": 2914,
    "frequency": 10461,
    "originalRank": 3013
  },
  {
    "word": "abandonar",
    "rank": 2915,
    "frequency": 10460,
    "originalRank": 3014
  },
  {
    "word": "dispara",
    "rank": 2916,
    "frequency": 10459,
    "originalRank": 3015
  },
  {
    "word": "buscamos",
    "rank": 2917,
    "frequency": 10457,
    "originalRank": 3016
  },
  {
    "word": "funcionando",
    "rank": 2918,
    "frequency": 10454,
    "originalRank": 3017
  },
  {
    "word": "traté",
    "rank": 2919,
    "frequency": 10451,
    "originalRank": 3018
  },
  {
    "word": "cia",
    "rank": 2920,
    "frequency": 10451,
    "originalRank": 3019
  },
  {
    "word": "tomen",
    "rank": 2921,
    "frequency": 10448,
    "originalRank": 3020
  },
  {
    "word": "darnos",
    "rank": 2922,
    "frequency": 10443,
    "originalRank": 3021
  },
  {
    "word": "intentas",
    "rank": 2923,
    "frequency": 10440,
    "originalRank": 3022
  },
  {
    "word": "lily",
    "rank": 2924,
    "frequency": 10439,
    "originalRank": 3023
  },
  {
    "word": "gustado",
    "rank": 2925,
    "frequency": 10433,
    "originalRank": 3024
  },
  {
    "word": "jamie",
    "rank": 2926,
    "frequency": 10431,
    "originalRank": 3025
  },
  {
    "word": "luchando",
    "rank": 2927,
    "frequency": 10428,
    "originalRank": 3026
  },
  {
    "word": "apesta",
    "rank": 2928,
    "frequency": 10427,
    "originalRank": 3027
  },
  {
    "word": "volando",
    "rank": 2929,
    "frequency": 10418,
    "originalRank": 3028
  },
  {
    "word": "periódicos",
    "rank": 2930,
    "frequency": 10416,
    "originalRank": 3029
  },
  {
    "word": "lucas",
    "rank": 2931,
    "frequency": 10415,
    "originalRank": 3030
  },
  {
    "word": "detenido",
    "rank": 2932,
    "frequency": 10412,
    "originalRank": 3031
  },
  {
    "word": "curioso",
    "rank": 2933,
    "frequency": 10411,
    "originalRank": 3032
  },
  {
    "word": "tetas",
    "rank": 2934,
    "frequency": 10395,
    "originalRank": 3033
  },
  {
    "word": "caro",
    "rank": 2935,
    "frequency": 10393,
    "originalRank": 3034
  },
  {
    "word": "asco",
    "rank": 2936,
    "frequency": 10385,
    "originalRank": 3035
  },
  {
    "word": "usó",
    "rank": 2937,
    "frequency": 10382,
    "originalRank": 3036
  },
  {
    "word": "buscas",
    "rank": 2938,
    "frequency": 10378,
    "originalRank": 3037
  },
  {
    "word": "amanda",
    "rank": 2939,
    "frequency": 10377,
    "originalRank": 3038
  },
  {
    "word": "salgo",
    "rank": 2940,
    "frequency": 10371,
    "originalRank": 3039
  },
  {
    "word": "decirnos",
    "rank": 2941,
    "frequency": 10370,
    "originalRank": 3040
  },
  {
    "word": "enseñó",
    "rank": 2942,
    "frequency": 10370,
    "originalRank": 3041
  },
  {
    "word": "rick",
    "rank": 2943,
    "frequency": 10369,
    "originalRank": 3042
  },
  {
    "word": "mírate",
    "rank": 2944,
    "frequency": 10368,
    "originalRank": 3043
  },
  {
    "word": "stan",
    "rank": 2945,
    "frequency": 10368,
    "originalRank": 3044
  },
  {
    "word": "debiste",
    "rank": 2946,
    "frequency": 10365,
    "originalRank": 3045
  },
  {
    "word": "océano",
    "rank": 2947,
    "frequency": 10358,
    "originalRank": 3046
  },
  {
    "word": "bolas",
    "rank": 2948,
    "frequency": 10355,
    "originalRank": 3047
  },
  {
    "word": "nuevamente",
    "rank": 2949,
    "frequency": 10350,
    "originalRank": 3048
  },
  {
    "word": "damos",
    "rank": 2950,
    "frequency": 10337,
    "originalRank": 3049
  },
  {
    "word": "pagado",
    "rank": 2951,
    "frequency": 10333,
    "originalRank": 3050
  },
  {
    "word": "federal",
    "rank": 2952,
    "frequency": 10325,
    "originalRank": 3051
  },
  {
    "word": "cuán",
    "rank": 2953,
    "frequency": 10324,
    "originalRank": 3052
  },
  {
    "word": "escalera",
    "rank": 2954,
    "frequency": 10323,
    "originalRank": 3053
  },
  {
    "word": "acepto",
    "rank": 2955,
    "frequency": 10322,
    "originalRank": 3054
  },
  {
    "word": "terapia",
    "rank": 2956,
    "frequency": 10316,
    "originalRank": 3056
  },
  {
    "word": "lágrimas",
    "rank": 2957,
    "frequency": 10312,
    "originalRank": 3057
  },
  {
    "word": "terreno",
    "rank": 2958,
    "frequency": 10312,
    "originalRank": 3058
  },
  {
    "word": "autoridad",
    "rank": 2959,
    "frequency": 10309,
    "originalRank": 3059
  },
  {
    "word": "encuentran",
    "rank": 2960,
    "frequency": 10308,
    "originalRank": 3060
  },
  {
    "word": "roca",
    "rank": 2961,
    "frequency": 10308,
    "originalRank": 3061
  },
  {
    "word": "superficie",
    "rank": 2962,
    "frequency": 10301,
    "originalRank": 3062
  },
  {
    "word": "cubierta",
    "rank": 2963,
    "frequency": 10300,
    "originalRank": 3063
  },
  {
    "word": "terry",
    "rank": 2964,
    "frequency": 10292,
    "originalRank": 3064
  },
  {
    "word": "hierba",
    "rank": 2965,
    "frequency": 10284,
    "originalRank": 3065
  },
  {
    "word": "juan",
    "rank": 2966,
    "frequency": 10283,
    "originalRank": 3066
  },
  {
    "word": "prometido",
    "rank": 2967,
    "frequency": 10283,
    "originalRank": 3067
  },
  {
    "word": "crecer",
    "rank": 2968,
    "frequency": 10282,
    "originalRank": 3068
  },
  {
    "word": "mental",
    "rank": 2969,
    "frequency": 10276,
    "originalRank": 3069
  },
  {
    "word": "extranjero",
    "rank": 2970,
    "frequency": 10273,
    "originalRank": 3070
  },
  {
    "word": "madame",
    "rank": 2971,
    "frequency": 10273,
    "originalRank": 3071
  },
  {
    "word": "prometí",
    "rank": 2972,
    "frequency": 10273,
    "originalRank": 3072
  },
  {
    "word": "mismas",
    "rank": 2973,
    "frequency": 10272,
    "originalRank": 3073
  },
  {
    "word": "existen",
    "rank": 2974,
    "frequency": 10267,
    "originalRank": 3074
  },
  {
    "word": "veas",
    "rank": 2975,
    "frequency": 10262,
    "originalRank": 3075
  },
  {
    "word": "lento",
    "rank": 2976,
    "frequency": 10257,
    "originalRank": 3076
  },
  {
    "word": "dirige",
    "rank": 2977,
    "frequency": 10249,
    "originalRank": 3077
  },
  {
    "word": "capaces",
    "rank": 2978,
    "frequency": 10235,
    "originalRank": 3078
  },
  {
    "word": "chino",
    "rank": 2979,
    "frequency": 10233,
    "originalRank": 3079
  },
  {
    "word": "vuelvan",
    "rank": 2980,
    "frequency": 10227,
    "originalRank": 3080
  },
  {
    "word": "meta",
    "rank": 2981,
    "frequency": 10225,
    "originalRank": 3081
  },
  {
    "word": "suelta",
    "rank": 2982,
    "frequency": 10216,
    "originalRank": 3082
  },
  {
    "word": "despedida",
    "rank": 2983,
    "frequency": 10216,
    "originalRank": 3083
  },
  {
    "word": "sucedido",
    "rank": 2984,
    "frequency": 10207,
    "originalRank": 3084
  },
  {
    "word": "pasta",
    "rank": 2985,
    "frequency": 10196,
    "originalRank": 3085
  },
  {
    "word": "cristal",
    "rank": 2986,
    "frequency": 10185,
    "originalRank": 3086
  },
  {
    "word": "vegas",
    "rank": 2987,
    "frequency": 10180,
    "originalRank": 3087
  },
  {
    "word": "gritando",
    "rank": 2988,
    "frequency": 10172,
    "originalRank": 3088
  },
  {
    "word": "pare",
    "rank": 2989,
    "frequency": 10147,
    "originalRank": 3089
  },
  {
    "word": "peces",
    "rank": 2990,
    "frequency": 10146,
    "originalRank": 3090
  },
  {
    "word": "brown",
    "rank": 2991,
    "frequency": 10138,
    "originalRank": 3091
  },
  {
    "word": "guardar",
    "rank": 2992,
    "frequency": 10132,
    "originalRank": 3092
  },
  {
    "word": "podían",
    "rank": 2993,
    "frequency": 10128,
    "originalRank": 3093
  },
  {
    "word": "sabían",
    "rank": 2994,
    "frequency": 10128,
    "originalRank": 3094
  },
  {
    "word": "literalmente",
    "rank": 2995,
    "frequency": 10126,
    "originalRank": 3095
  },
  {
    "word": "salvó",
    "rank": 2996,
    "frequency": 10122,
    "originalRank": 3096
  },
  {
    "word": "aprecio",
    "rank": 2997,
    "frequency": 10121,
    "originalRank": 3097
  },
  {
    "word": "fotografía",
    "rank": 2998,
    "frequency": 10120,
    "originalRank": 3098
  },
  {
    "word": "patrón",
    "rank": 2999,
    "frequency": 10119,
    "originalRank": 3099
  },
  {
    "word": "esposas",
    "rank": 3000,
    "frequency": 10113,
    "originalRank": 3100
  },
  {
    "word": "king",
    "rank": 3001,
    "frequency": 10104,
    "originalRank": 3101
  },
  {
    "word": "desafío",
    "rank": 3002,
    "frequency": 10099,
    "originalRank": 3102
  },
  {
    "word": "asombroso",
    "rank": 3003,
    "frequency": 10099,
    "originalRank": 3103
  },
  {
    "word": "pedazos",
    "rank": 3004,
    "frequency": 10094,
    "originalRank": 3104
  },
  {
    "word": "robin",
    "rank": 3005,
    "frequency": 10092,
    "originalRank": 3105
  },
  {
    "word": "sales",
    "rank": 3006,
    "frequency": 10091,
    "originalRank": 3106
  },
  {
    "word": "clínica",
    "rank": 3007,
    "frequency": 10091,
    "originalRank": 3107
  },
  {
    "word": "atrapar",
    "rank": 3008,
    "frequency": 10077,
    "originalRank": 3108
  },
  {
    "word": "experto",
    "rank": 3009,
    "frequency": 10072,
    "originalRank": 3109
  },
  {
    "word": "medida",
    "rank": 3010,
    "frequency": 10070,
    "originalRank": 3110
  },
  {
    "word": "tele",
    "rank": 3011,
    "frequency": 10054,
    "originalRank": 3111
  },
  {
    "word": "desagradable",
    "rank": 3012,
    "frequency": 10052,
    "originalRank": 3112
  },
  {
    "word": "custodia",
    "rank": 3013,
    "frequency": 10048,
    "originalRank": 3113
  },
  {
    "word": "nacido",
    "rank": 3014,
    "frequency": 10047,
    "originalRank": 3114
  },
  {
    "word": "anuncio",
    "rank": 3015,
    "frequency": 10045,
    "originalRank": 3115
  },
  {
    "word": "física",
    "rank": 3016,
    "frequency": 10040,
    "originalRank": 3116
  },
  {
    "word": "hollywood",
    "rank": 3017,
    "frequency": 10039,
    "originalRank": 3117
  },
  {
    "word": "empezado",
    "rank": 3018,
    "frequency": 10038,
    "originalRank": 3118
  },
  {
    "word": "fiebre",
    "rank": 3019,
    "frequency": 10022,
    "originalRank": 3120
  },
  {
    "word": "johnson",
    "rank": 3020,
    "frequency": 10019,
    "originalRank": 3121
  },
  {
    "word": "compañera",
    "rank": 3021,
    "frequency": 10017,
    "originalRank": 3122
  },
  {
    "word": "ayudarla",
    "rank": 3022,
    "frequency": 10015,
    "originalRank": 3123
  },
  {
    "word": "desgraciado",
    "rank": 3023,
    "frequency": 10015,
    "originalRank": 3124
  },
  {
    "word": "organización",
    "rank": 3024,
    "frequency": 10002,
    "originalRank": 3125
  },
  {
    "word": "echa",
    "rank": 3025,
    "frequency": 9995,
    "originalRank": 3126
  },
  {
    "word": "mina",
    "rank": 3026,
    "frequency": 9995,
    "originalRank": 3127
  },
  {
    "word": "honestamente",
    "rank": 3027,
    "frequency": 9991,
    "originalRank": 3128
  },
  {
    "word": "deuda",
    "rank": 3028,
    "frequency": 9988,
    "originalRank": 3129
  },
  {
    "word": "digan",
    "rank": 3029,
    "frequency": 9987,
    "originalRank": 3130
  },
  {
    "word": "transporte",
    "rank": 3030,
    "frequency": 9986,
    "originalRank": 3131
  },
  {
    "word": "cocinar",
    "rank": 3031,
    "frequency": 9986,
    "originalRank": 3132
  },
  {
    "word": "delicioso",
    "rank": 3032,
    "frequency": 9983,
    "originalRank": 3133
  },
  {
    "word": "podíamos",
    "rank": 3033,
    "frequency": 9980,
    "originalRank": 3134
  },
  {
    "word": "greg",
    "rank": 3034,
    "frequency": 9976,
    "originalRank": 3135
  },
  {
    "word": "dirás",
    "rank": 3035,
    "frequency": 9956,
    "originalRank": 3136
  },
  {
    "word": "habilidades",
    "rank": 3036,
    "frequency": 9949,
    "originalRank": 3137
  },
  {
    "word": "sentimiento",
    "rank": 3037,
    "frequency": 9944,
    "originalRank": 3138
  },
  {
    "word": "pudieras",
    "rank": 3038,
    "frequency": 9941,
    "originalRank": 3139
  },
  {
    "word": "golpes",
    "rank": 3039,
    "frequency": 9937,
    "originalRank": 3140
  },
  {
    "word": "nadar",
    "rank": 3040,
    "frequency": 9935,
    "originalRank": 3141
  },
  {
    "word": "operaciones",
    "rank": 3041,
    "frequency": 9934,
    "originalRank": 3142
  },
  {
    "word": "admitir",
    "rank": 3042,
    "frequency": 9929,
    "originalRank": 3143
  },
  {
    "word": "templo",
    "rank": 3043,
    "frequency": 9925,
    "originalRank": 3144
  },
  {
    "word": "adios",
    "rank": 3044,
    "frequency": 9921,
    "originalRank": 3145
  },
  {
    "word": "maravilla",
    "rank": 3045,
    "frequency": 9919,
    "originalRank": 3146
  },
  {
    "word": "quita",
    "rank": 3046,
    "frequency": 9914,
    "originalRank": 3147
  },
  {
    "word": "mate",
    "rank": 3047,
    "frequency": 9894,
    "originalRank": 3148
  },
  {
    "word": "piano",
    "rank": 3048,
    "frequency": 9891,
    "originalRank": 3149
  },
  {
    "word": "bombas",
    "rank": 3049,
    "frequency": 9885,
    "originalRank": 3150
  },
  {
    "word": "paredes",
    "rank": 3050,
    "frequency": 9874,
    "originalRank": 3151
  },
  {
    "word": "pantalla",
    "rank": 3051,
    "frequency": 9874,
    "originalRank": 3152
  },
  {
    "word": "italia",
    "rank": 3052,
    "frequency": 9865,
    "originalRank": 3153
  },
  {
    "word": "pusieron",
    "rank": 3053,
    "frequency": 9860,
    "originalRank": 3154
  },
  {
    "word": "sally",
    "rank": 3054,
    "frequency": 9857,
    "originalRank": 3155
  },
  {
    "word": "amén",
    "rank": 3055,
    "frequency": 9852,
    "originalRank": 3156
  },
  {
    "word": "mac",
    "rank": 3056,
    "frequency": 9848,
    "originalRank": 3157
  },
  {
    "word": "civil",
    "rank": 3057,
    "frequency": 9842,
    "originalRank": 3158
  },
  {
    "word": "fantasmas",
    "rank": 3058,
    "frequency": 9842,
    "originalRank": 3159
  },
  {
    "word": "gasolina",
    "rank": 3059,
    "frequency": 9841,
    "originalRank": 3160
  },
  {
    "word": "sabia",
    "rank": 3060,
    "frequency": 9839,
    "originalRank": 3161
  },
  {
    "word": "tyler",
    "rank": 3061,
    "frequency": 9832,
    "originalRank": 3162
  },
  {
    "word": "judíos",
    "rank": 3062,
    "frequency": 9819,
    "originalRank": 3163
  },
  {
    "word": "tripulación",
    "rank": 3063,
    "frequency": 9805,
    "originalRank": 3165
  },
  {
    "word": "pagan",
    "rank": 3064,
    "frequency": 9802,
    "originalRank": 3166
  },
  {
    "word": "arrestado",
    "rank": 3065,
    "frequency": 9787,
    "originalRank": 3167
  },
  {
    "word": "extraños",
    "rank": 3066,
    "frequency": 9782,
    "originalRank": 3168
  },
  {
    "word": "canta",
    "rank": 3067,
    "frequency": 9780,
    "originalRank": 3169
  },
  {
    "word": "texas",
    "rank": 3068,
    "frequency": 9772,
    "originalRank": 3170
  },
  {
    "word": "estando",
    "rank": 3069,
    "frequency": 9771,
    "originalRank": 3171
  },
  {
    "word": "flor",
    "rank": 3070,
    "frequency": 9765,
    "originalRank": 3172
  },
  {
    "word": "ricky",
    "rank": 3071,
    "frequency": 9763,
    "originalRank": 3173
  },
  {
    "word": "usan",
    "rank": 3072,
    "frequency": 9761,
    "originalRank": 3174
  },
  {
    "word": "cruzar",
    "rank": 3073,
    "frequency": 9758,
    "originalRank": 3175
  },
  {
    "word": "esperemos",
    "rank": 3074,
    "frequency": 9756,
    "originalRank": 3176
  },
  {
    "word": "guía",
    "rank": 3075,
    "frequency": 9755,
    "originalRank": 3177
  },
  {
    "word": "preocuparte",
    "rank": 3076,
    "frequency": 9752,
    "originalRank": 3178
  },
  {
    "word": "enseñar",
    "rank": 3077,
    "frequency": 9752,
    "originalRank": 3179
  },
  {
    "word": "irán",
    "rank": 3078,
    "frequency": 9750,
    "originalRank": 3180
  },
  {
    "word": "conferencia",
    "rank": 3079,
    "frequency": 9747,
    "originalRank": 3181
  },
  {
    "word": "miro",
    "rank": 3080,
    "frequency": 9745,
    "originalRank": 3182
  },
  {
    "word": "habitaciones",
    "rank": 3081,
    "frequency": 9744,
    "originalRank": 3183
  },
  {
    "word": "galletas",
    "rank": 3082,
    "frequency": 9743,
    "originalRank": 3184
  },
  {
    "word": "hablarle",
    "rank": 3083,
    "frequency": 9743,
    "originalRank": 3185
  },
  {
    "word": "delito",
    "rank": 3084,
    "frequency": 9740,
    "originalRank": 3186
  },
  {
    "word": "atacar",
    "rank": 3085,
    "frequency": 9738,
    "originalRank": 3187
  },
  {
    "word": "objeto",
    "rank": 3086,
    "frequency": 9734,
    "originalRank": 3188
  },
  {
    "word": "disparos",
    "rank": 3087,
    "frequency": 9732,
    "originalRank": 3189
  },
  {
    "word": "museo",
    "rank": 3088,
    "frequency": 9727,
    "originalRank": 3190
  },
  {
    "word": "ruedas",
    "rank": 3089,
    "frequency": 9716,
    "originalRank": 3191
  },
  {
    "word": "recientemente",
    "rank": 3090,
    "frequency": 9711,
    "originalRank": 3192
  },
  {
    "word": "huevo",
    "rank": 3091,
    "frequency": 9707,
    "originalRank": 3193
  },
  {
    "word": "violación",
    "rank": 3092,
    "frequency": 9706,
    "originalRank": 3194
  },
  {
    "word": "regresó",
    "rank": 3093,
    "frequency": 9704,
    "originalRank": 3195
  },
  {
    "word": "sufrir",
    "rank": 3094,
    "frequency": 9693,
    "originalRank": 3196
  },
  {
    "word": "tina",
    "rank": 3095,
    "frequency": 9687,
    "originalRank": 3197
  },
  {
    "word": "terminamos",
    "rank": 3096,
    "frequency": 9682,
    "originalRank": 3198
  },
  {
    "word": "disponible",
    "rank": 3097,
    "frequency": 9679,
    "originalRank": 3199
  },
  {
    "word": "rica",
    "rank": 3098,
    "frequency": 9679,
    "originalRank": 3200
  },
  {
    "word": "habilidad",
    "rank": 3099,
    "frequency": 9679,
    "originalRank": 3201
  },
  {
    "word": "práctica",
    "rank": 3100,
    "frequency": 9674,
    "originalRank": 3202
  },
  {
    "word": "acabe",
    "rank": 3101,
    "frequency": 9673,
    "originalRank": 3203
  },
  {
    "word": "amado",
    "rank": 3102,
    "frequency": 9672,
    "originalRank": 3204
  },
  {
    "word": "haberle",
    "rank": 3103,
    "frequency": 9667,
    "originalRank": 3205
  },
  {
    "word": "volvemos",
    "rank": 3104,
    "frequency": 9637,
    "originalRank": 3206
  },
  {
    "word": "tendrías",
    "rank": 3105,
    "frequency": 9633,
    "originalRank": 3207
  },
  {
    "word": "maestra",
    "rank": 3106,
    "frequency": 9629,
    "originalRank": 3208
  },
  {
    "word": "city",
    "rank": 3107,
    "frequency": 9627,
    "originalRank": 3209
  },
  {
    "word": "pastillas",
    "rank": 3108,
    "frequency": 9626,
    "originalRank": 3210
  },
  {
    "word": "aprendí",
    "rank": 3109,
    "frequency": 9624,
    "originalRank": 3211
  },
  {
    "word": "cable",
    "rank": 3110,
    "frequency": 9619,
    "originalRank": 3212
  },
  {
    "word": "nacimiento",
    "rank": 3111,
    "frequency": 9618,
    "originalRank": 3213
  },
  {
    "word": "consciente",
    "rank": 3112,
    "frequency": 9614,
    "originalRank": 3214
  },
  {
    "word": "alcance",
    "rank": 3113,
    "frequency": 9613,
    "originalRank": 3215
  },
  {
    "word": "evento",
    "rank": 3114,
    "frequency": 9605,
    "originalRank": 3216
  },
  {
    "word": "alquiler",
    "rank": 3115,
    "frequency": 9604,
    "originalRank": 3217
  },
  {
    "word": "ordenador",
    "rank": 3116,
    "frequency": 9604,
    "originalRank": 3218
  },
  {
    "word": "incidente",
    "rank": 3117,
    "frequency": 9601,
    "originalRank": 3219
  },
  {
    "word": "huh",
    "rank": 3118,
    "frequency": 9599,
    "originalRank": 3220
  },
  {
    "word": "escribí",
    "rank": 3119,
    "frequency": 9599,
    "originalRank": 3221
  },
  {
    "word": "estuvieron",
    "rank": 3120,
    "frequency": 9593,
    "originalRank": 3222
  },
  {
    "word": "intentaré",
    "rank": 3121,
    "frequency": 9586,
    "originalRank": 3223
  },
  {
    "word": "pensamiento",
    "rank": 3122,
    "frequency": 9581,
    "originalRank": 3224
  },
  {
    "word": "metió",
    "rank": 3123,
    "frequency": 9575,
    "originalRank": 3225
  },
  {
    "word": "maleta",
    "rank": 3124,
    "frequency": 9572,
    "originalRank": 3226
  },
  {
    "word": "condado",
    "rank": 3125,
    "frequency": 9569,
    "originalRank": 3227
  },
  {
    "word": "piezas",
    "rank": 3126,
    "frequency": 9568,
    "originalRank": 3228
  },
  {
    "word": "ladrones",
    "rank": 3127,
    "frequency": 9567,
    "originalRank": 3229
  },
  {
    "word": "metro",
    "rank": 3128,
    "frequency": 9564,
    "originalRank": 3230
  },
  {
    "word": "kilos",
    "rank": 3129,
    "frequency": 9563,
    "originalRank": 3231
  },
  {
    "word": "recuerde",
    "rank": 3130,
    "frequency": 9561,
    "originalRank": 3232
  },
  {
    "word": "español",
    "rank": 3131,
    "frequency": 9551,
    "originalRank": 3233
  },
  {
    "word": "motivos",
    "rank": 3132,
    "frequency": 9546,
    "originalRank": 3234
  },
  {
    "word": "explica",
    "rank": 3133,
    "frequency": 9540,
    "originalRank": 3235
  },
  {
    "word": "renunciar",
    "rank": 3134,
    "frequency": 9531,
    "originalRank": 3236
  },
  {
    "word": "actuación",
    "rank": 3135,
    "frequency": 9531,
    "originalRank": 3237
  },
  {
    "word": "refugio",
    "rank": 3136,
    "frequency": 9528,
    "originalRank": 3238
  },
  {
    "word": "harto",
    "rank": 3137,
    "frequency": 9525,
    "originalRank": 3239
  },
  {
    "word": "reacción",
    "rank": 3138,
    "frequency": 9522,
    "originalRank": 3240
  },
  {
    "word": "paliza",
    "rank": 3139,
    "frequency": 9520,
    "originalRank": 3241
  },
  {
    "word": "chef",
    "rank": 3140,
    "frequency": 9517,
    "originalRank": 3242
  },
  {
    "word": "ocurra",
    "rank": 3141,
    "frequency": 9513,
    "originalRank": 3243
  },
  {
    "word": "marty",
    "rank": 3142,
    "frequency": 9513,
    "originalRank": 3244
  },
  {
    "word": "entrado",
    "rank": 3143,
    "frequency": 9510,
    "originalRank": 3246
  },
  {
    "word": "quitar",
    "rank": 3144,
    "frequency": 9506,
    "originalRank": 3247
  },
  {
    "word": "amanecer",
    "rank": 3145,
    "frequency": 9504,
    "originalRank": 3248
  },
  {
    "word": "molly",
    "rank": 3146,
    "frequency": 9498,
    "originalRank": 3249
  },
  {
    "word": "corazones",
    "rank": 3147,
    "frequency": 9496,
    "originalRank": 3250
  },
  {
    "word": "rumores",
    "rank": 3148,
    "frequency": 9495,
    "originalRank": 3251
  },
  {
    "word": "llames",
    "rank": 3149,
    "frequency": 9492,
    "originalRank": 3252
  },
  {
    "word": "celoso",
    "rank": 3150,
    "frequency": 9489,
    "originalRank": 3253
  },
  {
    "word": "utilizar",
    "rank": 3151,
    "frequency": 9489,
    "originalRank": 3254
  },
  {
    "word": "territorio",
    "rank": 3152,
    "frequency": 9483,
    "originalRank": 3255
  },
  {
    "word": "olvide",
    "rank": 3153,
    "frequency": 9480,
    "originalRank": 3256
  },
  {
    "word": "prácticamente",
    "rank": 3154,
    "frequency": 9476,
    "originalRank": 3257
  },
  {
    "word": "disfrutar",
    "rank": 3155,
    "frequency": 9471,
    "originalRank": 3258
  },
  {
    "word": "intentaba",
    "rank": 3156,
    "frequency": 9466,
    "originalRank": 3259
  },
  {
    "word": "vecino",
    "rank": 3157,
    "frequency": 9462,
    "originalRank": 3260
  },
  {
    "word": "pública",
    "rank": 3158,
    "frequency": 9460,
    "originalRank": 3261
  },
  {
    "word": "collar",
    "rank": 3159,
    "frequency": 9459,
    "originalRank": 3262
  },
  {
    "word": "golf",
    "rank": 3160,
    "frequency": 9456,
    "originalRank": 3263
  },
  {
    "word": "betty",
    "rank": 3161,
    "frequency": 9454,
    "originalRank": 3264
  },
  {
    "word": "marco",
    "rank": 3162,
    "frequency": 9451,
    "originalRank": 3265
  },
  {
    "word": "cercano",
    "rank": 3163,
    "frequency": 9445,
    "originalRank": 3266
  },
  {
    "word": "fondos",
    "rank": 3164,
    "frequency": 9444,
    "originalRank": 3267
  },
  {
    "word": "ross",
    "rank": 3165,
    "frequency": 9444,
    "originalRank": 3268
  },
  {
    "word": "bruce",
    "rank": 3166,
    "frequency": 9444,
    "originalRank": 3269
  },
  {
    "word": "montar",
    "rank": 3167,
    "frequency": 9439,
    "originalRank": 3270
  },
  {
    "word": "salvado",
    "rank": 3168,
    "frequency": 9439,
    "originalRank": 3271
  },
  {
    "word": "grados",
    "rank": 3169,
    "frequency": 9438,
    "originalRank": 3272
  },
  {
    "word": "dylan",
    "rank": 3170,
    "frequency": 9436,
    "originalRank": 3273
  },
  {
    "word": "moto",
    "rank": 3171,
    "frequency": 9434,
    "originalRank": 3274
  },
  {
    "word": "instrucciones",
    "rank": 3172,
    "frequency": 9427,
    "originalRank": 3275
  },
  {
    "word": "treinta",
    "rank": 3173,
    "frequency": 9426,
    "originalRank": 3276
  },
  {
    "word": "gordon",
    "rank": 3174,
    "frequency": 9418,
    "originalRank": 3277
  },
  {
    "word": "adonde",
    "rank": 3175,
    "frequency": 9417,
    "originalRank": 3278
  },
  {
    "word": "hablarte",
    "rank": 3176,
    "frequency": 9416,
    "originalRank": 3279
  },
  {
    "word": "jesse",
    "rank": 3177,
    "frequency": 9414,
    "originalRank": 3280
  },
  {
    "word": "emperador",
    "rank": 3178,
    "frequency": 9413,
    "originalRank": 3281
  },
  {
    "word": "cigarrillo",
    "rank": 3179,
    "frequency": 9413,
    "originalRank": 3282
  },
  {
    "word": "cuéntame",
    "rank": 3180,
    "frequency": 9411,
    "originalRank": 3283
  },
  {
    "word": "secreta",
    "rank": 3181,
    "frequency": 9403,
    "originalRank": 3285
  },
  {
    "word": "haberse",
    "rank": 3182,
    "frequency": 9395,
    "originalRank": 3286
  },
  {
    "word": "hitler",
    "rank": 3183,
    "frequency": 9390,
    "originalRank": 3287
  },
  {
    "word": "anne",
    "rank": 3184,
    "frequency": 9387,
    "originalRank": 3288
  },
  {
    "word": "mortal",
    "rank": 3185,
    "frequency": 9386,
    "originalRank": 3289
  },
  {
    "word": "ronda",
    "rank": 3186,
    "frequency": 9386,
    "originalRank": 3290
  },
  {
    "word": "cuídate",
    "rank": 3187,
    "frequency": 9376,
    "originalRank": 3291
  },
  {
    "word": "metal",
    "rank": 3188,
    "frequency": 9375,
    "originalRank": 3292
  },
  {
    "word": "puro",
    "rank": 3189,
    "frequency": 9370,
    "originalRank": 3293
  },
  {
    "word": "cierre",
    "rank": 3190,
    "frequency": 9366,
    "originalRank": 3294
  },
  {
    "word": "colores",
    "rank": 3191,
    "frequency": 9364,
    "originalRank": 3295
  },
  {
    "word": "eva",
    "rank": 3192,
    "frequency": 9360,
    "originalRank": 3296
  },
  {
    "word": "rusia",
    "rank": 3193,
    "frequency": 9357,
    "originalRank": 3297
  },
  {
    "word": "botón",
    "rank": 3194,
    "frequency": 9354,
    "originalRank": 3298
  },
  {
    "word": "hijas",
    "rank": 3195,
    "frequency": 9354,
    "originalRank": 3299
  },
  {
    "word": "tenerlo",
    "rank": 3196,
    "frequency": 9353,
    "originalRank": 3300
  },
  {
    "word": "tono",
    "rank": 3197,
    "frequency": 9351,
    "originalRank": 3301
  },
  {
    "word": "espía",
    "rank": 3198,
    "frequency": 9347,
    "originalRank": 3302
  },
  {
    "word": "empleados",
    "rank": 3199,
    "frequency": 9342,
    "originalRank": 3303
  },
  {
    "word": "conduce",
    "rank": 3200,
    "frequency": 9339,
    "originalRank": 3304
  },
  {
    "word": "detalle",
    "rank": 3201,
    "frequency": 9339,
    "originalRank": 3305
  },
  {
    "word": "estuvieras",
    "rank": 3202,
    "frequency": 9338,
    "originalRank": 3306
  },
  {
    "word": "oliver",
    "rank": 3203,
    "frequency": 9337,
    "originalRank": 3307
  },
  {
    "word": "rusos",
    "rank": 3204,
    "frequency": 9337,
    "originalRank": 3308
  },
  {
    "word": "déjala",
    "rank": 3205,
    "frequency": 9331,
    "originalRank": 3309
  },
  {
    "word": "crema",
    "rank": 3206,
    "frequency": 9330,
    "originalRank": 3310
  },
  {
    "word": "roy",
    "rank": 3207,
    "frequency": 9330,
    "originalRank": 3311
  },
  {
    "word": "contesta",
    "rank": 3208,
    "frequency": 9325,
    "originalRank": 3312
  },
  {
    "word": "casarte",
    "rank": 3209,
    "frequency": 9322,
    "originalRank": 3313
  },
  {
    "word": "manda",
    "rank": 3210,
    "frequency": 9321,
    "originalRank": 3314
  },
  {
    "word": "dias",
    "rank": 3211,
    "frequency": 9314,
    "originalRank": 3315
  },
  {
    "word": "prisioneros",
    "rank": 3212,
    "frequency": 9313,
    "originalRank": 3316
  },
  {
    "word": "echado",
    "rank": 3213,
    "frequency": 9312,
    "originalRank": 3317
  },
  {
    "word": "trajiste",
    "rank": 3214,
    "frequency": 9308,
    "originalRank": 3318
  },
  {
    "word": "charlotte",
    "rank": 3215,
    "frequency": 9308,
    "originalRank": 3319
  },
  {
    "word": "flota",
    "rank": 3216,
    "frequency": 9305,
    "originalRank": 3320
  },
  {
    "word": "marie",
    "rank": 3217,
    "frequency": 9303,
    "originalRank": 3321
  },
  {
    "word": "criminales",
    "rank": 3218,
    "frequency": 9303,
    "originalRank": 3322
  },
  {
    "word": "mmm",
    "rank": 3219,
    "frequency": 9302,
    "originalRank": 3323
  },
  {
    "word": "platos",
    "rank": 3220,
    "frequency": 9291,
    "originalRank": 3324
  },
  {
    "word": "crímenes",
    "rank": 3221,
    "frequency": 9290,
    "originalRank": 3325
  },
  {
    "word": "cometido",
    "rank": 3222,
    "frequency": 9289,
    "originalRank": 3326
  },
  {
    "word": "golpear",
    "rank": 3223,
    "frequency": 9288,
    "originalRank": 3327
  },
  {
    "word": "igualmente",
    "rank": 3224,
    "frequency": 9286,
    "originalRank": 3328
  },
  {
    "word": "dispararon",
    "rank": 3225,
    "frequency": 9281,
    "originalRank": 3329
  },
  {
    "word": "dejará",
    "rank": 3226,
    "frequency": 9278,
    "originalRank": 3330
  },
  {
    "word": "tontos",
    "rank": 3227,
    "frequency": 9273,
    "originalRank": 3331
  },
  {
    "word": "sabría",
    "rank": 3228,
    "frequency": 9268,
    "originalRank": 3332
  },
  {
    "word": "abran",
    "rank": 3229,
    "frequency": 9267,
    "originalRank": 3333
  },
  {
    "word": "ayudante",
    "rank": 3230,
    "frequency": 9266,
    "originalRank": 3334
  },
  {
    "word": "cultura",
    "rank": 3231,
    "frequency": 9258,
    "originalRank": 3335
  },
  {
    "word": "revolución",
    "rank": 3232,
    "frequency": 9256,
    "originalRank": 3336
  },
  {
    "word": "hombro",
    "rank": 3233,
    "frequency": 9255,
    "originalRank": 3337
  },
  {
    "word": "botas",
    "rank": 3234,
    "frequency": 9253,
    "originalRank": 3338
  },
  {
    "word": "adoro",
    "rank": 3235,
    "frequency": 9252,
    "originalRank": 3339
  },
  {
    "word": "olvidó",
    "rank": 3236,
    "frequency": 9246,
    "originalRank": 3340
  },
  {
    "word": "biblia",
    "rank": 3237,
    "frequency": 9244,
    "originalRank": 3341
  },
  {
    "word": "saludos",
    "rank": 3238,
    "frequency": 9241,
    "originalRank": 3342
  },
  {
    "word": "katie",
    "rank": 3239,
    "frequency": 9236,
    "originalRank": 3343
  },
  {
    "word": "deme",
    "rank": 3240,
    "frequency": 9231,
    "originalRank": 3344
  },
  {
    "word": "adultos",
    "rank": 3241,
    "frequency": 9230,
    "originalRank": 3345
  },
  {
    "word": "sitios",
    "rank": 3242,
    "frequency": 9226,
    "originalRank": 3346
  },
  {
    "word": "serpiente",
    "rank": 3243,
    "frequency": 9221,
    "originalRank": 3347
  },
  {
    "word": "parker",
    "rank": 3244,
    "frequency": 9220,
    "originalRank": 3348
  },
  {
    "word": "nathan",
    "rank": 3245,
    "frequency": 9218,
    "originalRank": 3349
  },
  {
    "word": "romántico",
    "rank": 3246,
    "frequency": 9213,
    "originalRank": 3350
  },
  {
    "word": "posiblemente",
    "rank": 3247,
    "frequency": 9212,
    "originalRank": 3351
  },
  {
    "word": "adivinar",
    "rank": 3248,
    "frequency": 9205,
    "originalRank": 3352
  },
  {
    "word": "peores",
    "rank": 3249,
    "frequency": 9203,
    "originalRank": 3353
  },
  {
    "word": "buscan",
    "rank": 3250,
    "frequency": 9200,
    "originalRank": 3354
  },
  {
    "word": "enfrente",
    "rank": 3251,
    "frequency": 9199,
    "originalRank": 3355
  },
  {
    "word": "restos",
    "rank": 3252,
    "frequency": 9196,
    "originalRank": 3356
  },
  {
    "word": "capacidad",
    "rank": 3253,
    "frequency": 9192,
    "originalRank": 3357
  },
  {
    "word": "aliento",
    "rank": 3254,
    "frequency": 9188,
    "originalRank": 3358
  },
  {
    "word": "placa",
    "rank": 3255,
    "frequency": 9184,
    "originalRank": 3359
  },
  {
    "word": "rata",
    "rank": 3256,
    "frequency": 9184,
    "originalRank": 3360
  },
  {
    "word": "áfrica",
    "rank": 3257,
    "frequency": 9184,
    "originalRank": 3361
  },
  {
    "word": "entendí",
    "rank": 3258,
    "frequency": 9183,
    "originalRank": 3362
  },
  {
    "word": "metas",
    "rank": 3259,
    "frequency": 9181,
    "originalRank": 3363
  },
  {
    "word": "cuadro",
    "rank": 3260,
    "frequency": 9176,
    "originalRank": 3364
  },
  {
    "word": "afortunado",
    "rank": 3261,
    "frequency": 9175,
    "originalRank": 3365
  },
  {
    "word": "puestos",
    "rank": 3262,
    "frequency": 9175,
    "originalRank": 3366
  },
  {
    "word": "japón",
    "rank": 3263,
    "frequency": 9167,
    "originalRank": 3367
  },
  {
    "word": "división",
    "rank": 3264,
    "frequency": 9167,
    "originalRank": 3368
  },
  {
    "word": "subtítulos",
    "rank": 3265,
    "frequency": 9148,
    "originalRank": 3369
  },
  {
    "word": "entradas",
    "rank": 3266,
    "frequency": 9148,
    "originalRank": 3370
  },
  {
    "word": "bicicleta",
    "rank": 3267,
    "frequency": 9143,
    "originalRank": 3371
  },
  {
    "word": "vuestras",
    "rank": 3268,
    "frequency": 9140,
    "originalRank": 3372
  },
  {
    "word": "pesado",
    "rank": 3269,
    "frequency": 9140,
    "originalRank": 3373
  },
  {
    "word": "sugiero",
    "rank": 3270,
    "frequency": 9136,
    "originalRank": 3374
  },
  {
    "word": "calla",
    "rank": 3271,
    "frequency": 9136,
    "originalRank": 3375
  },
  {
    "word": "espacial",
    "rank": 3272,
    "frequency": 9132,
    "originalRank": 3376
  },
  {
    "word": "ventanas",
    "rank": 3273,
    "frequency": 9129,
    "originalRank": 3378
  },
  {
    "word": "mejorar",
    "rank": 3274,
    "frequency": 9125,
    "originalRank": 3379
  },
  {
    "word": "concurso",
    "rank": 3275,
    "frequency": 9121,
    "originalRank": 3380
  },
  {
    "word": "comisaría",
    "rank": 3276,
    "frequency": 9119,
    "originalRank": 3381
  },
  {
    "word": "sincero",
    "rank": 3277,
    "frequency": 9119,
    "originalRank": 3382
  },
  {
    "word": "centavos",
    "rank": 3278,
    "frequency": 9116,
    "originalRank": 3383
  },
  {
    "word": "naturalmente",
    "rank": 3279,
    "frequency": 9113,
    "originalRank": 3384
  },
  {
    "word": "deseas",
    "rank": 3280,
    "frequency": 9096,
    "originalRank": 3385
  },
  {
    "word": "pasara",
    "rank": 3281,
    "frequency": 9096,
    "originalRank": 3386
  },
  {
    "word": "jay",
    "rank": 3282,
    "frequency": 9086,
    "originalRank": 3387
  },
  {
    "word": "esperado",
    "rank": 3283,
    "frequency": 9085,
    "originalRank": 3388
  },
  {
    "word": "ocurrir",
    "rank": 3284,
    "frequency": 9083,
    "originalRank": 3389
  },
  {
    "word": "pondrá",
    "rank": 3285,
    "frequency": 9081,
    "originalRank": 3390
  },
  {
    "word": "recursos",
    "rank": 3286,
    "frequency": 9078,
    "originalRank": 3391
  },
  {
    "word": "raza",
    "rank": 3287,
    "frequency": 9078,
    "originalRank": 3392
  },
  {
    "word": "muestras",
    "rank": 3288,
    "frequency": 9078,
    "originalRank": 3393
  },
  {
    "word": "personales",
    "rank": 3289,
    "frequency": 9077,
    "originalRank": 3394
  },
  {
    "word": "wilson",
    "rank": 3290,
    "frequency": 9075,
    "originalRank": 3395
  },
  {
    "word": "imaginación",
    "rank": 3291,
    "frequency": 9074,
    "originalRank": 3396
  },
  {
    "word": "volverás",
    "rank": 3292,
    "frequency": 9074,
    "originalRank": 3397
  },
  {
    "word": "ceremonia",
    "rank": 3293,
    "frequency": 9068,
    "originalRank": 3398
  },
  {
    "word": "almacén",
    "rank": 3294,
    "frequency": 9062,
    "originalRank": 3399
  },
  {
    "word": "sabor",
    "rank": 3295,
    "frequency": 9060,
    "originalRank": 3400
  },
  {
    "word": "sentarse",
    "rank": 3296,
    "frequency": 9058,
    "originalRank": 3401
  },
  {
    "word": "unión",
    "rank": 3297,
    "frequency": 9056,
    "originalRank": 3403
  },
  {
    "word": "frankie",
    "rank": 3298,
    "frequency": 9054,
    "originalRank": 3404
  },
  {
    "word": "reserva",
    "rank": 3299,
    "frequency": 9054,
    "originalRank": 3405
  },
  {
    "word": "españa",
    "rank": 3300,
    "frequency": 9050,
    "originalRank": 3406
  },
  {
    "word": "encanto",
    "rank": 3301,
    "frequency": 9046,
    "originalRank": 3407
  },
  {
    "word": "aviones",
    "rank": 3302,
    "frequency": 9046,
    "originalRank": 3408
  },
  {
    "word": "calidad",
    "rank": 3303,
    "frequency": 9043,
    "originalRank": 3409
  },
  {
    "word": "escondido",
    "rank": 3304,
    "frequency": 9035,
    "originalRank": 3410
  },
  {
    "word": "citas",
    "rank": 3305,
    "frequency": 9035,
    "originalRank": 3411
  },
  {
    "word": "aceite",
    "rank": 3306,
    "frequency": 9034,
    "originalRank": 3412
  },
  {
    "word": "pusiste",
    "rank": 3307,
    "frequency": 9031,
    "originalRank": 3413
  },
  {
    "word": "querrá",
    "rank": 3308,
    "frequency": 9018,
    "originalRank": 3414
  },
  {
    "word": "punta",
    "rank": 3309,
    "frequency": 9013,
    "originalRank": 3415
  },
  {
    "word": "cinturón",
    "rank": 3310,
    "frequency": 9012,
    "originalRank": 3416
  },
  {
    "word": "podrán",
    "rank": 3311,
    "frequency": 9009,
    "originalRank": 3417
  },
  {
    "word": "cuales",
    "rank": 3312,
    "frequency": 9005,
    "originalRank": 3418
  },
  {
    "word": "chiste",
    "rank": 3313,
    "frequency": 9002,
    "originalRank": 3419
  },
  {
    "word": "consecuencias",
    "rank": 3314,
    "frequency": 8992,
    "originalRank": 3420
  },
  {
    "word": "sinceramente",
    "rank": 3315,
    "frequency": 8992,
    "originalRank": 3421
  },
  {
    "word": "lewis",
    "rank": 3316,
    "frequency": 8992,
    "originalRank": 3422
  },
  {
    "word": "hablaste",
    "rank": 3317,
    "frequency": 8989,
    "originalRank": 3423
  },
  {
    "word": "vaca",
    "rank": 3318,
    "frequency": 8988,
    "originalRank": 3424
  },
  {
    "word": "investigando",
    "rank": 3319,
    "frequency": 8988,
    "originalRank": 3425
  },
  {
    "word": "vuelven",
    "rank": 3320,
    "frequency": 8988,
    "originalRank": 3426
  },
  {
    "word": "chloe",
    "rank": 3321,
    "frequency": 8986,
    "originalRank": 3427
  },
  {
    "word": "prisionero",
    "rank": 3322,
    "frequency": 8985,
    "originalRank": 3428
  },
  {
    "word": "investigar",
    "rank": 3323,
    "frequency": 8985,
    "originalRank": 3429
  },
  {
    "word": "apellido",
    "rank": 3324,
    "frequency": 8984,
    "originalRank": 3430
  },
  {
    "word": "actual",
    "rank": 3325,
    "frequency": 8975,
    "originalRank": 3431
  },
  {
    "word": "despertar",
    "rank": 3326,
    "frequency": 8971,
    "originalRank": 3432
  },
  {
    "word": "instante",
    "rank": 3327,
    "frequency": 8971,
    "originalRank": 3433
  },
  {
    "word": "vincent",
    "rank": 3328,
    "frequency": 8969,
    "originalRank": 3434
  },
  {
    "word": "morirá",
    "rank": 3329,
    "frequency": 8955,
    "originalRank": 3436
  },
  {
    "word": "sacaste",
    "rank": 3330,
    "frequency": 8951,
    "originalRank": 3437
  },
  {
    "word": "justin",
    "rank": 3331,
    "frequency": 8946,
    "originalRank": 3438
  },
  {
    "word": "traiga",
    "rank": 3332,
    "frequency": 8943,
    "originalRank": 3439
  },
  {
    "word": "sentada",
    "rank": 3333,
    "frequency": 8942,
    "originalRank": 3440
  },
  {
    "word": "mueva",
    "rank": 3334,
    "frequency": 8936,
    "originalRank": 3441
  },
  {
    "word": "jordan",
    "rank": 3335,
    "frequency": 8934,
    "originalRank": 3442
  },
  {
    "word": "terminé",
    "rank": 3336,
    "frequency": 8931,
    "originalRank": 3443
  },
  {
    "word": "emociones",
    "rank": 3337,
    "frequency": 8931,
    "originalRank": 3444
  },
  {
    "word": "dormitorio",
    "rank": 3338,
    "frequency": 8930,
    "originalRank": 3445
  },
  {
    "word": "pulso",
    "rank": 3339,
    "frequency": 8929,
    "originalRank": 3446
  },
  {
    "word": "atreves",
    "rank": 3340,
    "frequency": 8928,
    "originalRank": 3447
  },
  {
    "word": "frase",
    "rank": 3341,
    "frequency": 8920,
    "originalRank": 3448
  },
  {
    "word": "partida",
    "rank": 3342,
    "frequency": 8919,
    "originalRank": 3449
  },
  {
    "word": "sabíamos",
    "rank": 3343,
    "frequency": 8916,
    "originalRank": 3450
  },
  {
    "word": "parezco",
    "rank": 3344,
    "frequency": 8915,
    "originalRank": 3451
  },
  {
    "word": "excelencia",
    "rank": 3345,
    "frequency": 8910,
    "originalRank": 3452
  },
  {
    "word": "despedido",
    "rank": 3346,
    "frequency": 8908,
    "originalRank": 3453
  },
  {
    "word": "moral",
    "rank": 3347,
    "frequency": 8905,
    "originalRank": 3454
  },
  {
    "word": "asalto",
    "rank": 3348,
    "frequency": 8901,
    "originalRank": 3455
  },
  {
    "word": "decente",
    "rank": 3349,
    "frequency": 8900,
    "originalRank": 3456
  },
  {
    "word": "informes",
    "rank": 3350,
    "frequency": 8894,
    "originalRank": 3457
  },
  {
    "word": "asusta",
    "rank": 3351,
    "frequency": 8890,
    "originalRank": 3458
  },
  {
    "word": "trabajan",
    "rank": 3352,
    "frequency": 8888,
    "originalRank": 3459
  },
  {
    "word": "doug",
    "rank": 3353,
    "frequency": 8879,
    "originalRank": 3461
  },
  {
    "word": "poca",
    "rank": 3354,
    "frequency": 8875,
    "originalRank": 3462
  },
  {
    "word": "pasaría",
    "rank": 3355,
    "frequency": 8869,
    "originalRank": 3463
  },
  {
    "word": "médica",
    "rank": 3356,
    "frequency": 8868,
    "originalRank": 3464
  },
  {
    "word": "combustible",
    "rank": 3357,
    "frequency": 8868,
    "originalRank": 3465
  },
  {
    "word": "discusión",
    "rank": 3358,
    "frequency": 8866,
    "originalRank": 3466
  },
  {
    "word": "verán",
    "rank": 3359,
    "frequency": 8864,
    "originalRank": 3467
  },
  {
    "word": "ciertas",
    "rank": 3360,
    "frequency": 8857,
    "originalRank": 3468
  },
  {
    "word": "pata",
    "rank": 3361,
    "frequency": 8856,
    "originalRank": 3469
  },
  {
    "word": "jean",
    "rank": 3362,
    "frequency": 8855,
    "originalRank": 3470
  },
  {
    "word": "antiguos",
    "rank": 3363,
    "frequency": 8853,
    "originalRank": 3471
  },
  {
    "word": "requiere",
    "rank": 3364,
    "frequency": 8852,
    "originalRank": 3472
  },
  {
    "word": "cogido",
    "rank": 3365,
    "frequency": 8847,
    "originalRank": 3473
  },
  {
    "word": "comunicación",
    "rank": 3366,
    "frequency": 8847,
    "originalRank": 3474
  },
  {
    "word": "manzana",
    "rank": 3367,
    "frequency": 8846,
    "originalRank": 3475
  },
  {
    "word": "sed",
    "rank": 3368,
    "frequency": 8845,
    "originalRank": 3476
  },
  {
    "word": "tio",
    "rank": 3369,
    "frequency": 8843,
    "originalRank": 3477
  },
  {
    "word": "joyas",
    "rank": 3370,
    "frequency": 8842,
    "originalRank": 3478
  },
  {
    "word": "cojones",
    "rank": 3371,
    "frequency": 8841,
    "originalRank": 3479
  },
  {
    "word": "noble",
    "rank": 3372,
    "frequency": 8840,
    "originalRank": 3480
  },
  {
    "word": "trabajamos",
    "rank": 3373,
    "frequency": 8833,
    "originalRank": 3482
  },
  {
    "word": "pediste",
    "rank": 3374,
    "frequency": 8829,
    "originalRank": 3483
  },
  {
    "word": "encontrarla",
    "rank": 3375,
    "frequency": 8828,
    "originalRank": 3484
  },
  {
    "word": "piedras",
    "rank": 3376,
    "frequency": 8827,
    "originalRank": 3485
  },
  {
    "word": "traidor",
    "rank": 3377,
    "frequency": 8811,
    "originalRank": 3486
  },
  {
    "word": "gané",
    "rank": 3378,
    "frequency": 8809,
    "originalRank": 3487
  },
  {
    "word": "letra",
    "rank": 3379,
    "frequency": 8808,
    "originalRank": 3488
  },
  {
    "word": "conseguimos",
    "rank": 3380,
    "frequency": 8801,
    "originalRank": 3489
  },
  {
    "word": "vía",
    "rank": 3381,
    "frequency": 8800,
    "originalRank": 3490
  },
  {
    "word": "sacerdote",
    "rank": 3382,
    "frequency": 8799,
    "originalRank": 3491
  },
  {
    "word": "efectos",
    "rank": 3383,
    "frequency": 8788,
    "originalRank": 3492
  },
  {
    "word": "resistencia",
    "rank": 3384,
    "frequency": 8783,
    "originalRank": 3493
  },
  {
    "word": "arroz",
    "rank": 3385,
    "frequency": 8783,
    "originalRank": 3494
  },
  {
    "word": "arreglado",
    "rank": 3386,
    "frequency": 8782,
    "originalRank": 3495
  },
  {
    "word": "tarjetas",
    "rank": 3387,
    "frequency": 8781,
    "originalRank": 3496
  },
  {
    "word": "descubrió",
    "rank": 3388,
    "frequency": 8780,
    "originalRank": 3497
  },
  {
    "word": "desconocido",
    "rank": 3389,
    "frequency": 8779,
    "originalRank": 3498
  },
  {
    "word": "mínimo",
    "rank": 3390,
    "frequency": 8778,
    "originalRank": 3499
  },
  {
    "word": "disparado",
    "rank": 3391,
    "frequency": 8778,
    "originalRank": 3500
  },
  {
    "word": "boston",
    "rank": 3392,
    "frequency": 8775,
    "originalRank": 3501
  },
  {
    "word": "entienden",
    "rank": 3393,
    "frequency": 8769,
    "originalRank": 3502
  },
  {
    "word": "bandera",
    "rank": 3394,
    "frequency": 8763,
    "originalRank": 3503
  },
  {
    "word": "llamarte",
    "rank": 3395,
    "frequency": 8762,
    "originalRank": 3504
  },
  {
    "word": "plaza",
    "rank": 3396,
    "frequency": 8759,
    "originalRank": 3505
  },
  {
    "word": "entrando",
    "rank": 3397,
    "frequency": 8758,
    "originalRank": 3506
  },
  {
    "word": "tomará",
    "rank": 3398,
    "frequency": 8751,
    "originalRank": 3507
  },
  {
    "word": "visitas",
    "rank": 3399,
    "frequency": 8749,
    "originalRank": 3508
  },
  {
    "word": "cooper",
    "rank": 3400,
    "frequency": 8747,
    "originalRank": 3509
  },
  {
    "word": "demasiada",
    "rank": 3401,
    "frequency": 8745,
    "originalRank": 3510
  },
  {
    "word": "faltan",
    "rank": 3402,
    "frequency": 8744,
    "originalRank": 3511
  },
  {
    "word": "planeado",
    "rank": 3403,
    "frequency": 8738,
    "originalRank": 3512
  },
  {
    "word": "imperio",
    "rank": 3404,
    "frequency": 8736,
    "originalRank": 3513
  },
  {
    "word": "esperaré",
    "rank": 3405,
    "frequency": 8729,
    "originalRank": 3514
  },
  {
    "word": "enfadada",
    "rank": 3406,
    "frequency": 8729,
    "originalRank": 3515
  },
  {
    "word": "levantar",
    "rank": 3407,
    "frequency": 8726,
    "originalRank": 3516
  },
  {
    "word": "cartera",
    "rank": 3408,
    "frequency": 8716,
    "originalRank": 3517
  },
  {
    "word": "jeremy",
    "rank": 3409,
    "frequency": 8714,
    "originalRank": 3518
  },
  {
    "word": "importar",
    "rank": 3410,
    "frequency": 8714,
    "originalRank": 3519
  },
  {
    "word": "depósito",
    "rank": 3411,
    "frequency": 8695,
    "originalRank": 3520
  },
  {
    "word": "colegas",
    "rank": 3412,
    "frequency": 8694,
    "originalRank": 3521
  },
  {
    "word": "periodista",
    "rank": 3413,
    "frequency": 8691,
    "originalRank": 3522
  },
  {
    "word": "comprobar",
    "rank": 3414,
    "frequency": 8690,
    "originalRank": 3523
  },
  {
    "word": "funcione",
    "rank": 3415,
    "frequency": 8684,
    "originalRank": 3524
  },
  {
    "word": "nina",
    "rank": 3416,
    "frequency": 8680,
    "originalRank": 3525
  },
  {
    "word": "mereces",
    "rank": 3417,
    "frequency": 8675,
    "originalRank": 3526
  },
  {
    "word": "forense",
    "rank": 3418,
    "frequency": 8669,
    "originalRank": 3527
  },
  {
    "word": "tensión",
    "rank": 3419,
    "frequency": 8665,
    "originalRank": 3528
  },
  {
    "word": "involucrado",
    "rank": 3420,
    "frequency": 8662,
    "originalRank": 3529
  },
  {
    "word": "vacía",
    "rank": 3421,
    "frequency": 8662,
    "originalRank": 3530
  },
  {
    "word": "abandonado",
    "rank": 3422,
    "frequency": 8661,
    "originalRank": 3531
  },
  {
    "word": "vídeo",
    "rank": 3423,
    "frequency": 8661,
    "originalRank": 3532
  },
  {
    "word": "ruso",
    "rank": 3424,
    "frequency": 8659,
    "originalRank": 3533
  },
  {
    "word": "círculo",
    "rank": 3425,
    "frequency": 8650,
    "originalRank": 3534
  },
  {
    "word": "judío",
    "rank": 3426,
    "frequency": 8643,
    "originalRank": 3535
  },
  {
    "word": "cole",
    "rank": 3427,
    "frequency": 8642,
    "originalRank": 3536
  },
  {
    "word": "gritos",
    "rank": 3428,
    "frequency": 8632,
    "originalRank": 3537
  },
  {
    "word": "carol",
    "rank": 3429,
    "frequency": 8632,
    "originalRank": 3538
  },
  {
    "word": "empecemos",
    "rank": 3430,
    "frequency": 8631,
    "originalRank": 3539
  },
  {
    "word": "resultó",
    "rank": 3431,
    "frequency": 8627,
    "originalRank": 3540
  },
  {
    "word": "campos",
    "rank": 3432,
    "frequency": 8625,
    "originalRank": 3541
  },
  {
    "word": "váyanse",
    "rank": 3433,
    "frequency": 8621,
    "originalRank": 3542
  },
  {
    "word": "escribiendo",
    "rank": 3434,
    "frequency": 8620,
    "originalRank": 3543
  },
  {
    "word": "divertida",
    "rank": 3435,
    "frequency": 8616,
    "originalRank": 3544
  },
  {
    "word": "pasen",
    "rank": 3436,
    "frequency": 8611,
    "originalRank": 3545
  },
  {
    "word": "pinta",
    "rank": 3437,
    "frequency": 8610,
    "originalRank": 3546
  },
  {
    "word": "supo",
    "rank": 3438,
    "frequency": 8608,
    "originalRank": 3547
  },
  {
    "word": "ascensor",
    "rank": 3439,
    "frequency": 8607,
    "originalRank": 3548
  },
  {
    "word": "quedarnos",
    "rank": 3440,
    "frequency": 8606,
    "originalRank": 3549
  },
  {
    "word": "matará",
    "rank": 3441,
    "frequency": 8606,
    "originalRank": 3550
  },
  {
    "word": "aparecer",
    "rank": 3442,
    "frequency": 8597,
    "originalRank": 3551
  },
  {
    "word": "helicóptero",
    "rank": 3443,
    "frequency": 8589,
    "originalRank": 3552
  },
  {
    "word": "actuando",
    "rank": 3444,
    "frequency": 8589,
    "originalRank": 3553
  },
  {
    "word": "ooh",
    "rank": 3445,
    "frequency": 8582,
    "originalRank": 3554
  },
  {
    "word": "pasas",
    "rank": 3446,
    "frequency": 8581,
    "originalRank": 3555
  },
  {
    "word": "apúrate",
    "rank": 3447,
    "frequency": 8579,
    "originalRank": 3556
  },
  {
    "word": "big",
    "rank": 3448,
    "frequency": 8571,
    "originalRank": 3557
  },
  {
    "word": "entregar",
    "rank": 3449,
    "frequency": 8561,
    "originalRank": 3558
  },
  {
    "word": "escape",
    "rank": 3450,
    "frequency": 8558,
    "originalRank": 3559
  },
  {
    "word": "indios",
    "rank": 3451,
    "frequency": 8558,
    "originalRank": 3560
  },
  {
    "word": "limpieza",
    "rank": 3452,
    "frequency": 8548,
    "originalRank": 3561
  },
  {
    "word": "rebecca",
    "rank": 3453,
    "frequency": 8539,
    "originalRank": 3562
  },
  {
    "word": "querrás",
    "rank": 3454,
    "frequency": 8531,
    "originalRank": 3563
  },
  {
    "word": "hueso",
    "rank": 3455,
    "frequency": 8531,
    "originalRank": 3564
  },
  {
    "word": "jessica",
    "rank": 3456,
    "frequency": 8524,
    "originalRank": 3565
  },
  {
    "word": "magnífico",
    "rank": 3457,
    "frequency": 8522,
    "originalRank": 3566
  },
  {
    "word": "trabajadores",
    "rank": 3458,
    "frequency": 8519,
    "originalRank": 3567
  },
  {
    "word": "caída",
    "rank": 3459,
    "frequency": 8516,
    "originalRank": 3568
  },
  {
    "word": "temperatura",
    "rank": 3460,
    "frequency": 8516,
    "originalRank": 3569
  },
  {
    "word": "habia",
    "rank": 3461,
    "frequency": 8510,
    "originalRank": 3570
  },
  {
    "word": "dejaría",
    "rank": 3462,
    "frequency": 8509,
    "originalRank": 3571
  },
  {
    "word": "encontrará",
    "rank": 3463,
    "frequency": 8504,
    "originalRank": 3572
  },
  {
    "word": "ejercicio",
    "rank": 3464,
    "frequency": 8504,
    "originalRank": 3573
  },
  {
    "word": "lealtad",
    "rank": 3465,
    "frequency": 8501,
    "originalRank": 3574
  },
  {
    "word": "alas",
    "rank": 3466,
    "frequency": 8492,
    "originalRank": 3575
  },
  {
    "word": "pasaron",
    "rank": 3467,
    "frequency": 8490,
    "originalRank": 3576
  },
  {
    "word": "invitación",
    "rank": 3468,
    "frequency": 8487,
    "originalRank": 3577
  },
  {
    "word": "diamantes",
    "rank": 3469,
    "frequency": 8483,
    "originalRank": 3578
  },
  {
    "word": "unidades",
    "rank": 3470,
    "frequency": 8479,
    "originalRank": 3579
  },
  {
    "word": "miller",
    "rank": 3471,
    "frequency": 8479,
    "originalRank": 3580
  },
  {
    "word": "enojada",
    "rank": 3472,
    "frequency": 8479,
    "originalRank": 3581
  },
  {
    "word": "decimos",
    "rank": 3473,
    "frequency": 8476,
    "originalRank": 3582
  },
  {
    "word": "leyenda",
    "rank": 3474,
    "frequency": 8475,
    "originalRank": 3583
  },
  {
    "word": "gilipollas",
    "rank": 3475,
    "frequency": 8475,
    "originalRank": 3584
  },
  {
    "word": "tomaste",
    "rank": 3476,
    "frequency": 8471,
    "originalRank": 3585
  },
  {
    "word": "paraíso",
    "rank": 3477,
    "frequency": 8469,
    "originalRank": 3586
  },
  {
    "word": "gatos",
    "rank": 3478,
    "frequency": 8462,
    "originalRank": 3587
  },
  {
    "word": "costumbre",
    "rank": 3479,
    "frequency": 8461,
    "originalRank": 3588
  },
  {
    "word": "podria",
    "rank": 3480,
    "frequency": 8457,
    "originalRank": 3589
  },
  {
    "word": "cabaña",
    "rank": 3481,
    "frequency": 8449,
    "originalRank": 3590
  },
  {
    "word": "secretaria",
    "rank": 3482,
    "frequency": 8447,
    "originalRank": 3591
  },
  {
    "word": "lentamente",
    "rank": 3483,
    "frequency": 8445,
    "originalRank": 3592
  },
  {
    "word": "ensayo",
    "rank": 3484,
    "frequency": 8444,
    "originalRank": 3593
  },
  {
    "word": "pagó",
    "rank": 3485,
    "frequency": 8443,
    "originalRank": 3594
  },
  {
    "word": "familiares",
    "rank": 3486,
    "frequency": 8443,
    "originalRank": 3595
  },
  {
    "word": "gimnasio",
    "rank": 3487,
    "frequency": 8437,
    "originalRank": 3596
  },
  {
    "word": "negativo",
    "rank": 3488,
    "frequency": 8437,
    "originalRank": 3597
  },
  {
    "word": "lenguaje",
    "rank": 3489,
    "frequency": 8435,
    "originalRank": 3598
  },
  {
    "word": "pájaros",
    "rank": 3490,
    "frequency": 8431,
    "originalRank": 3599
  },
  {
    "word": "presenta",
    "rank": 3491,
    "frequency": 8428,
    "originalRank": 3600
  },
  {
    "word": "quedes",
    "rank": 3492,
    "frequency": 8426,
    "originalRank": 3601
  },
  {
    "word": "garaje",
    "rank": 3493,
    "frequency": 8424,
    "originalRank": 3602
  },
  {
    "word": "palo",
    "rank": 3494,
    "frequency": 8423,
    "originalRank": 3603
  },
  {
    "word": "león",
    "rank": 3495,
    "frequency": 8422,
    "originalRank": 3604
  },
  {
    "word": "oídos",
    "rank": 3496,
    "frequency": 8422,
    "originalRank": 3605
  },
  {
    "word": "dick",
    "rank": 3497,
    "frequency": 8413,
    "originalRank": 3606
  },
  {
    "word": "espaldas",
    "rank": 3498,
    "frequency": 8410,
    "originalRank": 3607
  },
  {
    "word": "apuestas",
    "rank": 3499,
    "frequency": 8407,
    "originalRank": 3608
  },
  {
    "word": "científico",
    "rank": 3500,
    "frequency": 8404,
    "originalRank": 3609
  },
  {
    "word": "incluyendo",
    "rank": 3501,
    "frequency": 8402,
    "originalRank": 3610
  },
  {
    "word": "pelotas",
    "rank": 3502,
    "frequency": 8394,
    "originalRank": 3611
  },
  {
    "word": "actividad",
    "rank": 3503,
    "frequency": 8392,
    "originalRank": 3612
  },
  {
    "word": "dragón",
    "rank": 3504,
    "frequency": 8387,
    "originalRank": 3613
  },
  {
    "word": "necesite",
    "rank": 3505,
    "frequency": 8367,
    "originalRank": 3614
  },
  {
    "word": "intentamos",
    "rank": 3506,
    "frequency": 8360,
    "originalRank": 3615
  },
  {
    "word": "aguantar",
    "rank": 3507,
    "frequency": 8357,
    "originalRank": 3616
  },
  {
    "word": "davis",
    "rank": 3508,
    "frequency": 8354,
    "originalRank": 3617
  },
  {
    "word": "primeras",
    "rank": 3509,
    "frequency": 8351,
    "originalRank": 3618
  },
  {
    "word": "generación",
    "rank": 3510,
    "frequency": 8349,
    "originalRank": 3619
  },
  {
    "word": "sexuales",
    "rank": 3511,
    "frequency": 8349,
    "originalRank": 3620
  },
  {
    "word": "apetece",
    "rank": 3512,
    "frequency": 8338,
    "originalRank": 3621
  },
  {
    "word": "grupos",
    "rank": 3513,
    "frequency": 8337,
    "originalRank": 3622
  },
  {
    "word": "capital",
    "rank": 3514,
    "frequency": 8336,
    "originalRank": 3623
  },
  {
    "word": "dejemos",
    "rank": 3515,
    "frequency": 8333,
    "originalRank": 3624
  },
  {
    "word": "habrías",
    "rank": 3516,
    "frequency": 8333,
    "originalRank": 3625
  },
  {
    "word": "máquinas",
    "rank": 3517,
    "frequency": 8331,
    "originalRank": 3626
  },
  {
    "word": "barato",
    "rank": 3518,
    "frequency": 8324,
    "originalRank": 3627
  },
  {
    "word": "monsieur",
    "rank": 3519,
    "frequency": 8322,
    "originalRank": 3628
  },
  {
    "word": "sistemas",
    "rank": 3520,
    "frequency": 8319,
    "originalRank": 3629
  },
  {
    "word": "fingir",
    "rank": 3521,
    "frequency": 8316,
    "originalRank": 3630
  },
  {
    "word": "pensarlo",
    "rank": 3522,
    "frequency": 8316,
    "originalRank": 3631
  },
  {
    "word": "miércoles",
    "rank": 3523,
    "frequency": 8314,
    "originalRank": 3632
  },
  {
    "word": "escritor",
    "rank": 3524,
    "frequency": 8312,
    "originalRank": 3633
  },
  {
    "word": "solitario",
    "rank": 3525,
    "frequency": 8308,
    "originalRank": 3634
  },
  {
    "word": "recibo",
    "rank": 3526,
    "frequency": 8308,
    "originalRank": 3635
  },
  {
    "word": "conocerlo",
    "rank": 3527,
    "frequency": 8307,
    "originalRank": 3636
  },
  {
    "word": "pudimos",
    "rank": 3528,
    "frequency": 8302,
    "originalRank": 3637
  },
  {
    "word": "convertirse",
    "rank": 3529,
    "frequency": 8300,
    "originalRank": 3638
  },
  {
    "word": "almas",
    "rank": 3530,
    "frequency": 8299,
    "originalRank": 3639
  },
  {
    "word": "salto",
    "rank": 3531,
    "frequency": 8296,
    "originalRank": 3640
  },
  {
    "word": "sonar",
    "rank": 3532,
    "frequency": 8293,
    "originalRank": 3641
  },
  {
    "word": "publicidad",
    "rank": 3533,
    "frequency": 8287,
    "originalRank": 3642
  },
  {
    "word": "russell",
    "rank": 3534,
    "frequency": 8287,
    "originalRank": 3643
  },
  {
    "word": "temporal",
    "rank": 3535,
    "frequency": 8286,
    "originalRank": 3644
  },
  {
    "word": "antecedentes",
    "rank": 3536,
    "frequency": 8284,
    "originalRank": 3645
  },
  {
    "word": "probado",
    "rank": 3537,
    "frequency": 8282,
    "originalRank": 3646
  },
  {
    "word": "todd",
    "rank": 3538,
    "frequency": 8280,
    "originalRank": 3647
  },
  {
    "word": "kenny",
    "rank": 3539,
    "frequency": 8279,
    "originalRank": 3648
  },
  {
    "word": "llamaron",
    "rank": 3540,
    "frequency": 8276,
    "originalRank": 3649
  },
  {
    "word": "atractivo",
    "rank": 3541,
    "frequency": 8275,
    "originalRank": 3650
  },
  {
    "word": "váyase",
    "rank": 3542,
    "frequency": 8272,
    "originalRank": 3651
  },
  {
    "word": "barra",
    "rank": 3543,
    "frequency": 8267,
    "originalRank": 3652
  },
  {
    "word": "aniversario",
    "rank": 3544,
    "frequency": 8267,
    "originalRank": 3653
  },
  {
    "word": "intereses",
    "rank": 3545,
    "frequency": 8267,
    "originalRank": 3654
  },
  {
    "word": "madres",
    "rank": 3546,
    "frequency": 8264,
    "originalRank": 3655
  },
  {
    "word": "deba",
    "rank": 3547,
    "frequency": 8263,
    "originalRank": 3656
  },
  {
    "word": "imagina",
    "rank": 3548,
    "frequency": 8262,
    "originalRank": 3657
  },
  {
    "word": "niñera",
    "rank": 3549,
    "frequency": 8261,
    "originalRank": 3658
  },
  {
    "word": "movimientos",
    "rank": 3550,
    "frequency": 8259,
    "originalRank": 3659
  },
  {
    "word": "quince",
    "rank": 3551,
    "frequency": 8256,
    "originalRank": 3660
  },
  {
    "word": "holmes",
    "rank": 3552,
    "frequency": 8255,
    "originalRank": 3661
  },
  {
    "word": "muro",
    "rank": 3553,
    "frequency": 8254,
    "originalRank": 3662
  },
  {
    "word": "recibe",
    "rank": 3554,
    "frequency": 8244,
    "originalRank": 3663
  },
  {
    "word": "luce",
    "rank": 3555,
    "frequency": 8242,
    "originalRank": 3664
  },
  {
    "word": "nací",
    "rank": 3556,
    "frequency": 8242,
    "originalRank": 3665
  },
  {
    "word": "prima",
    "rank": 3557,
    "frequency": 8241,
    "originalRank": 3666
  },
  {
    "word": "cubierto",
    "rank": 3558,
    "frequency": 8235,
    "originalRank": 3667
  },
  {
    "word": "contando",
    "rank": 3559,
    "frequency": 8232,
    "originalRank": 3668
  },
  {
    "word": "reír",
    "rank": 3560,
    "frequency": 8231,
    "originalRank": 3669
  },
  {
    "word": "producto",
    "rank": 3561,
    "frequency": 8226,
    "originalRank": 3670
  },
  {
    "word": "daños",
    "rank": 3562,
    "frequency": 8221,
    "originalRank": 3671
  },
  {
    "word": "abrazo",
    "rank": 3563,
    "frequency": 8219,
    "originalRank": 3672
  },
  {
    "word": "gafas",
    "rank": 3564,
    "frequency": 8215,
    "originalRank": 3673
  },
  {
    "word": "arreglarlo",
    "rank": 3565,
    "frequency": 8213,
    "originalRank": 3674
  },
  {
    "word": "sobrino",
    "rank": 3566,
    "frequency": 8212,
    "originalRank": 3675
  },
  {
    "word": "man",
    "rank": 3567,
    "frequency": 8209,
    "originalRank": 3676
  },
  {
    "word": "demanda",
    "rank": 3568,
    "frequency": 8208,
    "originalRank": 3677
  },
  {
    "word": "elecciones",
    "rank": 3569,
    "frequency": 8205,
    "originalRank": 3678
  },
  {
    "word": "construcción",
    "rank": 3570,
    "frequency": 8203,
    "originalRank": 3679
  },
  {
    "word": "ayudaré",
    "rank": 3571,
    "frequency": 8201,
    "originalRank": 3680
  },
  {
    "word": "buscado",
    "rank": 3572,
    "frequency": 8200,
    "originalRank": 3681
  },
  {
    "word": "criaturas",
    "rank": 3573,
    "frequency": 8200,
    "originalRank": 3682
  },
  {
    "word": "dejarla",
    "rank": 3574,
    "frequency": 8199,
    "originalRank": 3683
  },
  {
    "word": "internacional",
    "rank": 3575,
    "frequency": 8194,
    "originalRank": 3684
  },
  {
    "word": "perfil",
    "rank": 3576,
    "frequency": 8193,
    "originalRank": 3685
  },
  {
    "word": "trozo",
    "rank": 3577,
    "frequency": 8192,
    "originalRank": 3686
  },
  {
    "word": "actriz",
    "rank": 3578,
    "frequency": 8190,
    "originalRank": 3687
  },
  {
    "word": "repito",
    "rank": 3579,
    "frequency": 8189,
    "originalRank": 3688
  },
  {
    "word": "bendiga",
    "rank": 3580,
    "frequency": 8185,
    "originalRank": 3689
  },
  {
    "word": "pistas",
    "rank": 3581,
    "frequency": 8184,
    "originalRank": 3690
  },
  {
    "word": "whoa",
    "rank": 3582,
    "frequency": 8182,
    "originalRank": 3691
  },
  {
    "word": "vecindario",
    "rank": 3583,
    "frequency": 8180,
    "originalRank": 3692
  },
  {
    "word": "hannah",
    "rank": 3584,
    "frequency": 8179,
    "originalRank": 3693
  },
  {
    "word": "marcus",
    "rank": 3585,
    "frequency": 8179,
    "originalRank": 3694
  },
  {
    "word": "ataques",
    "rank": 3586,
    "frequency": 8174,
    "originalRank": 3695
  },
  {
    "word": "razonable",
    "rank": 3587,
    "frequency": 8168,
    "originalRank": 3696
  },
  {
    "word": "vende",
    "rank": 3588,
    "frequency": 8167,
    "originalRank": 3697
  },
  {
    "word": "gerente",
    "rank": 3589,
    "frequency": 8164,
    "originalRank": 3698
  },
  {
    "word": "sensible",
    "rank": 3590,
    "frequency": 8161,
    "originalRank": 3699
  },
  {
    "word": "ríe",
    "rank": 3591,
    "frequency": 8157,
    "originalRank": 3700
  },
  {
    "word": "izquierdo",
    "rank": 3592,
    "frequency": 8150,
    "originalRank": 3701
  },
  {
    "word": "personalidad",
    "rank": 3593,
    "frequency": 8147,
    "originalRank": 3702
  },
  {
    "word": "camina",
    "rank": 3594,
    "frequency": 8146,
    "originalRank": 3703
  },
  {
    "word": "traes",
    "rank": 3595,
    "frequency": 8142,
    "originalRank": 3704
  },
  {
    "word": "tuvieras",
    "rank": 3596,
    "frequency": 8142,
    "originalRank": 3705
  },
  {
    "word": "albert",
    "rank": 3597,
    "frequency": 8140,
    "originalRank": 3706
  },
  {
    "word": "conté",
    "rank": 3598,
    "frequency": 8140,
    "originalRank": 3707
  },
  {
    "word": "preparando",
    "rank": 3599,
    "frequency": 8140,
    "originalRank": 3708
  },
  {
    "word": "secretario",
    "rank": 3600,
    "frequency": 8138,
    "originalRank": 3709
  },
  {
    "word": "rueda",
    "rank": 3601,
    "frequency": 8138,
    "originalRank": 3710
  },
  {
    "word": "sorprendido",
    "rank": 3602,
    "frequency": 8138,
    "originalRank": 3711
  },
  {
    "word": "profundamente",
    "rank": 3603,
    "frequency": 8138,
    "originalRank": 3712
  },
  {
    "word": "conoció",
    "rank": 3604,
    "frequency": 8130,
    "originalRank": 3713
  },
  {
    "word": "grano",
    "rank": 3605,
    "frequency": 8130,
    "originalRank": 3714
  },
  {
    "word": "pagaré",
    "rank": 3606,
    "frequency": 8129,
    "originalRank": 3715
  },
  {
    "word": "límites",
    "rank": 3607,
    "frequency": 8127,
    "originalRank": 3716
  },
  {
    "word": "moneda",
    "rank": 3608,
    "frequency": 8123,
    "originalRank": 3717
  },
  {
    "word": "super",
    "rank": 3609,
    "frequency": 8121,
    "originalRank": 3718
  },
  {
    "word": "piedad",
    "rank": 3610,
    "frequency": 8114,
    "originalRank": 3719
  },
  {
    "word": "militares",
    "rank": 3611,
    "frequency": 8113,
    "originalRank": 3720
  },
  {
    "word": "seguía",
    "rank": 3612,
    "frequency": 8104,
    "originalRank": 3721
  },
  {
    "word": "tocado",
    "rank": 3613,
    "frequency": 8103,
    "originalRank": 3722
  },
  {
    "word": "ciudadanos",
    "rank": 3614,
    "frequency": 8101,
    "originalRank": 3723
  },
  {
    "word": "creado",
    "rank": 3615,
    "frequency": 8094,
    "originalRank": 3724
  },
  {
    "word": "temas",
    "rank": 3616,
    "frequency": 8093,
    "originalRank": 3725
  },
  {
    "word": "acepta",
    "rank": 3617,
    "frequency": 8092,
    "originalRank": 3726
  },
  {
    "word": "encerrado",
    "rank": 3618,
    "frequency": 8090,
    "originalRank": 3727
  },
  {
    "word": "opinas",
    "rank": 3619,
    "frequency": 8090,
    "originalRank": 3728
  },
  {
    "word": "empiezo",
    "rank": 3620,
    "frequency": 8088,
    "originalRank": 3729
  },
  {
    "word": "borde",
    "rank": 3621,
    "frequency": 8086,
    "originalRank": 3730
  },
  {
    "word": "llevarla",
    "rank": 3622,
    "frequency": 8076,
    "originalRank": 3731
  },
  {
    "word": "barcos",
    "rank": 3623,
    "frequency": 8075,
    "originalRank": 3732
  },
  {
    "word": "toby",
    "rank": 3624,
    "frequency": 8071,
    "originalRank": 3733
  },
  {
    "word": "pudieron",
    "rank": 3625,
    "frequency": 8063,
    "originalRank": 3734
  },
  {
    "word": "tocando",
    "rank": 3626,
    "frequency": 8062,
    "originalRank": 3735
  },
  {
    "word": "harvey",
    "rank": 3627,
    "frequency": 8060,
    "originalRank": 3736
  },
  {
    "word": "profesora",
    "rank": 3628,
    "frequency": 8055,
    "originalRank": 3737
  },
  {
    "word": "dejame",
    "rank": 3629,
    "frequency": 8052,
    "originalRank": 3738
  },
  {
    "word": "expresión",
    "rank": 3630,
    "frequency": 8052,
    "originalRank": 3739
  },
  {
    "word": "asesinada",
    "rank": 3631,
    "frequency": 8051,
    "originalRank": 3740
  },
  {
    "word": "escándalo",
    "rank": 3632,
    "frequency": 8048,
    "originalRank": 3741
  },
  {
    "word": "nervios",
    "rank": 3633,
    "frequency": 8040,
    "originalRank": 3742
  },
  {
    "word": "ios",
    "rank": 3634,
    "frequency": 8040,
    "originalRank": 3743
  },
  {
    "word": "randy",
    "rank": 3635,
    "frequency": 8039,
    "originalRank": 3744
  },
  {
    "word": "emoción",
    "rank": 3636,
    "frequency": 8038,
    "originalRank": 3745
  },
  {
    "word": "blake",
    "rank": 3637,
    "frequency": 8019,
    "originalRank": 3746
  },
  {
    "word": "catherine",
    "rank": 3638,
    "frequency": 8019,
    "originalRank": 3747
  },
  {
    "word": "oficialmente",
    "rank": 3639,
    "frequency": 8014,
    "originalRank": 3748
  },
  {
    "word": "perdedor",
    "rank": 3640,
    "frequency": 8009,
    "originalRank": 3749
  },
  {
    "word": "margaret",
    "rank": 3641,
    "frequency": 8003,
    "originalRank": 3750
  },
  {
    "word": "sienten",
    "rank": 3642,
    "frequency": 8001,
    "originalRank": 3751
  },
  {
    "word": "rumbo",
    "rank": 3643,
    "frequency": 8000,
    "originalRank": 3752
  },
  {
    "word": "valle",
    "rank": 3644,
    "frequency": 7995,
    "originalRank": 3753
  },
  {
    "word": "ian",
    "rank": 3645,
    "frequency": 7992,
    "originalRank": 3754
  },
  {
    "word": "viejas",
    "rank": 3646,
    "frequency": 7988,
    "originalRank": 3756
  },
  {
    "word": "buscaba",
    "rank": 3647,
    "frequency": 7984,
    "originalRank": 3757
  },
  {
    "word": "científicos",
    "rank": 3648,
    "frequency": 7983,
    "originalRank": 3758
  },
  {
    "word": "gorda",
    "rank": 3649,
    "frequency": 7977,
    "originalRank": 3759
  },
  {
    "word": "juventud",
    "rank": 3650,
    "frequency": 7972,
    "originalRank": 3760
  },
  {
    "word": "hayamos",
    "rank": 3651,
    "frequency": 7969,
    "originalRank": 3761
  },
  {
    "word": "preocupación",
    "rank": 3652,
    "frequency": 7969,
    "originalRank": 3762
  },
  {
    "word": "desnudo",
    "rank": 3653,
    "frequency": 7965,
    "originalRank": 3763
  },
  {
    "word": "guión",
    "rank": 3654,
    "frequency": 7961,
    "originalRank": 3764
  },
  {
    "word": "grant",
    "rank": 3655,
    "frequency": 7960,
    "originalRank": 3765
  },
  {
    "word": "envié",
    "rank": 3656,
    "frequency": 7960,
    "originalRank": 3766
  },
  {
    "word": "señoritas",
    "rank": 3657,
    "frequency": 7960,
    "originalRank": 3767
  },
  {
    "word": "carreras",
    "rank": 3658,
    "frequency": 7951,
    "originalRank": 3768
  },
  {
    "word": "tratas",
    "rank": 3659,
    "frequency": 7951,
    "originalRank": 3769
  },
  {
    "word": "sucia",
    "rank": 3660,
    "frequency": 7949,
    "originalRank": 3770
  },
  {
    "word": "sophie",
    "rank": 3661,
    "frequency": 7944,
    "originalRank": 3771
  },
  {
    "word": "ratas",
    "rank": 3662,
    "frequency": 7938,
    "originalRank": 3772
  },
  {
    "word": "mayo",
    "rank": 3663,
    "frequency": 7923,
    "originalRank": 3773
  },
  {
    "word": "tirado",
    "rank": 3664,
    "frequency": 7917,
    "originalRank": 3774
  },
  {
    "word": "heroína",
    "rank": 3665,
    "frequency": 7914,
    "originalRank": 3775
  },
  {
    "word": "háblame",
    "rank": 3666,
    "frequency": 7913,
    "originalRank": 3776
  },
  {
    "word": "contestar",
    "rank": 3667,
    "frequency": 7911,
    "originalRank": 3777
  },
  {
    "word": "caos",
    "rank": 3668,
    "frequency": 7910,
    "originalRank": 3778
  },
  {
    "word": "alternativa",
    "rank": 3669,
    "frequency": 7908,
    "originalRank": 3779
  },
  {
    "word": "estupidez",
    "rank": 3670,
    "frequency": 7907,
    "originalRank": 3780
  },
  {
    "word": "derek",
    "rank": 3671,
    "frequency": 7906,
    "originalRank": 3781
  },
  {
    "word": "sorprendente",
    "rank": 3672,
    "frequency": 7906,
    "originalRank": 3782
  },
  {
    "word": "pedirte",
    "rank": 3673,
    "frequency": 7901,
    "originalRank": 3783
  },
  {
    "word": "principios",
    "rank": 3674,
    "frequency": 7898,
    "originalRank": 3784
  },
  {
    "word": "egoísta",
    "rank": 3675,
    "frequency": 7886,
    "originalRank": 3785
  },
  {
    "word": "mostraré",
    "rank": 3676,
    "frequency": 7884,
    "originalRank": 3786
  },
  {
    "word": "sentarme",
    "rank": 3677,
    "frequency": 7881,
    "originalRank": 3787
  },
  {
    "word": "verdaderamente",
    "rank": 3678,
    "frequency": 7875,
    "originalRank": 3788
  },
  {
    "word": "enhorabuena",
    "rank": 3679,
    "frequency": 7871,
    "originalRank": 3789
  },
  {
    "word": "casey",
    "rank": 3680,
    "frequency": 7869,
    "originalRank": 3790
  },
  {
    "word": "peligrosa",
    "rank": 3681,
    "frequency": 7868,
    "originalRank": 3791
  },
  {
    "word": "ánimo",
    "rank": 3682,
    "frequency": 7867,
    "originalRank": 3792
  },
  {
    "word": "viajes",
    "rank": 3683,
    "frequency": 7860,
    "originalRank": 3793
  },
  {
    "word": "lujo",
    "rank": 3684,
    "frequency": 7858,
    "originalRank": 3794
  },
  {
    "word": "mia",
    "rank": 3685,
    "frequency": 7854,
    "originalRank": 3795
  },
  {
    "word": "cantando",
    "rank": 3686,
    "frequency": 7854,
    "originalRank": 3796
  },
  {
    "word": "religión",
    "rank": 3687,
    "frequency": 7851,
    "originalRank": 3797
  },
  {
    "word": "nate",
    "rank": 3688,
    "frequency": 7851,
    "originalRank": 3798
  },
  {
    "word": "risas",
    "rank": 3689,
    "frequency": 7846,
    "originalRank": 3799
  },
  {
    "word": "despejado",
    "rank": 3690,
    "frequency": 7844,
    "originalRank": 3800
  },
  {
    "word": "miserable",
    "rank": 3691,
    "frequency": 7842,
    "originalRank": 3801
  },
  {
    "word": "hierro",
    "rank": 3692,
    "frequency": 7841,
    "originalRank": 3802
  },
  {
    "word": "corona",
    "rank": 3693,
    "frequency": 7840,
    "originalRank": 3803
  },
  {
    "word": "wayne",
    "rank": 3694,
    "frequency": 7839,
    "originalRank": 3804
  },
  {
    "word": "serías",
    "rank": 3695,
    "frequency": 7836,
    "originalRank": 3805
  },
  {
    "word": "dispositivo",
    "rank": 3696,
    "frequency": 7834,
    "originalRank": 3806
  },
  {
    "word": "mencionar",
    "rank": 3697,
    "frequency": 7832,
    "originalRank": 3807
  },
  {
    "word": "brad",
    "rank": 3698,
    "frequency": 7826,
    "originalRank": 3808
  },
  {
    "word": "mencionó",
    "rank": 3699,
    "frequency": 7825,
    "originalRank": 3809
  },
  {
    "word": "inmunidad",
    "rank": 3700,
    "frequency": 7823,
    "originalRank": 3810
  },
  {
    "word": "grabación",
    "rank": 3701,
    "frequency": 7815,
    "originalRank": 3811
  },
  {
    "word": "producción",
    "rank": 3702,
    "frequency": 7813,
    "originalRank": 3812
  },
  {
    "word": "nuclear",
    "rank": 3703,
    "frequency": 7807,
    "originalRank": 3813
  },
  {
    "word": "clima",
    "rank": 3704,
    "frequency": 7807,
    "originalRank": 3814
  },
  {
    "word": "puesta",
    "rank": 3705,
    "frequency": 7804,
    "originalRank": 3815
  },
  {
    "word": "buscarlo",
    "rank": 3706,
    "frequency": 7804,
    "originalRank": 3816
  },
  {
    "word": "carácter",
    "rank": 3707,
    "frequency": 7801,
    "originalRank": 3817
  },
  {
    "word": "prostituta",
    "rank": 3708,
    "frequency": 7800,
    "originalRank": 3818
  },
  {
    "word": "llamarlo",
    "rank": 3709,
    "frequency": 7797,
    "originalRank": 3819
  },
  {
    "word": "steven",
    "rank": 3710,
    "frequency": 7794,
    "originalRank": 3820
  },
  {
    "word": "máscara",
    "rank": 3711,
    "frequency": 7793,
    "originalRank": 3821
  },
  {
    "word": "alegre",
    "rank": 3712,
    "frequency": 7790,
    "originalRank": 3822
  },
  {
    "word": "comprender",
    "rank": 3713,
    "frequency": 7785,
    "originalRank": 3823
  },
  {
    "word": "volviste",
    "rank": 3714,
    "frequency": 7783,
    "originalRank": 3824
  },
  {
    "word": "cambiando",
    "rank": 3715,
    "frequency": 7782,
    "originalRank": 3825
  },
  {
    "word": "alianza",
    "rank": 3716,
    "frequency": 7780,
    "originalRank": 3826
  },
  {
    "word": "encontrarás",
    "rank": 3717,
    "frequency": 7779,
    "originalRank": 3827
  },
  {
    "word": "positivo",
    "rank": 3718,
    "frequency": 7777,
    "originalRank": 3828
  },
  {
    "word": "siglos",
    "rank": 3719,
    "frequency": 7775,
    "originalRank": 3829
  },
  {
    "word": "serían",
    "rank": 3720,
    "frequency": 7775,
    "originalRank": 3830
  },
  {
    "word": "desafortunadamente",
    "rank": 3721,
    "frequency": 7774,
    "originalRank": 3831
  },
  {
    "word": "guitarra",
    "rank": 3722,
    "frequency": 7773,
    "originalRank": 3832
  },
  {
    "word": "hacían",
    "rank": 3723,
    "frequency": 7771,
    "originalRank": 3833
  },
  {
    "word": "estrategia",
    "rank": 3724,
    "frequency": 7770,
    "originalRank": 3834
  },
  {
    "word": "entré",
    "rank": 3725,
    "frequency": 7768,
    "originalRank": 3835
  },
  {
    "word": "vinimos",
    "rank": 3726,
    "frequency": 7767,
    "originalRank": 3836
  },
  {
    "word": "frecuencia",
    "rank": 3727,
    "frequency": 7760,
    "originalRank": 3837
  },
  {
    "word": "poli",
    "rank": 3728,
    "frequency": 7758,
    "originalRank": 3838
  },
  {
    "word": "that",
    "rank": 3729,
    "frequency": 7754,
    "originalRank": 3839
  },
  {
    "word": "elena",
    "rank": 3730,
    "frequency": 7752,
    "originalRank": 3840
  },
  {
    "word": "discúlpame",
    "rank": 3731,
    "frequency": 7748,
    "originalRank": 3841
  },
  {
    "word": "llevé",
    "rank": 3732,
    "frequency": 7745,
    "originalRank": 3842
  },
  {
    "word": "vince",
    "rank": 3733,
    "frequency": 7742,
    "originalRank": 3843
  },
  {
    "word": "prohibido",
    "rank": 3734,
    "frequency": 7738,
    "originalRank": 3844
  },
  {
    "word": "caray",
    "rank": 3735,
    "frequency": 7738,
    "originalRank": 3845
  },
  {
    "word": "arruinar",
    "rank": 3736,
    "frequency": 7738,
    "originalRank": 3846
  },
  {
    "word": "masa",
    "rank": 3737,
    "frequency": 7737,
    "originalRank": 3847
  },
  {
    "word": "existencia",
    "rank": 3738,
    "frequency": 7737,
    "originalRank": 3848
  },
  {
    "word": "túnel",
    "rank": 3739,
    "frequency": 7736,
    "originalRank": 3849
  },
  {
    "word": "bromas",
    "rank": 3740,
    "frequency": 7734,
    "originalRank": 3850
  },
  {
    "word": "evitarlo",
    "rank": 3741,
    "frequency": 7734,
    "originalRank": 3851
  },
  {
    "word": "industria",
    "rank": 3742,
    "frequency": 7732,
    "originalRank": 3852
  },
  {
    "word": "trasera",
    "rank": 3743,
    "frequency": 7729,
    "originalRank": 3853
  },
  {
    "word": "monstruos",
    "rank": 3744,
    "frequency": 7729,
    "originalRank": 3854
  },
  {
    "word": "mete",
    "rank": 3745,
    "frequency": 7726,
    "originalRank": 3855
  },
  {
    "word": "conseguiré",
    "rank": 3746,
    "frequency": 7724,
    "originalRank": 3856
  },
  {
    "word": "inocentes",
    "rank": 3747,
    "frequency": 7722,
    "originalRank": 3857
  },
  {
    "word": "colección",
    "rank": 3748,
    "frequency": 7720,
    "originalRank": 3858
  },
  {
    "word": "empleado",
    "rank": 3749,
    "frequency": 7717,
    "originalRank": 3859
  },
  {
    "word": "fatal",
    "rank": 3750,
    "frequency": 7713,
    "originalRank": 3860
  },
  {
    "word": "stephen",
    "rank": 3751,
    "frequency": 7711,
    "originalRank": 3861
  },
  {
    "word": "olivia",
    "rank": 3752,
    "frequency": 7710,
    "originalRank": 3862
  },
  {
    "word": "intente",
    "rank": 3753,
    "frequency": 7709,
    "originalRank": 3863
  },
  {
    "word": "expediente",
    "rank": 3754,
    "frequency": 7709,
    "originalRank": 3864
  },
  {
    "word": "nancy",
    "rank": 3755,
    "frequency": 7707,
    "originalRank": 3865
  },
  {
    "word": "putas",
    "rank": 3756,
    "frequency": 7706,
    "originalRank": 3866
  },
  {
    "word": "jess",
    "rank": 3757,
    "frequency": 7706,
    "originalRank": 3867
  },
  {
    "word": "petición",
    "rank": 3758,
    "frequency": 7705,
    "originalRank": 3868
  },
  {
    "word": "ayudado",
    "rank": 3759,
    "frequency": 7702,
    "originalRank": 3869
  },
  {
    "word": "lou",
    "rank": 3760,
    "frequency": 7702,
    "originalRank": 3870
  },
  {
    "word": "presentación",
    "rank": 3761,
    "frequency": 7699,
    "originalRank": 3871
  },
  {
    "word": "beth",
    "rank": 3762,
    "frequency": 7698,
    "originalRank": 3872
  },
  {
    "word": "vendido",
    "rank": 3763,
    "frequency": 7698,
    "originalRank": 3873
  },
  {
    "word": "cerebral",
    "rank": 3764,
    "frequency": 7696,
    "originalRank": 3874
  },
  {
    "word": "coraje",
    "rank": 3765,
    "frequency": 7695,
    "originalRank": 3875
  },
  {
    "word": "adulto",
    "rank": 3766,
    "frequency": 7693,
    "originalRank": 3876
  },
  {
    "word": "rubia",
    "rank": 3767,
    "frequency": 7693,
    "originalRank": 3877
  },
  {
    "word": "mandar",
    "rank": 3768,
    "frequency": 7692,
    "originalRank": 3878
  },
  {
    "word": "pierdes",
    "rank": 3769,
    "frequency": 7687,
    "originalRank": 3879
  },
  {
    "word": "gano",
    "rank": 3770,
    "frequency": 7685,
    "originalRank": 3880
  },
  {
    "word": "almorzar",
    "rank": 3771,
    "frequency": 7685,
    "originalRank": 3881
  },
  {
    "word": "caridad",
    "rank": 3772,
    "frequency": 7684,
    "originalRank": 3882
  },
  {
    "word": "oscar",
    "rank": 3773,
    "frequency": 7681,
    "originalRank": 3883
  },
  {
    "word": "sepan",
    "rank": 3774,
    "frequency": 7680,
    "originalRank": 3884
  },
  {
    "word": "llegada",
    "rank": 3775,
    "frequency": 7679,
    "originalRank": 3885
  },
  {
    "word": "capítulo",
    "rank": 3776,
    "frequency": 7679,
    "originalRank": 3886
  },
  {
    "word": "disculparme",
    "rank": 3777,
    "frequency": 7679,
    "originalRank": 3887
  },
  {
    "word": "viniera",
    "rank": 3778,
    "frequency": 7678,
    "originalRank": 3888
  },
  {
    "word": "gastos",
    "rank": 3779,
    "frequency": 7675,
    "originalRank": 3889
  },
  {
    "word": "sentirse",
    "rank": 3780,
    "frequency": 7673,
    "originalRank": 3890
  },
  {
    "word": "entren",
    "rank": 3781,
    "frequency": 7673,
    "originalRank": 3891
  },
  {
    "word": "quédese",
    "rank": 3782,
    "frequency": 7672,
    "originalRank": 3892
  },
  {
    "word": "tarta",
    "rank": 3783,
    "frequency": 7671,
    "originalRank": 3893
  },
  {
    "word": "volvería",
    "rank": 3784,
    "frequency": 7668,
    "originalRank": 3894
  },
  {
    "word": "jersey",
    "rank": 3785,
    "frequency": 7662,
    "originalRank": 3895
  },
  {
    "word": "mataría",
    "rank": 3786,
    "frequency": 7657,
    "originalRank": 3896
  },
  {
    "word": "breve",
    "rank": 3787,
    "frequency": 7647,
    "originalRank": 3897
  },
  {
    "word": "obras",
    "rank": 3788,
    "frequency": 7644,
    "originalRank": 3898
  },
  {
    "word": "acero",
    "rank": 3789,
    "frequency": 7643,
    "originalRank": 3899
  },
  {
    "word": "llévame",
    "rank": 3790,
    "frequency": 7642,
    "originalRank": 3900
  },
  {
    "word": "street",
    "rank": 3791,
    "frequency": 7639,
    "originalRank": 3901
  },
  {
    "word": "suceda",
    "rank": 3792,
    "frequency": 7639,
    "originalRank": 3902
  },
  {
    "word": "cigarrillos",
    "rank": 3793,
    "frequency": 7638,
    "originalRank": 3903
  },
  {
    "word": "funcionará",
    "rank": 3794,
    "frequency": 7637,
    "originalRank": 3904
  },
  {
    "word": "alicia",
    "rank": 3795,
    "frequency": 7636,
    "originalRank": 3905
  },
  {
    "word": "haberla",
    "rank": 3796,
    "frequency": 7635,
    "originalRank": 3906
  },
  {
    "word": "camarada",
    "rank": 3797,
    "frequency": 7631,
    "originalRank": 3907
  },
  {
    "word": "confesión",
    "rank": 3798,
    "frequency": 7631,
    "originalRank": 3908
  },
  {
    "word": "dijimos",
    "rank": 3799,
    "frequency": 7626,
    "originalRank": 3909
  },
  {
    "word": "coartada",
    "rank": 3800,
    "frequency": 7622,
    "originalRank": 3910
  },
  {
    "word": "desnuda",
    "rank": 3801,
    "frequency": 7618,
    "originalRank": 3911
  },
  {
    "word": "payaso",
    "rank": 3802,
    "frequency": 7617,
    "originalRank": 3912
  },
  {
    "word": "rayo",
    "rank": 3803,
    "frequency": 7617,
    "originalRank": 3913
  },
  {
    "word": "guay",
    "rank": 3804,
    "frequency": 7614,
    "originalRank": 3914
  },
  {
    "word": "naves",
    "rank": 3805,
    "frequency": 7609,
    "originalRank": 3915
  },
  {
    "word": "americana",
    "rank": 3806,
    "frequency": 7607,
    "originalRank": 3916
  },
  {
    "word": "político",
    "rank": 3807,
    "frequency": 7605,
    "originalRank": 3917
  },
  {
    "word": "diseño",
    "rank": 3808,
    "frequency": 7605,
    "originalRank": 3918
  },
  {
    "word": "condenado",
    "rank": 3809,
    "frequency": 7603,
    "originalRank": 3919
  },
  {
    "word": "convencido",
    "rank": 3810,
    "frequency": 7599,
    "originalRank": 3920
  },
  {
    "word": "edward",
    "rank": 3811,
    "frequency": 7596,
    "originalRank": 3921
  },
  {
    "word": "policia",
    "rank": 3812,
    "frequency": 7589,
    "originalRank": 3922
  },
  {
    "word": "italiano",
    "rank": 3813,
    "frequency": 7586,
    "originalRank": 3923
  },
  {
    "word": "pedro",
    "rank": 3814,
    "frequency": 7585,
    "originalRank": 3924
  },
  {
    "word": "camiseta",
    "rank": 3815,
    "frequency": 7581,
    "originalRank": 3926
  },
  {
    "word": "vendrán",
    "rank": 3816,
    "frequency": 7578,
    "originalRank": 3927
  },
  {
    "word": "extrañas",
    "rank": 3817,
    "frequency": 7578,
    "originalRank": 3928
  },
  {
    "word": "impacto",
    "rank": 3818,
    "frequency": 7577,
    "originalRank": 3929
  },
  {
    "word": "equipaje",
    "rank": 3819,
    "frequency": 7575,
    "originalRank": 3930
  },
  {
    "word": "lois",
    "rank": 3820,
    "frequency": 7574,
    "originalRank": 3931
  },
  {
    "word": "sufrimiento",
    "rank": 3821,
    "frequency": 7566,
    "originalRank": 3932
  },
  {
    "word": "salieron",
    "rank": 3822,
    "frequency": 7553,
    "originalRank": 3933
  },
  {
    "word": "mantente",
    "rank": 3823,
    "frequency": 7545,
    "originalRank": 3934
  },
  {
    "word": "sabiendo",
    "rank": 3824,
    "frequency": 7545,
    "originalRank": 3935
  },
  {
    "word": "maten",
    "rank": 3825,
    "frequency": 7544,
    "originalRank": 3936
  },
  {
    "word": "adolescente",
    "rank": 3826,
    "frequency": 7542,
    "originalRank": 3937
  },
  {
    "word": "soltero",
    "rank": 3827,
    "frequency": 7542,
    "originalRank": 3938
  },
  {
    "word": "descubrí",
    "rank": 3828,
    "frequency": 7541,
    "originalRank": 3939
  },
  {
    "word": "tranquilos",
    "rank": 3829,
    "frequency": 7536,
    "originalRank": 3940
  },
  {
    "word": "influencia",
    "rank": 3830,
    "frequency": 7534,
    "originalRank": 3941
  },
  {
    "word": "oxígeno",
    "rank": 3831,
    "frequency": 7532,
    "originalRank": 3942
  },
  {
    "word": "experimento",
    "rank": 3832,
    "frequency": 7531,
    "originalRank": 3943
  },
  {
    "word": "absurdo",
    "rank": 3833,
    "frequency": 7529,
    "originalRank": 3944
  },
  {
    "word": "algun",
    "rank": 3834,
    "frequency": 7529,
    "originalRank": 3945
  },
  {
    "word": "habrían",
    "rank": 3835,
    "frequency": 7528,
    "originalRank": 3946
  },
  {
    "word": "ponerle",
    "rank": 3836,
    "frequency": 7528,
    "originalRank": 3947
  },
  {
    "word": "empiece",
    "rank": 3837,
    "frequency": 7528,
    "originalRank": 3948
  },
  {
    "word": "devolver",
    "rank": 3838,
    "frequency": 7524,
    "originalRank": 3949
  },
  {
    "word": "propuesta",
    "rank": 3839,
    "frequency": 7524,
    "originalRank": 3950
  },
  {
    "word": "tómalo",
    "rank": 3840,
    "frequency": 7523,
    "originalRank": 3951
  },
  {
    "word": "michelle",
    "rank": 3841,
    "frequency": 7521,
    "originalRank": 3952
  },
  {
    "word": "abrió",
    "rank": 3842,
    "frequency": 7519,
    "originalRank": 3953
  },
  {
    "word": "plantas",
    "rank": 3843,
    "frequency": 7519,
    "originalRank": 3954
  },
  {
    "word": "cantante",
    "rank": 3844,
    "frequency": 7513,
    "originalRank": 3955
  },
  {
    "word": "traición",
    "rank": 3845,
    "frequency": 7508,
    "originalRank": 3956
  },
  {
    "word": "cementerio",
    "rank": 3846,
    "frequency": 7506,
    "originalRank": 3957
  },
  {
    "word": "florida",
    "rank": 3847,
    "frequency": 7503,
    "originalRank": 3958
  },
  {
    "word": "pozo",
    "rank": 3848,
    "frequency": 7499,
    "originalRank": 3959
  },
  {
    "word": "patrulla",
    "rank": 3849,
    "frequency": 7498,
    "originalRank": 3960
  },
  {
    "word": "brandon",
    "rank": 3850,
    "frequency": 7498,
    "originalRank": 3961
  },
  {
    "word": "planeando",
    "rank": 3851,
    "frequency": 7495,
    "originalRank": 3962
  },
  {
    "word": "ann",
    "rank": 3852,
    "frequency": 7494,
    "originalRank": 3963
  },
  {
    "word": "tragedia",
    "rank": 3853,
    "frequency": 7489,
    "originalRank": 3964
  },
  {
    "word": "ethan",
    "rank": 3854,
    "frequency": 7478,
    "originalRank": 3965
  },
  {
    "word": "miami",
    "rank": 3855,
    "frequency": 7478,
    "originalRank": 3966
  },
  {
    "word": "autoridades",
    "rank": 3856,
    "frequency": 7476,
    "originalRank": 3967
  },
  {
    "word": "trate",
    "rank": 3857,
    "frequency": 7476,
    "originalRank": 3968
  },
  {
    "word": "procedimiento",
    "rank": 3858,
    "frequency": 7472,
    "originalRank": 3969
  },
  {
    "word": "fantasía",
    "rank": 3859,
    "frequency": 7471,
    "originalRank": 3970
  },
  {
    "word": "billetes",
    "rank": 3860,
    "frequency": 7470,
    "originalRank": 3971
  },
  {
    "word": "ganamos",
    "rank": 3861,
    "frequency": 7469,
    "originalRank": 3972
  },
  {
    "word": "secuestro",
    "rank": 3862,
    "frequency": 7469,
    "originalRank": 3973
  },
  {
    "word": "sabrás",
    "rank": 3863,
    "frequency": 7468,
    "originalRank": 3974
  },
  {
    "word": "prestado",
    "rank": 3864,
    "frequency": 7464,
    "originalRank": 3975
  },
  {
    "word": "bodas",
    "rank": 3865,
    "frequency": 7460,
    "originalRank": 3976
  },
  {
    "word": "béisbol",
    "rank": 3866,
    "frequency": 7460,
    "originalRank": 3977
  },
  {
    "word": "ciudades",
    "rank": 3867,
    "frequency": 7460,
    "originalRank": 3978
  },
  {
    "word": "conejo",
    "rank": 3868,
    "frequency": 7455,
    "originalRank": 3979
  },
  {
    "word": "pregúntale",
    "rank": 3869,
    "frequency": 7454,
    "originalRank": 3980
  },
  {
    "word": "billete",
    "rank": 3870,
    "frequency": 7453,
    "originalRank": 3981
  },
  {
    "word": "esperanzas",
    "rank": 3871,
    "frequency": 7453,
    "originalRank": 3982
  },
  {
    "word": "díselo",
    "rank": 3872,
    "frequency": 7449,
    "originalRank": 3983
  },
  {
    "word": "significado",
    "rank": 3873,
    "frequency": 7449,
    "originalRank": 3984
  },
  {
    "word": "mueren",
    "rank": 3874,
    "frequency": 7445,
    "originalRank": 3985
  },
  {
    "word": "shawn",
    "rank": 3875,
    "frequency": 7443,
    "originalRank": 3986
  },
  {
    "word": "cincuenta",
    "rank": 3876,
    "frequency": 7440,
    "originalRank": 3987
  },
  {
    "word": "jugadores",
    "rank": 3877,
    "frequency": 7438,
    "originalRank": 3988
  },
  {
    "word": "web",
    "rank": 3878,
    "frequency": 7432,
    "originalRank": 3989
  },
  {
    "word": "apropiado",
    "rank": 3879,
    "frequency": 7432,
    "originalRank": 3990
  },
  {
    "word": "robot",
    "rank": 3880,
    "frequency": 7429,
    "originalRank": 3991
  },
  {
    "word": "considerado",
    "rank": 3881,
    "frequency": 7429,
    "originalRank": 3992
  },
  {
    "word": "alcanzar",
    "rank": 3882,
    "frequency": 7427,
    "originalRank": 3993
  },
  {
    "word": "patatas",
    "rank": 3883,
    "frequency": 7424,
    "originalRank": 3994
  },
  {
    "word": "mantenga",
    "rank": 3884,
    "frequency": 7424,
    "originalRank": 3995
  },
  {
    "word": "continuación",
    "rank": 3885,
    "frequency": 7422,
    "originalRank": 3996
  },
  {
    "word": "tradición",
    "rank": 3886,
    "frequency": 7420,
    "originalRank": 3997
  },
  {
    "word": "países",
    "rank": 3887,
    "frequency": 7420,
    "originalRank": 3998
  },
  {
    "word": "ocultar",
    "rank": 3888,
    "frequency": 7419,
    "originalRank": 3999
  },
  {
    "word": "tendríamos",
    "rank": 3889,
    "frequency": 7419,
    "originalRank": 4000
  },
  {
    "word": "electricidad",
    "rank": 3890,
    "frequency": 7413,
    "originalRank": 4001
  },
  {
    "word": "bebidas",
    "rank": 3891,
    "frequency": 7409,
    "originalRank": 4002
  },
  {
    "word": "siguió",
    "rank": 3892,
    "frequency": 7409,
    "originalRank": 4003
  },
  {
    "word": "reto",
    "rank": 3893,
    "frequency": 7406,
    "originalRank": 4004
  },
  {
    "word": "aldea",
    "rank": 3894,
    "frequency": 7401,
    "originalRank": 4005
  },
  {
    "word": "robaron",
    "rank": 3895,
    "frequency": 7393,
    "originalRank": 4006
  },
  {
    "word": "aguas",
    "rank": 3896,
    "frequency": 7388,
    "originalRank": 4007
  },
  {
    "word": "caminos",
    "rank": 3897,
    "frequency": 7380,
    "originalRank": 4008
  },
  {
    "word": "ellen",
    "rank": 3898,
    "frequency": 7379,
    "originalRank": 4009
  },
  {
    "word": "permitido",
    "rank": 3899,
    "frequency": 7379,
    "originalRank": 4010
  },
  {
    "word": "alli",
    "rank": 3900,
    "frequency": 7373,
    "originalRank": 4011
  },
  {
    "word": "cima",
    "rank": 3901,
    "frequency": 7367,
    "originalRank": 4012
  },
  {
    "word": "risa",
    "rank": 3902,
    "frequency": 7363,
    "originalRank": 4014
  },
  {
    "word": "cumplido",
    "rank": 3903,
    "frequency": 7362,
    "originalRank": 4015
  },
  {
    "word": "objetos",
    "rank": 3904,
    "frequency": 7361,
    "originalRank": 4016
  },
  {
    "word": "decide",
    "rank": 3905,
    "frequency": 7358,
    "originalRank": 4017
  },
  {
    "word": "pregunte",
    "rank": 3906,
    "frequency": 7358,
    "originalRank": 4018
  },
  {
    "word": "once",
    "rank": 3907,
    "frequency": 7352,
    "originalRank": 4019
  },
  {
    "word": "matan",
    "rank": 3908,
    "frequency": 7345,
    "originalRank": 4020
  },
  {
    "word": "terrorista",
    "rank": 3909,
    "frequency": 7345,
    "originalRank": 4021
  },
  {
    "word": "tomes",
    "rank": 3910,
    "frequency": 7341,
    "originalRank": 4022
  },
  {
    "word": "términos",
    "rank": 3911,
    "frequency": 7337,
    "originalRank": 4023
  },
  {
    "word": "reyes",
    "rank": 3912,
    "frequency": 7336,
    "originalRank": 4024
  },
  {
    "word": "revés",
    "rank": 3913,
    "frequency": 7334,
    "originalRank": 4025
  },
  {
    "word": "explotar",
    "rank": 3914,
    "frequency": 7333,
    "originalRank": 4026
  },
  {
    "word": "maletas",
    "rank": 3915,
    "frequency": 7329,
    "originalRank": 4027
  },
  {
    "word": "nubes",
    "rank": 3916,
    "frequency": 7328,
    "originalRank": 4028
  },
  {
    "word": "circo",
    "rank": 3917,
    "frequency": 7326,
    "originalRank": 4029
  },
  {
    "word": "darse",
    "rank": 3918,
    "frequency": 7325,
    "originalRank": 4030
  },
  {
    "word": "west",
    "rank": 3919,
    "frequency": 7322,
    "originalRank": 4031
  },
  {
    "word": "prometiste",
    "rank": 3920,
    "frequency": 7321,
    "originalRank": 4032
  },
  {
    "word": "tanque",
    "rank": 3921,
    "frequency": 7321,
    "originalRank": 4033
  },
  {
    "word": "uñas",
    "rank": 3922,
    "frequency": 7319,
    "originalRank": 4034
  },
  {
    "word": "encargaré",
    "rank": 3923,
    "frequency": 7319,
    "originalRank": 4035
  },
  {
    "word": "terroristas",
    "rank": 3924,
    "frequency": 7318,
    "originalRank": 4036
  },
  {
    "word": "estúpidos",
    "rank": 3925,
    "frequency": 7316,
    "originalRank": 4037
  },
  {
    "word": "héroes",
    "rank": 3926,
    "frequency": 7316,
    "originalRank": 4038
  },
  {
    "word": "salta",
    "rank": 3927,
    "frequency": 7311,
    "originalRank": 4039
  },
  {
    "word": "daremos",
    "rank": 3928,
    "frequency": 7309,
    "originalRank": 4040
  },
  {
    "word": "agradecido",
    "rank": 3929,
    "frequency": 7303,
    "originalRank": 4041
  },
  {
    "word": "victor",
    "rank": 3930,
    "frequency": 7295,
    "originalRank": 4042
  },
  {
    "word": "terror",
    "rank": 3931,
    "frequency": 7295,
    "originalRank": 4043
  },
  {
    "word": "keith",
    "rank": 3932,
    "frequency": 7291,
    "originalRank": 4044
  },
  {
    "word": "sacrificio",
    "rank": 3933,
    "frequency": 7289,
    "originalRank": 4045
  },
  {
    "word": "destrucción",
    "rank": 3934,
    "frequency": 7289,
    "originalRank": 4046
  },
  {
    "word": "teddy",
    "rank": 3935,
    "frequency": 7288,
    "originalRank": 4047
  },
  {
    "word": "texto",
    "rank": 3936,
    "frequency": 7285,
    "originalRank": 4048
  },
  {
    "word": "peleas",
    "rank": 3937,
    "frequency": 7283,
    "originalRank": 4049
  },
  {
    "word": "liga",
    "rank": 3938,
    "frequency": 7282,
    "originalRank": 4050
  },
  {
    "word": "martha",
    "rank": 3939,
    "frequency": 7281,
    "originalRank": 4051
  },
  {
    "word": "ana",
    "rank": 3940,
    "frequency": 7280,
    "originalRank": 4052
  },
  {
    "word": "enviaré",
    "rank": 3941,
    "frequency": 7278,
    "originalRank": 4053
  },
  {
    "word": "teléfonos",
    "rank": 3942,
    "frequency": 7275,
    "originalRank": 4054
  },
  {
    "word": "porno",
    "rank": 3943,
    "frequency": 7266,
    "originalRank": 4055
  },
  {
    "word": "diera",
    "rank": 3944,
    "frequency": 7266,
    "originalRank": 4056
  },
  {
    "word": "oscura",
    "rank": 3945,
    "frequency": 7259,
    "originalRank": 4057
  },
  {
    "word": "tuyos",
    "rank": 3946,
    "frequency": 7259,
    "originalRank": 4058
  },
  {
    "word": "olvido",
    "rank": 3947,
    "frequency": 7258,
    "originalRank": 4059
  },
  {
    "word": "queridos",
    "rank": 3948,
    "frequency": 7256,
    "originalRank": 4060
  },
  {
    "word": "colina",
    "rank": 3949,
    "frequency": 7254,
    "originalRank": 4061
  },
  {
    "word": "bromeas",
    "rank": 3950,
    "frequency": 7246,
    "originalRank": 4062
  },
  {
    "word": "sano",
    "rank": 3951,
    "frequency": 7241,
    "originalRank": 4063
  },
  {
    "word": "únicos",
    "rank": 3952,
    "frequency": 7238,
    "originalRank": 4064
  },
  {
    "word": "musical",
    "rank": 3953,
    "frequency": 7237,
    "originalRank": 4065
  },
  {
    "word": "pastor",
    "rank": 3954,
    "frequency": 7236,
    "originalRank": 4066
  },
  {
    "word": "ponerlo",
    "rank": 3955,
    "frequency": 7233,
    "originalRank": 4067
  },
  {
    "word": "naranja",
    "rank": 3956,
    "frequency": 7230,
    "originalRank": 4068
  },
  {
    "word": "batería",
    "rank": 3957,
    "frequency": 7229,
    "originalRank": 4069
  },
  {
    "word": "trabajó",
    "rank": 3958,
    "frequency": 7227,
    "originalRank": 4070
  },
  {
    "word": "reuniones",
    "rank": 3959,
    "frequency": 7225,
    "originalRank": 4071
  },
  {
    "word": "sue",
    "rank": 3960,
    "frequency": 7224,
    "originalRank": 4072
  },
  {
    "word": "figura",
    "rank": 3961,
    "frequency": 7224,
    "originalRank": 4073
  },
  {
    "word": "jesucristo",
    "rank": 3962,
    "frequency": 7223,
    "originalRank": 4074
  },
  {
    "word": "funcionan",
    "rank": 3963,
    "frequency": 7220,
    "originalRank": 4075
  },
  {
    "word": "voces",
    "rank": 3964,
    "frequency": 7214,
    "originalRank": 4076
  },
  {
    "word": "caroline",
    "rank": 3965,
    "frequency": 7213,
    "originalRank": 4077
  },
  {
    "word": "jacob",
    "rank": 3966,
    "frequency": 7210,
    "originalRank": 4078
  },
  {
    "word": "caramba",
    "rank": 3967,
    "frequency": 7203,
    "originalRank": 4079
  },
  {
    "word": "callejón",
    "rank": 3968,
    "frequency": 7199,
    "originalRank": 4080
  },
  {
    "word": "técnica",
    "rank": 3969,
    "frequency": 7198,
    "originalRank": 4081
  },
  {
    "word": "marshall",
    "rank": 3970,
    "frequency": 7197,
    "originalRank": 4082
  },
  {
    "word": "refería",
    "rank": 3971,
    "frequency": 7197,
    "originalRank": 4083
  },
  {
    "word": "notado",
    "rank": 3972,
    "frequency": 7197,
    "originalRank": 4084
  },
  {
    "word": "maquillaje",
    "rank": 3973,
    "frequency": 7197,
    "originalRank": 4085
  },
  {
    "word": "lanzar",
    "rank": 3974,
    "frequency": 7193,
    "originalRank": 4086
  },
  {
    "word": "cadáveres",
    "rank": 3975,
    "frequency": 7192,
    "originalRank": 4087
  },
  {
    "word": "atacó",
    "rank": 3976,
    "frequency": 7192,
    "originalRank": 4088
  },
  {
    "word": "vendiendo",
    "rank": 3977,
    "frequency": 7190,
    "originalRank": 4089
  },
  {
    "word": "bailando",
    "rank": 3978,
    "frequency": 7187,
    "originalRank": 4090
  },
  {
    "word": "tenerte",
    "rank": 3979,
    "frequency": 7186,
    "originalRank": 4091
  },
  {
    "word": "cubrir",
    "rank": 3980,
    "frequency": 7184,
    "originalRank": 4092
  },
  {
    "word": "liz",
    "rank": 3981,
    "frequency": 7180,
    "originalRank": 4093
  },
  {
    "word": "policial",
    "rank": 3982,
    "frequency": 7178,
    "originalRank": 4094
  },
  {
    "word": "fase",
    "rank": 3983,
    "frequency": 7174,
    "originalRank": 4095
  },
  {
    "word": "gus",
    "rank": 3984,
    "frequency": 7170,
    "originalRank": 4096
  },
  {
    "word": "joseph",
    "rank": 3985,
    "frequency": 7168,
    "originalRank": 4097
  },
  {
    "word": "importaba",
    "rank": 3986,
    "frequency": 7163,
    "originalRank": 4098
  },
  {
    "word": "armada",
    "rank": 3987,
    "frequency": 7159,
    "originalRank": 4099
  },
  {
    "word": "fea",
    "rank": 3988,
    "frequency": 7157,
    "originalRank": 4100
  },
  {
    "word": "porquería",
    "rank": 3989,
    "frequency": 7154,
    "originalRank": 4101
  },
  {
    "word": "mickey",
    "rank": 3990,
    "frequency": 7153,
    "originalRank": 4102
  },
  {
    "word": "superar",
    "rank": 3991,
    "frequency": 7150,
    "originalRank": 4103
  },
  {
    "word": "disfruta",
    "rank": 3992,
    "frequency": 7149,
    "originalRank": 4104
  },
  {
    "word": "sueldo",
    "rank": 3993,
    "frequency": 7147,
    "originalRank": 4105
  },
  {
    "word": "abiertos",
    "rank": 3994,
    "frequency": 7144,
    "originalRank": 4106
  },
  {
    "word": "piénsalo",
    "rank": 3995,
    "frequency": 7140,
    "originalRank": 4107
  },
  {
    "word": "testimonio",
    "rank": 3996,
    "frequency": 7138,
    "originalRank": 4108
  },
  {
    "word": "incómodo",
    "rank": 3997,
    "frequency": 7136,
    "originalRank": 4109
  },
  {
    "word": "oyó",
    "rank": 3998,
    "frequency": 7132,
    "originalRank": 4110
  },
  {
    "word": "costado",
    "rank": 3999,
    "frequency": 7129,
    "originalRank": 4111
  },
  {
    "word": "apaga",
    "rank": 4000,
    "frequency": 7126,
    "originalRank": 4112
  },
  {
    "word": "considerando",
    "rank": 4001,
    "frequency": 7118,
    "originalRank": 4113
  },
  {
    "word": "bolsas",
    "rank": 4002,
    "frequency": 7118,
    "originalRank": 4114
  },
  {
    "word": "seguiré",
    "rank": 4003,
    "frequency": 7115,
    "originalRank": 4115
  },
  {
    "word": "imaginé",
    "rank": 4004,
    "frequency": 7112,
    "originalRank": 4116
  },
  {
    "word": "detenerlo",
    "rank": 4005,
    "frequency": 7112,
    "originalRank": 4117
  },
  {
    "word": "diana",
    "rank": 4006,
    "frequency": 7111,
    "originalRank": 4118
  },
  {
    "word": "pasaporte",
    "rank": 4007,
    "frequency": 7104,
    "originalRank": 4119
  },
  {
    "word": "infancia",
    "rank": 4008,
    "frequency": 7103,
    "originalRank": 4120
  },
  {
    "word": "suele",
    "rank": 4009,
    "frequency": 7099,
    "originalRank": 4121
  },
  {
    "word": "productos",
    "rank": 4010,
    "frequency": 7093,
    "originalRank": 4122
  },
  {
    "word": "rocas",
    "rank": 4011,
    "frequency": 7091,
    "originalRank": 4123
  },
  {
    "word": "reverendo",
    "rank": 4012,
    "frequency": 7088,
    "originalRank": 4124
  },
  {
    "word": "mediodía",
    "rank": 4013,
    "frequency": 7087,
    "originalRank": 4125
  },
  {
    "word": "golpeado",
    "rank": 4014,
    "frequency": 7086,
    "originalRank": 4126
  },
  {
    "word": "destruido",
    "rank": 4015,
    "frequency": 7086,
    "originalRank": 4127
  },
  {
    "word": "reconozco",
    "rank": 4016,
    "frequency": 7083,
    "originalRank": 4128
  },
  {
    "word": "plástico",
    "rank": 4017,
    "frequency": 7083,
    "originalRank": 4129
  },
  {
    "word": "young",
    "rank": 4018,
    "frequency": 7083,
    "originalRank": 4130
  },
  {
    "word": "barba",
    "rank": 4019,
    "frequency": 7082,
    "originalRank": 4131
  },
  {
    "word": "mago",
    "rank": 4020,
    "frequency": 7080,
    "originalRank": 4132
  },
  {
    "word": "hojas",
    "rank": 4021,
    "frequency": 7074,
    "originalRank": 4133
  },
  {
    "word": "conocerla",
    "rank": 4022,
    "frequency": 7071,
    "originalRank": 4134
  },
  {
    "word": "hallar",
    "rank": 4023,
    "frequency": 7067,
    "originalRank": 4135
  },
  {
    "word": "mantequilla",
    "rank": 4024,
    "frequency": 7067,
    "originalRank": 4136
  },
  {
    "word": "lidiar",
    "rank": 4025,
    "frequency": 7066,
    "originalRank": 4137
  },
  {
    "word": "sentencia",
    "rank": 4026,
    "frequency": 7065,
    "originalRank": 4138
  },
  {
    "word": "ideal",
    "rank": 4027,
    "frequency": 7064,
    "originalRank": 4139
  },
  {
    "word": "dámelo",
    "rank": 4028,
    "frequency": 7062,
    "originalRank": 4140
  },
  {
    "word": "mandó",
    "rank": 4029,
    "frequency": 7057,
    "originalRank": 4141
  },
  {
    "word": "residencia",
    "rank": 4030,
    "frequency": 7056,
    "originalRank": 4142
  },
  {
    "word": "francamente",
    "rank": 4031,
    "frequency": 7056,
    "originalRank": 4143
  },
  {
    "word": "guerrero",
    "rank": 4032,
    "frequency": 7055,
    "originalRank": 4144
  },
  {
    "word": "ayudo",
    "rank": 4033,
    "frequency": 7044,
    "originalRank": 4145
  },
  {
    "word": "sigamos",
    "rank": 4034,
    "frequency": 7044,
    "originalRank": 4146
  },
  {
    "word": "jennifer",
    "rank": 4035,
    "frequency": 7043,
    "originalRank": 4147
  },
  {
    "word": "engañar",
    "rank": 4036,
    "frequency": 7043,
    "originalRank": 4148
  },
  {
    "word": "baje",
    "rank": 4037,
    "frequency": 7043,
    "originalRank": 4149
  },
  {
    "word": "contaré",
    "rank": 4038,
    "frequency": 7042,
    "originalRank": 4150
  },
  {
    "word": "guantes",
    "rank": 4039,
    "frequency": 7040,
    "originalRank": 4151
  },
  {
    "word": "rompe",
    "rank": 4040,
    "frequency": 7040,
    "originalRank": 4152
  },
  {
    "word": "conociste",
    "rank": 4041,
    "frequency": 7036,
    "originalRank": 4153
  },
  {
    "word": "hoja",
    "rank": 4042,
    "frequency": 7033,
    "originalRank": 4154
  },
  {
    "word": "decían",
    "rank": 4043,
    "frequency": 7024,
    "originalRank": 4155
  },
  {
    "word": "recepción",
    "rank": 4044,
    "frequency": 7023,
    "originalRank": 4156
  },
  {
    "word": "logrado",
    "rank": 4045,
    "frequency": 7021,
    "originalRank": 4157
  },
  {
    "word": "odias",
    "rank": 4046,
    "frequency": 7019,
    "originalRank": 4158
  },
  {
    "word": "comisión",
    "rank": 4047,
    "frequency": 7018,
    "originalRank": 4159
  },
  {
    "word": "vampiro",
    "rank": 4048,
    "frequency": 7016,
    "originalRank": 4160
  },
  {
    "word": "finales",
    "rank": 4049,
    "frequency": 7016,
    "originalRank": 4161
  },
  {
    "word": "sufrido",
    "rank": 4050,
    "frequency": 7014,
    "originalRank": 4162
  },
  {
    "word": "azules",
    "rank": 4051,
    "frequency": 7012,
    "originalRank": 4163
  },
  {
    "word": "usarlo",
    "rank": 4052,
    "frequency": 7010,
    "originalRank": 4164
  },
  {
    "word": "cometer",
    "rank": 4053,
    "frequency": 7010,
    "originalRank": 4165
  },
  {
    "word": "descansa",
    "rank": 4054,
    "frequency": 7009,
    "originalRank": 4166
  },
  {
    "word": "peleando",
    "rank": 4055,
    "frequency": 7008,
    "originalRank": 4167
  },
  {
    "word": "docena",
    "rank": 4056,
    "frequency": 7005,
    "originalRank": 4168
  },
  {
    "word": "estaríamos",
    "rank": 4057,
    "frequency": 7003,
    "originalRank": 4169
  },
  {
    "word": "sera",
    "rank": 4058,
    "frequency": 7001,
    "originalRank": 4170
  },
  {
    "word": "lanza",
    "rank": 4059,
    "frequency": 7000,
    "originalRank": 4171
  },
  {
    "word": "averiguarlo",
    "rank": 4060,
    "frequency": 7000,
    "originalRank": 4172
  },
  {
    "word": "lanzamiento",
    "rank": 4061,
    "frequency": 6994,
    "originalRank": 4173
  },
  {
    "word": "moverse",
    "rank": 4062,
    "frequency": 6994,
    "originalRank": 4174
  },
  {
    "word": "falla",
    "rank": 4063,
    "frequency": 6992,
    "originalRank": 4176
  },
  {
    "word": "angela",
    "rank": 4064,
    "frequency": 6991,
    "originalRank": 4177
  },
  {
    "word": "técnicamente",
    "rank": 4065,
    "frequency": 6989,
    "originalRank": 4178
  },
  {
    "word": "dejara",
    "rank": 4066,
    "frequency": 6988,
    "originalRank": 4179
  },
  {
    "word": "medias",
    "rank": 4067,
    "frequency": 6986,
    "originalRank": 4180
  },
  {
    "word": "míralo",
    "rank": 4068,
    "frequency": 6983,
    "originalRank": 4181
  },
  {
    "word": "físico",
    "rank": 4069,
    "frequency": 6981,
    "originalRank": 4182
  },
  {
    "word": "hacerla",
    "rank": 4070,
    "frequency": 6977,
    "originalRank": 4183
  },
  {
    "word": "multitud",
    "rank": 4071,
    "frequency": 6977,
    "originalRank": 4184
  },
  {
    "word": "potencial",
    "rank": 4072,
    "frequency": 6976,
    "originalRank": 4185
  },
  {
    "word": "hacías",
    "rank": 4073,
    "frequency": 6976,
    "originalRank": 4186
  },
  {
    "word": "famosa",
    "rank": 4074,
    "frequency": 6973,
    "originalRank": 4187
  },
  {
    "word": "rutina",
    "rank": 4075,
    "frequency": 6972,
    "originalRank": 4188
  },
  {
    "word": "oportunidades",
    "rank": 4076,
    "frequency": 6969,
    "originalRank": 4189
  },
  {
    "word": "progreso",
    "rank": 4077,
    "frequency": 6964,
    "originalRank": 4190
  },
  {
    "word": "fascinante",
    "rank": 4078,
    "frequency": 6963,
    "originalRank": 4191
  },
  {
    "word": "ensalada",
    "rank": 4079,
    "frequency": 6960,
    "originalRank": 4192
  },
  {
    "word": "cómoda",
    "rank": 4080,
    "frequency": 6959,
    "originalRank": 4193
  },
  {
    "word": "prepara",
    "rank": 4081,
    "frequency": 6957,
    "originalRank": 4194
  },
  {
    "word": "tráeme",
    "rank": 4082,
    "frequency": 6955,
    "originalRank": 4195
  },
  {
    "word": "equivocas",
    "rank": 4083,
    "frequency": 6955,
    "originalRank": 4196
  },
  {
    "word": "tubo",
    "rank": 4084,
    "frequency": 6954,
    "originalRank": 4197
  },
  {
    "word": "owen",
    "rank": 4085,
    "frequency": 6953,
    "originalRank": 4198
  },
  {
    "word": "sacarlo",
    "rank": 4086,
    "frequency": 6952,
    "originalRank": 4199
  },
  {
    "word": "usas",
    "rank": 4087,
    "frequency": 6948,
    "originalRank": 4201
  },
  {
    "word": "letras",
    "rank": 4088,
    "frequency": 6947,
    "originalRank": 4202
  },
  {
    "word": "dennis",
    "rank": 4089,
    "frequency": 6945,
    "originalRank": 4203
  },
  {
    "word": "demasiados",
    "rank": 4090,
    "frequency": 6944,
    "originalRank": 4204
  },
  {
    "word": "éstas",
    "rank": 4091,
    "frequency": 6944,
    "originalRank": 4205
  },
  {
    "word": "interrumpir",
    "rank": 4092,
    "frequency": 6939,
    "originalRank": 4206
  },
  {
    "word": "representa",
    "rank": 4093,
    "frequency": 6937,
    "originalRank": 4207
  },
  {
    "word": "socios",
    "rank": 4094,
    "frequency": 6936,
    "originalRank": 4208
  },
  {
    "word": "pecados",
    "rank": 4095,
    "frequency": 6935,
    "originalRank": 4209
  },
  {
    "word": "novela",
    "rank": 4096,
    "frequency": 6935,
    "originalRank": 4210
  },
  {
    "word": "herramientas",
    "rank": 4097,
    "frequency": 6934,
    "originalRank": 4211
  },
  {
    "word": "desaparece",
    "rank": 4098,
    "frequency": 6930,
    "originalRank": 4212
  },
  {
    "word": "apostar",
    "rank": 4099,
    "frequency": 6929,
    "originalRank": 4213
  },
  {
    "word": "septiembre",
    "rank": 4100,
    "frequency": 6926,
    "originalRank": 4215
  },
  {
    "word": "vestidos",
    "rank": 4101,
    "frequency": 6922,
    "originalRank": 4216
  },
  {
    "word": "festival",
    "rank": 4102,
    "frequency": 6921,
    "originalRank": 4217
  },
  {
    "word": "franceses",
    "rank": 4103,
    "frequency": 6920,
    "originalRank": 4218
  },
  {
    "word": "queria",
    "rank": 4104,
    "frequency": 6919,
    "originalRank": 4219
  },
  {
    "word": "gustar",
    "rank": 4105,
    "frequency": 6917,
    "originalRank": 4220
  },
  {
    "word": "auxilio",
    "rank": 4106,
    "frequency": 6911,
    "originalRank": 4221
  },
  {
    "word": "éstos",
    "rank": 4107,
    "frequency": 6911,
    "originalRank": 4222
  },
  {
    "word": "fracaso",
    "rank": 4108,
    "frequency": 6908,
    "originalRank": 4223
  },
  {
    "word": "berlín",
    "rank": 4109,
    "frequency": 6907,
    "originalRank": 4224
  },
  {
    "word": "cañón",
    "rank": 4110,
    "frequency": 6906,
    "originalRank": 4225
  },
  {
    "word": "llegaremos",
    "rank": 4111,
    "frequency": 6906,
    "originalRank": 4226
  },
  {
    "word": "empezaron",
    "rank": 4112,
    "frequency": 6901,
    "originalRank": 4227
  },
  {
    "word": "spencer",
    "rank": 4113,
    "frequency": 6900,
    "originalRank": 4228
  },
  {
    "word": "fíjate",
    "rank": 4114,
    "frequency": 6899,
    "originalRank": 4229
  },
  {
    "word": "votar",
    "rank": 4115,
    "frequency": 6894,
    "originalRank": 4230
  },
  {
    "word": "merezco",
    "rank": 4116,
    "frequency": 6894,
    "originalRank": 4231
  },
  {
    "word": "infantil",
    "rank": 4117,
    "frequency": 6892,
    "originalRank": 4232
  },
  {
    "word": "estacionamiento",
    "rank": 4118,
    "frequency": 6892,
    "originalRank": 4233
  },
  {
    "word": "asesina",
    "rank": 4119,
    "frequency": 6892,
    "originalRank": 4234
  },
  {
    "word": "sentarte",
    "rank": 4120,
    "frequency": 6890,
    "originalRank": 4235
  },
  {
    "word": "mintió",
    "rank": 4121,
    "frequency": 6889,
    "originalRank": 4236
  },
  {
    "word": "grita",
    "rank": 4122,
    "frequency": 6889,
    "originalRank": 4237
  },
  {
    "word": "ofrecer",
    "rank": 4123,
    "frequency": 6886,
    "originalRank": 4238
  },
  {
    "word": "ruth",
    "rank": 4124,
    "frequency": 6876,
    "originalRank": 4239
  },
  {
    "word": "esclavos",
    "rank": 4125,
    "frequency": 6874,
    "originalRank": 4240
  },
  {
    "word": "academia",
    "rank": 4126,
    "frequency": 6874,
    "originalRank": 4241
  },
  {
    "word": "probarlo",
    "rank": 4127,
    "frequency": 6874,
    "originalRank": 4242
  },
  {
    "word": "viuda",
    "rank": 4128,
    "frequency": 6861,
    "originalRank": 4243
  },
  {
    "word": "reporte",
    "rank": 4129,
    "frequency": 6860,
    "originalRank": 4244
  },
  {
    "word": "monedas",
    "rank": 4130,
    "frequency": 6859,
    "originalRank": 4245
  },
  {
    "word": "rob",
    "rank": 4131,
    "frequency": 6857,
    "originalRank": 4246
  },
  {
    "word": "advertencia",
    "rank": 4132,
    "frequency": 6856,
    "originalRank": 4247
  },
  {
    "word": "jugo",
    "rank": 4133,
    "frequency": 6856,
    "originalRank": 4248
  },
  {
    "word": "malcolm",
    "rank": 4134,
    "frequency": 6855,
    "originalRank": 4249
  },
  {
    "word": "pico",
    "rank": 4135,
    "frequency": 6854,
    "originalRank": 4250
  },
  {
    "word": "miré",
    "rank": 4136,
    "frequency": 6851,
    "originalRank": 4251
  },
  {
    "word": "rota",
    "rank": 4137,
    "frequency": 6849,
    "originalRank": 4252
  },
  {
    "word": "sociales",
    "rank": 4138,
    "frequency": 6849,
    "originalRank": 4253
  },
  {
    "word": "amarillo",
    "rank": 4139,
    "frequency": 6846,
    "originalRank": 4254
  },
  {
    "word": "encargado",
    "rank": 4140,
    "frequency": 6846,
    "originalRank": 4255
  },
  {
    "word": "listas",
    "rank": 4141,
    "frequency": 6844,
    "originalRank": 4257
  },
  {
    "word": "poderosa",
    "rank": 4142,
    "frequency": 6842,
    "originalRank": 4259
  },
  {
    "word": "prometió",
    "rank": 4143,
    "frequency": 6842,
    "originalRank": 4260
  },
  {
    "word": "drama",
    "rank": 4144,
    "frequency": 6841,
    "originalRank": 4261
  },
  {
    "word": "confundido",
    "rank": 4145,
    "frequency": 6839,
    "originalRank": 4262
  },
  {
    "word": "olvídate",
    "rank": 4146,
    "frequency": 6838,
    "originalRank": 4263
  },
  {
    "word": "normales",
    "rank": 4147,
    "frequency": 6838,
    "originalRank": 4264
  },
  {
    "word": "inconsciente",
    "rank": 4148,
    "frequency": 6837,
    "originalRank": 4265
  },
  {
    "word": "asegurar",
    "rank": 4149,
    "frequency": 6836,
    "originalRank": 4266
  },
  {
    "word": "estadounidense",
    "rank": 4150,
    "frequency": 6835,
    "originalRank": 4267
  },
  {
    "word": "locales",
    "rank": 4151,
    "frequency": 6834,
    "originalRank": 4268
  },
  {
    "word": "informado",
    "rank": 4152,
    "frequency": 6833,
    "originalRank": 4269
  },
  {
    "word": "resuelto",
    "rank": 4153,
    "frequency": 6831,
    "originalRank": 4270
  },
  {
    "word": "cueva",
    "rank": 4154,
    "frequency": 6830,
    "originalRank": 4271
  },
  {
    "word": "conduciendo",
    "rank": 4155,
    "frequency": 6829,
    "originalRank": 4272
  },
  {
    "word": "perdidos",
    "rank": 4156,
    "frequency": 6828,
    "originalRank": 4273
  },
  {
    "word": "escuchó",
    "rank": 4157,
    "frequency": 6828,
    "originalRank": 4274
  },
  {
    "word": "patético",
    "rank": 4158,
    "frequency": 6827,
    "originalRank": 4275
  },
  {
    "word": "abril",
    "rank": 4159,
    "frequency": 6826,
    "originalRank": 4276
  },
  {
    "word": "matemáticas",
    "rank": 4160,
    "frequency": 6825,
    "originalRank": 4277
  },
  {
    "word": "eliminar",
    "rank": 4161,
    "frequency": 6825,
    "originalRank": 4278
  },
  {
    "word": "venid",
    "rank": 4162,
    "frequency": 6823,
    "originalRank": 4279
  },
  {
    "word": "hicieras",
    "rank": 4163,
    "frequency": 6823,
    "originalRank": 4280
  },
  {
    "word": "causar",
    "rank": 4164,
    "frequency": 6823,
    "originalRank": 4281
  },
  {
    "word": "demasiadas",
    "rank": 4165,
    "frequency": 6820,
    "originalRank": 4282
  },
  {
    "word": "vigilando",
    "rank": 4166,
    "frequency": 6819,
    "originalRank": 4283
  },
  {
    "word": "función",
    "rank": 4167,
    "frequency": 6818,
    "originalRank": 4284
  },
  {
    "word": "solar",
    "rank": 4168,
    "frequency": 6816,
    "originalRank": 4285
  },
  {
    "word": "encontrarme",
    "rank": 4169,
    "frequency": 6815,
    "originalRank": 4286
  },
  {
    "word": "williams",
    "rank": 4170,
    "frequency": 6813,
    "originalRank": 4287
  },
  {
    "word": "dólar",
    "rank": 4171,
    "frequency": 6813,
    "originalRank": 4288
  },
  {
    "word": "trucos",
    "rank": 4172,
    "frequency": 6806,
    "originalRank": 4289
  },
  {
    "word": "lectura",
    "rank": 4173,
    "frequency": 6806,
    "originalRank": 4291
  },
  {
    "word": "camarero",
    "rank": 4174,
    "frequency": 6805,
    "originalRank": 4292
  },
  {
    "word": "toman",
    "rank": 4175,
    "frequency": 6802,
    "originalRank": 4293
  },
  {
    "word": "regresaré",
    "rank": 4176,
    "frequency": 6802,
    "originalRank": 4294
  },
  {
    "word": "tiendas",
    "rank": 4177,
    "frequency": 6802,
    "originalRank": 4295
  },
  {
    "word": "encontremos",
    "rank": 4178,
    "frequency": 6801,
    "originalRank": 4296
  },
  {
    "word": "dimos",
    "rank": 4179,
    "frequency": 6798,
    "originalRank": 4297
  },
  {
    "word": "cabina",
    "rank": 4180,
    "frequency": 6798,
    "originalRank": 4298
  },
  {
    "word": "deporte",
    "rank": 4181,
    "frequency": 6795,
    "originalRank": 4299
  },
  {
    "word": "virginia",
    "rank": 4182,
    "frequency": 6790,
    "originalRank": 4300
  },
  {
    "word": "fuga",
    "rank": 4183,
    "frequency": 6786,
    "originalRank": 4301
  },
  {
    "word": "holly",
    "rank": 4184,
    "frequency": 6786,
    "originalRank": 4302
  },
  {
    "word": "sospechosos",
    "rank": 4185,
    "frequency": 6785,
    "originalRank": 4303
  },
  {
    "word": "jonathan",
    "rank": 4186,
    "frequency": 6784,
    "originalRank": 4304
  },
  {
    "word": "ala",
    "rank": 4187,
    "frequency": 6783,
    "originalRank": 4305
  },
  {
    "word": "champán",
    "rank": 4188,
    "frequency": 6783,
    "originalRank": 4306
  },
  {
    "word": "quedaba",
    "rank": 4189,
    "frequency": 6782,
    "originalRank": 4307
  },
  {
    "word": "viera",
    "rank": 4190,
    "frequency": 6776,
    "originalRank": 4308
  },
  {
    "word": "formar",
    "rank": 4191,
    "frequency": 6771,
    "originalRank": 4309
  },
  {
    "word": "walker",
    "rank": 4192,
    "frequency": 6766,
    "originalRank": 4310
  },
  {
    "word": "detectives",
    "rank": 4193,
    "frequency": 6764,
    "originalRank": 4311
  },
  {
    "word": "entenderlo",
    "rank": 4194,
    "frequency": 6759,
    "originalRank": 4312
  },
  {
    "word": "orejas",
    "rank": 4195,
    "frequency": 6759,
    "originalRank": 4313
  },
  {
    "word": "obligado",
    "rank": 4196,
    "frequency": 6759,
    "originalRank": 4314
  },
  {
    "word": "testamento",
    "rank": 4197,
    "frequency": 6757,
    "originalRank": 4315
  },
  {
    "word": "extremadamente",
    "rank": 4198,
    "frequency": 6756,
    "originalRank": 4316
  },
  {
    "word": "creyó",
    "rank": 4199,
    "frequency": 6754,
    "originalRank": 4317
  },
  {
    "word": "darán",
    "rank": 4200,
    "frequency": 6751,
    "originalRank": 4318
  },
  {
    "word": "materia",
    "rank": 4201,
    "frequency": 6748,
    "originalRank": 4319
  },
  {
    "word": "detuvo",
    "rank": 4202,
    "frequency": 6747,
    "originalRank": 4320
  },
  {
    "word": "casco",
    "rank": 4203,
    "frequency": 6746,
    "originalRank": 4321
  },
  {
    "word": "sabremos",
    "rank": 4204,
    "frequency": 6745,
    "originalRank": 4322
  },
  {
    "word": "agenda",
    "rank": 4205,
    "frequency": 6745,
    "originalRank": 4323
  },
  {
    "word": "rosas",
    "rank": 4206,
    "frequency": 6738,
    "originalRank": 4324
  },
  {
    "word": "aceptado",
    "rank": 4207,
    "frequency": 6736,
    "originalRank": 4325
  },
  {
    "word": "bello",
    "rank": 4208,
    "frequency": 6735,
    "originalRank": 4326
  },
  {
    "word": "fabuloso",
    "rank": 4209,
    "frequency": 6734,
    "originalRank": 4327
  },
  {
    "word": "llores",
    "rank": 4210,
    "frequency": 6733,
    "originalRank": 4328
  },
  {
    "word": "arruinado",
    "rank": 4211,
    "frequency": 6732,
    "originalRank": 4329
  },
  {
    "word": "enterado",
    "rank": 4212,
    "frequency": 6730,
    "originalRank": 4330
  },
  {
    "word": "junio",
    "rank": 4213,
    "frequency": 6728,
    "originalRank": 4331
  },
  {
    "word": "baila",
    "rank": 4214,
    "frequency": 6728,
    "originalRank": 4332
  },
  {
    "word": "artistas",
    "rank": 4215,
    "frequency": 6727,
    "originalRank": 4333
  },
  {
    "word": "realizar",
    "rank": 4216,
    "frequency": 6725,
    "originalRank": 4334
  },
  {
    "word": "hechizo",
    "rank": 4217,
    "frequency": 6725,
    "originalRank": 4335
  },
  {
    "word": "respiración",
    "rank": 4218,
    "frequency": 6721,
    "originalRank": 4336
  },
  {
    "word": "extremo",
    "rank": 4219,
    "frequency": 6716,
    "originalRank": 4337
  },
  {
    "word": "historial",
    "rank": 4220,
    "frequency": 6712,
    "originalRank": 4338
  },
  {
    "word": "pongan",
    "rank": 4221,
    "frequency": 6709,
    "originalRank": 4339
  },
  {
    "word": "yeah",
    "rank": 4222,
    "frequency": 6708,
    "originalRank": 4340
  },
  {
    "word": "próximos",
    "rank": 4223,
    "frequency": 6707,
    "originalRank": 4341
  },
  {
    "word": "extraordinario",
    "rank": 4224,
    "frequency": 6707,
    "originalRank": 4342
  },
  {
    "word": "tigre",
    "rank": 4225,
    "frequency": 6706,
    "originalRank": 4343
  },
  {
    "word": "fianza",
    "rank": 4226,
    "frequency": 6706,
    "originalRank": 4344
  },
  {
    "word": "consejos",
    "rank": 4227,
    "frequency": 6705,
    "originalRank": 4345
  },
  {
    "word": "mostrarte",
    "rank": 4228,
    "frequency": 6703,
    "originalRank": 4346
  },
  {
    "word": "doctores",
    "rank": 4229,
    "frequency": 6703,
    "originalRank": 4347
  },
  {
    "word": "auténtico",
    "rank": 4230,
    "frequency": 6702,
    "originalRank": 4348
  },
  {
    "word": "usamos",
    "rank": 4231,
    "frequency": 6701,
    "originalRank": 4349
  },
  {
    "word": "romance",
    "rank": 4232,
    "frequency": 6694,
    "originalRank": 4350
  },
  {
    "word": "miente",
    "rank": 4233,
    "frequency": 6691,
    "originalRank": 4351
  },
  {
    "word": "matthew",
    "rank": 4234,
    "frequency": 6680,
    "originalRank": 4352
  },
  {
    "word": "importan",
    "rank": 4235,
    "frequency": 6679,
    "originalRank": 4353
  },
  {
    "word": "paren",
    "rank": 4236,
    "frequency": 6678,
    "originalRank": 4354
  },
  {
    "word": "indio",
    "rank": 4237,
    "frequency": 6675,
    "originalRank": 4355
  },
  {
    "word": "increíblemente",
    "rank": 4238,
    "frequency": 6674,
    "originalRank": 4356
  },
  {
    "word": "pierdo",
    "rank": 4239,
    "frequency": 6670,
    "originalRank": 4357
  },
  {
    "word": "llevaremos",
    "rank": 4240,
    "frequency": 6669,
    "originalRank": 4358
  },
  {
    "word": "ofrece",
    "rank": 4241,
    "frequency": 6668,
    "originalRank": 4360
  },
  {
    "word": "seco",
    "rank": 4242,
    "frequency": 6667,
    "originalRank": 4361
  },
  {
    "word": "willie",
    "rank": 4243,
    "frequency": 6667,
    "originalRank": 4362
  },
  {
    "word": "quinn",
    "rank": 4244,
    "frequency": 6663,
    "originalRank": 4363
  },
  {
    "word": "sagrado",
    "rank": 4245,
    "frequency": 6663,
    "originalRank": 4364
  },
  {
    "word": "monte",
    "rank": 4246,
    "frequency": 6661,
    "originalRank": 4365
  },
  {
    "word": "paris",
    "rank": 4247,
    "frequency": 6661,
    "originalRank": 4366
  },
  {
    "word": "discos",
    "rank": 4248,
    "frequency": 6660,
    "originalRank": 4367
  },
  {
    "word": "louise",
    "rank": 4249,
    "frequency": 6653,
    "originalRank": 4368
  },
  {
    "word": "carrie",
    "rank": 4250,
    "frequency": 6650,
    "originalRank": 4369
  },
  {
    "word": "juguetes",
    "rank": 4251,
    "frequency": 6643,
    "originalRank": 4370
  },
  {
    "word": "cerdos",
    "rank": 4252,
    "frequency": 6642,
    "originalRank": 4371
  },
  {
    "word": "enteré",
    "rank": 4253,
    "frequency": 6642,
    "originalRank": 4372
  },
  {
    "word": "escapado",
    "rank": 4254,
    "frequency": 6640,
    "originalRank": 4373
  },
  {
    "word": "matarla",
    "rank": 4255,
    "frequency": 6638,
    "originalRank": 4374
  },
  {
    "word": "casó",
    "rank": 4256,
    "frequency": 6637,
    "originalRank": 4375
  },
  {
    "word": "ali",
    "rank": 4257,
    "frequency": 6636,
    "originalRank": 4376
  },
  {
    "word": "salgas",
    "rank": 4258,
    "frequency": 6635,
    "originalRank": 4377
  },
  {
    "word": "pasajeros",
    "rank": 4259,
    "frequency": 6632,
    "originalRank": 4378
  },
  {
    "word": "debilidad",
    "rank": 4260,
    "frequency": 6632,
    "originalRank": 4379
  },
  {
    "word": "civiles",
    "rank": 4261,
    "frequency": 6632,
    "originalRank": 4380
  },
  {
    "word": "corbata",
    "rank": 4262,
    "frequency": 6630,
    "originalRank": 4381
  },
  {
    "word": "dispuesta",
    "rank": 4263,
    "frequency": 6630,
    "originalRank": 4382
  },
  {
    "word": "necesitaré",
    "rank": 4264,
    "frequency": 6627,
    "originalRank": 4383
  },
  {
    "word": "cuartel",
    "rank": 4265,
    "frequency": 6627,
    "originalRank": 4384
  },
  {
    "word": "cazar",
    "rank": 4266,
    "frequency": 6622,
    "originalRank": 4385
  },
  {
    "word": "robando",
    "rank": 4267,
    "frequency": 6621,
    "originalRank": 4386
  },
  {
    "word": "convencer",
    "rank": 4268,
    "frequency": 6619,
    "originalRank": 4387
  },
  {
    "word": "rollo",
    "rank": 4269,
    "frequency": 6618,
    "originalRank": 4388
  },
  {
    "word": "pescar",
    "rank": 4270,
    "frequency": 6618,
    "originalRank": 4389
  },
  {
    "word": "mezcla",
    "rank": 4271,
    "frequency": 6617,
    "originalRank": 4390
  },
  {
    "word": "parejas",
    "rank": 4272,
    "frequency": 6614,
    "originalRank": 4391
  },
  {
    "word": "condicional",
    "rank": 4273,
    "frequency": 6614,
    "originalRank": 4392
  },
  {
    "word": "giro",
    "rank": 4274,
    "frequency": 6614,
    "originalRank": 4393
  },
  {
    "word": "bonitas",
    "rank": 4275,
    "frequency": 6613,
    "originalRank": 4394
  },
  {
    "word": "necesites",
    "rank": 4276,
    "frequency": 6612,
    "originalRank": 4395
  },
  {
    "word": "molestar",
    "rank": 4277,
    "frequency": 6607,
    "originalRank": 4396
  },
  {
    "word": "amantes",
    "rank": 4278,
    "frequency": 6607,
    "originalRank": 4397
  },
  {
    "word": "gris",
    "rank": 4279,
    "frequency": 6607,
    "originalRank": 4398
  },
  {
    "word": "zoe",
    "rank": 4280,
    "frequency": 6603,
    "originalRank": 4399
  },
  {
    "word": "pedimos",
    "rank": 4281,
    "frequency": 6602,
    "originalRank": 4400
  },
  {
    "word": "refuerzos",
    "rank": 4282,
    "frequency": 6600,
    "originalRank": 4401
  },
  {
    "word": "josé",
    "rank": 4283,
    "frequency": 6599,
    "originalRank": 4402
  },
  {
    "word": "colgar",
    "rank": 4284,
    "frequency": 6599,
    "originalRank": 4403
  },
  {
    "word": "heridos",
    "rank": 4285,
    "frequency": 6597,
    "originalRank": 4404
  },
  {
    "word": "arreglo",
    "rank": 4286,
    "frequency": 6597,
    "originalRank": 4405
  },
  {
    "word": "plazo",
    "rank": 4287,
    "frequency": 6595,
    "originalRank": 4406
  },
  {
    "word": "harold",
    "rank": 4288,
    "frequency": 6593,
    "originalRank": 4407
  },
  {
    "word": "salvajes",
    "rank": 4289,
    "frequency": 6592,
    "originalRank": 4408
  },
  {
    "word": "elliot",
    "rank": 4290,
    "frequency": 6592,
    "originalRank": 4409
  },
  {
    "word": "fotografías",
    "rank": 4291,
    "frequency": 6592,
    "originalRank": 4410
  },
  {
    "word": "sintió",
    "rank": 4292,
    "frequency": 6590,
    "originalRank": 4411
  },
  {
    "word": "hermosas",
    "rank": 4293,
    "frequency": 6588,
    "originalRank": 4412
  },
  {
    "word": "ashley",
    "rank": 4294,
    "frequency": 6588,
    "originalRank": 4413
  },
  {
    "word": "convertir",
    "rank": 4295,
    "frequency": 6585,
    "originalRank": 4414
  },
  {
    "word": "contarle",
    "rank": 4296,
    "frequency": 6584,
    "originalRank": 4415
  },
  {
    "word": "retiro",
    "rank": 4297,
    "frequency": 6584,
    "originalRank": 4416
  },
  {
    "word": "francis",
    "rank": 4298,
    "frequency": 6581,
    "originalRank": 4417
  },
  {
    "word": "gravedad",
    "rank": 4299,
    "frequency": 6580,
    "originalRank": 4418
  },
  {
    "word": "importe",
    "rank": 4300,
    "frequency": 6578,
    "originalRank": 4419
  },
  {
    "word": "lata",
    "rank": 4301,
    "frequency": 6577,
    "originalRank": 4420
  },
  {
    "word": "enseñaré",
    "rank": 4302,
    "frequency": 6576,
    "originalRank": 4421
  },
  {
    "word": "velas",
    "rank": 4303,
    "frequency": 6574,
    "originalRank": 4422
  },
  {
    "word": "suyos",
    "rank": 4304,
    "frequency": 6570,
    "originalRank": 4423
  },
  {
    "word": "símbolo",
    "rank": 4305,
    "frequency": 6569,
    "originalRank": 4424
  },
  {
    "word": "reconocimiento",
    "rank": 4306,
    "frequency": 6568,
    "originalRank": 4425
  },
  {
    "word": "típico",
    "rank": 4307,
    "frequency": 6568,
    "originalRank": 4426
  },
  {
    "word": "ayudas",
    "rank": 4308,
    "frequency": 6564,
    "originalRank": 4427
  },
  {
    "word": "regresado",
    "rank": 4309,
    "frequency": 6563,
    "originalRank": 4428
  },
  {
    "word": "conducta",
    "rank": 4310,
    "frequency": 6560,
    "originalRank": 4429
  },
  {
    "word": "lane",
    "rank": 4311,
    "frequency": 6560,
    "originalRank": 4430
  },
  {
    "word": "ken",
    "rank": 4312,
    "frequency": 6560,
    "originalRank": 4431
  },
  {
    "word": "participar",
    "rank": 4313,
    "frequency": 6555,
    "originalRank": 4433
  },
  {
    "word": "lana",
    "rank": 4314,
    "frequency": 6554,
    "originalRank": 4434
  },
  {
    "word": "shane",
    "rank": 4315,
    "frequency": 6553,
    "originalRank": 4435
  },
  {
    "word": "hacernos",
    "rank": 4316,
    "frequency": 6551,
    "originalRank": 4436
  },
  {
    "word": "tratan",
    "rank": 4317,
    "frequency": 6551,
    "originalRank": 4437
  },
  {
    "word": "vendedor",
    "rank": 4318,
    "frequency": 6549,
    "originalRank": 4438
  },
  {
    "word": "federales",
    "rank": 4319,
    "frequency": 6549,
    "originalRank": 4439
  },
  {
    "word": "pudiéramos",
    "rank": 4320,
    "frequency": 6544,
    "originalRank": 4440
  },
  {
    "word": "diane",
    "rank": 4321,
    "frequency": 6542,
    "originalRank": 4441
  },
  {
    "word": "estrés",
    "rank": 4322,
    "frequency": 6541,
    "originalRank": 4442
  },
  {
    "word": "césar",
    "rank": 4323,
    "frequency": 6540,
    "originalRank": 4443
  },
  {
    "word": "soltera",
    "rank": 4324,
    "frequency": 6539,
    "originalRank": 4444
  },
  {
    "word": "gustará",
    "rank": 4325,
    "frequency": 6536,
    "originalRank": 4445
  },
  {
    "word": "brujas",
    "rank": 4326,
    "frequency": 6533,
    "originalRank": 4447
  },
  {
    "word": "horario",
    "rank": 4327,
    "frequency": 6532,
    "originalRank": 4448
  },
  {
    "word": "recuerden",
    "rank": 4328,
    "frequency": 6528,
    "originalRank": 4449
  },
  {
    "word": "identificar",
    "rank": 4329,
    "frequency": 6526,
    "originalRank": 4450
  },
  {
    "word": "hill",
    "rank": 4330,
    "frequency": 6519,
    "originalRank": 4451
  },
  {
    "word": "alfombra",
    "rank": 4331,
    "frequency": 6518,
    "originalRank": 4452
  },
  {
    "word": "perdóneme",
    "rank": 4332,
    "frequency": 6518,
    "originalRank": 4453
  },
  {
    "word": "actores",
    "rank": 4333,
    "frequency": 6514,
    "originalRank": 4454
  },
  {
    "word": "atractiva",
    "rank": 4334,
    "frequency": 6512,
    "originalRank": 4455
  },
  {
    "word": "permítame",
    "rank": 4335,
    "frequency": 6509,
    "originalRank": 4456
  },
  {
    "word": "desperté",
    "rank": 4336,
    "frequency": 6505,
    "originalRank": 4457
  },
  {
    "word": "salía",
    "rank": 4337,
    "frequency": 6505,
    "originalRank": 4458
  },
  {
    "word": "recibiendo",
    "rank": 4338,
    "frequency": 6505,
    "originalRank": 4459
  },
  {
    "word": "preciso",
    "rank": 4339,
    "frequency": 6500,
    "originalRank": 4460
  },
  {
    "word": "comprendes",
    "rank": 4340,
    "frequency": 6497,
    "originalRank": 4461
  },
  {
    "word": "white",
    "rank": 4341,
    "frequency": 6495,
    "originalRank": 4462
  },
  {
    "word": "altos",
    "rank": 4342,
    "frequency": 6493,
    "originalRank": 4463
  },
  {
    "word": "fan",
    "rank": 4343,
    "frequency": 6491,
    "originalRank": 4464
  },
  {
    "word": "papas",
    "rank": 4344,
    "frequency": 6489,
    "originalRank": 4465
  },
  {
    "word": "anciano",
    "rank": 4345,
    "frequency": 6487,
    "originalRank": 4466
  },
  {
    "word": "profunda",
    "rank": 4346,
    "frequency": 6486,
    "originalRank": 4467
  },
  {
    "word": "petróleo",
    "rank": 4347,
    "frequency": 6486,
    "originalRank": 4468
  },
  {
    "word": "intenciones",
    "rank": 4348,
    "frequency": 6481,
    "originalRank": 4469
  },
  {
    "word": "francesa",
    "rank": 4349,
    "frequency": 6481,
    "originalRank": 4470
  },
  {
    "word": "neil",
    "rank": 4350,
    "frequency": 6473,
    "originalRank": 4471
  },
  {
    "word": "jin",
    "rank": 4351,
    "frequency": 6469,
    "originalRank": 4472
  },
  {
    "word": "rango",
    "rank": 4352,
    "frequency": 6468,
    "originalRank": 4473
  },
  {
    "word": "sombras",
    "rank": 4353,
    "frequency": 6465,
    "originalRank": 4474
  },
  {
    "word": "malvado",
    "rank": 4354,
    "frequency": 6463,
    "originalRank": 4475
  },
  {
    "word": "defender",
    "rank": 4355,
    "frequency": 6461,
    "originalRank": 4476
  },
  {
    "word": "lleguemos",
    "rank": 4356,
    "frequency": 6461,
    "originalRank": 4477
  },
  {
    "word": "suba",
    "rank": 4357,
    "frequency": 6459,
    "originalRank": 4478
  },
  {
    "word": "jaula",
    "rank": 4358,
    "frequency": 6458,
    "originalRank": 4479
  },
  {
    "word": "watson",
    "rank": 4359,
    "frequency": 6456,
    "originalRank": 4480
  },
  {
    "word": "natalie",
    "rank": 4360,
    "frequency": 6454,
    "originalRank": 4481
  },
  {
    "word": "comentarios",
    "rank": 4361,
    "frequency": 6448,
    "originalRank": 4482
  },
  {
    "word": "dosis",
    "rank": 4362,
    "frequency": 6448,
    "originalRank": 4483
  },
  {
    "word": "cartel",
    "rank": 4363,
    "frequency": 6445,
    "originalRank": 4484
  },
  {
    "word": "disparen",
    "rank": 4364,
    "frequency": 6444,
    "originalRank": 4485
  },
  {
    "word": "esperad",
    "rank": 4365,
    "frequency": 6442,
    "originalRank": 4486
  },
  {
    "word": "cargar",
    "rank": 4366,
    "frequency": 6442,
    "originalRank": 4487
  },
  {
    "word": "enviaron",
    "rank": 4367,
    "frequency": 6441,
    "originalRank": 4488
  },
  {
    "word": "jodida",
    "rank": 4368,
    "frequency": 6440,
    "originalRank": 4489
  },
  {
    "word": "seguí",
    "rank": 4369,
    "frequency": 6440,
    "originalRank": 4490
  },
  {
    "word": "aproximadamente",
    "rank": 4370,
    "frequency": 6437,
    "originalRank": 4491
  },
  {
    "word": "postre",
    "rank": 4371,
    "frequency": 6435,
    "originalRank": 4492
  },
  {
    "word": "escala",
    "rank": 4372,
    "frequency": 6432,
    "originalRank": 4493
  },
  {
    "word": "estudiando",
    "rank": 4373,
    "frequency": 6430,
    "originalRank": 4494
  },
  {
    "word": "pavo",
    "rank": 4374,
    "frequency": 6424,
    "originalRank": 4495
  },
  {
    "word": "origen",
    "rank": 4375,
    "frequency": 6424,
    "originalRank": 4496
  },
  {
    "word": "considerar",
    "rank": 4376,
    "frequency": 6420,
    "originalRank": 4497
  },
  {
    "word": "fiel",
    "rank": 4377,
    "frequency": 6420,
    "originalRank": 4498
  },
  {
    "word": "diego",
    "rank": 4378,
    "frequency": 6415,
    "originalRank": 4499
  },
  {
    "word": "embajador",
    "rank": 4379,
    "frequency": 6414,
    "originalRank": 4500
  },
  {
    "word": "tatuaje",
    "rank": 4380,
    "frequency": 6414,
    "originalRank": 4501
  },
  {
    "word": "población",
    "rank": 4381,
    "frequency": 6410,
    "originalRank": 4502
  },
  {
    "word": "harris",
    "rank": 4382,
    "frequency": 6409,
    "originalRank": 4503
  },
  {
    "word": "comes",
    "rank": 4383,
    "frequency": 6407,
    "originalRank": 4504
  },
  {
    "word": "llamen",
    "rank": 4384,
    "frequency": 6400,
    "originalRank": 4505
  },
  {
    "word": "horribles",
    "rank": 4385,
    "frequency": 6398,
    "originalRank": 4506
  },
  {
    "word": "vampiros",
    "rank": 4386,
    "frequency": 6395,
    "originalRank": 4507
  },
  {
    "word": "dormida",
    "rank": 4387,
    "frequency": 6393,
    "originalRank": 4508
  },
  {
    "word": "niveles",
    "rank": 4388,
    "frequency": 6392,
    "originalRank": 4509
  },
  {
    "word": "largas",
    "rank": 4389,
    "frequency": 6390,
    "originalRank": 4510
  },
  {
    "word": "pandilla",
    "rank": 4390,
    "frequency": 6385,
    "originalRank": 4511
  },
  {
    "word": "agrada",
    "rank": 4391,
    "frequency": 6384,
    "originalRank": 4512
  },
  {
    "word": "traigan",
    "rank": 4392,
    "frequency": 6381,
    "originalRank": 4513
  },
  {
    "word": "onda",
    "rank": 4393,
    "frequency": 6380,
    "originalRank": 4514
  },
  {
    "word": "atrapados",
    "rank": 4394,
    "frequency": 6379,
    "originalRank": 4515
  },
  {
    "word": "duque",
    "rank": 4395,
    "frequency": 6379,
    "originalRank": 4516
  },
  {
    "word": "bajas",
    "rank": 4396,
    "frequency": 6374,
    "originalRank": 4517
  },
  {
    "word": "dejaremos",
    "rank": 4397,
    "frequency": 6374,
    "originalRank": 4518
  },
  {
    "word": "trono",
    "rank": 4398,
    "frequency": 6371,
    "originalRank": 4520
  },
  {
    "word": "canto",
    "rank": 4399,
    "frequency": 6371,
    "originalRank": 4521
  },
  {
    "word": "aumento",
    "rank": 4400,
    "frequency": 6371,
    "originalRank": 4522
  },
  {
    "word": "esconder",
    "rank": 4401,
    "frequency": 6370,
    "originalRank": 4523
  },
  {
    "word": "políticos",
    "rank": 4402,
    "frequency": 6370,
    "originalRank": 4524
  },
  {
    "word": "muertes",
    "rank": 4403,
    "frequency": 6370,
    "originalRank": 4525
  },
  {
    "word": "anthony",
    "rank": 4404,
    "frequency": 6368,
    "originalRank": 4526
  },
  {
    "word": "pensabas",
    "rank": 4405,
    "frequency": 6367,
    "originalRank": 4527
  },
  {
    "word": "saqué",
    "rank": 4406,
    "frequency": 6367,
    "originalRank": 4528
  },
  {
    "word": "taller",
    "rank": 4407,
    "frequency": 6365,
    "originalRank": 4529
  },
  {
    "word": "fantástica",
    "rank": 4408,
    "frequency": 6364,
    "originalRank": 4530
  },
  {
    "word": "practicar",
    "rank": 4409,
    "frequency": 6361,
    "originalRank": 4531
  },
  {
    "word": "asientos",
    "rank": 4410,
    "frequency": 6361,
    "originalRank": 4532
  },
  {
    "word": "armado",
    "rank": 4411,
    "frequency": 6360,
    "originalRank": 4533
  },
  {
    "word": "gibbs",
    "rank": 4412,
    "frequency": 6359,
    "originalRank": 4534
  },
  {
    "word": "habrán",
    "rank": 4413,
    "frequency": 6359,
    "originalRank": 4535
  },
  {
    "word": "considera",
    "rank": 4414,
    "frequency": 6352,
    "originalRank": 4536
  },
  {
    "word": "atender",
    "rank": 4415,
    "frequency": 6351,
    "originalRank": 4537
  },
  {
    "word": "ponemos",
    "rank": 4416,
    "frequency": 6350,
    "originalRank": 4538
  },
  {
    "word": "consigues",
    "rank": 4417,
    "frequency": 6346,
    "originalRank": 4540
  },
  {
    "word": "sentados",
    "rank": 4418,
    "frequency": 6332,
    "originalRank": 4541
  },
  {
    "word": "costó",
    "rank": 4419,
    "frequency": 6329,
    "originalRank": 4542
  },
  {
    "word": "soñando",
    "rank": 4420,
    "frequency": 6325,
    "originalRank": 4543
  },
  {
    "word": "stanley",
    "rank": 4421,
    "frequency": 6325,
    "originalRank": 4544
  },
  {
    "word": "creó",
    "rank": 4422,
    "frequency": 6324,
    "originalRank": 4545
  },
  {
    "word": "ayúdenme",
    "rank": 4423,
    "frequency": 6323,
    "originalRank": 4546
  },
  {
    "word": "juzgado",
    "rank": 4424,
    "frequency": 6322,
    "originalRank": 4547
  },
  {
    "word": "hablarme",
    "rank": 4425,
    "frequency": 6321,
    "originalRank": 4548
  },
  {
    "word": "janet",
    "rank": 4426,
    "frequency": 6320,
    "originalRank": 4549
  },
  {
    "word": "bebido",
    "rank": 4427,
    "frequency": 6320,
    "originalRank": 4550
  },
  {
    "word": "pierdas",
    "rank": 4428,
    "frequency": 6317,
    "originalRank": 4551
  },
  {
    "word": "ponlo",
    "rank": 4429,
    "frequency": 6317,
    "originalRank": 4552
  },
  {
    "word": "gallina",
    "rank": 4430,
    "frequency": 6317,
    "originalRank": 4553
  },
  {
    "word": "miguel",
    "rank": 4431,
    "frequency": 6315,
    "originalRank": 4554
  },
  {
    "word": "octubre",
    "rank": 4432,
    "frequency": 6307,
    "originalRank": 4555
  },
  {
    "word": "sentirme",
    "rank": 4433,
    "frequency": 6304,
    "originalRank": 4556
  },
  {
    "word": "riesgos",
    "rank": 4434,
    "frequency": 6302,
    "originalRank": 4557
  },
  {
    "word": "dificil",
    "rank": 4435,
    "frequency": 6302,
    "originalRank": 4558
  },
  {
    "word": "besar",
    "rank": 4436,
    "frequency": 6302,
    "originalRank": 4559
  },
  {
    "word": "lavar",
    "rank": 4437,
    "frequency": 6299,
    "originalRank": 4560
  },
  {
    "word": "sacarte",
    "rank": 4438,
    "frequency": 6299,
    "originalRank": 4561
  },
  {
    "word": "cuyo",
    "rank": 4439,
    "frequency": 6299,
    "originalRank": 4562
  },
  {
    "word": "cayendo",
    "rank": 4440,
    "frequency": 6299,
    "originalRank": 4563
  },
  {
    "word": "emocional",
    "rank": 4441,
    "frequency": 6297,
    "originalRank": 4564
  },
  {
    "word": "prometida",
    "rank": 4442,
    "frequency": 6295,
    "originalRank": 4565
  },
  {
    "word": "molestia",
    "rank": 4443,
    "frequency": 6293,
    "originalRank": 4566
  },
  {
    "word": "christine",
    "rank": 4444,
    "frequency": 6289,
    "originalRank": 4567
  },
  {
    "word": "consiga",
    "rank": 4445,
    "frequency": 6288,
    "originalRank": 4568
  },
  {
    "word": "huella",
    "rank": 4446,
    "frequency": 6287,
    "originalRank": 4569
  },
  {
    "word": "agarra",
    "rank": 4447,
    "frequency": 6287,
    "originalRank": 4570
  },
  {
    "word": "karl",
    "rank": 4448,
    "frequency": 6284,
    "originalRank": 4571
  },
  {
    "word": "condena",
    "rank": 4449,
    "frequency": 6281,
    "originalRank": 4572
  },
  {
    "word": "decírmelo",
    "rank": 4450,
    "frequency": 6279,
    "originalRank": 4573
  },
  {
    "word": "cafetería",
    "rank": 4451,
    "frequency": 6279,
    "originalRank": 4574
  },
  {
    "word": "honesta",
    "rank": 4452,
    "frequency": 6278,
    "originalRank": 4575
  },
  {
    "word": "tómate",
    "rank": 4453,
    "frequency": 6277,
    "originalRank": 4576
  },
  {
    "word": "pablo",
    "rank": 4454,
    "frequency": 6275,
    "originalRank": 4577
  },
  {
    "word": "medidas",
    "rank": 4455,
    "frequency": 6275,
    "originalRank": 4578
  },
  {
    "word": "ofreció",
    "rank": 4456,
    "frequency": 6272,
    "originalRank": 4579
  },
  {
    "word": "dió",
    "rank": 4457,
    "frequency": 6270,
    "originalRank": 4580
  },
  {
    "word": "quizas",
    "rank": 4458,
    "frequency": 6269,
    "originalRank": 4581
  },
  {
    "word": "celosa",
    "rank": 4459,
    "frequency": 6269,
    "originalRank": 4582
  },
  {
    "word": "instinto",
    "rank": 4460,
    "frequency": 6268,
    "originalRank": 4583
  },
  {
    "word": "bancos",
    "rank": 4461,
    "frequency": 6265,
    "originalRank": 4584
  },
  {
    "word": "mías",
    "rank": 4462,
    "frequency": 6259,
    "originalRank": 4585
  },
  {
    "word": "emocionado",
    "rank": 4463,
    "frequency": 6259,
    "originalRank": 4586
  },
  {
    "word": "juguete",
    "rank": 4464,
    "frequency": 6258,
    "originalRank": 4587
  },
  {
    "word": "villa",
    "rank": 4465,
    "frequency": 6257,
    "originalRank": 4588
  },
  {
    "word": "conocida",
    "rank": 4466,
    "frequency": 6255,
    "originalRank": 4589
  },
  {
    "word": "servirá",
    "rank": 4467,
    "frequency": 6253,
    "originalRank": 4590
  },
  {
    "word": "norman",
    "rank": 4468,
    "frequency": 6252,
    "originalRank": 4591
  },
  {
    "word": "centavo",
    "rank": 4469,
    "frequency": 6250,
    "originalRank": 4592
  },
  {
    "word": "lincoln",
    "rank": 4470,
    "frequency": 6249,
    "originalRank": 4593
  },
  {
    "word": "connor",
    "rank": 4471,
    "frequency": 6248,
    "originalRank": 4594
  },
  {
    "word": "potencia",
    "rank": 4472,
    "frequency": 6246,
    "originalRank": 4595
  },
  {
    "word": "unido",
    "rank": 4473,
    "frequency": 6246,
    "originalRank": 4596
  },
  {
    "word": "julian",
    "rank": 4474,
    "frequency": 6246,
    "originalRank": 4597
  },
  {
    "word": "copias",
    "rank": 4475,
    "frequency": 6245,
    "originalRank": 4598
  },
  {
    "word": "receta",
    "rank": 4476,
    "frequency": 6242,
    "originalRank": 4599
  },
  {
    "word": "interesada",
    "rank": 4477,
    "frequency": 6242,
    "originalRank": 4600
  },
  {
    "word": "seguirá",
    "rank": 4478,
    "frequency": 6236,
    "originalRank": 4601
  },
  {
    "word": "oírme",
    "rank": 4479,
    "frequency": 6232,
    "originalRank": 4602
  },
  {
    "word": "normas",
    "rank": 4480,
    "frequency": 6230,
    "originalRank": 4603
  },
  {
    "word": "cocaína",
    "rank": 4481,
    "frequency": 6230,
    "originalRank": 4604
  },
  {
    "word": "encontrarte",
    "rank": 4482,
    "frequency": 6228,
    "originalRank": 4605
  },
  {
    "word": "cambie",
    "rank": 4483,
    "frequency": 6227,
    "originalRank": 4606
  },
  {
    "word": "asesinó",
    "rank": 4484,
    "frequency": 6226,
    "originalRank": 4607
  },
  {
    "word": "huyendo",
    "rank": 4485,
    "frequency": 6223,
    "originalRank": 4608
  },
  {
    "word": "marihuana",
    "rank": 4486,
    "frequency": 6222,
    "originalRank": 4609
  },
  {
    "word": "entramos",
    "rank": 4487,
    "frequency": 6220,
    "originalRank": 4610
  },
  {
    "word": "congreso",
    "rank": 4488,
    "frequency": 6219,
    "originalRank": 4611
  },
  {
    "word": "capa",
    "rank": 4489,
    "frequency": 6217,
    "originalRank": 4612
  },
  {
    "word": "tocó",
    "rank": 4490,
    "frequency": 6217,
    "originalRank": 4613
  },
  {
    "word": "mágico",
    "rank": 4491,
    "frequency": 6215,
    "originalRank": 4614
  },
  {
    "word": "beneficios",
    "rank": 4492,
    "frequency": 6214,
    "originalRank": 4615
  },
  {
    "word": "aburrida",
    "rank": 4493,
    "frequency": 6212,
    "originalRank": 4616
  },
  {
    "word": "invito",
    "rank": 4494,
    "frequency": 6205,
    "originalRank": 4617
  },
  {
    "word": "período",
    "rank": 4495,
    "frequency": 6200,
    "originalRank": 4618
  },
  {
    "word": "corredor",
    "rank": 4496,
    "frequency": 6199,
    "originalRank": 4619
  },
  {
    "word": "marte",
    "rank": 4497,
    "frequency": 6197,
    "originalRank": 4620
  },
  {
    "word": "ayudaría",
    "rank": 4498,
    "frequency": 6195,
    "originalRank": 4621
  },
  {
    "word": "cortado",
    "rank": 4499,
    "frequency": 6195,
    "originalRank": 4622
  },
  {
    "word": "mentiste",
    "rank": 4500,
    "frequency": 6193,
    "originalRank": 4623
  },
  {
    "word": "olvidaste",
    "rank": 4501,
    "frequency": 6190,
    "originalRank": 4624
  },
  {
    "word": "nieto",
    "rank": 4502,
    "frequency": 6188,
    "originalRank": 4625
  },
  {
    "word": "odiaba",
    "rank": 4503,
    "frequency": 6187,
    "originalRank": 4626
  },
  {
    "word": "fraude",
    "rank": 4504,
    "frequency": 6187,
    "originalRank": 4627
  },
  {
    "word": "zapato",
    "rank": 4505,
    "frequency": 6181,
    "originalRank": 4628
  },
  {
    "word": "mantenerlo",
    "rank": 4506,
    "frequency": 6181,
    "originalRank": 4629
  },
  {
    "word": "liam",
    "rank": 4507,
    "frequency": 6180,
    "originalRank": 4630
  },
  {
    "word": "tiró",
    "rank": 4508,
    "frequency": 6179,
    "originalRank": 4631
  },
  {
    "word": "sector",
    "rank": 4509,
    "frequency": 6178,
    "originalRank": 4632
  },
  {
    "word": "conseguirlo",
    "rank": 4510,
    "frequency": 6176,
    "originalRank": 4633
  },
  {
    "word": "furgoneta",
    "rank": 4511,
    "frequency": 6174,
    "originalRank": 4634
  },
  {
    "word": "causado",
    "rank": 4512,
    "frequency": 6169,
    "originalRank": 4635
  },
  {
    "word": "beneficio",
    "rank": 4513,
    "frequency": 6166,
    "originalRank": 4636
  },
  {
    "word": "querrías",
    "rank": 4514,
    "frequency": 6166,
    "originalRank": 4637
  },
  {
    "word": "graduación",
    "rank": 4515,
    "frequency": 6162,
    "originalRank": 4638
  },
  {
    "word": "alejado",
    "rank": 4516,
    "frequency": 6162,
    "originalRank": 4639
  },
  {
    "word": "junior",
    "rank": 4517,
    "frequency": 6159,
    "originalRank": 4640
  },
  {
    "word": "complejo",
    "rank": 4518,
    "frequency": 6159,
    "originalRank": 4641
  },
  {
    "word": "miraba",
    "rank": 4519,
    "frequency": 6157,
    "originalRank": 4642
  },
  {
    "word": "patas",
    "rank": 4520,
    "frequency": 6157,
    "originalRank": 4643
  },
  {
    "word": "columna",
    "rank": 4521,
    "frequency": 6155,
    "originalRank": 4644
  },
  {
    "word": "empieces",
    "rank": 4522,
    "frequency": 6154,
    "originalRank": 4645
  },
  {
    "word": "bienes",
    "rank": 4523,
    "frequency": 6154,
    "originalRank": 4646
  },
  {
    "word": "quisieras",
    "rank": 4524,
    "frequency": 6152,
    "originalRank": 4647
  },
  {
    "word": "clásico",
    "rank": 4525,
    "frequency": 6152,
    "originalRank": 4648
  },
  {
    "word": "saque",
    "rank": 4526,
    "frequency": 6151,
    "originalRank": 4649
  },
  {
    "word": "oírlo",
    "rank": 4527,
    "frequency": 6151,
    "originalRank": 4650
  },
  {
    "word": "hígado",
    "rank": 4528,
    "frequency": 6148,
    "originalRank": 4651
  },
  {
    "word": "robaste",
    "rank": 4529,
    "frequency": 6144,
    "originalRank": 4652
  },
  {
    "word": "decías",
    "rank": 4530,
    "frequency": 6143,
    "originalRank": 4653
  },
  {
    "word": "all",
    "rank": 4531,
    "frequency": 6143,
    "originalRank": 4654
  },
  {
    "word": "lleven",
    "rank": 4532,
    "frequency": 6142,
    "originalRank": 4655
  },
  {
    "word": "trabajé",
    "rank": 4533,
    "frequency": 6140,
    "originalRank": 4656
  },
  {
    "word": "muebles",
    "rank": 4534,
    "frequency": 6138,
    "originalRank": 4657
  },
  {
    "word": "actos",
    "rank": 4535,
    "frequency": 6135,
    "originalRank": 4658
  },
  {
    "word": "células",
    "rank": 4536,
    "frequency": 6130,
    "originalRank": 4659
  },
  {
    "word": "presa",
    "rank": 4537,
    "frequency": 6129,
    "originalRank": 4660
  },
  {
    "word": "hubiéramos",
    "rank": 4538,
    "frequency": 6129,
    "originalRank": 4661
  },
  {
    "word": "travis",
    "rank": 4539,
    "frequency": 6129,
    "originalRank": 4662
  },
  {
    "word": "joan",
    "rank": 4540,
    "frequency": 6123,
    "originalRank": 4663
  },
  {
    "word": "páginas",
    "rank": 4541,
    "frequency": 6122,
    "originalRank": 4664
  },
  {
    "word": "raymond",
    "rank": 4542,
    "frequency": 6122,
    "originalRank": 4665
  },
  {
    "word": "llenar",
    "rank": 4543,
    "frequency": 6120,
    "originalRank": 4666
  },
  {
    "word": "riley",
    "rank": 4544,
    "frequency": 6119,
    "originalRank": 4667
  },
  {
    "word": "cambian",
    "rank": 4545,
    "frequency": 6118,
    "originalRank": 4668
  },
  {
    "word": "sonríe",
    "rank": 4546,
    "frequency": 6116,
    "originalRank": 4669
  },
  {
    "word": "moscú",
    "rank": 4547,
    "frequency": 6116,
    "originalRank": 4670
  },
  {
    "word": "ordenó",
    "rank": 4548,
    "frequency": 6111,
    "originalRank": 4671
  },
  {
    "word": "motel",
    "rank": 4549,
    "frequency": 6111,
    "originalRank": 4673
  },
  {
    "word": "venimos",
    "rank": 4550,
    "frequency": 6110,
    "originalRank": 4674
  },
  {
    "word": "cuente",
    "rank": 4551,
    "frequency": 6109,
    "originalRank": 4675
  },
  {
    "word": "preguntes",
    "rank": 4552,
    "frequency": 6105,
    "originalRank": 4677
  },
  {
    "word": "mentido",
    "rank": 4553,
    "frequency": 6105,
    "originalRank": 4678
  },
  {
    "word": "decidimos",
    "rank": 4554,
    "frequency": 6102,
    "originalRank": 4679
  },
  {
    "word": "house",
    "rank": 4555,
    "frequency": 6100,
    "originalRank": 4680
  },
  {
    "word": "alimentos",
    "rank": 4556,
    "frequency": 6099,
    "originalRank": 4681
  },
  {
    "word": "actúa",
    "rank": 4557,
    "frequency": 6099,
    "originalRank": 4682
  },
  {
    "word": "prefieres",
    "rank": 4558,
    "frequency": 6098,
    "originalRank": 4683
  },
  {
    "word": "mason",
    "rank": 4559,
    "frequency": 6096,
    "originalRank": 4684
  },
  {
    "word": "presupuesto",
    "rank": 4560,
    "frequency": 6096,
    "originalRank": 4685
  },
  {
    "word": "prepárate",
    "rank": 4561,
    "frequency": 6094,
    "originalRank": 4686
  },
  {
    "word": "ubicación",
    "rank": 4562,
    "frequency": 6093,
    "originalRank": 4687
  },
  {
    "word": "etapa",
    "rank": 4563,
    "frequency": 6091,
    "originalRank": 4688
  },
  {
    "word": "olvidaré",
    "rank": 4564,
    "frequency": 6091,
    "originalRank": 4689
  },
  {
    "word": "trajes",
    "rank": 4565,
    "frequency": 6088,
    "originalRank": 4690
  },
  {
    "word": "santos",
    "rank": 4566,
    "frequency": 6086,
    "originalRank": 4691
  },
  {
    "word": "idioma",
    "rank": 4567,
    "frequency": 6086,
    "originalRank": 4692
  },
  {
    "word": "fruta",
    "rank": 4568,
    "frequency": 6083,
    "originalRank": 4693
  },
  {
    "word": "reconoce",
    "rank": 4569,
    "frequency": 6078,
    "originalRank": 4694
  },
  {
    "word": "vuela",
    "rank": 4570,
    "frequency": 6078,
    "originalRank": 4695
  },
  {
    "word": "ganando",
    "rank": 4571,
    "frequency": 6076,
    "originalRank": 4696
  },
  {
    "word": "bendición",
    "rank": 4572,
    "frequency": 6076,
    "originalRank": 4697
  },
  {
    "word": "luis",
    "rank": 4573,
    "frequency": 6076,
    "originalRank": 4698
  },
  {
    "word": "compasión",
    "rank": 4574,
    "frequency": 6074,
    "originalRank": 4699
  },
  {
    "word": "reconocer",
    "rank": 4575,
    "frequency": 6072,
    "originalRank": 4700
  },
  {
    "word": "desarrollo",
    "rank": 4576,
    "frequency": 6072,
    "originalRank": 4701
  },
  {
    "word": "contarte",
    "rank": 4577,
    "frequency": 6070,
    "originalRank": 4702
  },
  {
    "word": "vomitar",
    "rank": 4578,
    "frequency": 6070,
    "originalRank": 4703
  },
  {
    "word": "cazador",
    "rank": 4579,
    "frequency": 6069,
    "originalRank": 4704
  },
  {
    "word": "pesca",
    "rank": 4580,
    "frequency": 6068,
    "originalRank": 4705
  },
  {
    "word": "arco",
    "rank": 4581,
    "frequency": 6067,
    "originalRank": 4706
  },
  {
    "word": "wendy",
    "rank": 4582,
    "frequency": 6066,
    "originalRank": 4707
  },
  {
    "word": "llora",
    "rank": 4583,
    "frequency": 6065,
    "originalRank": 4708
  },
  {
    "word": "abandonó",
    "rank": 4584,
    "frequency": 6064,
    "originalRank": 4709
  },
  {
    "word": "supiste",
    "rank": 4585,
    "frequency": 6062,
    "originalRank": 4710
  },
  {
    "word": "abogada",
    "rank": 4586,
    "frequency": 6061,
    "originalRank": 4711
  },
  {
    "word": "fama",
    "rank": 4587,
    "frequency": 6060,
    "originalRank": 4712
  },
  {
    "word": "plano",
    "rank": 4588,
    "frequency": 6059,
    "originalRank": 4713
  },
  {
    "word": "elige",
    "rank": 4589,
    "frequency": 6054,
    "originalRank": 4714
  },
  {
    "word": "maíz",
    "rank": 4590,
    "frequency": 6054,
    "originalRank": 4715
  },
  {
    "word": "remedio",
    "rank": 4591,
    "frequency": 6052,
    "originalRank": 4716
  },
  {
    "word": "harta",
    "rank": 4592,
    "frequency": 6050,
    "originalRank": 4717
  },
  {
    "word": "maria",
    "rank": 4593,
    "frequency": 6047,
    "originalRank": 4718
  },
  {
    "word": "muéstrame",
    "rank": 4594,
    "frequency": 6046,
    "originalRank": 4719
  },
  {
    "word": "audrey",
    "rank": 4595,
    "frequency": 6045,
    "originalRank": 4720
  },
  {
    "word": "acostumbrado",
    "rank": 4596,
    "frequency": 6043,
    "originalRank": 4721
  },
  {
    "word": "green",
    "rank": 4597,
    "frequency": 6041,
    "originalRank": 4722
  },
  {
    "word": "leonard",
    "rank": 4598,
    "frequency": 6039,
    "originalRank": 4723
  },
  {
    "word": "disfraz",
    "rank": 4599,
    "frequency": 6035,
    "originalRank": 4724
  },
  {
    "word": "termino",
    "rank": 4600,
    "frequency": 6033,
    "originalRank": 4725
  },
  {
    "word": "hombros",
    "rank": 4601,
    "frequency": 6033,
    "originalRank": 4726
  },
  {
    "word": "química",
    "rank": 4602,
    "frequency": 6031,
    "originalRank": 4727
  },
  {
    "word": "vela",
    "rank": 4603,
    "frequency": 6031,
    "originalRank": 4728
  },
  {
    "word": "muelle",
    "rank": 4604,
    "frequency": 6029,
    "originalRank": 4729
  },
  {
    "word": "tiroteo",
    "rank": 4605,
    "frequency": 6025,
    "originalRank": 4730
  },
  {
    "word": "dirigir",
    "rank": 4606,
    "frequency": 6023,
    "originalRank": 4731
  },
  {
    "word": "enterrado",
    "rank": 4607,
    "frequency": 6022,
    "originalRank": 4732
  },
  {
    "word": "acento",
    "rank": 4608,
    "frequency": 6021,
    "originalRank": 4733
  },
  {
    "word": "psiquiatra",
    "rank": 4609,
    "frequency": 6018,
    "originalRank": 4734
  },
  {
    "word": "escoger",
    "rank": 4610,
    "frequency": 6016,
    "originalRank": 4735
  },
  {
    "word": "estupenda",
    "rank": 4611,
    "frequency": 6015,
    "originalRank": 4736
  },
  {
    "word": "canadá",
    "rank": 4612,
    "frequency": 6009,
    "originalRank": 4737
  },
  {
    "word": "indica",
    "rank": 4613,
    "frequency": 6007,
    "originalRank": 4738
  },
  {
    "word": "deudas",
    "rank": 4614,
    "frequency": 6001,
    "originalRank": 4739
  },
  {
    "word": "subiendo",
    "rank": 4615,
    "frequency": 5999,
    "originalRank": 4740
  },
  {
    "word": "bla",
    "rank": 4616,
    "frequency": 5998,
    "originalRank": 4741
  },
  {
    "word": "desayunar",
    "rank": 4617,
    "frequency": 5997,
    "originalRank": 4742
  },
  {
    "word": "tomaron",
    "rank": 4618,
    "frequency": 5994,
    "originalRank": 4743
  },
  {
    "word": "fines",
    "rank": 4619,
    "frequency": 5992,
    "originalRank": 4744
  },
  {
    "word": "espíritus",
    "rank": 4620,
    "frequency": 5991,
    "originalRank": 4745
  },
  {
    "word": "ingeniero",
    "rank": 4621,
    "frequency": 5991,
    "originalRank": 4746
  },
  {
    "word": "cráneo",
    "rank": 4622,
    "frequency": 5988,
    "originalRank": 4747
  },
  {
    "word": "desesperado",
    "rank": 4623,
    "frequency": 5987,
    "originalRank": 4748
  },
  {
    "word": "baby",
    "rank": 4624,
    "frequency": 5982,
    "originalRank": 4749
  },
  {
    "word": "separados",
    "rank": 4625,
    "frequency": 5977,
    "originalRank": 4750
  },
  {
    "word": "queja",
    "rank": 4626,
    "frequency": 5976,
    "originalRank": 4751
  },
  {
    "word": "jugada",
    "rank": 4627,
    "frequency": 5975,
    "originalRank": 4752
  },
  {
    "word": "bajando",
    "rank": 4628,
    "frequency": 5975,
    "originalRank": 4753
  },
  {
    "word": "signos",
    "rank": 4629,
    "frequency": 5974,
    "originalRank": 4754
  },
  {
    "word": "dirías",
    "rank": 4630,
    "frequency": 5973,
    "originalRank": 4755
  },
  {
    "word": "von",
    "rank": 4631,
    "frequency": 5971,
    "originalRank": 4756
  },
  {
    "word": "buscaré",
    "rank": 4632,
    "frequency": 5970,
    "originalRank": 4757
  },
  {
    "word": "comen",
    "rank": 4633,
    "frequency": 5969,
    "originalRank": 4758
  },
  {
    "word": "hong",
    "rank": 4634,
    "frequency": 5968,
    "originalRank": 4759
  },
  {
    "word": "pediré",
    "rank": 4635,
    "frequency": 5967,
    "originalRank": 4760
  },
  {
    "word": "documento",
    "rank": 4636,
    "frequency": 5967,
    "originalRank": 4761
  },
  {
    "word": "descripción",
    "rank": 4637,
    "frequency": 5966,
    "originalRank": 4762
  },
  {
    "word": "tercero",
    "rank": 4638,
    "frequency": 5965,
    "originalRank": 4763
  },
  {
    "word": "estructura",
    "rank": 4639,
    "frequency": 5965,
    "originalRank": 4764
  },
  {
    "word": "rehenes",
    "rank": 4640,
    "frequency": 5961,
    "originalRank": 4765
  },
  {
    "word": "lleguen",
    "rank": 4641,
    "frequency": 5956,
    "originalRank": 4766
  },
  {
    "word": "botellas",
    "rank": 4642,
    "frequency": 5956,
    "originalRank": 4767
  },
  {
    "word": "encuentren",
    "rank": 4643,
    "frequency": 5955,
    "originalRank": 4768
  },
  {
    "word": "bomberos",
    "rank": 4644,
    "frequency": 5953,
    "originalRank": 4769
  },
  {
    "word": "horno",
    "rank": 4645,
    "frequency": 5950,
    "originalRank": 4770
  },
  {
    "word": "préstamo",
    "rank": 4646,
    "frequency": 5947,
    "originalRank": 4771
  },
  {
    "word": "black",
    "rank": 4647,
    "frequency": 5947,
    "originalRank": 4772
  },
  {
    "word": "tratamos",
    "rank": 4648,
    "frequency": 5947,
    "originalRank": 4773
  },
  {
    "word": "autopsia",
    "rank": 4649,
    "frequency": 5942,
    "originalRank": 4774
  },
  {
    "word": "ocupados",
    "rank": 4650,
    "frequency": 5941,
    "originalRank": 4775
  },
  {
    "word": "penny",
    "rank": 4651,
    "frequency": 5941,
    "originalRank": 4776
  },
  {
    "word": "metí",
    "rank": 4652,
    "frequency": 5941,
    "originalRank": 4777
  },
  {
    "word": "pares",
    "rank": 4653,
    "frequency": 5940,
    "originalRank": 4778
  },
  {
    "word": "propietario",
    "rank": 4654,
    "frequency": 5938,
    "originalRank": 4779
  },
  {
    "word": "supieras",
    "rank": 4655,
    "frequency": 5937,
    "originalRank": 4780
  },
  {
    "word": "adecuada",
    "rank": 4656,
    "frequency": 5937,
    "originalRank": 4781
  },
  {
    "word": "cuarenta",
    "rank": 4657,
    "frequency": 5936,
    "originalRank": 4782
  },
  {
    "word": "profesión",
    "rank": 4658,
    "frequency": 5935,
    "originalRank": 4783
  },
  {
    "word": "británico",
    "rank": 4659,
    "frequency": 5934,
    "originalRank": 4784
  },
  {
    "word": "exámenes",
    "rank": 4660,
    "frequency": 5930,
    "originalRank": 4785
  },
  {
    "word": "tracy",
    "rank": 4661,
    "frequency": 5925,
    "originalRank": 4786
  },
  {
    "word": "evan",
    "rank": 4662,
    "frequency": 5921,
    "originalRank": 4787
  },
  {
    "word": "seth",
    "rank": 4663,
    "frequency": 5919,
    "originalRank": 4788
  },
  {
    "word": "moleste",
    "rank": 4664,
    "frequency": 5919,
    "originalRank": 4789
  },
  {
    "word": "agosto",
    "rank": 4665,
    "frequency": 5916,
    "originalRank": 4790
  },
  {
    "word": "logró",
    "rank": 4666,
    "frequency": 5914,
    "originalRank": 4791
  },
  {
    "word": "marchar",
    "rank": 4667,
    "frequency": 5913,
    "originalRank": 4792
  },
  {
    "word": "logan",
    "rank": 4668,
    "frequency": 5913,
    "originalRank": 4793
  },
  {
    "word": "crecido",
    "rank": 4669,
    "frequency": 5913,
    "originalRank": 4794
  },
  {
    "word": "representante",
    "rank": 4670,
    "frequency": 5911,
    "originalRank": 4795
  },
  {
    "word": "empiezas",
    "rank": 4671,
    "frequency": 5908,
    "originalRank": 4796
  },
  {
    "word": "tareas",
    "rank": 4672,
    "frequency": 5908,
    "originalRank": 4797
  },
  {
    "word": "gabriel",
    "rank": 4673,
    "frequency": 5908,
    "originalRank": 4798
  },
  {
    "word": "vodka",
    "rank": 4674,
    "frequency": 5908,
    "originalRank": 4799
  },
  {
    "word": "terribles",
    "rank": 4675,
    "frequency": 5904,
    "originalRank": 4802
  },
  {
    "word": "infeliz",
    "rank": 4676,
    "frequency": 5903,
    "originalRank": 4803
  },
  {
    "word": "enormes",
    "rank": 4677,
    "frequency": 5903,
    "originalRank": 4804
  },
  {
    "word": "geniales",
    "rank": 4678,
    "frequency": 5902,
    "originalRank": 4805
  },
  {
    "word": "generoso",
    "rank": 4679,
    "frequency": 5901,
    "originalRank": 4806
  },
  {
    "word": "brindis",
    "rank": 4680,
    "frequency": 5897,
    "originalRank": 4807
  },
  {
    "word": "rita",
    "rank": 4681,
    "frequency": 5892,
    "originalRank": 4808
  },
  {
    "word": "directa",
    "rank": 4682,
    "frequency": 5890,
    "originalRank": 4809
  },
  {
    "word": "hacéis",
    "rank": 4683,
    "frequency": 5884,
    "originalRank": 4810
  },
  {
    "word": "actualmente",
    "rank": 4684,
    "frequency": 5884,
    "originalRank": 4811
  },
  {
    "word": "rifle",
    "rank": 4685,
    "frequency": 5881,
    "originalRank": 4812
  },
  {
    "word": "casino",
    "rank": 4686,
    "frequency": 5881,
    "originalRank": 4813
  },
  {
    "word": "logro",
    "rank": 4687,
    "frequency": 5880,
    "originalRank": 4814
  },
  {
    "word": "trajeron",
    "rank": 4688,
    "frequency": 5879,
    "originalRank": 4815
  },
  {
    "word": "celos",
    "rank": 4689,
    "frequency": 5878,
    "originalRank": 4816
  },
  {
    "word": "artículos",
    "rank": 4690,
    "frequency": 5878,
    "originalRank": 4817
  },
  {
    "word": "estable",
    "rank": 4691,
    "frequency": 5878,
    "originalRank": 4818
  },
  {
    "word": "escuadrón",
    "rank": 4692,
    "frequency": 5877,
    "originalRank": 4819
  },
  {
    "word": "ciudadano",
    "rank": 4693,
    "frequency": 5875,
    "originalRank": 4820
  },
  {
    "word": "colin",
    "rank": 4694,
    "frequency": 5874,
    "originalRank": 4821
  },
  {
    "word": "sospecha",
    "rank": 4695,
    "frequency": 5871,
    "originalRank": 4822
  },
  {
    "word": "violento",
    "rank": 4696,
    "frequency": 5870,
    "originalRank": 4823
  },
  {
    "word": "engañado",
    "rank": 4697,
    "frequency": 5869,
    "originalRank": 4824
  },
  {
    "word": "relacionado",
    "rank": 4698,
    "frequency": 5868,
    "originalRank": 4825
  },
  {
    "word": "niega",
    "rank": 4699,
    "frequency": 5864,
    "originalRank": 4826
  },
  {
    "word": "vietnam",
    "rank": 4700,
    "frequency": 5862,
    "originalRank": 4827
  },
  {
    "word": "batman",
    "rank": 4701,
    "frequency": 5861,
    "originalRank": 4828
  },
  {
    "word": "vendió",
    "rank": 4702,
    "frequency": 5860,
    "originalRank": 4829
  },
  {
    "word": "ralph",
    "rank": 4703,
    "frequency": 5855,
    "originalRank": 4830
  },
  {
    "word": "chaval",
    "rank": 4704,
    "frequency": 5852,
    "originalRank": 4831
  },
  {
    "word": "macho",
    "rank": 4705,
    "frequency": 5849,
    "originalRank": 4832
  },
  {
    "word": "allison",
    "rank": 4706,
    "frequency": 5848,
    "originalRank": 4833
  },
  {
    "word": "menores",
    "rank": 4707,
    "frequency": 5846,
    "originalRank": 4834
  },
  {
    "word": "constantemente",
    "rank": 4708,
    "frequency": 5844,
    "originalRank": 4835
  },
  {
    "word": "conozca",
    "rank": 4709,
    "frequency": 5844,
    "originalRank": 4836
  },
  {
    "word": "directora",
    "rank": 4710,
    "frequency": 5837,
    "originalRank": 4837
  },
  {
    "word": "borracha",
    "rank": 4711,
    "frequency": 5836,
    "originalRank": 4838
  },
  {
    "word": "ventas",
    "rank": 4712,
    "frequency": 5836,
    "originalRank": 4839
  },
  {
    "word": "alivio",
    "rank": 4713,
    "frequency": 5836,
    "originalRank": 4840
  },
  {
    "word": "trauma",
    "rank": 4714,
    "frequency": 5834,
    "originalRank": 4841
  },
  {
    "word": "enseñarte",
    "rank": 4715,
    "frequency": 5834,
    "originalRank": 4842
  },
  {
    "word": "estadounidenses",
    "rank": 4716,
    "frequency": 5833,
    "originalRank": 4843
  },
  {
    "word": "necesidades",
    "rank": 4717,
    "frequency": 5833,
    "originalRank": 4844
  },
  {
    "word": "bart",
    "rank": 4718,
    "frequency": 5832,
    "originalRank": 4845
  },
  {
    "word": "exposición",
    "rank": 4719,
    "frequency": 5830,
    "originalRank": 4846
  },
  {
    "word": "negociar",
    "rank": 4720,
    "frequency": 5829,
    "originalRank": 4847
  },
  {
    "word": "todavia",
    "rank": 4721,
    "frequency": 5828,
    "originalRank": 4848
  },
  {
    "word": "explicarlo",
    "rank": 4722,
    "frequency": 5826,
    "originalRank": 4849
  },
  {
    "word": "copas",
    "rank": 4723,
    "frequency": 5824,
    "originalRank": 4850
  },
  {
    "word": "golpea",
    "rank": 4724,
    "frequency": 5824,
    "originalRank": 4851
  },
  {
    "word": "edificios",
    "rank": 4725,
    "frequency": 5824,
    "originalRank": 4852
  },
  {
    "word": "región",
    "rank": 4726,
    "frequency": 5823,
    "originalRank": 4853
  },
  {
    "word": "duros",
    "rank": 4727,
    "frequency": 5823,
    "originalRank": 4854
  },
  {
    "word": "moviendo",
    "rank": 4728,
    "frequency": 5821,
    "originalRank": 4855
  },
  {
    "word": "kitty",
    "rank": 4729,
    "frequency": 5820,
    "originalRank": 4856
  },
  {
    "word": "aman",
    "rank": 4730,
    "frequency": 5817,
    "originalRank": 4857
  },
  {
    "word": "kong",
    "rank": 4731,
    "frequency": 5817,
    "originalRank": 4858
  },
  {
    "word": "ford",
    "rank": 4732,
    "frequency": 5817,
    "originalRank": 4859
  },
  {
    "word": "shh",
    "rank": 4733,
    "frequency": 5816,
    "originalRank": 4860
  },
  {
    "word": "lógica",
    "rank": 4734,
    "frequency": 5815,
    "originalRank": 4861
  },
  {
    "word": "eligió",
    "rank": 4735,
    "frequency": 5813,
    "originalRank": 4862
  },
  {
    "word": "sammy",
    "rank": 4736,
    "frequency": 5808,
    "originalRank": 4863
  },
  {
    "word": "sangrando",
    "rank": 4737,
    "frequency": 5806,
    "originalRank": 4864
  },
  {
    "word": "jefes",
    "rank": 4738,
    "frequency": 5805,
    "originalRank": 4865
  },
  {
    "word": "comió",
    "rank": 4739,
    "frequency": 5804,
    "originalRank": 4866
  },
  {
    "word": "traducido",
    "rank": 4740,
    "frequency": 5803,
    "originalRank": 4867
  },
  {
    "word": "narices",
    "rank": 4741,
    "frequency": 5803,
    "originalRank": 4868
  },
  {
    "word": "deberes",
    "rank": 4742,
    "frequency": 5802,
    "originalRank": 4869
  },
  {
    "word": "grito",
    "rank": 4743,
    "frequency": 5800,
    "originalRank": 4870
  },
  {
    "word": "empresas",
    "rank": 4744,
    "frequency": 5800,
    "originalRank": 4871
  },
  {
    "word": "contactos",
    "rank": 4745,
    "frequency": 5796,
    "originalRank": 4872
  },
  {
    "word": "engaño",
    "rank": 4746,
    "frequency": 5796,
    "originalRank": 4873
  },
  {
    "word": "acusación",
    "rank": 4747,
    "frequency": 5795,
    "originalRank": 4874
  },
  {
    "word": "cirujano",
    "rank": 4748,
    "frequency": 5795,
    "originalRank": 4875
  },
  {
    "word": "pagando",
    "rank": 4749,
    "frequency": 5795,
    "originalRank": 4876
  },
  {
    "word": "cenizas",
    "rank": 4750,
    "frequency": 5794,
    "originalRank": 4877
  },
  {
    "word": "retraso",
    "rank": 4751,
    "frequency": 5793,
    "originalRank": 4878
  },
  {
    "word": "asesinar",
    "rank": 4752,
    "frequency": 5788,
    "originalRank": 4879
  },
  {
    "word": "mentí",
    "rank": 4753,
    "frequency": 5788,
    "originalRank": 4880
  },
  {
    "word": "imaginas",
    "rank": 4754,
    "frequency": 5787,
    "originalRank": 4881
  },
  {
    "word": "haciéndolo",
    "rank": 4755,
    "frequency": 5786,
    "originalRank": 4882
  },
  {
    "word": "ocurriendo",
    "rank": 4756,
    "frequency": 5786,
    "originalRank": 4883
  },
  {
    "word": "pechos",
    "rank": 4757,
    "frequency": 5785,
    "originalRank": 4884
  },
  {
    "word": "solicitud",
    "rank": 4758,
    "frequency": 5785,
    "originalRank": 4885
  },
  {
    "word": "enfermedades",
    "rank": 4759,
    "frequency": 5783,
    "originalRank": 4886
  },
  {
    "word": "soporto",
    "rank": 4760,
    "frequency": 5783,
    "originalRank": 4887
  },
  {
    "word": "buscarla",
    "rank": 4761,
    "frequency": 5782,
    "originalRank": 4888
  },
  {
    "word": "mona",
    "rank": 4762,
    "frequency": 5776,
    "originalRank": 4889
  },
  {
    "word": "fresca",
    "rank": 4763,
    "frequency": 5776,
    "originalRank": 4890
  },
  {
    "word": "prioridad",
    "rank": 4764,
    "frequency": 5773,
    "originalRank": 4891
  },
  {
    "word": "mentes",
    "rank": 4765,
    "frequency": 5771,
    "originalRank": 4892
  },
  {
    "word": "francos",
    "rank": 4766,
    "frequency": 5770,
    "originalRank": 4893
  },
  {
    "word": "rumor",
    "rank": 4767,
    "frequency": 5769,
    "originalRank": 4894
  },
  {
    "word": "confías",
    "rank": 4768,
    "frequency": 5767,
    "originalRank": 4895
  },
  {
    "word": "dibujo",
    "rank": 4769,
    "frequency": 5767,
    "originalRank": 4896
  },
  {
    "word": "saliste",
    "rank": 4770,
    "frequency": 5763,
    "originalRank": 4897
  },
  {
    "word": "contaste",
    "rank": 4771,
    "frequency": 5763,
    "originalRank": 4898
  },
  {
    "word": "buscarte",
    "rank": 4772,
    "frequency": 5763,
    "originalRank": 4899
  },
  {
    "word": "prefiere",
    "rank": 4773,
    "frequency": 5762,
    "originalRank": 4900
  },
  {
    "word": "almirante",
    "rank": 4774,
    "frequency": 5762,
    "originalRank": 4901
  },
  {
    "word": "gastar",
    "rank": 4775,
    "frequency": 5761,
    "originalRank": 4902
  },
  {
    "word": "vendrás",
    "rank": 4776,
    "frequency": 5759,
    "originalRank": 4903
  },
  {
    "word": "use",
    "rank": 4777,
    "frequency": 5758,
    "originalRank": 4904
  },
  {
    "word": "craig",
    "rank": 4778,
    "frequency": 5758,
    "originalRank": 4905
  },
  {
    "word": "warren",
    "rank": 4779,
    "frequency": 5756,
    "originalRank": 4906
  },
  {
    "word": "conjunto",
    "rank": 4780,
    "frequency": 5756,
    "originalRank": 4907
  },
  {
    "word": "profesionales",
    "rank": 4781,
    "frequency": 5753,
    "originalRank": 4908
  },
  {
    "word": "ciertos",
    "rank": 4782,
    "frequency": 5753,
    "originalRank": 4909
  },
  {
    "word": "verdes",
    "rank": 4783,
    "frequency": 5753,
    "originalRank": 4910
  },
  {
    "word": "invitó",
    "rank": 4784,
    "frequency": 5752,
    "originalRank": 4911
  },
  {
    "word": "alumnos",
    "rank": 4785,
    "frequency": 5752,
    "originalRank": 4912
  },
  {
    "word": "presentó",
    "rank": 4786,
    "frequency": 5751,
    "originalRank": 4913
  },
  {
    "word": "informar",
    "rank": 4787,
    "frequency": 5751,
    "originalRank": 4914
  },
  {
    "word": "cortó",
    "rank": 4788,
    "frequency": 5750,
    "originalRank": 4915
  },
  {
    "word": "maya",
    "rank": 4789,
    "frequency": 5750,
    "originalRank": 4916
  },
  {
    "word": "apagar",
    "rank": 4790,
    "frequency": 5749,
    "originalRank": 4917
  },
  {
    "word": "malditas",
    "rank": 4791,
    "frequency": 5749,
    "originalRank": 4918
  },
  {
    "word": "harían",
    "rank": 4792,
    "frequency": 5746,
    "originalRank": 4919
  },
  {
    "word": "nelson",
    "rank": 4793,
    "frequency": 5745,
    "originalRank": 4920
  },
  {
    "word": "besos",
    "rank": 4794,
    "frequency": 5745,
    "originalRank": 4921
  },
  {
    "word": "graciosa",
    "rank": 4795,
    "frequency": 5744,
    "originalRank": 4922
  },
  {
    "word": "chinos",
    "rank": 4796,
    "frequency": 5744,
    "originalRank": 4923
  },
  {
    "word": "noviembre",
    "rank": 4797,
    "frequency": 5744,
    "originalRank": 4924
  },
  {
    "word": "invisible",
    "rank": 4798,
    "frequency": 5743,
    "originalRank": 4925
  },
  {
    "word": "contarme",
    "rank": 4799,
    "frequency": 5742,
    "originalRank": 4926
  },
  {
    "word": "economía",
    "rank": 4800,
    "frequency": 5742,
    "originalRank": 4927
  },
  {
    "word": "logramos",
    "rank": 4801,
    "frequency": 5738,
    "originalRank": 4928
  },
  {
    "word": "combinación",
    "rank": 4802,
    "frequency": 5736,
    "originalRank": 4929
  },
  {
    "word": "enfermos",
    "rank": 4803,
    "frequency": 5735,
    "originalRank": 4930
  },
  {
    "word": "conectado",
    "rank": 4804,
    "frequency": 5733,
    "originalRank": 4931
  },
  {
    "word": "sucederá",
    "rank": 4805,
    "frequency": 5733,
    "originalRank": 4932
  },
  {
    "word": "asumir",
    "rank": 4806,
    "frequency": 5731,
    "originalRank": 4933
  },
  {
    "word": "rusa",
    "rank": 4807,
    "frequency": 5721,
    "originalRank": 4934
  },
  {
    "word": "habitual",
    "rank": 4808,
    "frequency": 5718,
    "originalRank": 4935
  },
  {
    "word": "posesión",
    "rank": 4809,
    "frequency": 5716,
    "originalRank": 4937
  },
  {
    "word": "inténtalo",
    "rank": 4810,
    "frequency": 5714,
    "originalRank": 4938
  },
  {
    "word": "ministerio",
    "rank": 4811,
    "frequency": 5714,
    "originalRank": 4939
  },
  {
    "word": "saludable",
    "rank": 4812,
    "frequency": 5712,
    "originalRank": 4940
  },
  {
    "word": "firmado",
    "rank": 4813,
    "frequency": 5711,
    "originalRank": 4941
  },
  {
    "word": "oreja",
    "rank": 4814,
    "frequency": 5710,
    "originalRank": 4942
  },
  {
    "word": "calientes",
    "rank": 4815,
    "frequency": 5709,
    "originalRank": 4943
  },
  {
    "word": "personajes",
    "rank": 4816,
    "frequency": 5708,
    "originalRank": 4944
  },
  {
    "word": "liberar",
    "rank": 4817,
    "frequency": 5708,
    "originalRank": 4945
  },
  {
    "word": "cogió",
    "rank": 4818,
    "frequency": 5707,
    "originalRank": 4946
  },
  {
    "word": "toro",
    "rank": 4819,
    "frequency": 5707,
    "originalRank": 4947
  },
  {
    "word": "pintar",
    "rank": 4820,
    "frequency": 5705,
    "originalRank": 4948
  },
  {
    "word": "eternidad",
    "rank": 4821,
    "frequency": 5705,
    "originalRank": 4949
  },
  {
    "word": "similar",
    "rank": 4822,
    "frequency": 5704,
    "originalRank": 4950
  },
  {
    "word": "sobrina",
    "rank": 4823,
    "frequency": 5702,
    "originalRank": 4951
  },
  {
    "word": "tortura",
    "rank": 4824,
    "frequency": 5701,
    "originalRank": 4952
  },
  {
    "word": "máxima",
    "rank": 4825,
    "frequency": 5700,
    "originalRank": 4953
  },
  {
    "word": "franco",
    "rank": 4826,
    "frequency": 5699,
    "originalRank": 4954
  },
  {
    "word": "earl",
    "rank": 4827,
    "frequency": 5698,
    "originalRank": 4955
  },
  {
    "word": "raras",
    "rank": 4828,
    "frequency": 5696,
    "originalRank": 4956
  },
  {
    "word": "paige",
    "rank": 4829,
    "frequency": 5696,
    "originalRank": 4957
  },
  {
    "word": "espérame",
    "rank": 4830,
    "frequency": 5695,
    "originalRank": 4958
  },
  {
    "word": "nene",
    "rank": 4831,
    "frequency": 5691,
    "originalRank": 4959
  },
  {
    "word": "deportes",
    "rank": 4832,
    "frequency": 5691,
    "originalRank": 4960
  },
  {
    "word": "sígueme",
    "rank": 4833,
    "frequency": 5689,
    "originalRank": 4961
  },
  {
    "word": "sra",
    "rank": 4834,
    "frequency": 5687,
    "originalRank": 4962
  },
  {
    "word": "pulmones",
    "rank": 4835,
    "frequency": 5687,
    "originalRank": 4963
  },
  {
    "word": "cuánta",
    "rank": 4836,
    "frequency": 5685,
    "originalRank": 4964
  },
  {
    "word": "necesitaremos",
    "rank": 4837,
    "frequency": 5684,
    "originalRank": 4965
  },
  {
    "word": "isabel",
    "rank": 4838,
    "frequency": 5682,
    "originalRank": 4966
  },
  {
    "word": "acabará",
    "rank": 4839,
    "frequency": 5680,
    "originalRank": 4967
  },
  {
    "word": "manzanas",
    "rank": 4840,
    "frequency": 5679,
    "originalRank": 4968
  },
  {
    "word": "ratón",
    "rank": 4841,
    "frequency": 5679,
    "originalRank": 4969
  },
  {
    "word": "eléctrica",
    "rank": 4842,
    "frequency": 5676,
    "originalRank": 4970
  },
  {
    "word": "productor",
    "rank": 4843,
    "frequency": 5675,
    "originalRank": 4972
  },
  {
    "word": "quédense",
    "rank": 4844,
    "frequency": 5674,
    "originalRank": 4973
  },
  {
    "word": "demuestra",
    "rank": 4845,
    "frequency": 5673,
    "originalRank": 4974
  },
  {
    "word": "lauren",
    "rank": 4846,
    "frequency": 5672,
    "originalRank": 4975
  },
  {
    "word": "eventos",
    "rank": 4847,
    "frequency": 5671,
    "originalRank": 4976
  },
  {
    "word": "entendiste",
    "rank": 4848,
    "frequency": 5668,
    "originalRank": 4977
  },
  {
    "word": "reciente",
    "rank": 4849,
    "frequency": 5665,
    "originalRank": 4979
  },
  {
    "word": "empiezan",
    "rank": 4850,
    "frequency": 5665,
    "originalRank": 4980
  },
  {
    "word": "pasaste",
    "rank": 4851,
    "frequency": 5664,
    "originalRank": 4981
  },
  {
    "word": "enfrentar",
    "rank": 4852,
    "frequency": 5663,
    "originalRank": 4982
  },
  {
    "word": "dejaba",
    "rank": 4853,
    "frequency": 5663,
    "originalRank": 4983
  },
  {
    "word": "escucharme",
    "rank": 4854,
    "frequency": 5659,
    "originalRank": 4984
  },
  {
    "word": "apariencia",
    "rank": 4855,
    "frequency": 5657,
    "originalRank": 4985
  },
  {
    "word": "aves",
    "rank": 4856,
    "frequency": 5657,
    "originalRank": 4986
  },
  {
    "word": "radiación",
    "rank": 4857,
    "frequency": 5657,
    "originalRank": 4987
  },
  {
    "word": "advierto",
    "rank": 4858,
    "frequency": 5656,
    "originalRank": 4988
  },
  {
    "word": "quemado",
    "rank": 4859,
    "frequency": 5654,
    "originalRank": 4989
  },
  {
    "word": "corea",
    "rank": 4860,
    "frequency": 5654,
    "originalRank": 4990
  },
  {
    "word": "sandy",
    "rank": 4861,
    "frequency": 5653,
    "originalRank": 4991
  },
  {
    "word": "síntomas",
    "rank": 4862,
    "frequency": 5652,
    "originalRank": 4992
  },
  {
    "word": "japoneses",
    "rank": 4863,
    "frequency": 5652,
    "originalRank": 4993
  },
  {
    "word": "kurt",
    "rank": 4864,
    "frequency": 5650,
    "originalRank": 4994
  },
  {
    "word": "juzgar",
    "rank": 4865,
    "frequency": 5644,
    "originalRank": 4995
  },
  {
    "word": "adrian",
    "rank": 4866,
    "frequency": 5644,
    "originalRank": 4996
  },
  {
    "word": "cervezas",
    "rank": 4867,
    "frequency": 5643,
    "originalRank": 4997
  },
  {
    "word": "quemar",
    "rank": 4868,
    "frequency": 5642,
    "originalRank": 4998
  },
  {
    "word": "kent",
    "rank": 4869,
    "frequency": 5641,
    "originalRank": 4999
  },
  {
    "word": "marzo",
    "rank": 4870,
    "frequency": 5639,
    "originalRank": 5000
  },
  {
    "word": "meterme",
    "rank": 4871,
    "frequency": 5639,
    "originalRank": 5001
  },
  {
    "word": "cuarta",
    "rank": 4872,
    "frequency": 5638,
    "originalRank": 5002
  },
  {
    "word": "gatillo",
    "rank": 4873,
    "frequency": 5635,
    "originalRank": 5003
  },
  {
    "word": "azar",
    "rank": 4874,
    "frequency": 5635,
    "originalRank": 5004
  },
  {
    "word": "soledad",
    "rank": 4875,
    "frequency": 5635,
    "originalRank": 5005
  },
  {
    "word": "vera",
    "rank": 4876,
    "frequency": 5634,
    "originalRank": 5006
  },
  {
    "word": "método",
    "rank": 4877,
    "frequency": 5634,
    "originalRank": 5007
  },
  {
    "word": "creciendo",
    "rank": 4878,
    "frequency": 5634,
    "originalRank": 5008
  },
  {
    "word": "amenazas",
    "rank": 4879,
    "frequency": 5634,
    "originalRank": 5009
  },
  {
    "word": "alfa",
    "rank": 4880,
    "frequency": 5633,
    "originalRank": 5010
  },
  {
    "word": "afecta",
    "rank": 4881,
    "frequency": 5633,
    "originalRank": 5011
  },
  {
    "word": "alguacil",
    "rank": 4882,
    "frequency": 5633,
    "originalRank": 5012
  },
  {
    "word": "jugado",
    "rank": 4883,
    "frequency": 5631,
    "originalRank": 5013
  },
  {
    "word": "excepción",
    "rank": 4884,
    "frequency": 5630,
    "originalRank": 5014
  },
  {
    "word": "dignidad",
    "rank": 4885,
    "frequency": 5628,
    "originalRank": 5015
  },
  {
    "word": "graves",
    "rank": 4886,
    "frequency": 5628,
    "originalRank": 5016
  },
  {
    "word": "riendo",
    "rank": 4887,
    "frequency": 5627,
    "originalRank": 5017
  },
  {
    "word": "aaron",
    "rank": 4888,
    "frequency": 5623,
    "originalRank": 5018
  },
  {
    "word": "pasear",
    "rank": 4889,
    "frequency": 5623,
    "originalRank": 5019
  },
  {
    "word": "autorización",
    "rank": 4890,
    "frequency": 5622,
    "originalRank": 5020
  },
  {
    "word": "concepto",
    "rank": 4891,
    "frequency": 5618,
    "originalRank": 5021
  },
  {
    "word": "enseñado",
    "rank": 4892,
    "frequency": 5618,
    "originalRank": 5022
  },
  {
    "word": "molestes",
    "rank": 4893,
    "frequency": 5617,
    "originalRank": 5023
  },
  {
    "word": "volvieron",
    "rank": 4894,
    "frequency": 5617,
    "originalRank": 5024
  },
  {
    "word": "llevaría",
    "rank": 4895,
    "frequency": 5614,
    "originalRank": 5025
  },
  {
    "word": "pato",
    "rank": 4896,
    "frequency": 5613,
    "originalRank": 5026
  },
  {
    "word": "duncan",
    "rank": 4897,
    "frequency": 5612,
    "originalRank": 5027
  },
  {
    "word": "padrino",
    "rank": 4898,
    "frequency": 5612,
    "originalRank": 5028
  },
  {
    "word": "vigila",
    "rank": 4899,
    "frequency": 5612,
    "originalRank": 5029
  },
  {
    "word": "generalmente",
    "rank": 4900,
    "frequency": 5610,
    "originalRank": 5030
  },
  {
    "word": "quedando",
    "rank": 4901,
    "frequency": 5609,
    "originalRank": 5031
  },
  {
    "word": "numero",
    "rank": 4902,
    "frequency": 5609,
    "originalRank": 5032
  },
  {
    "word": "permiten",
    "rank": 4903,
    "frequency": 5602,
    "originalRank": 5033
  },
  {
    "word": "bebo",
    "rank": 4904,
    "frequency": 5601,
    "originalRank": 5034
  },
  {
    "word": "contratar",
    "rank": 4905,
    "frequency": 5600,
    "originalRank": 5035
  },
  {
    "word": "pides",
    "rank": 4906,
    "frequency": 5600,
    "originalRank": 5036
  },
  {
    "word": "administración",
    "rank": 4907,
    "frequency": 5599,
    "originalRank": 5037
  },
  {
    "word": "continúe",
    "rank": 4908,
    "frequency": 5595,
    "originalRank": 5038
  },
  {
    "word": "eli",
    "rank": 4909,
    "frequency": 5592,
    "originalRank": 5039
  },
  {
    "word": "case",
    "rank": 4910,
    "frequency": 5591,
    "originalRank": 5040
  },
  {
    "word": "inusual",
    "rank": 4911,
    "frequency": 5584,
    "originalRank": 5041
  },
  {
    "word": "feria",
    "rank": 4912,
    "frequency": 5580,
    "originalRank": 5042
  },
  {
    "word": "mancha",
    "rank": 4913,
    "frequency": 5578,
    "originalRank": 5043
  },
  {
    "word": "leal",
    "rank": 4914,
    "frequency": 5578,
    "originalRank": 5044
  },
  {
    "word": "transmisión",
    "rank": 4915,
    "frequency": 5577,
    "originalRank": 5045
  },
  {
    "word": "tranquilízate",
    "rank": 4916,
    "frequency": 5576,
    "originalRank": 5046
  },
  {
    "word": "asociación",
    "rank": 4917,
    "frequency": 5576,
    "originalRank": 5047
  },
  {
    "word": "corran",
    "rank": 4918,
    "frequency": 5574,
    "originalRank": 5048
  },
  {
    "word": "seguiremos",
    "rank": 4919,
    "frequency": 5574,
    "originalRank": 5049
  },
  {
    "word": "parto",
    "rank": 4920,
    "frequency": 5573,
    "originalRank": 5050
  },
  {
    "word": "pegado",
    "rank": 4921,
    "frequency": 5573,
    "originalRank": 5051
  },
  {
    "word": "estarían",
    "rank": 4922,
    "frequency": 5571,
    "originalRank": 5052
  },
  {
    "word": "mafia",
    "rank": 4923,
    "frequency": 5562,
    "originalRank": 5053
  },
  {
    "word": "poesía",
    "rank": 4924,
    "frequency": 5561,
    "originalRank": 5054
  },
  {
    "word": "preocupados",
    "rank": 4925,
    "frequency": 5559,
    "originalRank": 5055
  },
  {
    "word": "intercambio",
    "rank": 4926,
    "frequency": 5558,
    "originalRank": 5056
  },
  {
    "word": "mel",
    "rank": 4927,
    "frequency": 5557,
    "originalRank": 5057
  },
  {
    "word": "constante",
    "rank": 4928,
    "frequency": 5553,
    "originalRank": 5058
  },
  {
    "word": "selva",
    "rank": 4929,
    "frequency": 5551,
    "originalRank": 5059
  },
  {
    "word": "mostró",
    "rank": 4930,
    "frequency": 5547,
    "originalRank": 5060
  },
  {
    "word": "jenna",
    "rank": 4931,
    "frequency": 5546,
    "originalRank": 5061
  },
  {
    "word": "juegas",
    "rank": 4932,
    "frequency": 5543,
    "originalRank": 5062
  },
  {
    "word": "contrató",
    "rank": 4933,
    "frequency": 5542,
    "originalRank": 5063
  },
  {
    "word": "sintiendo",
    "rank": 4934,
    "frequency": 5540,
    "originalRank": 5064
  },
  {
    "word": "gane",
    "rank": 4935,
    "frequency": 5539,
    "originalRank": 5065
  },
  {
    "word": "aprende",
    "rank": 4936,
    "frequency": 5538,
    "originalRank": 5066
  },
  {
    "word": "presentimiento",
    "rank": 4937,
    "frequency": 5538,
    "originalRank": 5067
  },
  {
    "word": "fuentes",
    "rank": 4938,
    "frequency": 5538,
    "originalRank": 5068
  },
  {
    "word": "protegerte",
    "rank": 4939,
    "frequency": 5537,
    "originalRank": 5069
  },
  {
    "word": "raíces",
    "rank": 4940,
    "frequency": 5536,
    "originalRank": 5070
  },
  {
    "word": "meterte",
    "rank": 4941,
    "frequency": 5535,
    "originalRank": 5071
  },
  {
    "word": "nicole",
    "rank": 4942,
    "frequency": 5532,
    "originalRank": 5072
  },
  {
    "word": "perspectiva",
    "rank": 4943,
    "frequency": 5531,
    "originalRank": 5073
  },
  {
    "word": "escolar",
    "rank": 4944,
    "frequency": 5530,
    "originalRank": 5074
  },
  {
    "word": "digno",
    "rank": 4945,
    "frequency": 5529,
    "originalRank": 5075
  },
  {
    "word": "shock",
    "rank": 4946,
    "frequency": 5528,
    "originalRank": 5076
  },
  {
    "word": "heather",
    "rank": 4947,
    "frequency": 5528,
    "originalRank": 5077
  },
  {
    "word": "bastardos",
    "rank": 4948,
    "frequency": 5528,
    "originalRank": 5078
  },
  {
    "word": "quinto",
    "rank": 4949,
    "frequency": 5524,
    "originalRank": 5079
  },
  {
    "word": "for",
    "rank": 4950,
    "frequency": 5523,
    "originalRank": 5080
  },
  {
    "word": "soportarlo",
    "rank": 4951,
    "frequency": 5522,
    "originalRank": 5081
  },
  {
    "word": "star",
    "rank": 4952,
    "frequency": 5522,
    "originalRank": 5082
  },
  {
    "word": "your",
    "rank": 4953,
    "frequency": 5521,
    "originalRank": 5083
  },
  {
    "word": "campana",
    "rank": 4954,
    "frequency": 5521,
    "originalRank": 5084
  },
  {
    "word": "juramento",
    "rank": 4955,
    "frequency": 5520,
    "originalRank": 5085
  },
  {
    "word": "matarán",
    "rank": 4956,
    "frequency": 5519,
    "originalRank": 5086
  },
  {
    "word": "mitchell",
    "rank": 4957,
    "frequency": 5518,
    "originalRank": 5087
  },
  {
    "word": "utiliza",
    "rank": 4958,
    "frequency": 5516,
    "originalRank": 5088
  },
  {
    "word": "ronnie",
    "rank": 4959,
    "frequency": 5516,
    "originalRank": 5089
  },
  {
    "word": "ilusión",
    "rank": 4960,
    "frequency": 5513,
    "originalRank": 5090
  },
  {
    "word": "vencer",
    "rank": 4961,
    "frequency": 5512,
    "originalRank": 5091
  },
  {
    "word": "rezar",
    "rank": 4962,
    "frequency": 5512,
    "originalRank": 5092
  },
  {
    "word": "hoyo",
    "rank": 4963,
    "frequency": 5510,
    "originalRank": 5093
  },
  {
    "word": "tristeza",
    "rank": 4964,
    "frequency": 5510,
    "originalRank": 5094
  },
  {
    "word": "miró",
    "rank": 4965,
    "frequency": 5509,
    "originalRank": 5095
  },
  {
    "word": "pases",
    "rank": 4966,
    "frequency": 5508,
    "originalRank": 5096
  },
  {
    "word": "dolores",
    "rank": 4967,
    "frequency": 5507,
    "originalRank": 5097
  },
  {
    "word": "sigas",
    "rank": 4968,
    "frequency": 5506,
    "originalRank": 5098
  },
  {
    "word": "doloroso",
    "rank": 4969,
    "frequency": 5503,
    "originalRank": 5099
  },
  {
    "word": "love",
    "rank": 4970,
    "frequency": 5501,
    "originalRank": 5100
  },
  {
    "word": "debbie",
    "rank": 4971,
    "frequency": 5496,
    "originalRank": 5101
  },
  {
    "word": "equivoqué",
    "rank": 4972,
    "frequency": 5496,
    "originalRank": 5102
  },
  {
    "word": "cuidando",
    "rank": 4973,
    "frequency": 5496,
    "originalRank": 5103
  },
  {
    "word": "medicamentos",
    "rank": 4974,
    "frequency": 5494,
    "originalRank": 5104
  },
  {
    "word": "ocuparé",
    "rank": 4975,
    "frequency": 5493,
    "originalRank": 5105
  },
  {
    "word": "bandas",
    "rank": 4976,
    "frequency": 5493,
    "originalRank": 5106
  },
  {
    "word": "harper",
    "rank": 4977,
    "frequency": 5492,
    "originalRank": 5107
  },
  {
    "word": "protocolo",
    "rank": 4978,
    "frequency": 5492,
    "originalRank": 5108
  },
  {
    "word": "unirse",
    "rank": 4979,
    "frequency": 5490,
    "originalRank": 5109
  },
  {
    "word": "vosotras",
    "rank": 4980,
    "frequency": 5489,
    "originalRank": 5110
  },
  {
    "word": "sufriendo",
    "rank": 4981,
    "frequency": 5489,
    "originalRank": 5111
  },
  {
    "word": "tomaremos",
    "rank": 4982,
    "frequency": 5487,
    "originalRank": 5112
  },
  {
    "word": "otoño",
    "rank": 4983,
    "frequency": 5484,
    "originalRank": 5113
  },
  {
    "word": "estatal",
    "rank": 4984,
    "frequency": 5483,
    "originalRank": 5114
  },
  {
    "word": "candidato",
    "rank": 4985,
    "frequency": 5481,
    "originalRank": 5115
  },
  {
    "word": "vencido",
    "rank": 4986,
    "frequency": 5479,
    "originalRank": 5116
  },
  {
    "word": "autor",
    "rank": 4987,
    "frequency": 5479,
    "originalRank": 5117
  },
  {
    "word": "aérea",
    "rank": 4988,
    "frequency": 5479,
    "originalRank": 5118
  },
  {
    "word": "usaba",
    "rank": 4989,
    "frequency": 5479,
    "originalRank": 5119
  },
  {
    "word": "comprende",
    "rank": 4990,
    "frequency": 5478,
    "originalRank": 5120
  },
  {
    "word": "polla",
    "rank": 4991,
    "frequency": 5475,
    "originalRank": 5121
  },
  {
    "word": "huelga",
    "rank": 4992,
    "frequency": 5474,
    "originalRank": 5122
  },
  {
    "word": "rabia",
    "rank": 4993,
    "frequency": 5473,
    "originalRank": 5123
  },
  {
    "word": "agujeros",
    "rank": 4994,
    "frequency": 5472,
    "originalRank": 5124
  },
  {
    "word": "estuviese",
    "rank": 4995,
    "frequency": 5471,
    "originalRank": 5125
  },
  {
    "word": "esperabas",
    "rank": 4996,
    "frequency": 5470,
    "originalRank": 5126
  },
  {
    "word": "jovencita",
    "rank": 4997,
    "frequency": 5468,
    "originalRank": 5127
  },
  {
    "word": "callado",
    "rank": 4998,
    "frequency": 5467,
    "originalRank": 5128
  },
  {
    "word": "encender",
    "rank": 4999,
    "frequency": 5464,
    "originalRank": 5129
  },
  {
    "word": "grosero",
    "rank": 5000,
    "frequency": 5460,
    "originalRank": 5130
  },
  {
    "word": "mitch",
    "rank": 5001,
    "frequency": 5460,
    "originalRank": 5131
  },
  {
    "word": "rancho",
    "rank": 5002,
    "frequency": 5458,
    "originalRank": 5132
  },
  {
    "word": "conflicto",
    "rank": 5003,
    "frequency": 5455,
    "originalRank": 5133
  },
  {
    "word": "conspiración",
    "rank": 5004,
    "frequency": 5453,
    "originalRank": 5134
  },
  {
    "word": "comando",
    "rank": 5005,
    "frequency": 5452,
    "originalRank": 5135
  },
  {
    "word": "gota",
    "rank": 5006,
    "frequency": 5452,
    "originalRank": 5136
  },
  {
    "word": "escenas",
    "rank": 5007,
    "frequency": 5451,
    "originalRank": 5137
  },
  {
    "word": "colonia",
    "rank": 5008,
    "frequency": 5447,
    "originalRank": 5139
  },
  {
    "word": "medalla",
    "rank": 5009,
    "frequency": 5446,
    "originalRank": 5140
  },
  {
    "word": "contactar",
    "rank": 5010,
    "frequency": 5446,
    "originalRank": 5141
  },
  {
    "word": "jugamos",
    "rank": 5011,
    "frequency": 5445,
    "originalRank": 5142
  },
  {
    "word": "stone",
    "rank": 5012,
    "frequency": 5443,
    "originalRank": 5143
  },
  {
    "word": "cabra",
    "rank": 5013,
    "frequency": 5442,
    "originalRank": 5144
  },
  {
    "word": "traerme",
    "rank": 5014,
    "frequency": 5442,
    "originalRank": 5145
  },
  {
    "word": "parientes",
    "rank": 5015,
    "frequency": 5441,
    "originalRank": 5146
  },
  {
    "word": "creído",
    "rank": 5016,
    "frequency": 5440,
    "originalRank": 5147
  },
  {
    "word": "adolescentes",
    "rank": 5017,
    "frequency": 5439,
    "originalRank": 5148
  },
  {
    "word": "llenos",
    "rank": 5018,
    "frequency": 5439,
    "originalRank": 5149
  },
  {
    "word": "ultima",
    "rank": 5019,
    "frequency": 5438,
    "originalRank": 5150
  },
  {
    "word": "altas",
    "rank": 5020,
    "frequency": 5438,
    "originalRank": 5151
  },
  {
    "word": "cambiará",
    "rank": 5021,
    "frequency": 5432,
    "originalRank": 5152
  },
  {
    "word": "inteligentes",
    "rank": 5022,
    "frequency": 5432,
    "originalRank": 5153
  },
  {
    "word": "dieta",
    "rank": 5023,
    "frequency": 5431,
    "originalRank": 5154
  },
  {
    "word": "quedarás",
    "rank": 5024,
    "frequency": 5431,
    "originalRank": 5155
  },
  {
    "word": "correctamente",
    "rank": 5025,
    "frequency": 5430,
    "originalRank": 5156
  },
  {
    "word": "vería",
    "rank": 5026,
    "frequency": 5428,
    "originalRank": 5157
  },
  {
    "word": "suelto",
    "rank": 5027,
    "frequency": 5423,
    "originalRank": 5158
  },
  {
    "word": "fans",
    "rank": 5028,
    "frequency": 5422,
    "originalRank": 5159
  },
  {
    "word": "japonés",
    "rank": 5029,
    "frequency": 5422,
    "originalRank": 5160
  },
  {
    "word": "ropas",
    "rank": 5030,
    "frequency": 5421,
    "originalRank": 5161
  },
  {
    "word": "recibimos",
    "rank": 5031,
    "frequency": 5421,
    "originalRank": 5162
  },
  {
    "word": "elementos",
    "rank": 5032,
    "frequency": 5421,
    "originalRank": 5163
  },
  {
    "word": "verdaderos",
    "rank": 5033,
    "frequency": 5411,
    "originalRank": 5164
  },
  {
    "word": "bonnie",
    "rank": 5034,
    "frequency": 5410,
    "originalRank": 5165
  },
  {
    "word": "piensen",
    "rank": 5035,
    "frequency": 5410,
    "originalRank": 5166
  },
  {
    "word": "pondremos",
    "rank": 5036,
    "frequency": 5409,
    "originalRank": 5167
  },
  {
    "word": "contiene",
    "rank": 5037,
    "frequency": 5409,
    "originalRank": 5168
  },
  {
    "word": "diciembre",
    "rank": 5038,
    "frequency": 5408,
    "originalRank": 5169
  },
  {
    "word": "motores",
    "rank": 5039,
    "frequency": 5407,
    "originalRank": 5170
  },
  {
    "word": "graham",
    "rank": 5040,
    "frequency": 5406,
    "originalRank": 5171
  },
  {
    "word": "estarlo",
    "rank": 5041,
    "frequency": 5405,
    "originalRank": 5172
  },
  {
    "word": "preguntarme",
    "rank": 5042,
    "frequency": 5404,
    "originalRank": 5173
  },
  {
    "word": "permanente",
    "rank": 5043,
    "frequency": 5402,
    "originalRank": 5175
  },
  {
    "word": "comercio",
    "rank": 5044,
    "frequency": 5400,
    "originalRank": 5176
  },
  {
    "word": "llegara",
    "rank": 5045,
    "frequency": 5400,
    "originalRank": 5177
  },
  {
    "word": "amada",
    "rank": 5046,
    "frequency": 5398,
    "originalRank": 5178
  },
  {
    "word": "jodidamente",
    "rank": 5047,
    "frequency": 5397,
    "originalRank": 5179
  },
  {
    "word": "grasa",
    "rank": 5048,
    "frequency": 5395,
    "originalRank": 5180
  },
  {
    "word": "infección",
    "rank": 5049,
    "frequency": 5395,
    "originalRank": 5181
  },
  {
    "word": "comenzado",
    "rank": 5050,
    "frequency": 5387,
    "originalRank": 5182
  },
  {
    "word": "satisfecho",
    "rank": 5051,
    "frequency": 5386,
    "originalRank": 5183
  },
  {
    "word": "presidenta",
    "rank": 5052,
    "frequency": 5385,
    "originalRank": 5184
  },
  {
    "word": "llevarse",
    "rank": 5053,
    "frequency": 5382,
    "originalRank": 5185
  },
  {
    "word": "pesada",
    "rank": 5054,
    "frequency": 5380,
    "originalRank": 5186
  },
  {
    "word": "megan",
    "rank": 5055,
    "frequency": 5376,
    "originalRank": 5187
  },
  {
    "word": "barney",
    "rank": 5056,
    "frequency": 5372,
    "originalRank": 5188
  },
  {
    "word": "envío",
    "rank": 5057,
    "frequency": 5372,
    "originalRank": 5189
  },
  {
    "word": "desfile",
    "rank": 5058,
    "frequency": 5368,
    "originalRank": 5190
  },
  {
    "word": "suma",
    "rank": 5059,
    "frequency": 5366,
    "originalRank": 5191
  },
  {
    "word": "meterse",
    "rank": 5060,
    "frequency": 5366,
    "originalRank": 5192
  },
  {
    "word": "conclusión",
    "rank": 5061,
    "frequency": 5363,
    "originalRank": 5193
  },
  {
    "word": "atrapada",
    "rank": 5062,
    "frequency": 5360,
    "originalRank": 5194
  },
  {
    "word": "mientes",
    "rank": 5063,
    "frequency": 5359,
    "originalRank": 5195
  },
  {
    "word": "homicidios",
    "rank": 5064,
    "frequency": 5358,
    "originalRank": 5196
  },
  {
    "word": "cajón",
    "rank": 5065,
    "frequency": 5357,
    "originalRank": 5197
  },
  {
    "word": "tragos",
    "rank": 5066,
    "frequency": 5356,
    "originalRank": 5198
  },
  {
    "word": "salve",
    "rank": 5067,
    "frequency": 5356,
    "originalRank": 5199
  },
  {
    "word": "valores",
    "rank": 5068,
    "frequency": 5354,
    "originalRank": 5200
  },
  {
    "word": "pierre",
    "rank": 5069,
    "frequency": 5353,
    "originalRank": 5201
  },
  {
    "word": "leslie",
    "rank": 5070,
    "frequency": 5353,
    "originalRank": 5202
  },
  {
    "word": "ejecución",
    "rank": 5071,
    "frequency": 5352,
    "originalRank": 5203
  },
  {
    "word": "misterioso",
    "rank": 5072,
    "frequency": 5350,
    "originalRank": 5204
  },
  {
    "word": "sándwich",
    "rank": 5073,
    "frequency": 5345,
    "originalRank": 5205
  },
  {
    "word": "lobos",
    "rank": 5074,
    "frequency": 5343,
    "originalRank": 5206
  },
  {
    "word": "fortaleza",
    "rank": 5075,
    "frequency": 5343,
    "originalRank": 5207
  },
  {
    "word": "furioso",
    "rank": 5076,
    "frequency": 5342,
    "originalRank": 5208
  },
  {
    "word": "hamburguesa",
    "rank": 5077,
    "frequency": 5342,
    "originalRank": 5209
  },
  {
    "word": "barbara",
    "rank": 5078,
    "frequency": 5341,
    "originalRank": 5210
  },
  {
    "word": "salario",
    "rank": 5079,
    "frequency": 5341,
    "originalRank": 5211
  },
  {
    "word": "débiles",
    "rank": 5080,
    "frequency": 5340,
    "originalRank": 5212
  },
  {
    "word": "plena",
    "rank": 5081,
    "frequency": 5337,
    "originalRank": 5213
  },
  {
    "word": "pierda",
    "rank": 5082,
    "frequency": 5337,
    "originalRank": 5214
  },
  {
    "word": "murphy",
    "rank": 5083,
    "frequency": 5335,
    "originalRank": 5215
  },
  {
    "word": "cuero",
    "rank": 5084,
    "frequency": 5335,
    "originalRank": 5216
  },
  {
    "word": "jodan",
    "rank": 5085,
    "frequency": 5334,
    "originalRank": 5217
  },
  {
    "word": "oculta",
    "rank": 5086,
    "frequency": 5334,
    "originalRank": 5218
  },
  {
    "word": "salvaste",
    "rank": 5087,
    "frequency": 5331,
    "originalRank": 5219
  },
  {
    "word": "quema",
    "rank": 5088,
    "frequency": 5330,
    "originalRank": 5220
  },
  {
    "word": "cometió",
    "rank": 5089,
    "frequency": 5329,
    "originalRank": 5221
  },
  {
    "word": "temor",
    "rank": 5090,
    "frequency": 5329,
    "originalRank": 5222
  },
  {
    "word": "nora",
    "rank": 5091,
    "frequency": 5327,
    "originalRank": 5223
  },
  {
    "word": "muchísimas",
    "rank": 5092,
    "frequency": 5324,
    "originalRank": 5224
  },
  {
    "word": "comedor",
    "rank": 5093,
    "frequency": 5321,
    "originalRank": 5226
  },
  {
    "word": "aclarar",
    "rank": 5094,
    "frequency": 5319,
    "originalRank": 5227
  },
  {
    "word": "controla",
    "rank": 5095,
    "frequency": 5316,
    "originalRank": 5228
  },
  {
    "word": "admito",
    "rank": 5096,
    "frequency": 5314,
    "originalRank": 5229
  },
  {
    "word": "esconde",
    "rank": 5097,
    "frequency": 5314,
    "originalRank": 5231
  },
  {
    "word": "valioso",
    "rank": 5098,
    "frequency": 5314,
    "originalRank": 5232
  },
  {
    "word": "aguja",
    "rank": 5099,
    "frequency": 5313,
    "originalRank": 5233
  },
  {
    "word": "equivoco",
    "rank": 5100,
    "frequency": 5312,
    "originalRank": 5234
  },
  {
    "word": "terminaste",
    "rank": 5101,
    "frequency": 5312,
    "originalRank": 5235
  },
  {
    "word": "brillantes",
    "rank": 5102,
    "frequency": 5310,
    "originalRank": 5236
  },
  {
    "word": "ingleses",
    "rank": 5103,
    "frequency": 5308,
    "originalRank": 5237
  },
  {
    "word": "observando",
    "rank": 5104,
    "frequency": 5308,
    "originalRank": 5238
  },
  {
    "word": "objetivos",
    "rank": 5105,
    "frequency": 5307,
    "originalRank": 5239
  },
  {
    "word": "casarnos",
    "rank": 5106,
    "frequency": 5305,
    "originalRank": 5240
  },
  {
    "word": "emocionada",
    "rank": 5107,
    "frequency": 5304,
    "originalRank": 5241
  },
  {
    "word": "desaparición",
    "rank": 5108,
    "frequency": 5303,
    "originalRank": 5242
  },
  {
    "word": "sello",
    "rank": 5109,
    "frequency": 5301,
    "originalRank": 5243
  },
  {
    "word": "quietos",
    "rank": 5110,
    "frequency": 5301,
    "originalRank": 5244
  },
  {
    "word": "escuelas",
    "rank": 5111,
    "frequency": 5293,
    "originalRank": 5245
  },
  {
    "word": "merecía",
    "rank": 5112,
    "frequency": 5292,
    "originalRank": 5246
  },
  {
    "word": "deshacerse",
    "rank": 5113,
    "frequency": 5290,
    "originalRank": 5247
  },
  {
    "word": "tiburón",
    "rank": 5114,
    "frequency": 5288,
    "originalRank": 5248
  },
  {
    "word": "mostrarle",
    "rank": 5115,
    "frequency": 5287,
    "originalRank": 5249
  },
  {
    "word": "nube",
    "rank": 5116,
    "frequency": 5286,
    "originalRank": 5250
  },
  {
    "word": "formación",
    "rank": 5117,
    "frequency": 5284,
    "originalRank": 5251
  },
  {
    "word": "compraste",
    "rank": 5118,
    "frequency": 5284,
    "originalRank": 5252
  },
  {
    "word": "decepcionado",
    "rank": 5119,
    "frequency": 5284,
    "originalRank": 5253
  },
  {
    "word": "autopista",
    "rank": 5120,
    "frequency": 5283,
    "originalRank": 5254
  },
  {
    "word": "evidente",
    "rank": 5121,
    "frequency": 5282,
    "originalRank": 5255
  },
  {
    "word": "camiones",
    "rank": 5122,
    "frequency": 5282,
    "originalRank": 5256
  },
  {
    "word": "programas",
    "rank": 5123,
    "frequency": 5282,
    "originalRank": 5257
  },
  {
    "word": "falsas",
    "rank": 5124,
    "frequency": 5281,
    "originalRank": 5258
  },
  {
    "word": "daisy",
    "rank": 5125,
    "frequency": 5281,
    "originalRank": 5259
  },
  {
    "word": "encuentres",
    "rank": 5126,
    "frequency": 5279,
    "originalRank": 5260
  },
  {
    "word": "matas",
    "rank": 5127,
    "frequency": 5279,
    "originalRank": 5261
  },
  {
    "word": "quitado",
    "rank": 5128,
    "frequency": 5279,
    "originalRank": 5262
  },
  {
    "word": "actividades",
    "rank": 5129,
    "frequency": 5279,
    "originalRank": 5263
  },
  {
    "word": "líderes",
    "rank": 5130,
    "frequency": 5278,
    "originalRank": 5264
  },
  {
    "word": "escuchad",
    "rank": 5131,
    "frequency": 5277,
    "originalRank": 5265
  },
  {
    "word": "global",
    "rank": 5132,
    "frequency": 5274,
    "originalRank": 5266
  },
  {
    "word": "esclavo",
    "rank": 5133,
    "frequency": 5274,
    "originalRank": 5267
  },
  {
    "word": "ocasiones",
    "rank": 5134,
    "frequency": 5273,
    "originalRank": 5268
  },
  {
    "word": "dejarle",
    "rank": 5135,
    "frequency": 5272,
    "originalRank": 5269
  },
  {
    "word": "confirmar",
    "rank": 5136,
    "frequency": 5272,
    "originalRank": 5270
  },
  {
    "word": "pendiente",
    "rank": 5137,
    "frequency": 5272,
    "originalRank": 5271
  },
  {
    "word": "toalla",
    "rank": 5138,
    "frequency": 5268,
    "originalRank": 5272
  },
  {
    "word": "construido",
    "rank": 5139,
    "frequency": 5267,
    "originalRank": 5273
  },
  {
    "word": "creación",
    "rank": 5140,
    "frequency": 5265,
    "originalRank": 5274
  },
  {
    "word": "raros",
    "rank": 5141,
    "frequency": 5264,
    "originalRank": 5275
  },
  {
    "word": "novios",
    "rank": 5142,
    "frequency": 5261,
    "originalRank": 5276
  },
  {
    "word": "escuches",
    "rank": 5143,
    "frequency": 5260,
    "originalRank": 5277
  },
  {
    "word": "temía",
    "rank": 5144,
    "frequency": 5260,
    "originalRank": 5278
  },
  {
    "word": "detiene",
    "rank": 5145,
    "frequency": 5256,
    "originalRank": 5279
  },
  {
    "word": "gusano",
    "rank": 5146,
    "frequency": 5248,
    "originalRank": 5281
  },
  {
    "word": "atmósfera",
    "rank": 5147,
    "frequency": 5248,
    "originalRank": 5282
  },
  {
    "word": "gina",
    "rank": 5148,
    "frequency": 5247,
    "originalRank": 5283
  },
  {
    "word": "reunir",
    "rank": 5149,
    "frequency": 5244,
    "originalRank": 5284
  },
  {
    "word": "espiritual",
    "rank": 5150,
    "frequency": 5243,
    "originalRank": 5285
  },
  {
    "word": "pensión",
    "rank": 5151,
    "frequency": 5242,
    "originalRank": 5286
  },
  {
    "word": "sirven",
    "rank": 5152,
    "frequency": 5242,
    "originalRank": 5287
  },
  {
    "word": "saldremos",
    "rank": 5153,
    "frequency": 5242,
    "originalRank": 5288
  },
  {
    "word": "marica",
    "rank": 5154,
    "frequency": 5240,
    "originalRank": 5289
  },
  {
    "word": "república",
    "rank": 5155,
    "frequency": 5238,
    "originalRank": 5290
  },
  {
    "word": "siéntense",
    "rank": 5156,
    "frequency": 5237,
    "originalRank": 5291
  },
  {
    "word": "sabio",
    "rank": 5157,
    "frequency": 5235,
    "originalRank": 5292
  },
  {
    "word": "increíbles",
    "rank": 5158,
    "frequency": 5235,
    "originalRank": 5293
  },
  {
    "word": "embajada",
    "rank": 5159,
    "frequency": 5235,
    "originalRank": 5294
  },
  {
    "word": "quieta",
    "rank": 5160,
    "frequency": 5235,
    "originalRank": 5295
  },
  {
    "word": "escribo",
    "rank": 5161,
    "frequency": 5234,
    "originalRank": 5296
  },
  {
    "word": "poema",
    "rank": 5162,
    "frequency": 5232,
    "originalRank": 5297
  },
  {
    "word": "kang",
    "rank": 5163,
    "frequency": 5232,
    "originalRank": 5298
  },
  {
    "word": "terminará",
    "rank": 5164,
    "frequency": 5231,
    "originalRank": 5299
  },
  {
    "word": "tenis",
    "rank": 5165,
    "frequency": 5231,
    "originalRank": 5300
  },
  {
    "word": "civilización",
    "rank": 5166,
    "frequency": 5230,
    "originalRank": 5301
  },
  {
    "word": "patada",
    "rank": 5167,
    "frequency": 5229,
    "originalRank": 5302
  },
  {
    "word": "cuerdas",
    "rank": 5168,
    "frequency": 5228,
    "originalRank": 5303
  },
  {
    "word": "dibujos",
    "rank": 5169,
    "frequency": 5227,
    "originalRank": 5304
  },
  {
    "word": "perdieron",
    "rank": 5170,
    "frequency": 5227,
    "originalRank": 5305
  },
  {
    "word": "brenda",
    "rank": 5171,
    "frequency": 5226,
    "originalRank": 5306
  },
  {
    "word": "tirando",
    "rank": 5172,
    "frequency": 5226,
    "originalRank": 5307
  },
  {
    "word": "miran",
    "rank": 5173,
    "frequency": 5225,
    "originalRank": 5308
  },
  {
    "word": "prometes",
    "rank": 5174,
    "frequency": 5225,
    "originalRank": 5309
  },
  {
    "word": "chase",
    "rank": 5175,
    "frequency": 5225,
    "originalRank": 5310
  },
  {
    "word": "pluma",
    "rank": 5176,
    "frequency": 5224,
    "originalRank": 5311
  },
  {
    "word": "posibles",
    "rank": 5177,
    "frequency": 5224,
    "originalRank": 5313
  },
  {
    "word": "fallo",
    "rank": 5178,
    "frequency": 5223,
    "originalRank": 5314
  },
  {
    "word": "iris",
    "rank": 5179,
    "frequency": 5222,
    "originalRank": 5315
  },
  {
    "word": "superman",
    "rank": 5180,
    "frequency": 5221,
    "originalRank": 5316
  },
  {
    "word": "entendemos",
    "rank": 5181,
    "frequency": 5217,
    "originalRank": 5317
  },
  {
    "word": "rodilla",
    "rank": 5182,
    "frequency": 5217,
    "originalRank": 5318
  },
  {
    "word": "vestida",
    "rank": 5183,
    "frequency": 5217,
    "originalRank": 5319
  },
  {
    "word": "echó",
    "rank": 5184,
    "frequency": 5216,
    "originalRank": 5320
  },
  {
    "word": "philip",
    "rank": 5185,
    "frequency": 5213,
    "originalRank": 5321
  },
  {
    "word": "tirador",
    "rank": 5186,
    "frequency": 5213,
    "originalRank": 5322
  },
  {
    "word": "aparato",
    "rank": 5187,
    "frequency": 5213,
    "originalRank": 5323
  },
  {
    "word": "modales",
    "rank": 5188,
    "frequency": 5212,
    "originalRank": 5324
  },
  {
    "word": "horror",
    "rank": 5189,
    "frequency": 5211,
    "originalRank": 5325
  },
  {
    "word": "quisiste",
    "rank": 5190,
    "frequency": 5210,
    "originalRank": 5326
  },
  {
    "word": "pavos",
    "rank": 5191,
    "frequency": 5210,
    "originalRank": 5327
  },
  {
    "word": "permitiré",
    "rank": 5192,
    "frequency": 5205,
    "originalRank": 5328
  },
  {
    "word": "estatua",
    "rank": 5193,
    "frequency": 5203,
    "originalRank": 5329
  },
  {
    "word": "asegurarse",
    "rank": 5194,
    "frequency": 5202,
    "originalRank": 5330
  },
  {
    "word": "regresen",
    "rank": 5195,
    "frequency": 5198,
    "originalRank": 5331
  },
  {
    "word": "mandado",
    "rank": 5196,
    "frequency": 5198,
    "originalRank": 5332
  },
  {
    "word": "continua",
    "rank": 5197,
    "frequency": 5195,
    "originalRank": 5333
  },
  {
    "word": "siesta",
    "rank": 5198,
    "frequency": 5194,
    "originalRank": 5334
  },
  {
    "word": "ausencia",
    "rank": 5199,
    "frequency": 5194,
    "originalRank": 5335
  },
  {
    "word": "perdemos",
    "rank": 5200,
    "frequency": 5193,
    "originalRank": 5336
  },
  {
    "word": "collins",
    "rank": 5201,
    "frequency": 5193,
    "originalRank": 5337
  },
  {
    "word": "encontrarán",
    "rank": 5202,
    "frequency": 5192,
    "originalRank": 5338
  },
  {
    "word": "cuentos",
    "rank": 5203,
    "frequency": 5191,
    "originalRank": 5339
  },
  {
    "word": "wade",
    "rank": 5204,
    "frequency": 5191,
    "originalRank": 5340
  },
  {
    "word": "maletín",
    "rank": 5205,
    "frequency": 5189,
    "originalRank": 5341
  },
  {
    "word": "phoebe",
    "rank": 5206,
    "frequency": 5189,
    "originalRank": 5342
  },
  {
    "word": "jules",
    "rank": 5207,
    "frequency": 5189,
    "originalRank": 5343
  },
  {
    "word": "ellie",
    "rank": 5208,
    "frequency": 5188,
    "originalRank": 5344
  },
  {
    "word": "perfume",
    "rank": 5209,
    "frequency": 5185,
    "originalRank": 5345
  },
  {
    "word": "grabar",
    "rank": 5210,
    "frequency": 5182,
    "originalRank": 5346
  },
  {
    "word": "crece",
    "rank": 5211,
    "frequency": 5181,
    "originalRank": 5347
  },
  {
    "word": "jen",
    "rank": 5212,
    "frequency": 5179,
    "originalRank": 5348
  },
  {
    "word": "echarle",
    "rank": 5213,
    "frequency": 5178,
    "originalRank": 5349
  },
  {
    "word": "entro",
    "rank": 5214,
    "frequency": 5178,
    "originalRank": 5350
  },
  {
    "word": "duelo",
    "rank": 5215,
    "frequency": 5176,
    "originalRank": 5351
  },
  {
    "word": "israel",
    "rank": 5216,
    "frequency": 5174,
    "originalRank": 5352
  },
  {
    "word": "cometí",
    "rank": 5217,
    "frequency": 5172,
    "originalRank": 5353
  },
  {
    "word": "organizar",
    "rank": 5218,
    "frequency": 5172,
    "originalRank": 5354
  },
  {
    "word": "pervertido",
    "rank": 5219,
    "frequency": 5169,
    "originalRank": 5355
  },
  {
    "word": "subió",
    "rank": 5220,
    "frequency": 5169,
    "originalRank": 5356
  },
  {
    "word": "revistas",
    "rank": 5221,
    "frequency": 5169,
    "originalRank": 5357
  },
  {
    "word": "dejarás",
    "rank": 5222,
    "frequency": 5168,
    "originalRank": 5358
  },
  {
    "word": "lleves",
    "rank": 5223,
    "frequency": 5167,
    "originalRank": 5359
  },
  {
    "word": "walt",
    "rank": 5224,
    "frequency": 5166,
    "originalRank": 5360
  },
  {
    "word": "carla",
    "rank": 5225,
    "frequency": 5162,
    "originalRank": 5361
  },
  {
    "word": "jill",
    "rank": 5226,
    "frequency": 5161,
    "originalRank": 5362
  },
  {
    "word": "enciende",
    "rank": 5227,
    "frequency": 5160,
    "originalRank": 5363
  },
  {
    "word": "quitó",
    "rank": 5228,
    "frequency": 5159,
    "originalRank": 5364
  },
  {
    "word": "radar",
    "rank": 5229,
    "frequency": 5158,
    "originalRank": 5365
  },
  {
    "word": "seriamente",
    "rank": 5230,
    "frequency": 5157,
    "originalRank": 5366
  },
  {
    "word": "probabilidades",
    "rank": 5231,
    "frequency": 5157,
    "originalRank": 5367
  },
  {
    "word": "capullo",
    "rank": 5232,
    "frequency": 5156,
    "originalRank": 5368
  },
  {
    "word": "deseando",
    "rank": 5233,
    "frequency": 5155,
    "originalRank": 5369
  },
  {
    "word": "dana",
    "rank": 5234,
    "frequency": 5150,
    "originalRank": 5370
  },
  {
    "word": "bang",
    "rank": 5235,
    "frequency": 5150,
    "originalRank": 5371
  },
  {
    "word": "habrás",
    "rank": 5236,
    "frequency": 5144,
    "originalRank": 5372
  },
  {
    "word": "ganaste",
    "rank": 5237,
    "frequency": 5144,
    "originalRank": 5373
  },
  {
    "word": "locas",
    "rank": 5238,
    "frequency": 5144,
    "originalRank": 5374
  },
  {
    "word": "hall",
    "rank": 5239,
    "frequency": 5137,
    "originalRank": 5375
  },
  {
    "word": "encantó",
    "rank": 5240,
    "frequency": 5136,
    "originalRank": 5376
  },
  {
    "word": "telefónica",
    "rank": 5241,
    "frequency": 5133,
    "originalRank": 5377
  },
  {
    "word": "llegues",
    "rank": 5242,
    "frequency": 5133,
    "originalRank": 5378
  },
  {
    "word": "micrófono",
    "rank": 5243,
    "frequency": 5132,
    "originalRank": 5379
  },
  {
    "word": "margen",
    "rank": 5244,
    "frequency": 5130,
    "originalRank": 5380
  },
  {
    "word": "gesto",
    "rank": 5245,
    "frequency": 5130,
    "originalRank": 5381
  },
  {
    "word": "cintas",
    "rank": 5246,
    "frequency": 5127,
    "originalRank": 5382
  },
  {
    "word": "sugiere",
    "rank": 5247,
    "frequency": 5127,
    "originalRank": 5383
  },
  {
    "word": "embarazo",
    "rank": 5248,
    "frequency": 5126,
    "originalRank": 5384
  },
  {
    "word": "stuart",
    "rank": 5249,
    "frequency": 5123,
    "originalRank": 5385
  },
  {
    "word": "encaja",
    "rank": 5250,
    "frequency": 5121,
    "originalRank": 5386
  },
  {
    "word": "consuelo",
    "rank": 5251,
    "frequency": 5121,
    "originalRank": 5387
  },
  {
    "word": "llamarla",
    "rank": 5252,
    "frequency": 5119,
    "originalRank": 5388
  },
  {
    "word": "sabiduría",
    "rank": 5253,
    "frequency": 5118,
    "originalRank": 5389
  },
  {
    "word": "sincera",
    "rank": 5254,
    "frequency": 5118,
    "originalRank": 5390
  },
  {
    "word": "bolsillos",
    "rank": 5255,
    "frequency": 5115,
    "originalRank": 5391
  },
  {
    "word": "paula",
    "rank": 5256,
    "frequency": 5115,
    "originalRank": 5392
  },
  {
    "word": "comencé",
    "rank": 5257,
    "frequency": 5114,
    "originalRank": 5393
  },
  {
    "word": "noel",
    "rank": 5258,
    "frequency": 5114,
    "originalRank": 5394
  },
  {
    "word": "muestran",
    "rank": 5259,
    "frequency": 5113,
    "originalRank": 5395
  },
  {
    "word": "lea",
    "rank": 5260,
    "frequency": 5112,
    "originalRank": 5396
  },
  {
    "word": "mágica",
    "rank": 5261,
    "frequency": 5109,
    "originalRank": 5397
  },
  {
    "word": "terriblemente",
    "rank": 5262,
    "frequency": 5107,
    "originalRank": 5398
  },
  {
    "word": "recuerdan",
    "rank": 5263,
    "frequency": 5105,
    "originalRank": 5399
  },
  {
    "word": "solíamos",
    "rank": 5264,
    "frequency": 5104,
    "originalRank": 5400
  },
  {
    "word": "susto",
    "rank": 5265,
    "frequency": 5104,
    "originalRank": 5401
  },
  {
    "word": "ocurrirá",
    "rank": 5266,
    "frequency": 5101,
    "originalRank": 5402
  },
  {
    "word": "hadas",
    "rank": 5267,
    "frequency": 5101,
    "originalRank": 5403
  },
  {
    "word": "sos",
    "rank": 5268,
    "frequency": 5099,
    "originalRank": 5404
  },
  {
    "word": "preocuparme",
    "rank": 5269,
    "frequency": 5098,
    "originalRank": 5405
  },
  {
    "word": "hare",
    "rank": 5270,
    "frequency": 5098,
    "originalRank": 5406
  },
  {
    "word": "vidrio",
    "rank": 5271,
    "frequency": 5095,
    "originalRank": 5407
  },
  {
    "word": "término",
    "rank": 5272,
    "frequency": 5094,
    "originalRank": 5408
  },
  {
    "word": "volverán",
    "rank": 5273,
    "frequency": 5093,
    "originalRank": 5409
  },
  {
    "word": "desorden",
    "rank": 5274,
    "frequency": 5092,
    "originalRank": 5410
  },
  {
    "word": "alimentar",
    "rank": 5275,
    "frequency": 5092,
    "originalRank": 5411
  },
  {
    "word": "boleto",
    "rank": 5276,
    "frequency": 5091,
    "originalRank": 5412
  },
  {
    "word": "lavado",
    "rank": 5277,
    "frequency": 5090,
    "originalRank": 5413
  },
  {
    "word": "confusión",
    "rank": 5278,
    "frequency": 5086,
    "originalRank": 5414
  },
  {
    "word": "angeles",
    "rank": 5279,
    "frequency": 5083,
    "originalRank": 5415
  },
  {
    "word": "ave",
    "rank": 5280,
    "frequency": 5080,
    "originalRank": 5416
  },
  {
    "word": "cambié",
    "rank": 5281,
    "frequency": 5080,
    "originalRank": 5417
  },
  {
    "word": "temer",
    "rank": 5282,
    "frequency": 5079,
    "originalRank": 5418
  },
  {
    "word": "pense",
    "rank": 5283,
    "frequency": 5079,
    "originalRank": 5419
  },
  {
    "word": "danos",
    "rank": 5284,
    "frequency": 5079,
    "originalRank": 5420
  },
  {
    "word": "facultad",
    "rank": 5285,
    "frequency": 5077,
    "originalRank": 5421
  },
  {
    "word": "mochila",
    "rank": 5286,
    "frequency": 5077,
    "originalRank": 5422
  },
  {
    "word": "satélite",
    "rank": 5287,
    "frequency": 5076,
    "originalRank": 5423
  },
  {
    "word": "independiente",
    "rank": 5288,
    "frequency": 5076,
    "originalRank": 5424
  },
  {
    "word": "intentan",
    "rank": 5289,
    "frequency": 5073,
    "originalRank": 5425
  },
  {
    "word": "enero",
    "rank": 5290,
    "frequency": 5073,
    "originalRank": 5426
  },
  {
    "word": "busqué",
    "rank": 5291,
    "frequency": 5072,
    "originalRank": 5427
  },
  {
    "word": "diosa",
    "rank": 5292,
    "frequency": 5072,
    "originalRank": 5428
  },
  {
    "word": "estuvieran",
    "rank": 5293,
    "frequency": 5071,
    "originalRank": 5429
  },
  {
    "word": "barón",
    "rank": 5294,
    "frequency": 5070,
    "originalRank": 5430
  },
  {
    "word": "clay",
    "rank": 5295,
    "frequency": 5070,
    "originalRank": 5431
  },
  {
    "word": "artes",
    "rank": 5296,
    "frequency": 5069,
    "originalRank": 5432
  },
  {
    "word": "nocturno",
    "rank": 5297,
    "frequency": 5068,
    "originalRank": 5433
  },
  {
    "word": "timbre",
    "rank": 5298,
    "frequency": 5066,
    "originalRank": 5434
  },
  {
    "word": "escapa",
    "rank": 5299,
    "frequency": 5065,
    "originalRank": 5435
  },
  {
    "word": "establecer",
    "rank": 5300,
    "frequency": 5065,
    "originalRank": 5436
  },
  {
    "word": "what",
    "rank": 5301,
    "frequency": 5061,
    "originalRank": 5437
  },
  {
    "word": "duermo",
    "rank": 5302,
    "frequency": 5061,
    "originalRank": 5438
  },
  {
    "word": "araña",
    "rank": 5303,
    "frequency": 5061,
    "originalRank": 5439
  },
  {
    "word": "detenga",
    "rank": 5304,
    "frequency": 5060,
    "originalRank": 5440
  },
  {
    "word": "intentes",
    "rank": 5305,
    "frequency": 5059,
    "originalRank": 5441
  },
  {
    "word": "correos",
    "rank": 5306,
    "frequency": 5054,
    "originalRank": 5442
  },
  {
    "word": "profesores",
    "rank": 5307,
    "frequency": 5053,
    "originalRank": 5443
  },
  {
    "word": "enseñarle",
    "rank": 5308,
    "frequency": 5052,
    "originalRank": 5444
  },
  {
    "word": "guerreros",
    "rank": 5309,
    "frequency": 5052,
    "originalRank": 5445
  },
  {
    "word": "ancianos",
    "rank": 5310,
    "frequency": 5049,
    "originalRank": 5446
  },
  {
    "word": "preocupo",
    "rank": 5311,
    "frequency": 5045,
    "originalRank": 5447
  },
  {
    "word": "bebes",
    "rank": 5312,
    "frequency": 5045,
    "originalRank": 5448
  },
  {
    "word": "imaginaba",
    "rank": 5313,
    "frequency": 5042,
    "originalRank": 5449
  },
  {
    "word": "mundos",
    "rank": 5314,
    "frequency": 5041,
    "originalRank": 5450
  },
  {
    "word": "martillo",
    "rank": 5315,
    "frequency": 5041,
    "originalRank": 5451
  },
  {
    "word": "eterna",
    "rank": 5316,
    "frequency": 5041,
    "originalRank": 5452
  },
  {
    "word": "sufrió",
    "rank": 5317,
    "frequency": 5039,
    "originalRank": 5453
  },
  {
    "word": "comentario",
    "rank": 5318,
    "frequency": 5038,
    "originalRank": 5454
  },
  {
    "word": "inicio",
    "rank": 5319,
    "frequency": 5038,
    "originalRank": 5455
  },
  {
    "word": "buscarme",
    "rank": 5320,
    "frequency": 5037,
    "originalRank": 5456
  },
  {
    "word": "impresionado",
    "rank": 5321,
    "frequency": 5035,
    "originalRank": 5457
  },
  {
    "word": "estelar",
    "rank": 5322,
    "frequency": 5034,
    "originalRank": 5458
  },
  {
    "word": "pagas",
    "rank": 5323,
    "frequency": 5034,
    "originalRank": 5459
  },
  {
    "word": "álbum",
    "rank": 5324,
    "frequency": 5032,
    "originalRank": 5460
  },
  {
    "word": "rojos",
    "rank": 5325,
    "frequency": 5031,
    "originalRank": 5461
  },
  {
    "word": "jueces",
    "rank": 5326,
    "frequency": 5031,
    "originalRank": 5462
  },
  {
    "word": "allen",
    "rank": 5327,
    "frequency": 5030,
    "originalRank": 5463
  },
  {
    "word": "sufre",
    "rank": 5328,
    "frequency": 5029,
    "originalRank": 5464
  },
  {
    "word": "internos",
    "rank": 5329,
    "frequency": 5029,
    "originalRank": 5465
  },
  {
    "word": "casé",
    "rank": 5330,
    "frequency": 5028,
    "originalRank": 5466
  },
  {
    "word": "teresa",
    "rank": 5331,
    "frequency": 5028,
    "originalRank": 5467
  },
  {
    "word": "pudieran",
    "rank": 5332,
    "frequency": 5024,
    "originalRank": 5468
  },
  {
    "word": "ola",
    "rank": 5333,
    "frequency": 5023,
    "originalRank": 5469
  },
  {
    "word": "equivoca",
    "rank": 5334,
    "frequency": 5022,
    "originalRank": 5470
  },
  {
    "word": "desaparecida",
    "rank": 5335,
    "frequency": 5020,
    "originalRank": 5471
  },
  {
    "word": "retrato",
    "rank": 5336,
    "frequency": 5019,
    "originalRank": 5472
  },
  {
    "word": "justa",
    "rank": 5337,
    "frequency": 5018,
    "originalRank": 5473
  },
  {
    "word": "repugnante",
    "rank": 5338,
    "frequency": 5018,
    "originalRank": 5474
  },
  {
    "word": "mentirosa",
    "rank": 5339,
    "frequency": 5016,
    "originalRank": 5475
  },
  {
    "word": "mirado",
    "rank": 5340,
    "frequency": 5015,
    "originalRank": 5477
  },
  {
    "word": "confesar",
    "rank": 5341,
    "frequency": 5013,
    "originalRank": 5478
  },
  {
    "word": "vacas",
    "rank": 5342,
    "frequency": 5013,
    "originalRank": 5479
  },
  {
    "word": "deberá",
    "rank": 5343,
    "frequency": 5013,
    "originalRank": 5480
  },
  {
    "word": "rojas",
    "rank": 5344,
    "frequency": 5012,
    "originalRank": 5481
  },
  {
    "word": "repetir",
    "rank": 5345,
    "frequency": 5012,
    "originalRank": 5482
  },
  {
    "word": "respiro",
    "rank": 5346,
    "frequency": 5012,
    "originalRank": 5483
  },
  {
    "word": "cuya",
    "rank": 5347,
    "frequency": 5011,
    "originalRank": 5484
  },
  {
    "word": "ganancias",
    "rank": 5348,
    "frequency": 5011,
    "originalRank": 5485
  },
  {
    "word": "disfrutando",
    "rank": 5349,
    "frequency": 5006,
    "originalRank": 5486
  },
  {
    "word": "comedia",
    "rank": 5350,
    "frequency": 5006,
    "originalRank": 5487
  },
  {
    "word": "boy",
    "rank": 5351,
    "frequency": 5003,
    "originalRank": 5488
  },
  {
    "word": "chip",
    "rank": 5352,
    "frequency": 5002,
    "originalRank": 5489
  },
  {
    "word": "amables",
    "rank": 5353,
    "frequency": 5002,
    "originalRank": 5490
  },
  {
    "word": "inversión",
    "rank": 5354,
    "frequency": 5001,
    "originalRank": 5491
  },
  {
    "word": "gemelos",
    "rank": 5355,
    "frequency": 4997,
    "originalRank": 5492
  },
  {
    "word": "minas",
    "rank": 5356,
    "frequency": 4996,
    "originalRank": 5493
  },
  {
    "word": "falsos",
    "rank": 5357,
    "frequency": 4996,
    "originalRank": 5494
  },
  {
    "word": "times",
    "rank": 5358,
    "frequency": 4996,
    "originalRank": 5495
  },
  {
    "word": "pat",
    "rank": 5359,
    "frequency": 4995,
    "originalRank": 5496
  },
  {
    "word": "matarnos",
    "rank": 5360,
    "frequency": 4994,
    "originalRank": 5497
  },
  {
    "word": "cogí",
    "rank": 5361,
    "frequency": 4994,
    "originalRank": 5498
  },
  {
    "word": "australia",
    "rank": 5362,
    "frequency": 4994,
    "originalRank": 5499
  },
  {
    "word": "seda",
    "rank": 5363,
    "frequency": 4992,
    "originalRank": 5500
  },
  {
    "word": "malentendido",
    "rank": 5364,
    "frequency": 4989,
    "originalRank": 5501
  },
  {
    "word": "distintas",
    "rank": 5365,
    "frequency": 4986,
    "originalRank": 5502
  },
  {
    "word": "diamante",
    "rank": 5366,
    "frequency": 4986,
    "originalRank": 5503
  },
  {
    "word": "april",
    "rank": 5367,
    "frequency": 4985,
    "originalRank": 5504
  },
  {
    "word": "cojo",
    "rank": 5368,
    "frequency": 4985,
    "originalRank": 5505
  },
  {
    "word": "avergonzado",
    "rank": 5369,
    "frequency": 4984,
    "originalRank": 5506
  },
  {
    "word": "siguientes",
    "rank": 5370,
    "frequency": 4984,
    "originalRank": 5507
  },
  {
    "word": "agarrar",
    "rank": 5371,
    "frequency": 4983,
    "originalRank": 5508
  },
  {
    "word": "comunicaciones",
    "rank": 5372,
    "frequency": 4982,
    "originalRank": 5509
  },
  {
    "word": "dirán",
    "rank": 5373,
    "frequency": 4981,
    "originalRank": 5510
  },
  {
    "word": "cobrar",
    "rank": 5374,
    "frequency": 4980,
    "originalRank": 5511
  },
  {
    "word": "dificultades",
    "rank": 5375,
    "frequency": 4979,
    "originalRank": 5512
  },
  {
    "word": "lápiz",
    "rank": 5376,
    "frequency": 4979,
    "originalRank": 5513
  },
  {
    "word": "pague",
    "rank": 5377,
    "frequency": 4977,
    "originalRank": 5514
  },
  {
    "word": "deberia",
    "rank": 5378,
    "frequency": 4976,
    "originalRank": 5515
  },
  {
    "word": "caiga",
    "rank": 5379,
    "frequency": 4975,
    "originalRank": 5516
  },
  {
    "word": "tara",
    "rank": 5380,
    "frequency": 4973,
    "originalRank": 5517
  },
  {
    "word": "christopher",
    "rank": 5381,
    "frequency": 4973,
    "originalRank": 5518
  },
  {
    "word": "avenida",
    "rank": 5382,
    "frequency": 4971,
    "originalRank": 5519
  },
  {
    "word": "comenzamos",
    "rank": 5383,
    "frequency": 4970,
    "originalRank": 5520
  },
  {
    "word": "seca",
    "rank": 5384,
    "frequency": 4968,
    "originalRank": 5521
  },
  {
    "word": "contentos",
    "rank": 5385,
    "frequency": 4967,
    "originalRank": 5522
  },
  {
    "word": "vivió",
    "rank": 5386,
    "frequency": 4965,
    "originalRank": 5523
  },
  {
    "word": "hágalo",
    "rank": 5387,
    "frequency": 4964,
    "originalRank": 5524
  },
  {
    "word": "que-",
    "rank": 5388,
    "frequency": 4961,
    "originalRank": 5525
  },
  {
    "word": "bruno",
    "rank": 5389,
    "frequency": 4961,
    "originalRank": 5526
  },
  {
    "word": "llévate",
    "rank": 5390,
    "frequency": 4960,
    "originalRank": 5527
  },
  {
    "word": "oculto",
    "rank": 5391,
    "frequency": 4960,
    "originalRank": 5528
  },
  {
    "word": "metes",
    "rank": 5392,
    "frequency": 4958,
    "originalRank": 5529
  },
  {
    "word": "soo",
    "rank": 5393,
    "frequency": 4957,
    "originalRank": 5530
  },
  {
    "word": "principales",
    "rank": 5394,
    "frequency": 4956,
    "originalRank": 5531
  },
  {
    "word": "mario",
    "rank": 5395,
    "frequency": 4955,
    "originalRank": 5532
  },
  {
    "word": "vic",
    "rank": 5396,
    "frequency": 4954,
    "originalRank": 5533
  },
  {
    "word": "euros",
    "rank": 5397,
    "frequency": 4954,
    "originalRank": 5534
  },
  {
    "word": "salva",
    "rank": 5398,
    "frequency": 4951,
    "originalRank": 5535
  },
  {
    "word": "mantengan",
    "rank": 5399,
    "frequency": 4950,
    "originalRank": 5536
  },
  {
    "word": "entras",
    "rank": 5400,
    "frequency": 4950,
    "originalRank": 5537
  },
  {
    "word": "manhattan",
    "rank": 5401,
    "frequency": 4948,
    "originalRank": 5538
  },
  {
    "word": "promesas",
    "rank": 5402,
    "frequency": 4944,
    "originalRank": 5539
  },
  {
    "word": "explosivos",
    "rank": 5403,
    "frequency": 4944,
    "originalRank": 5540
  },
  {
    "word": "kennedy",
    "rank": 5404,
    "frequency": 4942,
    "originalRank": 5541
  },
  {
    "word": "ataúd",
    "rank": 5405,
    "frequency": 4940,
    "originalRank": 5542
  },
  {
    "word": "cancelar",
    "rank": 5406,
    "frequency": 4937,
    "originalRank": 5543
  },
  {
    "word": "island",
    "rank": 5407,
    "frequency": 4937,
    "originalRank": 5544
  },
  {
    "word": "excusas",
    "rank": 5408,
    "frequency": 4936,
    "originalRank": 5545
  },
  {
    "word": "emergencias",
    "rank": 5409,
    "frequency": 4935,
    "originalRank": 5546
  },
  {
    "word": "orgullosos",
    "rank": 5410,
    "frequency": 4933,
    "originalRank": 5547
  },
  {
    "word": "creerme",
    "rank": 5411,
    "frequency": 4932,
    "originalRank": 5548
  },
  {
    "word": "brooklyn",
    "rank": 5412,
    "frequency": 4931,
    "originalRank": 5549
  },
  {
    "word": "seguida",
    "rank": 5413,
    "frequency": 4931,
    "originalRank": 5550
  },
  {
    "word": "busque",
    "rank": 5414,
    "frequency": 4929,
    "originalRank": 5551
  },
  {
    "word": "encendido",
    "rank": 5415,
    "frequency": 4929,
    "originalRank": 5552
  },
  {
    "word": "coro",
    "rank": 5416,
    "frequency": 4929,
    "originalRank": 5553
  },
  {
    "word": "urgencias",
    "rank": 5417,
    "frequency": 4929,
    "originalRank": 5554
  },
  {
    "word": "tales",
    "rank": 5418,
    "frequency": 4926,
    "originalRank": 5555
  },
  {
    "word": "observa",
    "rank": 5419,
    "frequency": 4926,
    "originalRank": 5556
  },
  {
    "word": "manual",
    "rank": 5420,
    "frequency": 4924,
    "originalRank": 5557
  },
  {
    "word": "privacidad",
    "rank": 5421,
    "frequency": 4923,
    "originalRank": 5558
  },
  {
    "word": "pasaré",
    "rank": 5422,
    "frequency": 4921,
    "originalRank": 5560
  },
  {
    "word": "recuperación",
    "rank": 5423,
    "frequency": 4918,
    "originalRank": 5561
  },
  {
    "word": "cuartos",
    "rank": 5424,
    "frequency": 4918,
    "originalRank": 5562
  },
  {
    "word": "semejante",
    "rank": 5425,
    "frequency": 4917,
    "originalRank": 5563
  },
  {
    "word": "sobra",
    "rank": 5426,
    "frequency": 4916,
    "originalRank": 5564
  },
  {
    "word": "oler",
    "rank": 5427,
    "frequency": 4916,
    "originalRank": 5565
  },
  {
    "word": "presentado",
    "rank": 5428,
    "frequency": 4915,
    "originalRank": 5566
  },
  {
    "word": "basado",
    "rank": 5429,
    "frequency": 4913,
    "originalRank": 5567
  },
  {
    "word": "paro",
    "rank": 5430,
    "frequency": 4912,
    "originalRank": 5568
  },
  {
    "word": "dinos",
    "rank": 5431,
    "frequency": 4912,
    "originalRank": 5569
  },
  {
    "word": "tenerla",
    "rank": 5432,
    "frequency": 4912,
    "originalRank": 5570
  },
  {
    "word": "lawrence",
    "rank": 5433,
    "frequency": 4912,
    "originalRank": 5571
  },
  {
    "word": "andrea",
    "rank": 5434,
    "frequency": 4910,
    "originalRank": 5572
  },
  {
    "word": "modelos",
    "rank": 5435,
    "frequency": 4908,
    "originalRank": 5573
  },
  {
    "word": "pida",
    "rank": 5436,
    "frequency": 4906,
    "originalRank": 5574
  },
  {
    "word": "saluda",
    "rank": 5437,
    "frequency": 4906,
    "originalRank": 5575
  },
  {
    "word": "dejadme",
    "rank": 5438,
    "frequency": 4904,
    "originalRank": 5576
  },
  {
    "word": "comí",
    "rank": 5439,
    "frequency": 4903,
    "originalRank": 5577
  },
  {
    "word": "nido",
    "rank": 5440,
    "frequency": 4900,
    "originalRank": 5578
  },
  {
    "word": "curtis",
    "rank": 5441,
    "frequency": 4898,
    "originalRank": 5579
  },
  {
    "word": "plataforma",
    "rank": 5442,
    "frequency": 4897,
    "originalRank": 5580
  },
  {
    "word": "benny",
    "rank": 5443,
    "frequency": 4893,
    "originalRank": 5581
  },
  {
    "word": "booth",
    "rank": 5444,
    "frequency": 4889,
    "originalRank": 5582
  },
  {
    "word": "pam",
    "rank": 5445,
    "frequency": 4889,
    "originalRank": 5583
  },
  {
    "word": "afortunadamente",
    "rank": 5446,
    "frequency": 4888,
    "originalRank": 5584
  },
  {
    "word": "entran",
    "rank": 5447,
    "frequency": 4887,
    "originalRank": 5585
  },
  {
    "word": "pagué",
    "rank": 5448,
    "frequency": 4887,
    "originalRank": 5586
  },
  {
    "word": "objeción",
    "rank": 5449,
    "frequency": 4885,
    "originalRank": 5587
  },
  {
    "word": "reconoces",
    "rank": 5450,
    "frequency": 4885,
    "originalRank": 5588
  },
  {
    "word": "clan",
    "rank": 5451,
    "frequency": 4884,
    "originalRank": 5589
  },
  {
    "word": "chance",
    "rank": 5452,
    "frequency": 4884,
    "originalRank": 5590
  },
  {
    "word": "tokio",
    "rank": 5453,
    "frequency": 4881,
    "originalRank": 5591
  },
  {
    "word": "preguntaste",
    "rank": 5454,
    "frequency": 4879,
    "originalRank": 5592
  },
  {
    "word": "vital",
    "rank": 5455,
    "frequency": 4879,
    "originalRank": 5593
  },
  {
    "word": "vanessa",
    "rank": 5456,
    "frequency": 4879,
    "originalRank": 5594
  },
  {
    "word": "vinieras",
    "rank": 5457,
    "frequency": 4878,
    "originalRank": 5595
  },
  {
    "word": "pañuelo",
    "rank": 5458,
    "frequency": 4877,
    "originalRank": 5596
  },
  {
    "word": "preso",
    "rank": 5459,
    "frequency": 4877,
    "originalRank": 5597
  },
  {
    "word": "durar",
    "rank": 5460,
    "frequency": 4876,
    "originalRank": 5598
  },
  {
    "word": "llevarnos",
    "rank": 5461,
    "frequency": 4876,
    "originalRank": 5599
  },
  {
    "word": "esperé",
    "rank": 5462,
    "frequency": 4875,
    "originalRank": 5600
  },
  {
    "word": "trampas",
    "rank": 5463,
    "frequency": 4875,
    "originalRank": 5601
  },
  {
    "word": "quedaron",
    "rank": 5464,
    "frequency": 4875,
    "originalRank": 5602
  },
  {
    "word": "ned",
    "rank": 5465,
    "frequency": 4874,
    "originalRank": 5603
  },
  {
    "word": "saludar",
    "rank": 5466,
    "frequency": 4874,
    "originalRank": 5604
  },
  {
    "word": "prométeme",
    "rank": 5467,
    "frequency": 4872,
    "originalRank": 5605
  },
  {
    "word": "caen",
    "rank": 5468,
    "frequency": 4871,
    "originalRank": 5606
  },
  {
    "word": "franklin",
    "rank": 5469,
    "frequency": 4868,
    "originalRank": 5607
  },
  {
    "word": "halloween",
    "rank": 5470,
    "frequency": 4868,
    "originalRank": 5608
  },
  {
    "word": "donald",
    "rank": 5471,
    "frequency": 4868,
    "originalRank": 5609
  },
  {
    "word": "aguarda",
    "rank": 5472,
    "frequency": 4867,
    "originalRank": 5610
  },
  {
    "word": "causó",
    "rank": 5473,
    "frequency": 4867,
    "originalRank": 5611
  },
  {
    "word": "darás",
    "rank": 5474,
    "frequency": 4867,
    "originalRank": 5612
  },
  {
    "word": "niebla",
    "rank": 5475,
    "frequency": 4865,
    "originalRank": 5613
  },
  {
    "word": "psicópata",
    "rank": 5476,
    "frequency": 4865,
    "originalRank": 5614
  },
  {
    "word": "rodeado",
    "rank": 5477,
    "frequency": 4863,
    "originalRank": 5615
  },
  {
    "word": "invitar",
    "rank": 5478,
    "frequency": 4861,
    "originalRank": 5616
  },
  {
    "word": "cal",
    "rank": 5479,
    "frequency": 4861,
    "originalRank": 5617
  },
  {
    "word": "escucharlo",
    "rank": 5480,
    "frequency": 4859,
    "originalRank": 5618
  },
  {
    "word": "culpo",
    "rank": 5481,
    "frequency": 4856,
    "originalRank": 5619
  },
  {
    "word": "vamonos",
    "rank": 5482,
    "frequency": 4856,
    "originalRank": 5620
  },
  {
    "word": "colgado",
    "rank": 5483,
    "frequency": 4856,
    "originalRank": 5621
  },
  {
    "word": "goma",
    "rank": 5484,
    "frequency": 4855,
    "originalRank": 5622
  },
  {
    "word": "talla",
    "rank": 5485,
    "frequency": 4854,
    "originalRank": 5623
  },
  {
    "word": "oración",
    "rank": 5486,
    "frequency": 4852,
    "originalRank": 5624
  },
  {
    "word": "turner",
    "rank": 5487,
    "frequency": 4851,
    "originalRank": 5625
  },
  {
    "word": "acércate",
    "rank": 5488,
    "frequency": 4851,
    "originalRank": 5626
  },
  {
    "word": "tomemos",
    "rank": 5489,
    "frequency": 4850,
    "originalRank": 5627
  },
  {
    "word": "maestros",
    "rank": 5490,
    "frequency": 4850,
    "originalRank": 5628
  },
  {
    "word": "cómplice",
    "rank": 5491,
    "frequency": 4849,
    "originalRank": 5629
  },
  {
    "word": "cercana",
    "rank": 5492,
    "frequency": 4847,
    "originalRank": 5630
  },
  {
    "word": "preguntan",
    "rank": 5493,
    "frequency": 4843,
    "originalRank": 5631
  },
  {
    "word": "preocupas",
    "rank": 5494,
    "frequency": 4842,
    "originalRank": 5632
  },
  {
    "word": "saldré",
    "rank": 5495,
    "frequency": 4842,
    "originalRank": 5633
  },
  {
    "word": "licor",
    "rank": 5496,
    "frequency": 4841,
    "originalRank": 5634
  },
  {
    "word": "llevara",
    "rank": 5497,
    "frequency": 4841,
    "originalRank": 5635
  },
  {
    "word": "teme",
    "rank": 5498,
    "frequency": 4841,
    "originalRank": 5636
  },
  {
    "word": "ídolo",
    "rank": 5499,
    "frequency": 4840,
    "originalRank": 5637
  },
  {
    "word": "sindicato",
    "rank": 5500,
    "frequency": 4840,
    "originalRank": 5638
  },
  {
    "word": "fallado",
    "rank": 5501,
    "frequency": 4837,
    "originalRank": 5639
  },
  {
    "word": "crane",
    "rank": 5502,
    "frequency": 4837,
    "originalRank": 5640
  },
  {
    "word": "usé",
    "rank": 5503,
    "frequency": 4836,
    "originalRank": 5641
  },
  {
    "word": "simpson",
    "rank": 5504,
    "frequency": 4835,
    "originalRank": 5642
  },
  {
    "word": "globo",
    "rank": 5505,
    "frequency": 4834,
    "originalRank": 5643
  },
  {
    "word": "blancas",
    "rank": 5506,
    "frequency": 4834,
    "originalRank": 5644
  },
  {
    "word": "audición",
    "rank": 5507,
    "frequency": 4833,
    "originalRank": 5645
  },
  {
    "word": "vigilar",
    "rank": 5508,
    "frequency": 4831,
    "originalRank": 5646
  },
  {
    "word": "almohada",
    "rank": 5509,
    "frequency": 4830,
    "originalRank": 5647
  },
  {
    "word": "oido",
    "rank": 5510,
    "frequency": 4825,
    "originalRank": 5648
  },
  {
    "word": "rehabilitación",
    "rank": 5511,
    "frequency": 4825,
    "originalRank": 5649
  },
  {
    "word": "increible",
    "rank": 5512,
    "frequency": 4825,
    "originalRank": 5650
  },
  {
    "word": "galaxia",
    "rank": 5513,
    "frequency": 4823,
    "originalRank": 5651
  },
  {
    "word": "long",
    "rank": 5514,
    "frequency": 4822,
    "originalRank": 5652
  },
  {
    "word": "curar",
    "rank": 5515,
    "frequency": 4820,
    "originalRank": 5653
  },
  {
    "word": "elefante",
    "rank": 5516,
    "frequency": 4818,
    "originalRank": 5654
  },
  {
    "word": "robé",
    "rank": 5517,
    "frequency": 4818,
    "originalRank": 5655
  },
  {
    "word": "guardián",
    "rank": 5518,
    "frequency": 4818,
    "originalRank": 5656
  },
  {
    "word": "investigaciones",
    "rank": 5519,
    "frequency": 4817,
    "originalRank": 5657
  },
  {
    "word": "fuéramos",
    "rank": 5520,
    "frequency": 4816,
    "originalRank": 5658
  },
  {
    "word": "tejido",
    "rank": 5521,
    "frequency": 4815,
    "originalRank": 5659
  },
  {
    "word": "muñecas",
    "rank": 5522,
    "frequency": 4813,
    "originalRank": 5660
  },
  {
    "word": "llamaría",
    "rank": 5523,
    "frequency": 4813,
    "originalRank": 5661
  },
  {
    "word": "anderson",
    "rank": 5524,
    "frequency": 4812,
    "originalRank": 5662
  },
  {
    "word": "atacado",
    "rank": 5525,
    "frequency": 4812,
    "originalRank": 5663
  },
  {
    "word": "vagina",
    "rank": 5526,
    "frequency": 4809,
    "originalRank": 5664
  },
  {
    "word": "samantha",
    "rank": 5527,
    "frequency": 4808,
    "originalRank": 5665
  },
  {
    "word": "levantado",
    "rank": 5528,
    "frequency": 4805,
    "originalRank": 5666
  },
  {
    "word": "tabla",
    "rank": 5529,
    "frequency": 4804,
    "originalRank": 5667
  },
  {
    "word": "monos",
    "rank": 5530,
    "frequency": 4803,
    "originalRank": 5668
  },
  {
    "word": "escudo",
    "rank": 5531,
    "frequency": 4802,
    "originalRank": 5669
  },
  {
    "word": "extranjeros",
    "rank": 5532,
    "frequency": 4802,
    "originalRank": 5670
  },
  {
    "word": "denise",
    "rank": 5533,
    "frequency": 4800,
    "originalRank": 5671
  },
  {
    "word": "bañera",
    "rank": 5534,
    "frequency": 4795,
    "originalRank": 5672
  },
  {
    "word": "pop",
    "rank": 5535,
    "frequency": 4795,
    "originalRank": 5673
  },
  {
    "word": "ayudarlos",
    "rank": 5536,
    "frequency": 4794,
    "originalRank": 5674
  },
  {
    "word": "moderna",
    "rank": 5537,
    "frequency": 4793,
    "originalRank": 5675
  },
  {
    "word": "blue",
    "rank": 5538,
    "frequency": 4793,
    "originalRank": 5676
  },
  {
    "word": "interrogatorio",
    "rank": 5539,
    "frequency": 4792,
    "originalRank": 5677
  },
  {
    "word": "rapido",
    "rank": 5540,
    "frequency": 4788,
    "originalRank": 5678
  },
  {
    "word": "merecen",
    "rank": 5541,
    "frequency": 4787,
    "originalRank": 5679
  },
  {
    "word": "bonitos",
    "rank": 5542,
    "frequency": 4787,
    "originalRank": 5680
  },
  {
    "word": "angel",
    "rank": 5543,
    "frequency": 4786,
    "originalRank": 5681
  },
  {
    "word": "woo",
    "rank": 5544,
    "frequency": 4782,
    "originalRank": 5683
  },
  {
    "word": "brasil",
    "rank": 5545,
    "frequency": 4782,
    "originalRank": 5684
  },
  {
    "word": "freddie",
    "rank": 5546,
    "frequency": 4780,
    "originalRank": 5685
  },
  {
    "word": "asistencia",
    "rank": 5547,
    "frequency": 4779,
    "originalRank": 5686
  },
  {
    "word": "pagará",
    "rank": 5548,
    "frequency": 4779,
    "originalRank": 5687
  },
  {
    "word": "novato",
    "rank": 5549,
    "frequency": 4779,
    "originalRank": 5688
  },
  {
    "word": "avisar",
    "rank": 5550,
    "frequency": 4778,
    "originalRank": 5689
  },
  {
    "word": "hemorragia",
    "rank": 5551,
    "frequency": 4778,
    "originalRank": 5690
  },
  {
    "word": "conviene",
    "rank": 5552,
    "frequency": 4777,
    "originalRank": 5691
  },
  {
    "word": "ajá",
    "rank": 5553,
    "frequency": 4776,
    "originalRank": 5692
  },
  {
    "word": "perrito",
    "rank": 5554,
    "frequency": 4775,
    "originalRank": 5693
  },
  {
    "word": "créame",
    "rank": 5555,
    "frequency": 4774,
    "originalRank": 5694
  },
  {
    "word": "olas",
    "rank": 5556,
    "frequency": 4774,
    "originalRank": 5695
  },
  {
    "word": "sabré",
    "rank": 5557,
    "frequency": 4773,
    "originalRank": 5696
  },
  {
    "word": "caí",
    "rank": 5558,
    "frequency": 4770,
    "originalRank": 5697
  },
  {
    "word": "manejarlo",
    "rank": 5559,
    "frequency": 4765,
    "originalRank": 5698
  },
  {
    "word": "fenómeno",
    "rank": 5560,
    "frequency": 4763,
    "originalRank": 5699
  },
  {
    "word": "quejas",
    "rank": 5561,
    "frequency": 4763,
    "originalRank": 5700
  },
  {
    "word": "coca",
    "rank": 5562,
    "frequency": 4762,
    "originalRank": 5701
  },
  {
    "word": "persiguiendo",
    "rank": 5563,
    "frequency": 4762,
    "originalRank": 5702
  },
  {
    "word": "lotería",
    "rank": 5564,
    "frequency": 4760,
    "originalRank": 5703
  },
  {
    "word": "acerques",
    "rank": 5565,
    "frequency": 4759,
    "originalRank": 5704
  },
  {
    "word": "certificado",
    "rank": 5566,
    "frequency": 4758,
    "originalRank": 5705
  },
  {
    "word": "bigote",
    "rank": 5567,
    "frequency": 4757,
    "originalRank": 5706
  },
  {
    "word": "aca",
    "rank": 5568,
    "frequency": 4756,
    "originalRank": 5707
  },
  {
    "word": "bondad",
    "rank": 5569,
    "frequency": 4756,
    "originalRank": 5708
  },
  {
    "word": "aterrizar",
    "rank": 5570,
    "frequency": 4756,
    "originalRank": 5709
  },
  {
    "word": "misiles",
    "rank": 5571,
    "frequency": 4754,
    "originalRank": 5710
  },
  {
    "word": "planos",
    "rank": 5572,
    "frequency": 4753,
    "originalRank": 5711
  },
  {
    "word": "despierte",
    "rank": 5573,
    "frequency": 4752,
    "originalRank": 5712
  },
  {
    "word": "despedirme",
    "rank": 5574,
    "frequency": 4751,
    "originalRank": 5713
  },
  {
    "word": "connie",
    "rank": 5575,
    "frequency": 4751,
    "originalRank": 5714
  },
  {
    "word": "avance",
    "rank": 5576,
    "frequency": 4750,
    "originalRank": 5715
  },
  {
    "word": "sacarme",
    "rank": 5577,
    "frequency": 4747,
    "originalRank": 5716
  },
  {
    "word": "prepárense",
    "rank": 5578,
    "frequency": 4747,
    "originalRank": 5717
  },
  {
    "word": "tumor",
    "rank": 5579,
    "frequency": 4745,
    "originalRank": 5718
  },
  {
    "word": "camarera",
    "rank": 5580,
    "frequency": 4745,
    "originalRank": 5719
  },
  {
    "word": "herencia",
    "rank": 5581,
    "frequency": 4742,
    "originalRank": 5720
  },
  {
    "word": "vaquero",
    "rank": 5582,
    "frequency": 4741,
    "originalRank": 5721
  },
  {
    "word": "trenes",
    "rank": 5583,
    "frequency": 4741,
    "originalRank": 5722
  },
  {
    "word": "largos",
    "rank": 5584,
    "frequency": 4739,
    "originalRank": 5723
  },
  {
    "word": "patria",
    "rank": 5585,
    "frequency": 4738,
    "originalRank": 5724
  },
  {
    "word": "ponía",
    "rank": 5586,
    "frequency": 4738,
    "originalRank": 5725
  },
  {
    "word": "enviando",
    "rank": 5587,
    "frequency": 4738,
    "originalRank": 5726
  },
  {
    "word": "apagado",
    "rank": 5588,
    "frequency": 4737,
    "originalRank": 5727
  },
  {
    "word": "rastrear",
    "rank": 5589,
    "frequency": 4735,
    "originalRank": 5728
  },
  {
    "word": "acababa",
    "rank": 5590,
    "frequency": 4734,
    "originalRank": 5729
  },
  {
    "word": "campeonato",
    "rank": 5591,
    "frequency": 4734,
    "originalRank": 5730
  },
  {
    "word": "técnico",
    "rank": 5592,
    "frequency": 4733,
    "originalRank": 5731
  },
  {
    "word": "injusto",
    "rank": 5593,
    "frequency": 4731,
    "originalRank": 5732
  },
  {
    "word": "activo",
    "rank": 5594,
    "frequency": 4730,
    "originalRank": 5733
  },
  {
    "word": "pesadillas",
    "rank": 5595,
    "frequency": 4730,
    "originalRank": 5734
  },
  {
    "word": "galería",
    "rank": 5596,
    "frequency": 4728,
    "originalRank": 5735
  },
  {
    "word": "drew",
    "rank": 5597,
    "frequency": 4726,
    "originalRank": 5736
  },
  {
    "word": "sacando",
    "rank": 5598,
    "frequency": 4724,
    "originalRank": 5737
  },
  {
    "word": "vió",
    "rank": 5599,
    "frequency": 4723,
    "originalRank": 5738
  },
  {
    "word": "tanques",
    "rank": 5600,
    "frequency": 4722,
    "originalRank": 5739
  },
  {
    "word": "enseña",
    "rank": 5601,
    "frequency": 4721,
    "originalRank": 5740
  },
  {
    "word": "editor",
    "rank": 5602,
    "frequency": 4721,
    "originalRank": 5741
  },
  {
    "word": "liberación",
    "rank": 5603,
    "frequency": 4720,
    "originalRank": 5742
  },
  {
    "word": "interesantes",
    "rank": 5604,
    "frequency": 4719,
    "originalRank": 5743
  },
  {
    "word": "comenzaron",
    "rank": 5605,
    "frequency": 4719,
    "originalRank": 5744
  },
  {
    "word": "quinta",
    "rank": 5606,
    "frequency": 4717,
    "originalRank": 5745
  },
  {
    "word": "levante",
    "rank": 5607,
    "frequency": 4716,
    "originalRank": 5746
  },
  {
    "word": "pesa",
    "rank": 5608,
    "frequency": 4713,
    "originalRank": 5747
  },
  {
    "word": "responda",
    "rank": 5609,
    "frequency": 4713,
    "originalRank": 5748
  },
  {
    "word": "lance",
    "rank": 5610,
    "frequency": 4711,
    "originalRank": 5749
  },
  {
    "word": "pondría",
    "rank": 5611,
    "frequency": 4711,
    "originalRank": 5750
  },
  {
    "word": "resistir",
    "rank": 5612,
    "frequency": 4709,
    "originalRank": 5751
  },
  {
    "word": "hueles",
    "rank": 5613,
    "frequency": 4709,
    "originalRank": 5752
  },
  {
    "word": "bajen",
    "rank": 5614,
    "frequency": 4709,
    "originalRank": 5753
  },
  {
    "word": "hermosos",
    "rank": 5615,
    "frequency": 4708,
    "originalRank": 5754
  },
  {
    "word": "arriesgado",
    "rank": 5616,
    "frequency": 4707,
    "originalRank": 5755
  },
  {
    "word": "mueres",
    "rank": 5617,
    "frequency": 4707,
    "originalRank": 5756
  },
  {
    "word": "duke",
    "rank": 5618,
    "frequency": 4707,
    "originalRank": 5757
  },
  {
    "word": "agallas",
    "rank": 5619,
    "frequency": 4707,
    "originalRank": 5758
  },
  {
    "word": "verlas",
    "rank": 5620,
    "frequency": 4706,
    "originalRank": 5759
  },
  {
    "word": "sentirlo",
    "rank": 5621,
    "frequency": 4706,
    "originalRank": 5760
  },
  {
    "word": "faltaba",
    "rank": 5622,
    "frequency": 4706,
    "originalRank": 5761
  },
  {
    "word": "cindy",
    "rank": 5623,
    "frequency": 4706,
    "originalRank": 5762
  },
  {
    "word": "armados",
    "rank": 5624,
    "frequency": 4705,
    "originalRank": 5763
  },
  {
    "word": "volumen",
    "rank": 5625,
    "frequency": 4705,
    "originalRank": 5764
  },
  {
    "word": "hunter",
    "rank": 5626,
    "frequency": 4705,
    "originalRank": 5765
  },
  {
    "word": "bailarina",
    "rank": 5627,
    "frequency": 4705,
    "originalRank": 5766
  },
  {
    "word": "huyó",
    "rank": 5628,
    "frequency": 4704,
    "originalRank": 5767
  },
  {
    "word": "edición",
    "rank": 5629,
    "frequency": 4704,
    "originalRank": 5768
  },
  {
    "word": "atreve",
    "rank": 5630,
    "frequency": 4704,
    "originalRank": 5769
  },
  {
    "word": "ganan",
    "rank": 5631,
    "frequency": 4704,
    "originalRank": 5770
  },
  {
    "word": "debate",
    "rank": 5632,
    "frequency": 4704,
    "originalRank": 5771
  },
  {
    "word": "cables",
    "rank": 5633,
    "frequency": 4703,
    "originalRank": 5772
  },
  {
    "word": "necesitará",
    "rank": 5634,
    "frequency": 4702,
    "originalRank": 5773
  },
  {
    "word": "compraré",
    "rank": 5635,
    "frequency": 4702,
    "originalRank": 5774
  },
  {
    "word": "odian",
    "rank": 5636,
    "frequency": 4702,
    "originalRank": 5775
  },
  {
    "word": "poeta",
    "rank": 5637,
    "frequency": 4698,
    "originalRank": 5776
  },
  {
    "word": "cortes",
    "rank": 5638,
    "frequency": 4696,
    "originalRank": 5777
  },
  {
    "word": "doña",
    "rank": 5639,
    "frequency": 4695,
    "originalRank": 5778
  },
  {
    "word": "manta",
    "rank": 5640,
    "frequency": 4695,
    "originalRank": 5779
  },
  {
    "word": "competir",
    "rank": 5641,
    "frequency": 4695,
    "originalRank": 5780
  },
  {
    "word": "nazis",
    "rank": 5642,
    "frequency": 4693,
    "originalRank": 5781
  },
  {
    "word": "fritas",
    "rank": 5643,
    "frequency": 4693,
    "originalRank": 5782
  },
  {
    "word": "dentista",
    "rank": 5644,
    "frequency": 4693,
    "originalRank": 5783
  },
  {
    "word": "amamos",
    "rank": 5645,
    "frequency": 4692,
    "originalRank": 5784
  },
  {
    "word": "encontraba",
    "rank": 5646,
    "frequency": 4691,
    "originalRank": 5785
  },
  {
    "word": "menú",
    "rank": 5647,
    "frequency": 4691,
    "originalRank": 5786
  },
  {
    "word": "may",
    "rank": 5648,
    "frequency": 4689,
    "originalRank": 5787
  },
  {
    "word": "necesariamente",
    "rank": 5649,
    "frequency": 4688,
    "originalRank": 5788
  },
  {
    "word": "negras",
    "rank": 5650,
    "frequency": 4688,
    "originalRank": 5789
  },
  {
    "word": "descubrimiento",
    "rank": 5651,
    "frequency": 4687,
    "originalRank": 5790
  },
  {
    "word": "organizado",
    "rank": 5652,
    "frequency": 4685,
    "originalRank": 5791
  },
  {
    "word": "apetito",
    "rank": 5653,
    "frequency": 4685,
    "originalRank": 5792
  },
  {
    "word": "cameron",
    "rank": 5654,
    "frequency": 4681,
    "originalRank": 5793
  },
  {
    "word": "traen",
    "rank": 5655,
    "frequency": 4681,
    "originalRank": 5794
  },
  {
    "word": "muriera",
    "rank": 5656,
    "frequency": 4680,
    "originalRank": 5795
  },
  {
    "word": "visual",
    "rank": 5657,
    "frequency": 4679,
    "originalRank": 5796
  },
  {
    "word": "acostado",
    "rank": 5658,
    "frequency": 4677,
    "originalRank": 5797
  },
  {
    "word": "ángulo",
    "rank": 5659,
    "frequency": 4673,
    "originalRank": 5798
  },
  {
    "word": "inferior",
    "rank": 5660,
    "frequency": 4671,
    "originalRank": 5799
  },
  {
    "word": "sydney",
    "rank": 5661,
    "frequency": 4671,
    "originalRank": 5800
  },
  {
    "word": "incapaz",
    "rank": 5662,
    "frequency": 4670,
    "originalRank": 5801
  },
  {
    "word": "volante",
    "rank": 5663,
    "frequency": 4670,
    "originalRank": 5802
  },
  {
    "word": "sierra",
    "rank": 5664,
    "frequency": 4669,
    "originalRank": 5803
  },
  {
    "word": "probando",
    "rank": 5665,
    "frequency": 4668,
    "originalRank": 5804
  },
  {
    "word": "distinta",
    "rank": 5666,
    "frequency": 4667,
    "originalRank": 5805
  },
  {
    "word": "sentiría",
    "rank": 5667,
    "frequency": 4665,
    "originalRank": 5806
  },
  {
    "word": "abuso",
    "rank": 5668,
    "frequency": 4663,
    "originalRank": 5807
  },
  {
    "word": "celebración",
    "rank": 5669,
    "frequency": 4663,
    "originalRank": 5808
  },
  {
    "word": "diente",
    "rank": 5670,
    "frequency": 4663,
    "originalRank": 5809
  },
  {
    "word": "tuyas",
    "rank": 5671,
    "frequency": 4663,
    "originalRank": 5810
  },
  {
    "word": "humilde",
    "rank": 5672,
    "frequency": 4660,
    "originalRank": 5811
  },
  {
    "word": "discutiendo",
    "rank": 5673,
    "frequency": 4659,
    "originalRank": 5812
  },
  {
    "word": "gene",
    "rank": 5674,
    "frequency": 4659,
    "originalRank": 5813
  },
  {
    "word": "suicidó",
    "rank": 5675,
    "frequency": 4659,
    "originalRank": 5814
  },
  {
    "word": "disposición",
    "rank": 5676,
    "frequency": 4658,
    "originalRank": 5815
  },
  {
    "word": "conversaciones",
    "rank": 5677,
    "frequency": 4658,
    "originalRank": 5816
  },
  {
    "word": "lámpara",
    "rank": 5678,
    "frequency": 4655,
    "originalRank": 5817
  },
  {
    "word": "sabrán",
    "rank": 5679,
    "frequency": 4655,
    "originalRank": 5818
  },
  {
    "word": "métodos",
    "rank": 5680,
    "frequency": 4654,
    "originalRank": 5819
  },
  {
    "word": "marcos",
    "rank": 5681,
    "frequency": 4652,
    "originalRank": 5820
  },
  {
    "word": "huéspedes",
    "rank": 5682,
    "frequency": 4651,
    "originalRank": 5821
  },
  {
    "word": "crean",
    "rank": 5683,
    "frequency": 4651,
    "originalRank": 5822
  },
  {
    "word": "preocupen",
    "rank": 5684,
    "frequency": 4650,
    "originalRank": 5823
  },
  {
    "word": "direcciones",
    "rank": 5685,
    "frequency": 4650,
    "originalRank": 5824
  },
  {
    "word": "baker",
    "rank": 5686,
    "frequency": 4649,
    "originalRank": 5825
  },
  {
    "word": "planetas",
    "rank": 5687,
    "frequency": 4648,
    "originalRank": 5826
  },
  {
    "word": "determinar",
    "rank": 5688,
    "frequency": 4648,
    "originalRank": 5827
  },
  {
    "word": "condesa",
    "rank": 5689,
    "frequency": 4647,
    "originalRank": 5828
  },
  {
    "word": "ópera",
    "rank": 5690,
    "frequency": 4647,
    "originalRank": 5829
  },
  {
    "word": "corten",
    "rank": 5691,
    "frequency": 4646,
    "originalRank": 5830
  },
  {
    "word": "peligrosos",
    "rank": 5692,
    "frequency": 4643,
    "originalRank": 5831
  },
  {
    "word": "asesinados",
    "rank": 5693,
    "frequency": 4642,
    "originalRank": 5832
  },
  {
    "word": "joy",
    "rank": 5694,
    "frequency": 4641,
    "originalRank": 5833
  },
  {
    "word": "medicinas",
    "rank": 5695,
    "frequency": 4640,
    "originalRank": 5834
  },
  {
    "word": "rory",
    "rank": 5696,
    "frequency": 4639,
    "originalRank": 5835
  },
  {
    "word": "mansión",
    "rank": 5697,
    "frequency": 4636,
    "originalRank": 5836
  },
  {
    "word": "torres",
    "rank": 5698,
    "frequency": 4636,
    "originalRank": 5837
  },
  {
    "word": "lecciones",
    "rank": 5699,
    "frequency": 4634,
    "originalRank": 5838
  },
  {
    "word": "sentirte",
    "rank": 5700,
    "frequency": 4634,
    "originalRank": 5839
  },
  {
    "word": "comprando",
    "rank": 5701,
    "frequency": 4634,
    "originalRank": 5840
  },
  {
    "word": "equilibrio",
    "rank": 5702,
    "frequency": 4634,
    "originalRank": 5841
  },
  {
    "word": "trevor",
    "rank": 5703,
    "frequency": 4633,
    "originalRank": 5842
  },
  {
    "word": "lograrlo",
    "rank": 5704,
    "frequency": 4632,
    "originalRank": 5843
  },
  {
    "word": "culpar",
    "rank": 5705,
    "frequency": 4632,
    "originalRank": 5844
  },
  {
    "word": "sacas",
    "rank": 5706,
    "frequency": 4631,
    "originalRank": 5845
  },
  {
    "word": "crecí",
    "rank": 5707,
    "frequency": 4630,
    "originalRank": 5846
  },
  {
    "word": "certeza",
    "rank": 5708,
    "frequency": 4629,
    "originalRank": 5847
  },
  {
    "word": "observar",
    "rank": 5709,
    "frequency": 4629,
    "originalRank": 5848
  },
  {
    "word": "molestando",
    "rank": 5710,
    "frequency": 4625,
    "originalRank": 5849
  },
  {
    "word": "supervivencia",
    "rank": 5711,
    "frequency": 4624,
    "originalRank": 5850
  },
  {
    "word": "nacer",
    "rank": 5712,
    "frequency": 4624,
    "originalRank": 5851
  },
  {
    "word": "hechas",
    "rank": 5713,
    "frequency": 4624,
    "originalRank": 5852
  },
  {
    "word": "sacaron",
    "rank": 5714,
    "frequency": 4623,
    "originalRank": 5853
  },
  {
    "word": "olvidas",
    "rank": 5715,
    "frequency": 4617,
    "originalRank": 5855
  },
  {
    "word": "escondiendo",
    "rank": 5716,
    "frequency": 4616,
    "originalRank": 5856
  },
  {
    "word": "can",
    "rank": 5717,
    "frequency": 4616,
    "originalRank": 5857
  },
  {
    "word": "famosos",
    "rank": 5718,
    "frequency": 4616,
    "originalRank": 5858
  },
  {
    "word": "melissa",
    "rank": 5719,
    "frequency": 4616,
    "originalRank": 5859
  },
  {
    "word": "ias",
    "rank": 5720,
    "frequency": 4613,
    "originalRank": 5860
  },
  {
    "word": "aterrizaje",
    "rank": 5721,
    "frequency": 4612,
    "originalRank": 5861
  },
  {
    "word": "girar",
    "rank": 5722,
    "frequency": 4611,
    "originalRank": 5862
  },
  {
    "word": "aceptarlo",
    "rank": 5723,
    "frequency": 4608,
    "originalRank": 5863
  },
  {
    "word": "danza",
    "rank": 5724,
    "frequency": 4608,
    "originalRank": 5864
  },
  {
    "word": "little",
    "rank": 5725,
    "frequency": 4607,
    "originalRank": 5865
  },
  {
    "word": "métete",
    "rank": 5726,
    "frequency": 4607,
    "originalRank": 5866
  },
  {
    "word": "hambriento",
    "rank": 5727,
    "frequency": 4606,
    "originalRank": 5867
  },
  {
    "word": "mates",
    "rank": 5728,
    "frequency": 4605,
    "originalRank": 5868
  },
  {
    "word": "ordenado",
    "rank": 5729,
    "frequency": 4604,
    "originalRank": 5869
  },
  {
    "word": "calcetines",
    "rank": 5730,
    "frequency": 4603,
    "originalRank": 5870
  },
  {
    "word": "confuso",
    "rank": 5731,
    "frequency": 4603,
    "originalRank": 5871
  },
  {
    "word": "enamorados",
    "rank": 5732,
    "frequency": 4601,
    "originalRank": 5872
  },
  {
    "word": "moderno",
    "rank": 5733,
    "frequency": 4600,
    "originalRank": 5874
  },
  {
    "word": "tocas",
    "rank": 5734,
    "frequency": 4600,
    "originalRank": 5875
  },
  {
    "word": "responsables",
    "rank": 5735,
    "frequency": 4600,
    "originalRank": 5876
  },
  {
    "word": "tabaco",
    "rank": 5736,
    "frequency": 4600,
    "originalRank": 5877
  },
  {
    "word": "registrado",
    "rank": 5737,
    "frequency": 4598,
    "originalRank": 5878
  },
  {
    "word": "balón",
    "rank": 5738,
    "frequency": 4596,
    "originalRank": 5879
  },
  {
    "word": "top",
    "rank": 5739,
    "frequency": 4596,
    "originalRank": 5880
  },
  {
    "word": "boletos",
    "rank": 5740,
    "frequency": 4596,
    "originalRank": 5881
  },
  {
    "word": "lentes",
    "rank": 5741,
    "frequency": 4596,
    "originalRank": 5882
  },
  {
    "word": "consejero",
    "rank": 5742,
    "frequency": 4595,
    "originalRank": 5883
  },
  {
    "word": "chistes",
    "rank": 5743,
    "frequency": 4595,
    "originalRank": 5884
  },
  {
    "word": "guerras",
    "rank": 5744,
    "frequency": 4595,
    "originalRank": 5885
  },
  {
    "word": "sacaré",
    "rank": 5745,
    "frequency": 4592,
    "originalRank": 5886
  },
  {
    "word": "coordenadas",
    "rank": 5746,
    "frequency": 4590,
    "originalRank": 5887
  },
  {
    "word": "vergonzoso",
    "rank": 5747,
    "frequency": 4590,
    "originalRank": 5888
  },
  {
    "word": "distintos",
    "rank": 5748,
    "frequency": 4590,
    "originalRank": 5889
  },
  {
    "word": "fingiendo",
    "rank": 5749,
    "frequency": 4588,
    "originalRank": 5890
  },
  {
    "word": "significaba",
    "rank": 5750,
    "frequency": 4587,
    "originalRank": 5891
  },
  {
    "word": "mensajero",
    "rank": 5751,
    "frequency": 4586,
    "originalRank": 5892
  },
  {
    "word": "judy",
    "rank": 5752,
    "frequency": 4584,
    "originalRank": 5893
  },
  {
    "word": "test",
    "rank": 5753,
    "frequency": 4584,
    "originalRank": 5894
  },
  {
    "word": "cortesía",
    "rank": 5754,
    "frequency": 4584,
    "originalRank": 5895
  },
  {
    "word": "campus",
    "rank": 5755,
    "frequency": 4581,
    "originalRank": 5896
  },
  {
    "word": "compro",
    "rank": 5756,
    "frequency": 4577,
    "originalRank": 5897
  },
  {
    "word": "bingo",
    "rank": 5757,
    "frequency": 4576,
    "originalRank": 5898
  },
  {
    "word": "asumo",
    "rank": 5758,
    "frequency": 4575,
    "originalRank": 5899
  },
  {
    "word": "impulso",
    "rank": 5759,
    "frequency": 4574,
    "originalRank": 5901
  },
  {
    "word": "pensaría",
    "rank": 5760,
    "frequency": 4572,
    "originalRank": 5902
  },
  {
    "word": "venden",
    "rank": 5761,
    "frequency": 4571,
    "originalRank": 5903
  },
  {
    "word": "contratado",
    "rank": 5762,
    "frequency": 4571,
    "originalRank": 5904
  },
  {
    "word": "conozcas",
    "rank": 5763,
    "frequency": 4569,
    "originalRank": 5905
  },
  {
    "word": "utilizando",
    "rank": 5764,
    "frequency": 4569,
    "originalRank": 5906
  },
  {
    "word": "chan",
    "rank": 5765,
    "frequency": 4567,
    "originalRank": 5907
  },
  {
    "word": "propiedades",
    "rank": 5766,
    "frequency": 4566,
    "originalRank": 5908
  },
  {
    "word": "explicaré",
    "rank": 5767,
    "frequency": 4566,
    "originalRank": 5909
  },
  {
    "word": "signo",
    "rank": 5768,
    "frequency": 4566,
    "originalRank": 5910
  },
  {
    "word": "disparando",
    "rank": 5769,
    "frequency": 4564,
    "originalRank": 5911
  },
  {
    "word": "ajedrez",
    "rank": 5770,
    "frequency": 4562,
    "originalRank": 5912
  },
  {
    "word": "aseguraré",
    "rank": 5771,
    "frequency": 4561,
    "originalRank": 5913
  },
  {
    "word": "crítica",
    "rank": 5772,
    "frequency": 4560,
    "originalRank": 5914
  },
  {
    "word": "necesitabas",
    "rank": 5773,
    "frequency": 4560,
    "originalRank": 5915
  },
  {
    "word": "británicos",
    "rank": 5774,
    "frequency": 4559,
    "originalRank": 5916
  },
  {
    "word": "ciega",
    "rank": 5775,
    "frequency": 4558,
    "originalRank": 5917
  },
  {
    "word": "cordero",
    "rank": 5776,
    "frequency": 4557,
    "originalRank": 5918
  },
  {
    "word": "democracia",
    "rank": 5777,
    "frequency": 4555,
    "originalRank": 5919
  },
  {
    "word": "rastros",
    "rank": 5778,
    "frequency": 4548,
    "originalRank": 5920
  },
  {
    "word": "protege",
    "rank": 5779,
    "frequency": 4547,
    "originalRank": 5921
  },
  {
    "word": "papeleo",
    "rank": 5780,
    "frequency": 4546,
    "originalRank": 5922
  },
  {
    "word": "cubo",
    "rank": 5781,
    "frequency": 4545,
    "originalRank": 5923
  },
  {
    "word": "judicial",
    "rank": 5782,
    "frequency": 4544,
    "originalRank": 5924
  },
  {
    "word": "sid",
    "rank": 5783,
    "frequency": 4544,
    "originalRank": 5925
  },
  {
    "word": "masaje",
    "rank": 5784,
    "frequency": 4543,
    "originalRank": 5926
  },
  {
    "word": "beca",
    "rank": 5785,
    "frequency": 4543,
    "originalRank": 5927
  },
  {
    "word": "verse",
    "rank": 5786,
    "frequency": 4542,
    "originalRank": 5928
  },
  {
    "word": "miseria",
    "rank": 5787,
    "frequency": 4542,
    "originalRank": 5929
  },
  {
    "word": "conocías",
    "rank": 5788,
    "frequency": 4540,
    "originalRank": 5930
  },
  {
    "word": "contenido",
    "rank": 5789,
    "frequency": 4540,
    "originalRank": 5931
  },
  {
    "word": "razon",
    "rank": 5790,
    "frequency": 4538,
    "originalRank": 5932
  },
  {
    "word": "sana",
    "rank": 5791,
    "frequency": 4537,
    "originalRank": 5933
  },
  {
    "word": "ritual",
    "rank": 5792,
    "frequency": 4537,
    "originalRank": 5934
  },
  {
    "word": "aliados",
    "rank": 5793,
    "frequency": 4535,
    "originalRank": 5935
  },
  {
    "word": "orina",
    "rank": 5794,
    "frequency": 4534,
    "originalRank": 5936
  },
  {
    "word": "ofender",
    "rank": 5795,
    "frequency": 4532,
    "originalRank": 5937
  },
  {
    "word": "hilo",
    "rank": 5796,
    "frequency": 4531,
    "originalRank": 5938
  },
  {
    "word": "seattle",
    "rank": 5797,
    "frequency": 4530,
    "originalRank": 5939
  },
  {
    "word": "subido",
    "rank": 5798,
    "frequency": 4528,
    "originalRank": 5940
  },
  {
    "word": "eche",
    "rank": 5799,
    "frequency": 4526,
    "originalRank": 5941
  },
  {
    "word": "quedaría",
    "rank": 5800,
    "frequency": 4526,
    "originalRank": 5942
  },
  {
    "word": "enfermería",
    "rank": 5801,
    "frequency": 4526,
    "originalRank": 5943
  },
  {
    "word": "entienda",
    "rank": 5802,
    "frequency": 4526,
    "originalRank": 5944
  },
  {
    "word": "matrícula",
    "rank": 5803,
    "frequency": 4526,
    "originalRank": 5945
  },
  {
    "word": "jung",
    "rank": 5804,
    "frequency": 4526,
    "originalRank": 5946
  },
  {
    "word": "dejarán",
    "rank": 5805,
    "frequency": 4525,
    "originalRank": 5947
  },
  {
    "word": "raya",
    "rank": 5806,
    "frequency": 4522,
    "originalRank": 5949
  },
  {
    "word": "superiores",
    "rank": 5807,
    "frequency": 4521,
    "originalRank": 5950
  },
  {
    "word": "islas",
    "rank": 5808,
    "frequency": 4521,
    "originalRank": 5951
  },
  {
    "word": "dispuestos",
    "rank": 5809,
    "frequency": 4520,
    "originalRank": 5952
  },
  {
    "word": "mascota",
    "rank": 5810,
    "frequency": 4520,
    "originalRank": 5953
  },
  {
    "word": "ascenso",
    "rank": 5811,
    "frequency": 4519,
    "originalRank": 5954
  },
  {
    "word": "comenzando",
    "rank": 5812,
    "frequency": 4517,
    "originalRank": 5955
  },
  {
    "word": "delicado",
    "rank": 5813,
    "frequency": 4516,
    "originalRank": 5956
  },
  {
    "word": "incluye",
    "rank": 5814,
    "frequency": 4516,
    "originalRank": 5957
  },
  {
    "word": "revisa",
    "rank": 5815,
    "frequency": 4515,
    "originalRank": 5958
  },
  {
    "word": "entraron",
    "rank": 5816,
    "frequency": 4515,
    "originalRank": 5959
  },
  {
    "word": "estabamos",
    "rank": 5817,
    "frequency": 4514,
    "originalRank": 5960
  },
  {
    "word": "llevaste",
    "rank": 5818,
    "frequency": 4514,
    "originalRank": 5961
  },
  {
    "word": "duermes",
    "rank": 5819,
    "frequency": 4513,
    "originalRank": 5962
  },
  {
    "word": "neal",
    "rank": 5820,
    "frequency": 4513,
    "originalRank": 5963
  },
  {
    "word": "empuja",
    "rank": 5821,
    "frequency": 4512,
    "originalRank": 5964
  },
  {
    "word": "atado",
    "rank": 5822,
    "frequency": 4512,
    "originalRank": 5965
  },
  {
    "word": "telegrama",
    "rank": 5823,
    "frequency": 4511,
    "originalRank": 5966
  },
  {
    "word": "oir",
    "rank": 5824,
    "frequency": 4509,
    "originalRank": 5967
  },
  {
    "word": "sorprendió",
    "rank": 5825,
    "frequency": 4507,
    "originalRank": 5968
  },
  {
    "word": "christian",
    "rank": 5826,
    "frequency": 4507,
    "originalRank": 5969
  },
  {
    "word": "pegó",
    "rank": 5827,
    "frequency": 4506,
    "originalRank": 5970
  },
  {
    "word": "salvarte",
    "rank": 5828,
    "frequency": 4505,
    "originalRank": 5971
  },
  {
    "word": "deseaba",
    "rank": 5829,
    "frequency": 4505,
    "originalRank": 5972
  },
  {
    "word": "pisos",
    "rank": 5830,
    "frequency": 4503,
    "originalRank": 5973
  },
  {
    "word": "soñar",
    "rank": 5831,
    "frequency": 4503,
    "originalRank": 5974
  },
  {
    "word": "interna",
    "rank": 5832,
    "frequency": 4503,
    "originalRank": 5975
  },
  {
    "word": "avanzar",
    "rank": 5833,
    "frequency": 4499,
    "originalRank": 5976
  },
  {
    "word": "guy",
    "rank": 5834,
    "frequency": 4499,
    "originalRank": 5977
  },
  {
    "word": "mercancía",
    "rank": 5835,
    "frequency": 4499,
    "originalRank": 5978
  },
  {
    "word": "localizar",
    "rank": 5836,
    "frequency": 4497,
    "originalRank": 5979
  },
  {
    "word": "choque",
    "rank": 5837,
    "frequency": 4495,
    "originalRank": 5980
  },
  {
    "word": "desesperada",
    "rank": 5838,
    "frequency": 4495,
    "originalRank": 5981
  },
  {
    "word": "águila",
    "rank": 5839,
    "frequency": 4493,
    "originalRank": 5983
  },
  {
    "word": "rebeldes",
    "rank": 5840,
    "frequency": 4493,
    "originalRank": 5984
  },
  {
    "word": "apunta",
    "rank": 5841,
    "frequency": 4490,
    "originalRank": 5985
  },
  {
    "word": "troy",
    "rank": 5842,
    "frequency": 4490,
    "originalRank": 5986
  },
  {
    "word": "líquido",
    "rank": 5843,
    "frequency": 4489,
    "originalRank": 5987
  },
  {
    "word": "llegaré",
    "rank": 5844,
    "frequency": 4488,
    "originalRank": 5988
  },
  {
    "word": "rompí",
    "rank": 5845,
    "frequency": 4488,
    "originalRank": 5989
  },
  {
    "word": "dispararle",
    "rank": 5846,
    "frequency": 4486,
    "originalRank": 5990
  },
  {
    "word": "bailey",
    "rank": 5847,
    "frequency": 4485,
    "originalRank": 5991
  },
  {
    "word": "jodas",
    "rank": 5848,
    "frequency": 4485,
    "originalRank": 5992
  },
  {
    "word": "carbón",
    "rank": 5849,
    "frequency": 4485,
    "originalRank": 5993
  },
  {
    "word": "regresé",
    "rank": 5850,
    "frequency": 4484,
    "originalRank": 5994
  },
  {
    "word": "secuestrado",
    "rank": 5851,
    "frequency": 4482,
    "originalRank": 5995
  },
  {
    "word": "aprendiendo",
    "rank": 5852,
    "frequency": 4482,
    "originalRank": 5996
  },
  {
    "word": "sandra",
    "rank": 5853,
    "frequency": 4480,
    "originalRank": 5997
  },
  {
    "word": "ayúdeme",
    "rank": 5854,
    "frequency": 4480,
    "originalRank": 5998
  },
  {
    "word": "cocinero",
    "rank": 5855,
    "frequency": 4479,
    "originalRank": 5999
  },
  {
    "word": "quitarme",
    "rank": 5856,
    "frequency": 4479,
    "originalRank": 6000
  },
  {
    "word": "entraste",
    "rank": 5857,
    "frequency": 4479,
    "originalRank": 6001
  },
  {
    "word": "katherine",
    "rank": 5858,
    "frequency": 4478,
    "originalRank": 6002
  },
  {
    "word": "medicación",
    "rank": 5859,
    "frequency": 4477,
    "originalRank": 6003
  },
  {
    "word": "baños",
    "rank": 5860,
    "frequency": 4474,
    "originalRank": 6004
  },
  {
    "word": "creías",
    "rank": 5861,
    "frequency": 4474,
    "originalRank": 6005
  },
  {
    "word": "ácido",
    "rank": 5862,
    "frequency": 4472,
    "originalRank": 6006
  },
  {
    "word": "agresión",
    "rank": 5863,
    "frequency": 4472,
    "originalRank": 6007
  },
  {
    "word": "lex",
    "rank": 5864,
    "frequency": 4472,
    "originalRank": 6008
  },
  {
    "word": "consulta",
    "rank": 5865,
    "frequency": 4470,
    "originalRank": 6009
  },
  {
    "word": "nicky",
    "rank": 5866,
    "frequency": 4469,
    "originalRank": 6010
  },
  {
    "word": "alison",
    "rank": 5867,
    "frequency": 4467,
    "originalRank": 6011
  },
  {
    "word": "jan",
    "rank": 5868,
    "frequency": 4467,
    "originalRank": 6012
  },
  {
    "word": "detenerme",
    "rank": 5869,
    "frequency": 4466,
    "originalRank": 6013
  },
  {
    "word": "órganos",
    "rank": 5870,
    "frequency": 4464,
    "originalRank": 6014
  },
  {
    "word": "zach",
    "rank": 5871,
    "frequency": 4464,
    "originalRank": 6015
  },
  {
    "word": "situaciones",
    "rank": 5872,
    "frequency": 4464,
    "originalRank": 6016
  },
  {
    "word": "barro",
    "rank": 5873,
    "frequency": 4462,
    "originalRank": 6017
  },
  {
    "word": "jódete",
    "rank": 5874,
    "frequency": 4462,
    "originalRank": 6018
  },
  {
    "word": "jazz",
    "rank": 5875,
    "frequency": 4461,
    "originalRank": 6019
  },
  {
    "word": "debamos",
    "rank": 5876,
    "frequency": 4460,
    "originalRank": 6020
  },
  {
    "word": "amber",
    "rank": 5877,
    "frequency": 4459,
    "originalRank": 6021
  },
  {
    "word": "cleveland",
    "rank": 5878,
    "frequency": 4458,
    "originalRank": 6022
  },
  {
    "word": "múltiples",
    "rank": 5879,
    "frequency": 4456,
    "originalRank": 6023
  },
  {
    "word": "cuentan",
    "rank": 5880,
    "frequency": 4456,
    "originalRank": 6024
  },
  {
    "word": "apártate",
    "rank": 5881,
    "frequency": 4454,
    "originalRank": 6025
  },
  {
    "word": "cretino",
    "rank": 5882,
    "frequency": 4453,
    "originalRank": 6026
  },
  {
    "word": "brooke",
    "rank": 5883,
    "frequency": 4452,
    "originalRank": 6027
  },
  {
    "word": "gays",
    "rank": 5884,
    "frequency": 4451,
    "originalRank": 6028
  },
  {
    "word": "obtuvo",
    "rank": 5885,
    "frequency": 4451,
    "originalRank": 6029
  },
  {
    "word": "min",
    "rank": 5886,
    "frequency": 4451,
    "originalRank": 6030
  },
  {
    "word": "drake",
    "rank": 5887,
    "frequency": 4450,
    "originalRank": 6031
  },
  {
    "word": "multa",
    "rank": 5888,
    "frequency": 4450,
    "originalRank": 6032
  },
  {
    "word": "anillos",
    "rank": 5889,
    "frequency": 4449,
    "originalRank": 6033
  },
  {
    "word": "kirk",
    "rank": 5890,
    "frequency": 4448,
    "originalRank": 6034
  },
  {
    "word": "quedara",
    "rank": 5891,
    "frequency": 4447,
    "originalRank": 6035
  },
  {
    "word": "claudia",
    "rank": 5892,
    "frequency": 4446,
    "originalRank": 6036
  },
  {
    "word": "hacerles",
    "rank": 5893,
    "frequency": 4446,
    "originalRank": 6037
  },
  {
    "word": "trabajador",
    "rank": 5894,
    "frequency": 4445,
    "originalRank": 6038
  },
  {
    "word": "acabaron",
    "rank": 5895,
    "frequency": 4445,
    "originalRank": 6039
  },
  {
    "word": "quirófano",
    "rank": 5896,
    "frequency": 4440,
    "originalRank": 6040
  },
  {
    "word": "aéreo",
    "rank": 5897,
    "frequency": 4440,
    "originalRank": 6041
  },
  {
    "word": "carmen",
    "rank": 5898,
    "frequency": 4438,
    "originalRank": 6042
  },
  {
    "word": "misa",
    "rank": 5899,
    "frequency": 4438,
    "originalRank": 6043
  },
  {
    "word": "riqueza",
    "rank": 5900,
    "frequency": 4437,
    "originalRank": 6044
  },
  {
    "word": "separado",
    "rank": 5901,
    "frequency": 4436,
    "originalRank": 6045
  },
  {
    "word": "toneladas",
    "rank": 5902,
    "frequency": 4435,
    "originalRank": 6046
  },
  {
    "word": "criada",
    "rank": 5903,
    "frequency": 4434,
    "originalRank": 6047
  },
  {
    "word": "ida",
    "rank": 5904,
    "frequency": 4434,
    "originalRank": 6048
  },
  {
    "word": "madison",
    "rank": 5905,
    "frequency": 4430,
    "originalRank": 6049
  },
  {
    "word": "observación",
    "rank": 5906,
    "frequency": 4430,
    "originalRank": 6050
  },
  {
    "word": "deténgase",
    "rank": 5907,
    "frequency": 4430,
    "originalRank": 6051
  },
  {
    "word": "asistir",
    "rank": 5908,
    "frequency": 4430,
    "originalRank": 6052
  },
  {
    "word": "compañías",
    "rank": 5909,
    "frequency": 4429,
    "originalRank": 6053
  },
  {
    "word": "mm-hmm",
    "rank": 5910,
    "frequency": 4427,
    "originalRank": 6054
  },
  {
    "word": "freddy",
    "rank": 5911,
    "frequency": 4425,
    "originalRank": 6055
  },
  {
    "word": "voluntario",
    "rank": 5912,
    "frequency": 4424,
    "originalRank": 6056
  },
  {
    "word": "puñado",
    "rank": 5913,
    "frequency": 4423,
    "originalRank": 6057
  },
  {
    "word": "profundidad",
    "rank": 5914,
    "frequency": 4423,
    "originalRank": 6058
  },
  {
    "word": "ligero",
    "rank": 5915,
    "frequency": 4422,
    "originalRank": 6059
  },
  {
    "word": "cuadros",
    "rank": 5916,
    "frequency": 4422,
    "originalRank": 6060
  },
  {
    "word": "incendios",
    "rank": 5917,
    "frequency": 4422,
    "originalRank": 6061
  },
  {
    "word": "meg",
    "rank": 5918,
    "frequency": 4421,
    "originalRank": 6062
  },
  {
    "word": "afortunada",
    "rank": 5919,
    "frequency": 4420,
    "originalRank": 6063
  },
  {
    "word": "pega",
    "rank": 5920,
    "frequency": 4420,
    "originalRank": 6064
  },
  {
    "word": "añadir",
    "rank": 5921,
    "frequency": 4417,
    "originalRank": 6066
  },
  {
    "word": "harrison",
    "rank": 5922,
    "frequency": 4417,
    "originalRank": 6067
  },
  {
    "word": "músculos",
    "rank": 5923,
    "frequency": 4416,
    "originalRank": 6068
  },
  {
    "word": "reunirse",
    "rank": 5924,
    "frequency": 4415,
    "originalRank": 6069
  },
  {
    "word": "sheila",
    "rank": 5925,
    "frequency": 4412,
    "originalRank": 6070
  },
  {
    "word": "sacamos",
    "rank": 5926,
    "frequency": 4410,
    "originalRank": 6071
  },
  {
    "word": "depresión",
    "rank": 5927,
    "frequency": 4409,
    "originalRank": 6072
  },
  {
    "word": "afueras",
    "rank": 5928,
    "frequency": 4408,
    "originalRank": 6073
  },
  {
    "word": "confirmado",
    "rank": 5929,
    "frequency": 4408,
    "originalRank": 6074
  },
  {
    "word": "sordo",
    "rank": 5930,
    "frequency": 4407,
    "originalRank": 6075
  },
  {
    "word": "vano",
    "rank": 5931,
    "frequency": 4406,
    "originalRank": 6076
  },
  {
    "word": "brigada",
    "rank": 5932,
    "frequency": 4406,
    "originalRank": 6077
  },
  {
    "word": "diremos",
    "rank": 5933,
    "frequency": 4404,
    "originalRank": 6078
  },
  {
    "word": "perdonar",
    "rank": 5934,
    "frequency": 4404,
    "originalRank": 6079
  },
  {
    "word": "gigantes",
    "rank": 5935,
    "frequency": 4402,
    "originalRank": 6080
  },
  {
    "word": "pila",
    "rank": 5936,
    "frequency": 4401,
    "originalRank": 6081
  },
  {
    "word": "presentes",
    "rank": 5937,
    "frequency": 4401,
    "originalRank": 6082
  },
  {
    "word": "bahía",
    "rank": 5938,
    "frequency": 4401,
    "originalRank": 6083
  },
  {
    "word": "lesbiana",
    "rank": 5939,
    "frequency": 4398,
    "originalRank": 6084
  },
  {
    "word": "ayuntamiento",
    "rank": 5940,
    "frequency": 4397,
    "originalRank": 6085
  },
  {
    "word": "ligera",
    "rank": 5941,
    "frequency": 4396,
    "originalRank": 6086
  },
  {
    "word": "acceder",
    "rank": 5942,
    "frequency": 4393,
    "originalRank": 6087
  },
  {
    "word": "comprometido",
    "rank": 5943,
    "frequency": 4392,
    "originalRank": 6088
  },
  {
    "word": "sentar",
    "rank": 5944,
    "frequency": 4390,
    "originalRank": 6089
  },
  {
    "word": "fáciles",
    "rank": 5945,
    "frequency": 4389,
    "originalRank": 6090
  },
  {
    "word": "píldoras",
    "rank": 5946,
    "frequency": 4389,
    "originalRank": 6091
  },
  {
    "word": "preocupaciones",
    "rank": 5947,
    "frequency": 4387,
    "originalRank": 6092
  },
  {
    "word": "eve",
    "rank": 5948,
    "frequency": 4386,
    "originalRank": 6093
  },
  {
    "word": "compre",
    "rank": 5949,
    "frequency": 4385,
    "originalRank": 6094
  },
  {
    "word": "desean",
    "rank": 5950,
    "frequency": 4383,
    "originalRank": 6095
  },
  {
    "word": "ansioso",
    "rank": 5951,
    "frequency": 4382,
    "originalRank": 6096
  },
  {
    "word": "despertado",
    "rank": 5952,
    "frequency": 4381,
    "originalRank": 6097
  },
  {
    "word": "mantenerte",
    "rank": 5953,
    "frequency": 4381,
    "originalRank": 6098
  },
  {
    "word": "suplico",
    "rank": 5954,
    "frequency": 4380,
    "originalRank": 6099
  },
  {
    "word": "with",
    "rank": 5955,
    "frequency": 4380,
    "originalRank": 6100
  },
  {
    "word": "escúcheme",
    "rank": 5956,
    "frequency": 4378,
    "originalRank": 6101
  },
  {
    "word": "demos",
    "rank": 5957,
    "frequency": 4376,
    "originalRank": 6102
  },
  {
    "word": "stella",
    "rank": 5958,
    "frequency": 4376,
    "originalRank": 6103
  },
  {
    "word": "pierden",
    "rank": 5959,
    "frequency": 4375,
    "originalRank": 6104
  },
  {
    "word": "olvidarlo",
    "rank": 5960,
    "frequency": 4373,
    "originalRank": 6106
  },
  {
    "word": "mencionado",
    "rank": 5961,
    "frequency": 4373,
    "originalRank": 6107
  },
  {
    "word": "interno",
    "rank": 5962,
    "frequency": 4372,
    "originalRank": 6108
  },
  {
    "word": "pacífico",
    "rank": 5963,
    "frequency": 4371,
    "originalRank": 6109
  },
  {
    "word": "obligación",
    "rank": 5964,
    "frequency": 4370,
    "originalRank": 6110
  },
  {
    "word": "hablará",
    "rank": 5965,
    "frequency": 4370,
    "originalRank": 6111
  },
  {
    "word": "comunista",
    "rank": 5966,
    "frequency": 4369,
    "originalRank": 6112
  },
  {
    "word": "osos",
    "rank": 5967,
    "frequency": 4368,
    "originalRank": 6113
  },
  {
    "word": "espías",
    "rank": 5968,
    "frequency": 4368,
    "originalRank": 6114
  },
  {
    "word": "ohh",
    "rank": 5969,
    "frequency": 4365,
    "originalRank": 6115
  },
  {
    "word": "arreglaré",
    "rank": 5970,
    "frequency": 4364,
    "originalRank": 6116
  },
  {
    "word": "cuentes",
    "rank": 5971,
    "frequency": 4364,
    "originalRank": 6117
  },
  {
    "word": "coincide",
    "rank": 5972,
    "frequency": 4363,
    "originalRank": 6118
  },
  {
    "word": "servido",
    "rank": 5973,
    "frequency": 4362,
    "originalRank": 6119
  },
  {
    "word": "asegurarnos",
    "rank": 5974,
    "frequency": 4361,
    "originalRank": 6120
  },
  {
    "word": "mick",
    "rank": 5975,
    "frequency": 4361,
    "originalRank": 6121
  },
  {
    "word": "espectacular",
    "rank": 5976,
    "frequency": 4360,
    "originalRank": 6122
  },
  {
    "word": "filosofía",
    "rank": 5977,
    "frequency": 4360,
    "originalRank": 6123
  },
  {
    "word": "simpático",
    "rank": 5978,
    "frequency": 4358,
    "originalRank": 6124
  },
  {
    "word": "contraseña",
    "rank": 5979,
    "frequency": 4357,
    "originalRank": 6125
  },
  {
    "word": "pillado",
    "rank": 5980,
    "frequency": 4357,
    "originalRank": 6126
  },
  {
    "word": "naomi",
    "rank": 5981,
    "frequency": 4357,
    "originalRank": 6127
  },
  {
    "word": "volviera",
    "rank": 5982,
    "frequency": 4357,
    "originalRank": 6128
  },
  {
    "word": "levantarse",
    "rank": 5983,
    "frequency": 4356,
    "originalRank": 6129
  },
  {
    "word": "supuestamente",
    "rank": 5984,
    "frequency": 4355,
    "originalRank": 6130
  },
  {
    "word": "veredicto",
    "rank": 5985,
    "frequency": 4354,
    "originalRank": 6131
  },
  {
    "word": "regresará",
    "rank": 5986,
    "frequency": 4354,
    "originalRank": 6132
  },
  {
    "word": "cubre",
    "rank": 5987,
    "frequency": 4353,
    "originalRank": 6133
  },
  {
    "word": "jabón",
    "rank": 5988,
    "frequency": 4351,
    "originalRank": 6134
  },
  {
    "word": "egipto",
    "rank": 5989,
    "frequency": 4350,
    "originalRank": 6135
  },
  {
    "word": "terminemos",
    "rank": 5990,
    "frequency": 4350,
    "originalRank": 6136
  },
  {
    "word": "simples",
    "rank": 5991,
    "frequency": 4349,
    "originalRank": 6137
  },
  {
    "word": "concentración",
    "rank": 5992,
    "frequency": 4349,
    "originalRank": 6138
  },
  {
    "word": "dejarnos",
    "rank": 5993,
    "frequency": 4348,
    "originalRank": 6139
  },
  {
    "word": "déjanos",
    "rank": 5994,
    "frequency": 4347,
    "originalRank": 6140
  },
  {
    "word": "factura",
    "rank": 5995,
    "frequency": 4347,
    "originalRank": 6141
  },
  {
    "word": "zack",
    "rank": 5996,
    "frequency": 4347,
    "originalRank": 6142
  },
  {
    "word": "cargado",
    "rank": 5997,
    "frequency": 4346,
    "originalRank": 6143
  },
  {
    "word": "submarino",
    "rank": 5998,
    "frequency": 4346,
    "originalRank": 6144
  },
  {
    "word": "expertos",
    "rank": 5999,
    "frequency": 4344,
    "originalRank": 6145
  },
  {
    "word": "cazadores",
    "rank": 6000,
    "frequency": 4342,
    "originalRank": 6146
  },
  {
    "word": "afecto",
    "rank": 6001,
    "frequency": 4340,
    "originalRank": 6147
  },
  {
    "word": "sonreír",
    "rank": 6002,
    "frequency": 4340,
    "originalRank": 6148
  },
  {
    "word": "volvía",
    "rank": 6003,
    "frequency": 4340,
    "originalRank": 6149
  },
  {
    "word": "protegiendo",
    "rank": 6004,
    "frequency": 4338,
    "originalRank": 6150
  },
  {
    "word": "dejad",
    "rank": 6005,
    "frequency": 4337,
    "originalRank": 6151
  },
  {
    "word": "desconocida",
    "rank": 6006,
    "frequency": 4337,
    "originalRank": 6152
  },
  {
    "word": "one",
    "rank": 6007,
    "frequency": 4335,
    "originalRank": 6153
  },
  {
    "word": "oírte",
    "rank": 6008,
    "frequency": 4334,
    "originalRank": 6154
  },
  {
    "word": "cristiano",
    "rank": 6009,
    "frequency": 4334,
    "originalRank": 6155
  },
  {
    "word": "víctor",
    "rank": 6010,
    "frequency": 4333,
    "originalRank": 6156
  },
  {
    "word": "invasión",
    "rank": 6011,
    "frequency": 4333,
    "originalRank": 6157
  },
  {
    "word": "maricón",
    "rank": 6012,
    "frequency": 4332,
    "originalRank": 6158
  },
  {
    "word": "permanece",
    "rank": 6013,
    "frequency": 4332,
    "originalRank": 6159
  },
  {
    "word": "jon",
    "rank": 6014,
    "frequency": 4332,
    "originalRank": 6160
  },
  {
    "word": "botones",
    "rank": 6015,
    "frequency": 4331,
    "originalRank": 6161
  },
  {
    "word": "habríamos",
    "rank": 6016,
    "frequency": 4330,
    "originalRank": 6162
  },
  {
    "word": "criado",
    "rank": 6017,
    "frequency": 4329,
    "originalRank": 6163
  },
  {
    "word": "solucionar",
    "rank": 6018,
    "frequency": 4328,
    "originalRank": 6164
  },
  {
    "word": "dawson",
    "rank": 6019,
    "frequency": 4326,
    "originalRank": 6165
  },
  {
    "word": "despertó",
    "rank": 6020,
    "frequency": 4326,
    "originalRank": 6166
  },
  {
    "word": "oriente",
    "rank": 6021,
    "frequency": 4324,
    "originalRank": 6167
  },
  {
    "word": "especialista",
    "rank": 6022,
    "frequency": 4324,
    "originalRank": 6168
  },
  {
    "word": "imbéciles",
    "rank": 6023,
    "frequency": 4323,
    "originalRank": 6169
  },
  {
    "word": "mantenerse",
    "rank": 6024,
    "frequency": 4321,
    "originalRank": 6170
  },
  {
    "word": "alexander",
    "rank": 6025,
    "frequency": 4320,
    "originalRank": 6171
  },
  {
    "word": "suiza",
    "rank": 6026,
    "frequency": 4319,
    "originalRank": 6172
  },
  {
    "word": "tapa",
    "rank": 6027,
    "frequency": 4319,
    "originalRank": 6173
  },
  {
    "word": "alla",
    "rank": 6028,
    "frequency": 4318,
    "originalRank": 6174
  },
  {
    "word": "votación",
    "rank": 6029,
    "frequency": 4317,
    "originalRank": 6175
  },
  {
    "word": "shaw",
    "rank": 6030,
    "frequency": 4316,
    "originalRank": 6176
  },
  {
    "word": "lloyd",
    "rank": 6031,
    "frequency": 4316,
    "originalRank": 6177
  },
  {
    "word": "heredero",
    "rank": 6032,
    "frequency": 4316,
    "originalRank": 6178
  },
  {
    "word": "atravesar",
    "rank": 6033,
    "frequency": 4315,
    "originalRank": 6179
  },
  {
    "word": "adams",
    "rank": 6034,
    "frequency": 4315,
    "originalRank": 6180
  },
  {
    "word": "favoritos",
    "rank": 6035,
    "frequency": 4313,
    "originalRank": 6181
  },
  {
    "word": "traerá",
    "rank": 6036,
    "frequency": 4311,
    "originalRank": 6182
  },
  {
    "word": "engañando",
    "rank": 6037,
    "frequency": 4310,
    "originalRank": 6183
  },
  {
    "word": "hamburguesas",
    "rank": 6038,
    "frequency": 4310,
    "originalRank": 6184
  },
  {
    "word": "esfuerzos",
    "rank": 6039,
    "frequency": 4310,
    "originalRank": 6185
  },
  {
    "word": "diarios",
    "rank": 6040,
    "frequency": 4308,
    "originalRank": 6186
  },
  {
    "word": "arrogante",
    "rank": 6041,
    "frequency": 4307,
    "originalRank": 6187
  },
  {
    "word": "moriré",
    "rank": 6042,
    "frequency": 4307,
    "originalRank": 6188
  },
  {
    "word": "excitante",
    "rank": 6043,
    "frequency": 4307,
    "originalRank": 6189
  },
  {
    "word": "entrenar",
    "rank": 6044,
    "frequency": 4306,
    "originalRank": 6190
  },
  {
    "word": "maneja",
    "rank": 6045,
    "frequency": 4305,
    "originalRank": 6191
  },
  {
    "word": "permíteme",
    "rank": 6046,
    "frequency": 4304,
    "originalRank": 6192
  },
  {
    "word": "creíste",
    "rank": 6047,
    "frequency": 4304,
    "originalRank": 6193
  },
  {
    "word": "bosques",
    "rank": 6048,
    "frequency": 4304,
    "originalRank": 6194
  },
  {
    "word": "insectos",
    "rank": 6049,
    "frequency": 4302,
    "originalRank": 6195
  },
  {
    "word": "liberado",
    "rank": 6050,
    "frequency": 4301,
    "originalRank": 6196
  },
  {
    "word": "irene",
    "rank": 6051,
    "frequency": 4301,
    "originalRank": 6197
  },
  {
    "word": "brillo",
    "rank": 6052,
    "frequency": 4300,
    "originalRank": 6198
  },
  {
    "word": "becky",
    "rank": 6053,
    "frequency": 4299,
    "originalRank": 6199
  },
  {
    "word": "romántica",
    "rank": 6054,
    "frequency": 4298,
    "originalRank": 6200
  },
  {
    "word": "corresponde",
    "rank": 6055,
    "frequency": 4296,
    "originalRank": 6201
  },
  {
    "word": "ruby",
    "rank": 6056,
    "frequency": 4295,
    "originalRank": 6202
  },
  {
    "word": "harvard",
    "rank": 6057,
    "frequency": 4295,
    "originalRank": 6203
  },
  {
    "word": "debías",
    "rank": 6058,
    "frequency": 4294,
    "originalRank": 6204
  },
  {
    "word": "choi",
    "rank": 6059,
    "frequency": 4294,
    "originalRank": 6205
  },
  {
    "word": "molestado",
    "rank": 6060,
    "frequency": 4294,
    "originalRank": 6206
  },
  {
    "word": "rosie",
    "rank": 6061,
    "frequency": 4294,
    "originalRank": 6207
  },
  {
    "word": "admiro",
    "rank": 6062,
    "frequency": 4293,
    "originalRank": 6208
  },
  {
    "word": "georgia",
    "rank": 6063,
    "frequency": 4293,
    "originalRank": 6209
  },
  {
    "word": "costillas",
    "rank": 6064,
    "frequency": 4292,
    "originalRank": 6210
  },
  {
    "word": "bernard",
    "rank": 6065,
    "frequency": 4292,
    "originalRank": 6211
  },
  {
    "word": "valentín",
    "rank": 6066,
    "frequency": 4289,
    "originalRank": 6212
  },
  {
    "word": "llenas",
    "rank": 6067,
    "frequency": 4288,
    "originalRank": 6213
  },
  {
    "word": "retirado",
    "rank": 6068,
    "frequency": 4288,
    "originalRank": 6214
  },
  {
    "word": "anciana",
    "rank": 6069,
    "frequency": 4287,
    "originalRank": 6215
  },
  {
    "word": "escribiste",
    "rank": 6070,
    "frequency": 4287,
    "originalRank": 6216
  },
  {
    "word": "hablen",
    "rank": 6071,
    "frequency": 4286,
    "originalRank": 6217
  },
  {
    "word": "concéntrate",
    "rank": 6072,
    "frequency": 4285,
    "originalRank": 6218
  },
  {
    "word": "matamos",
    "rank": 6073,
    "frequency": 4285,
    "originalRank": 6219
  },
  {
    "word": "fuegos",
    "rank": 6074,
    "frequency": 4283,
    "originalRank": 6220
  },
  {
    "word": "suban",
    "rank": 6075,
    "frequency": 4281,
    "originalRank": 6221
  },
  {
    "word": "sucios",
    "rank": 6076,
    "frequency": 4280,
    "originalRank": 6222
  },
  {
    "word": "divertirse",
    "rank": 6077,
    "frequency": 4279,
    "originalRank": 6223
  },
  {
    "word": "astuto",
    "rank": 6078,
    "frequency": 4278,
    "originalRank": 6224
  },
  {
    "word": "hueco",
    "rank": 6079,
    "frequency": 4277,
    "originalRank": 6225
  },
  {
    "word": "pariente",
    "rank": 6080,
    "frequency": 4276,
    "originalRank": 6226
  },
  {
    "word": "oficinas",
    "rank": 6081,
    "frequency": 4274,
    "originalRank": 6227
  },
  {
    "word": "reed",
    "rank": 6082,
    "frequency": 4273,
    "originalRank": 6228
  },
  {
    "word": "coja",
    "rank": 6083,
    "frequency": 4271,
    "originalRank": 6229
  },
  {
    "word": "complicada",
    "rank": 6084,
    "frequency": 4270,
    "originalRank": 6230
  },
  {
    "word": "acercarse",
    "rank": 6085,
    "frequency": 4270,
    "originalRank": 6231
  },
  {
    "word": "oficio",
    "rank": 6086,
    "frequency": 4268,
    "originalRank": 6232
  },
  {
    "word": "tejado",
    "rank": 6087,
    "frequency": 4267,
    "originalRank": 6233
  },
  {
    "word": "periodistas",
    "rank": 6088,
    "frequency": 4267,
    "originalRank": 6234
  },
  {
    "word": "dorado",
    "rank": 6089,
    "frequency": 4266,
    "originalRank": 6235
  },
  {
    "word": "marinero",
    "rank": 6090,
    "frequency": 4264,
    "originalRank": 6236
  },
  {
    "word": "sentidos",
    "rank": 6091,
    "frequency": 4264,
    "originalRank": 6237
  },
  {
    "word": "torneo",
    "rank": 6092,
    "frequency": 4263,
    "originalRank": 6238
  },
  {
    "word": "kit",
    "rank": 6093,
    "frequency": 4263,
    "originalRank": 6239
  },
  {
    "word": "encantaba",
    "rank": 6094,
    "frequency": 4263,
    "originalRank": 6240
  },
  {
    "word": "this",
    "rank": 6095,
    "frequency": 4261,
    "originalRank": 6241
  },
  {
    "word": "hacha",
    "rank": 6096,
    "frequency": 4257,
    "originalRank": 6242
  },
  {
    "word": "palmer",
    "rank": 6097,
    "frequency": 4256,
    "originalRank": 6243
  },
  {
    "word": "pasteles",
    "rank": 6098,
    "frequency": 4254,
    "originalRank": 6244
  },
  {
    "word": "despedir",
    "rank": 6099,
    "frequency": 4253,
    "originalRank": 6245
  },
  {
    "word": "enteró",
    "rank": 6100,
    "frequency": 4253,
    "originalRank": 6246
  },
  {
    "word": "echaré",
    "rank": 6101,
    "frequency": 4253,
    "originalRank": 6247
  },
  {
    "word": "destrozado",
    "rank": 6102,
    "frequency": 4251,
    "originalRank": 6248
  },
  {
    "word": "marchó",
    "rank": 6103,
    "frequency": 4251,
    "originalRank": 6249
  },
  {
    "word": "miranda",
    "rank": 6104,
    "frequency": 4251,
    "originalRank": 6250
  },
  {
    "word": "computadoras",
    "rank": 6105,
    "frequency": 4250,
    "originalRank": 6251
  },
  {
    "word": "burro",
    "rank": 6106,
    "frequency": 4247,
    "originalRank": 6252
  },
  {
    "word": "etiqueta",
    "rank": 6107,
    "frequency": 4242,
    "originalRank": 6253
  },
  {
    "word": "sharon",
    "rank": 6108,
    "frequency": 4242,
    "originalRank": 6254
  },
  {
    "word": "marcharse",
    "rank": 6109,
    "frequency": 4241,
    "originalRank": 6255
  },
  {
    "word": "produce",
    "rank": 6110,
    "frequency": 4240,
    "originalRank": 6256
  },
  {
    "word": "naciones",
    "rank": 6111,
    "frequency": 4240,
    "originalRank": 6257
  },
  {
    "word": "referencia",
    "rank": 6112,
    "frequency": 4240,
    "originalRank": 6258
  },
  {
    "word": "polo",
    "rank": 6113,
    "frequency": 4239,
    "originalRank": 6259
  },
  {
    "word": "maldad",
    "rank": 6114,
    "frequency": 4238,
    "originalRank": 6260
  },
  {
    "word": "quedaremos",
    "rank": 6115,
    "frequency": 4237,
    "originalRank": 6261
  },
  {
    "word": "jodidos",
    "rank": 6116,
    "frequency": 4236,
    "originalRank": 6262
  },
  {
    "word": "aprendiste",
    "rank": 6117,
    "frequency": 4236,
    "originalRank": 6263
  },
  {
    "word": "perry",
    "rank": 6118,
    "frequency": 4236,
    "originalRank": 6264
  },
  {
    "word": "divirtiendo",
    "rank": 6119,
    "frequency": 4235,
    "originalRank": 6265
  },
  {
    "word": "costo",
    "rank": 6120,
    "frequency": 4233,
    "originalRank": 6266
  },
  {
    "word": "recorrido",
    "rank": 6121,
    "frequency": 4232,
    "originalRank": 6267
  },
  {
    "word": "retrasado",
    "rank": 6122,
    "frequency": 4230,
    "originalRank": 6268
  },
  {
    "word": "arnold",
    "rank": 6123,
    "frequency": 4229,
    "originalRank": 6269
  },
  {
    "word": "lograste",
    "rank": 6124,
    "frequency": 4229,
    "originalRank": 6270
  },
  {
    "word": "convertirme",
    "rank": 6125,
    "frequency": 4228,
    "originalRank": 6271
  },
  {
    "word": "núcleo",
    "rank": 6126,
    "frequency": 4228,
    "originalRank": 6272
  },
  {
    "word": "controlado",
    "rank": 6127,
    "frequency": 4226,
    "originalRank": 6273
  },
  {
    "word": "bell",
    "rank": 6128,
    "frequency": 4225,
    "originalRank": 6275
  },
  {
    "word": "pidieron",
    "rank": 6129,
    "frequency": 4224,
    "originalRank": 6276
  },
  {
    "word": "conseguiremos",
    "rank": 6130,
    "frequency": 4224,
    "originalRank": 6277
  },
  {
    "word": "acuerda",
    "rank": 6131,
    "frequency": 4224,
    "originalRank": 6278
  },
  {
    "word": "grabado",
    "rank": 6132,
    "frequency": 4223,
    "originalRank": 6279
  },
  {
    "word": "cadenas",
    "rank": 6133,
    "frequency": 4222,
    "originalRank": 6280
  },
  {
    "word": "cálmese",
    "rank": 6134,
    "frequency": 4222,
    "originalRank": 6281
  },
  {
    "word": "reducir",
    "rank": 6135,
    "frequency": 4221,
    "originalRank": 6282
  },
  {
    "word": "bajos",
    "rank": 6136,
    "frequency": 4221,
    "originalRank": 6283
  },
  {
    "word": "honorable",
    "rank": 6137,
    "frequency": 4219,
    "originalRank": 6284
  },
  {
    "word": "comidas",
    "rank": 6138,
    "frequency": 4218,
    "originalRank": 6285
  },
  {
    "word": "bodega",
    "rank": 6139,
    "frequency": 4218,
    "originalRank": 6286
  },
  {
    "word": "funcionado",
    "rank": 6140,
    "frequency": 4218,
    "originalRank": 6287
  },
  {
    "word": "traficante",
    "rank": 6141,
    "frequency": 4217,
    "originalRank": 6288
  },
  {
    "word": "amenazó",
    "rank": 6142,
    "frequency": 4216,
    "originalRank": 6289
  },
  {
    "word": "renta",
    "rank": 6143,
    "frequency": 4215,
    "originalRank": 6290
  },
  {
    "word": "saliera",
    "rank": 6144,
    "frequency": 4215,
    "originalRank": 6291
  },
  {
    "word": "posiciones",
    "rank": 6145,
    "frequency": 4214,
    "originalRank": 6292
  },
  {
    "word": "tiros",
    "rank": 6146,
    "frequency": 4213,
    "originalRank": 6293
  },
  {
    "word": "toco",
    "rank": 6147,
    "frequency": 4212,
    "originalRank": 6294
  },
  {
    "word": "metiendo",
    "rank": 6148,
    "frequency": 4212,
    "originalRank": 6295
  },
  {
    "word": "tímido",
    "rank": 6149,
    "frequency": 4210,
    "originalRank": 6296
  },
  {
    "word": "conveniente",
    "rank": 6150,
    "frequency": 4210,
    "originalRank": 6297
  },
  {
    "word": "cerrados",
    "rank": 6151,
    "frequency": 4210,
    "originalRank": 6298
  },
  {
    "word": "identificado",
    "rank": 6152,
    "frequency": 4208,
    "originalRank": 6300
  },
  {
    "word": "inocencia",
    "rank": 6153,
    "frequency": 4206,
    "originalRank": 6301
  },
  {
    "word": "pinturas",
    "rank": 6154,
    "frequency": 4205,
    "originalRank": 6302
  },
  {
    "word": "estadio",
    "rank": 6155,
    "frequency": 4204,
    "originalRank": 6303
  },
  {
    "word": "elemento",
    "rank": 6156,
    "frequency": 4202,
    "originalRank": 6304
  },
  {
    "word": "marrón",
    "rank": 6157,
    "frequency": 4201,
    "originalRank": 6305
  },
  {
    "word": "supuse",
    "rank": 6158,
    "frequency": 4200,
    "originalRank": 6306
  },
  {
    "word": "retrocede",
    "rank": 6159,
    "frequency": 4199,
    "originalRank": 6307
  },
  {
    "word": "sillas",
    "rank": 6160,
    "frequency": 4199,
    "originalRank": 6308
  },
  {
    "word": "individuo",
    "rank": 6161,
    "frequency": 4198,
    "originalRank": 6309
  },
  {
    "word": "sorpresas",
    "rank": 6162,
    "frequency": 4197,
    "originalRank": 6310
  },
  {
    "word": "adicto",
    "rank": 6163,
    "frequency": 4197,
    "originalRank": 6311
  },
  {
    "word": "cabrones",
    "rank": 6164,
    "frequency": 4196,
    "originalRank": 6312
  },
  {
    "word": "terapeuta",
    "rank": 6165,
    "frequency": 4195,
    "originalRank": 6313
  },
  {
    "word": "ridícula",
    "rank": 6166,
    "frequency": 4194,
    "originalRank": 6314
  },
  {
    "word": "busquen",
    "rank": 6167,
    "frequency": 4193,
    "originalRank": 6315
  },
  {
    "word": "derrota",
    "rank": 6168,
    "frequency": 4192,
    "originalRank": 6316
  },
  {
    "word": "traerlo",
    "rank": 6169,
    "frequency": 4190,
    "originalRank": 6317
  },
  {
    "word": "hazte",
    "rank": 6170,
    "frequency": 4190,
    "originalRank": 6318
  },
  {
    "word": "finn",
    "rank": 6171,
    "frequency": 4189,
    "originalRank": 6319
  },
  {
    "word": "morirás",
    "rank": 6172,
    "frequency": 4189,
    "originalRank": 6320
  },
  {
    "word": "orilla",
    "rank": 6173,
    "frequency": 4188,
    "originalRank": 6321
  },
  {
    "word": "mientas",
    "rank": 6174,
    "frequency": 4187,
    "originalRank": 6322
  },
  {
    "word": "construyó",
    "rank": 6175,
    "frequency": 4184,
    "originalRank": 6323
  },
  {
    "word": "escuchan",
    "rank": 6176,
    "frequency": 4181,
    "originalRank": 6324
  },
  {
    "word": "chimenea",
    "rank": 6177,
    "frequency": 4181,
    "originalRank": 6325
  },
  {
    "word": "febrero",
    "rank": 6178,
    "frequency": 4178,
    "originalRank": 6326
  },
  {
    "word": "respondió",
    "rank": 6179,
    "frequency": 4177,
    "originalRank": 6327
  },
  {
    "word": "recoge",
    "rank": 6180,
    "frequency": 4176,
    "originalRank": 6328
  },
  {
    "word": "wallace",
    "rank": 6181,
    "frequency": 4175,
    "originalRank": 6329
  },
  {
    "word": "doyle",
    "rank": 6182,
    "frequency": 4175,
    "originalRank": 6330
  },
  {
    "word": "inglesa",
    "rank": 6183,
    "frequency": 4175,
    "originalRank": 6331
  },
  {
    "word": "mueras",
    "rank": 6184,
    "frequency": 4174,
    "originalRank": 6332
  },
  {
    "word": "cumple",
    "rank": 6185,
    "frequency": 4173,
    "originalRank": 6333
  },
  {
    "word": "muevan",
    "rank": 6186,
    "frequency": 4173,
    "originalRank": 6334
  },
  {
    "word": "muertas",
    "rank": 6187,
    "frequency": 4173,
    "originalRank": 6335
  },
  {
    "word": "dormí",
    "rank": 6188,
    "frequency": 4173,
    "originalRank": 6336
  },
  {
    "word": "limpiando",
    "rank": 6189,
    "frequency": 4172,
    "originalRank": 6337
  },
  {
    "word": "confidencial",
    "rank": 6190,
    "frequency": 4172,
    "originalRank": 6338
  },
  {
    "word": "suite",
    "rank": 6191,
    "frequency": 4172,
    "originalRank": 6339
  },
  {
    "word": "caleb",
    "rank": 6192,
    "frequency": 4170,
    "originalRank": 6340
  },
  {
    "word": "piratas",
    "rank": 6193,
    "frequency": 4170,
    "originalRank": 6341
  },
  {
    "word": "reparar",
    "rank": 6194,
    "frequency": 4170,
    "originalRank": 6342
  },
  {
    "word": "dorothy",
    "rank": 6195,
    "frequency": 4170,
    "originalRank": 6343
  },
  {
    "word": "rehén",
    "rank": 6196,
    "frequency": 4169,
    "originalRank": 6344
  },
  {
    "word": "manchas",
    "rank": 6197,
    "frequency": 4168,
    "originalRank": 6345
  },
  {
    "word": "bud",
    "rank": 6198,
    "frequency": 4167,
    "originalRank": 6346
  },
  {
    "word": "cicatriz",
    "rank": 6199,
    "frequency": 4166,
    "originalRank": 6347
  },
  {
    "word": "borrar",
    "rank": 6200,
    "frequency": 4165,
    "originalRank": 6348
  },
  {
    "word": "fundación",
    "rank": 6201,
    "frequency": 4165,
    "originalRank": 6349
  },
  {
    "word": "robbie",
    "rank": 6202,
    "frequency": 4165,
    "originalRank": 6350
  },
  {
    "word": "ciencias",
    "rank": 6203,
    "frequency": 4165,
    "originalRank": 6351
  },
  {
    "word": "iniciar",
    "rank": 6204,
    "frequency": 4164,
    "originalRank": 6352
  },
  {
    "word": "reservado",
    "rank": 6205,
    "frequency": 4164,
    "originalRank": 6353
  },
  {
    "word": "justamente",
    "rank": 6206,
    "frequency": 4164,
    "originalRank": 6354
  },
  {
    "word": "conocidos",
    "rank": 6207,
    "frequency": 4163,
    "originalRank": 6355
  },
  {
    "word": "niego",
    "rank": 6208,
    "frequency": 4161,
    "originalRank": 6356
  },
  {
    "word": "ningun",
    "rank": 6209,
    "frequency": 4159,
    "originalRank": 6357
  },
  {
    "word": "descubre",
    "rank": 6210,
    "frequency": 4158,
    "originalRank": 6358
  },
  {
    "word": "adelantado",
    "rank": 6211,
    "frequency": 4157,
    "originalRank": 6359
  },
  {
    "word": "blair",
    "rank": 6212,
    "frequency": 4157,
    "originalRank": 6360
  },
  {
    "word": "aah",
    "rank": 6213,
    "frequency": 4156,
    "originalRank": 6361
  },
  {
    "word": "sábanas",
    "rank": 6214,
    "frequency": 4156,
    "originalRank": 6362
  },
  {
    "word": "argumento",
    "rank": 6215,
    "frequency": 4154,
    "originalRank": 6363
  },
  {
    "word": "dueños",
    "rank": 6216,
    "frequency": 4154,
    "originalRank": 6364
  },
  {
    "word": "castle",
    "rank": 6217,
    "frequency": 4154,
    "originalRank": 6365
  },
  {
    "word": "viajando",
    "rank": 6218,
    "frequency": 4153,
    "originalRank": 6366
  },
  {
    "word": "metiste",
    "rank": 6219,
    "frequency": 4151,
    "originalRank": 6367
  },
  {
    "word": "terminaron",
    "rank": 6220,
    "frequency": 4149,
    "originalRank": 6368
  },
  {
    "word": "sip",
    "rank": 6221,
    "frequency": 4149,
    "originalRank": 6369
  },
  {
    "word": "esperábamos",
    "rank": 6222,
    "frequency": 4148,
    "originalRank": 6370
  },
  {
    "word": "flash",
    "rank": 6223,
    "frequency": 4148,
    "originalRank": 6371
  },
  {
    "word": "alec",
    "rank": 6224,
    "frequency": 4147,
    "originalRank": 6372
  },
  {
    "word": "enseño",
    "rank": 6225,
    "frequency": 4145,
    "originalRank": 6373
  },
  {
    "word": "fox",
    "rank": 6226,
    "frequency": 4145,
    "originalRank": 6374
  },
  {
    "word": "phillip",
    "rank": 6227,
    "frequency": 4144,
    "originalRank": 6375
  },
  {
    "word": "cruzado",
    "rank": 6228,
    "frequency": 4144,
    "originalRank": 6376
  },
  {
    "word": "roba",
    "rank": 6229,
    "frequency": 4143,
    "originalRank": 6377
  },
  {
    "word": "tradicional",
    "rank": 6230,
    "frequency": 4143,
    "originalRank": 6378
  },
  {
    "word": "creció",
    "rank": 6231,
    "frequency": 4141,
    "originalRank": 6379
  },
  {
    "word": "cobertura",
    "rank": 6232,
    "frequency": 4141,
    "originalRank": 6380
  },
  {
    "word": "pillo",
    "rank": 6233,
    "frequency": 4139,
    "originalRank": 6381
  },
  {
    "word": "escritura",
    "rank": 6234,
    "frequency": 4139,
    "originalRank": 6382
  },
  {
    "word": "entere",
    "rank": 6235,
    "frequency": 4137,
    "originalRank": 6383
  },
  {
    "word": "billetera",
    "rank": 6236,
    "frequency": 4136,
    "originalRank": 6384
  },
  {
    "word": "hacíamos",
    "rank": 6237,
    "frequency": 4136,
    "originalRank": 6385
  },
  {
    "word": "vapor",
    "rank": 6238,
    "frequency": 4135,
    "originalRank": 6386
  },
  {
    "word": "cosecha",
    "rank": 6239,
    "frequency": 4134,
    "originalRank": 6387
  },
  {
    "word": "generaciones",
    "rank": 6240,
    "frequency": 4134,
    "originalRank": 6388
  },
  {
    "word": "wyatt",
    "rank": 6241,
    "frequency": 4134,
    "originalRank": 6389
  },
  {
    "word": "capturado",
    "rank": 6242,
    "frequency": 4133,
    "originalRank": 6390
  },
  {
    "word": "cuñado",
    "rank": 6243,
    "frequency": 4133,
    "originalRank": 6391
  },
  {
    "word": "damon",
    "rank": 6244,
    "frequency": 4132,
    "originalRank": 6392
  },
  {
    "word": "sagrada",
    "rank": 6245,
    "frequency": 4132,
    "originalRank": 6393
  },
  {
    "word": "sonidos",
    "rank": 6246,
    "frequency": 4130,
    "originalRank": 6394
  },
  {
    "word": "eeuu",
    "rank": 6247,
    "frequency": 4129,
    "originalRank": 6395
  },
  {
    "word": "tranquilidad",
    "rank": 6248,
    "frequency": 4128,
    "originalRank": 6396
  },
  {
    "word": "gatito",
    "rank": 6249,
    "frequency": 4128,
    "originalRank": 6397
  },
  {
    "word": "periodo",
    "rank": 6250,
    "frequency": 4127,
    "originalRank": 6398
  },
  {
    "word": "ocupo",
    "rank": 6251,
    "frequency": 4126,
    "originalRank": 6399
  },
  {
    "word": "traicionado",
    "rank": 6252,
    "frequency": 4126,
    "originalRank": 6400
  },
  {
    "word": "furia",
    "rank": 6253,
    "frequency": 4126,
    "originalRank": 6401
  },
  {
    "word": "recuperado",
    "rank": 6254,
    "frequency": 4126,
    "originalRank": 6402
  },
  {
    "word": "cuide",
    "rank": 6255,
    "frequency": 4125,
    "originalRank": 6403
  },
  {
    "word": "tortuga",
    "rank": 6256,
    "frequency": 4125,
    "originalRank": 6404
  },
  {
    "word": "patty",
    "rank": 6257,
    "frequency": 4125,
    "originalRank": 6405
  },
  {
    "word": "piden",
    "rank": 6258,
    "frequency": 4124,
    "originalRank": 6406
  },
  {
    "word": "ficción",
    "rank": 6259,
    "frequency": 4123,
    "originalRank": 6408
  },
  {
    "word": "nikki",
    "rank": 6260,
    "frequency": 4123,
    "originalRank": 6409
  },
  {
    "word": "fuí",
    "rank": 6261,
    "frequency": 4123,
    "originalRank": 6410
  },
  {
    "word": "milagros",
    "rank": 6262,
    "frequency": 4122,
    "originalRank": 6411
  },
  {
    "word": "soñado",
    "rank": 6263,
    "frequency": 4122,
    "originalRank": 6412
  },
  {
    "word": "pis",
    "rank": 6264,
    "frequency": 4122,
    "originalRank": 6413
  },
  {
    "word": "andas",
    "rank": 6265,
    "frequency": 4122,
    "originalRank": 6414
  },
  {
    "word": "ovejas",
    "rank": 6266,
    "frequency": 4121,
    "originalRank": 6415
  },
  {
    "word": "granero",
    "rank": 6267,
    "frequency": 4120,
    "originalRank": 6416
  },
  {
    "word": "docenas",
    "rank": 6268,
    "frequency": 4120,
    "originalRank": 6417
  },
  {
    "word": "quienquiera",
    "rank": 6269,
    "frequency": 4119,
    "originalRank": 6418
  },
  {
    "word": "juegan",
    "rank": 6270,
    "frequency": 4119,
    "originalRank": 6419
  },
  {
    "word": "lógico",
    "rank": 6271,
    "frequency": 4119,
    "originalRank": 6420
  },
  {
    "word": "disciplina",
    "rank": 6272,
    "frequency": 4119,
    "originalRank": 6421
  },
  {
    "word": "revisando",
    "rank": 6273,
    "frequency": 4119,
    "originalRank": 6422
  },
  {
    "word": "recibiste",
    "rank": 6274,
    "frequency": 4117,
    "originalRank": 6423
  },
  {
    "word": "retirarse",
    "rank": 6275,
    "frequency": 4117,
    "originalRank": 6424
  },
  {
    "word": "noah",
    "rank": 6276,
    "frequency": 4115,
    "originalRank": 6425
  },
  {
    "word": "salvador",
    "rank": 6277,
    "frequency": 4115,
    "originalRank": 6426
  },
  {
    "word": "privilegio",
    "rank": 6278,
    "frequency": 4113,
    "originalRank": 6427
  },
  {
    "word": "secuencia",
    "rank": 6279,
    "frequency": 4113,
    "originalRank": 6428
  },
  {
    "word": "pensaré",
    "rank": 6280,
    "frequency": 4113,
    "originalRank": 6429
  },
  {
    "word": "antiguas",
    "rank": 6281,
    "frequency": 4113,
    "originalRank": 6430
  },
  {
    "word": "lydia",
    "rank": 6282,
    "frequency": 4111,
    "originalRank": 6431
  },
  {
    "word": "semillas",
    "rank": 6283,
    "frequency": 4109,
    "originalRank": 6432
  },
  {
    "word": "afganistán",
    "rank": 6284,
    "frequency": 4109,
    "originalRank": 6433
  },
  {
    "word": "ponernos",
    "rank": 6285,
    "frequency": 4109,
    "originalRank": 6434
  },
  {
    "word": "aprovechar",
    "rank": 6286,
    "frequency": 4109,
    "originalRank": 6435
  },
  {
    "word": "falda",
    "rank": 6287,
    "frequency": 4108,
    "originalRank": 6436
  },
  {
    "word": "mikey",
    "rank": 6288,
    "frequency": 4108,
    "originalRank": 6437
  },
  {
    "word": "morris",
    "rank": 6289,
    "frequency": 4107,
    "originalRank": 6438
  },
  {
    "word": "shakespeare",
    "rank": 6290,
    "frequency": 4106,
    "originalRank": 6439
  },
  {
    "word": "tendrían",
    "rank": 6291,
    "frequency": 4106,
    "originalRank": 6440
  },
  {
    "word": "acompaño",
    "rank": 6292,
    "frequency": 4105,
    "originalRank": 6441
  },
  {
    "word": "diferencias",
    "rank": 6293,
    "frequency": 4104,
    "originalRank": 6442
  },
  {
    "word": "escocia",
    "rank": 6294,
    "frequency": 4104,
    "originalRank": 6443
  },
  {
    "word": "menuda",
    "rank": 6295,
    "frequency": 4103,
    "originalRank": 6444
  },
  {
    "word": "utilizado",
    "rank": 6296,
    "frequency": 4103,
    "originalRank": 6445
  },
  {
    "word": "linea",
    "rank": 6297,
    "frequency": 4102,
    "originalRank": 6446
  },
  {
    "word": "pelos",
    "rank": 6298,
    "frequency": 4101,
    "originalRank": 6447
  },
  {
    "word": "circuito",
    "rank": 6299,
    "frequency": 4097,
    "originalRank": 6448
  },
  {
    "word": "agradecida",
    "rank": 6300,
    "frequency": 4097,
    "originalRank": 6449
  },
  {
    "word": "richie",
    "rank": 6301,
    "frequency": 4096,
    "originalRank": 6450
  },
  {
    "word": "mantuvo",
    "rank": 6302,
    "frequency": 4094,
    "originalRank": 6452
  },
  {
    "word": "aprobación",
    "rank": 6303,
    "frequency": 4094,
    "originalRank": 6453
  },
  {
    "word": "novedad",
    "rank": 6304,
    "frequency": 4094,
    "originalRank": 6454
  },
  {
    "word": "impedir",
    "rank": 6305,
    "frequency": 4094,
    "originalRank": 6455
  },
  {
    "word": "ego",
    "rank": 6306,
    "frequency": 4094,
    "originalRank": 6456
  },
  {
    "word": "conocerle",
    "rank": 6307,
    "frequency": 4092,
    "originalRank": 6457
  },
  {
    "word": "imaginado",
    "rank": 6308,
    "frequency": 4091,
    "originalRank": 6458
  },
  {
    "word": "protegido",
    "rank": 6309,
    "frequency": 4091,
    "originalRank": 6459
  },
  {
    "word": "enfermeras",
    "rank": 6310,
    "frequency": 4091,
    "originalRank": 6460
  },
  {
    "word": "gustaria",
    "rank": 6311,
    "frequency": 4090,
    "originalRank": 6461
  },
  {
    "word": "pirata",
    "rank": 6312,
    "frequency": 4089,
    "originalRank": 6462
  },
  {
    "word": "mantenido",
    "rank": 6313,
    "frequency": 4088,
    "originalRank": 6463
  },
  {
    "word": "burke",
    "rank": 6314,
    "frequency": 4088,
    "originalRank": 6464
  },
  {
    "word": "usarla",
    "rank": 6315,
    "frequency": 4087,
    "originalRank": 6465
  },
  {
    "word": "inspiración",
    "rank": 6316,
    "frequency": 4087,
    "originalRank": 6466
  },
  {
    "word": "aterrador",
    "rank": 6317,
    "frequency": 4084,
    "originalRank": 6467
  },
  {
    "word": "lindsay",
    "rank": 6318,
    "frequency": 4084,
    "originalRank": 6468
  },
  {
    "word": "dolares",
    "rank": 6319,
    "frequency": 4084,
    "originalRank": 6469
  },
  {
    "word": "logré",
    "rank": 6320,
    "frequency": 4084,
    "originalRank": 6470
  },
  {
    "word": "borrachos",
    "rank": 6321,
    "frequency": 4083,
    "originalRank": 6471
  },
  {
    "word": "estaciones",
    "rank": 6322,
    "frequency": 4083,
    "originalRank": 6472
  },
  {
    "word": "cheques",
    "rank": 6323,
    "frequency": 4083,
    "originalRank": 6473
  },
  {
    "word": "norma",
    "rank": 6324,
    "frequency": 4082,
    "originalRank": 6474
  },
  {
    "word": "mecánico",
    "rank": 6325,
    "frequency": 4082,
    "originalRank": 6475
  },
  {
    "word": "perdedores",
    "rank": 6326,
    "frequency": 4081,
    "originalRank": 6476
  },
  {
    "word": "houston",
    "rank": 6327,
    "frequency": 4081,
    "originalRank": 6477
  },
  {
    "word": "polis",
    "rank": 6328,
    "frequency": 4078,
    "originalRank": 6478
  },
  {
    "word": "reconocido",
    "rank": 6329,
    "frequency": 4077,
    "originalRank": 6479
  },
  {
    "word": "videos",
    "rank": 6330,
    "frequency": 4076,
    "originalRank": 6480
  },
  {
    "word": "gripe",
    "rank": 6331,
    "frequency": 4075,
    "originalRank": 6481
  },
  {
    "word": "ataca",
    "rank": 6332,
    "frequency": 4074,
    "originalRank": 6482
  },
  {
    "word": "sacarle",
    "rank": 6333,
    "frequency": 4073,
    "originalRank": 6483
  },
  {
    "word": "existir",
    "rank": 6334,
    "frequency": 4072,
    "originalRank": 6484
  },
  {
    "word": "jesus",
    "rank": 6335,
    "frequency": 4071,
    "originalRank": 6485
  },
  {
    "word": "thompson",
    "rank": 6336,
    "frequency": 4071,
    "originalRank": 6486
  },
  {
    "word": "bus",
    "rank": 6337,
    "frequency": 4071,
    "originalRank": 6487
  },
  {
    "word": "precios",
    "rank": 6338,
    "frequency": 4069,
    "originalRank": 6488
  },
  {
    "word": "inevitable",
    "rank": 6339,
    "frequency": 4065,
    "originalRank": 6489
  },
  {
    "word": "pusimos",
    "rank": 6340,
    "frequency": 4065,
    "originalRank": 6490
  },
  {
    "word": "cuba",
    "rank": 6341,
    "frequency": 4063,
    "originalRank": 6491
  },
  {
    "word": "estúpidas",
    "rank": 6342,
    "frequency": 4062,
    "originalRank": 6492
  },
  {
    "word": "matarlos",
    "rank": 6343,
    "frequency": 4061,
    "originalRank": 6493
  },
  {
    "word": "lastimado",
    "rank": 6344,
    "frequency": 4059,
    "originalRank": 6494
  },
  {
    "word": "delitos",
    "rank": 6345,
    "frequency": 4058,
    "originalRank": 6495
  },
  {
    "word": "espantoso",
    "rank": 6346,
    "frequency": 4057,
    "originalRank": 6496
  },
  {
    "word": "comience",
    "rank": 6347,
    "frequency": 4056,
    "originalRank": 6497
  },
  {
    "word": "quitarle",
    "rank": 6348,
    "frequency": 4055,
    "originalRank": 6498
  },
  {
    "word": "postal",
    "rank": 6349,
    "frequency": 4055,
    "originalRank": 6499
  },
  {
    "word": "irak",
    "rank": 6350,
    "frequency": 4052,
    "originalRank": 6500
  },
  {
    "word": "claridad",
    "rank": 6351,
    "frequency": 4051,
    "originalRank": 6501
  },
  {
    "word": "demostrado",
    "rank": 6352,
    "frequency": 4050,
    "originalRank": 6502
  },
  {
    "word": "acusaciones",
    "rank": 6353,
    "frequency": 4050,
    "originalRank": 6503
  },
  {
    "word": "hal",
    "rank": 6354,
    "frequency": 4050,
    "originalRank": 6504
  },
  {
    "word": "hans",
    "rank": 6355,
    "frequency": 4050,
    "originalRank": 6505
  },
  {
    "word": "bicho",
    "rank": 6356,
    "frequency": 4050,
    "originalRank": 6506
  },
  {
    "word": "beverly",
    "rank": 6357,
    "frequency": 4050,
    "originalRank": 6507
  },
  {
    "word": "sencilla",
    "rank": 6358,
    "frequency": 4047,
    "originalRank": 6508
  },
  {
    "word": "saltó",
    "rank": 6359,
    "frequency": 4047,
    "originalRank": 6509
  },
  {
    "word": "chofer",
    "rank": 6360,
    "frequency": 4047,
    "originalRank": 6510
  },
  {
    "word": "tomarlo",
    "rank": 6361,
    "frequency": 4047,
    "originalRank": 6511
  },
  {
    "word": "creéis",
    "rank": 6362,
    "frequency": 4047,
    "originalRank": 6512
  },
  {
    "word": "encantará",
    "rank": 6363,
    "frequency": 4046,
    "originalRank": 6513
  },
  {
    "word": "físicamente",
    "rank": 6364,
    "frequency": 4042,
    "originalRank": 6515
  },
  {
    "word": "occidental",
    "rank": 6365,
    "frequency": 4041,
    "originalRank": 6516
  },
  {
    "word": "ejecutivo",
    "rank": 6366,
    "frequency": 4041,
    "originalRank": 6517
  },
  {
    "word": "escondite",
    "rank": 6367,
    "frequency": 4040,
    "originalRank": 6518
  },
  {
    "word": "aumentar",
    "rank": 6368,
    "frequency": 4039,
    "originalRank": 6519
  },
  {
    "word": "entregado",
    "rank": 6369,
    "frequency": 4038,
    "originalRank": 6520
  },
  {
    "word": "mantenerme",
    "rank": 6370,
    "frequency": 4038,
    "originalRank": 6521
  },
  {
    "word": "desee",
    "rank": 6371,
    "frequency": 4038,
    "originalRank": 6522
  },
  {
    "word": "femenina",
    "rank": 6372,
    "frequency": 4037,
    "originalRank": 6523
  },
  {
    "word": "romeo",
    "rank": 6373,
    "frequency": 4037,
    "originalRank": 6524
  },
  {
    "word": "molestarte",
    "rank": 6374,
    "frequency": 4036,
    "originalRank": 6525
  },
  {
    "word": "torpe",
    "rank": 6375,
    "frequency": 4036,
    "originalRank": 6526
  },
  {
    "word": "maurice",
    "rank": 6376,
    "frequency": 4036,
    "originalRank": 6527
  },
  {
    "word": "partículas",
    "rank": 6377,
    "frequency": 4036,
    "originalRank": 6528
  },
  {
    "word": "enano",
    "rank": 6378,
    "frequency": 4035,
    "originalRank": 6529
  },
  {
    "word": "cerró",
    "rank": 6379,
    "frequency": 4033,
    "originalRank": 6530
  },
  {
    "word": "pásame",
    "rank": 6380,
    "frequency": 4031,
    "originalRank": 6531
  },
  {
    "word": "delgado",
    "rank": 6381,
    "frequency": 4031,
    "originalRank": 6532
  },
  {
    "word": "escuchamos",
    "rank": 6382,
    "frequency": 4030,
    "originalRank": 6533
  },
  {
    "word": "denuncia",
    "rank": 6383,
    "frequency": 4030,
    "originalRank": 6534
  },
  {
    "word": "dispare",
    "rank": 6384,
    "frequency": 4028,
    "originalRank": 6535
  },
  {
    "word": "vasos",
    "rank": 6385,
    "frequency": 4026,
    "originalRank": 6536
  },
  {
    "word": "serpientes",
    "rank": 6386,
    "frequency": 4025,
    "originalRank": 6537
  },
  {
    "word": "experimentos",
    "rank": 6387,
    "frequency": 4025,
    "originalRank": 6538
  },
  {
    "word": "apoyar",
    "rank": 6388,
    "frequency": 4024,
    "originalRank": 6539
  },
  {
    "word": "obsesionado",
    "rank": 6389,
    "frequency": 4022,
    "originalRank": 6540
  },
  {
    "word": "retirar",
    "rank": 6390,
    "frequency": 4022,
    "originalRank": 6541
  },
  {
    "word": "encontrarnos",
    "rank": 6391,
    "frequency": 4022,
    "originalRank": 6542
  },
  {
    "word": "dada",
    "rank": 6392,
    "frequency": 4022,
    "originalRank": 6543
  },
  {
    "word": "cállese",
    "rank": 6393,
    "frequency": 4020,
    "originalRank": 6544
  },
  {
    "word": "aquellas",
    "rank": 6394,
    "frequency": 4020,
    "originalRank": 6545
  },
  {
    "word": "detención",
    "rank": 6395,
    "frequency": 4020,
    "originalRank": 6546
  },
  {
    "word": "tristes",
    "rank": 6396,
    "frequency": 4019,
    "originalRank": 6547
  },
  {
    "word": "perímetro",
    "rank": 6397,
    "frequency": 4018,
    "originalRank": 6548
  },
  {
    "word": "bloqueo",
    "rank": 6398,
    "frequency": 4018,
    "originalRank": 6549
  },
  {
    "word": "preguntaré",
    "rank": 6399,
    "frequency": 4018,
    "originalRank": 6550
  },
  {
    "word": "intenso",
    "rank": 6400,
    "frequency": 4017,
    "originalRank": 6551
  },
  {
    "word": "pierce",
    "rank": 6401,
    "frequency": 4017,
    "originalRank": 6552
  },
  {
    "word": "construyendo",
    "rank": 6402,
    "frequency": 4015,
    "originalRank": 6553
  },
  {
    "word": "principalmente",
    "rank": 6403,
    "frequency": 4015,
    "originalRank": 6554
  },
  {
    "word": "suelen",
    "rank": 6404,
    "frequency": 4012,
    "originalRank": 6555
  },
  {
    "word": "portátil",
    "rank": 6405,
    "frequency": 4011,
    "originalRank": 6556
  },
  {
    "word": "vagabundo",
    "rank": 6406,
    "frequency": 4011,
    "originalRank": 6557
  },
  {
    "word": "comemos",
    "rank": 6407,
    "frequency": 4010,
    "originalRank": 6558
  },
  {
    "word": "pueblos",
    "rank": 6408,
    "frequency": 4009,
    "originalRank": 6559
  },
  {
    "word": "casamos",
    "rank": 6409,
    "frequency": 4007,
    "originalRank": 6560
  },
  {
    "word": "investigador",
    "rank": 6410,
    "frequency": 4007,
    "originalRank": 6561
  },
  {
    "word": "suministros",
    "rank": 6411,
    "frequency": 4006,
    "originalRank": 6562
  },
  {
    "word": "putos",
    "rank": 6412,
    "frequency": 4006,
    "originalRank": 6563
  },
  {
    "word": "preocupaba",
    "rank": 6413,
    "frequency": 4006,
    "originalRank": 6564
  },
  {
    "word": "conversar",
    "rank": 6414,
    "frequency": 4005,
    "originalRank": 6565
  },
  {
    "word": "daphne",
    "rank": 6415,
    "frequency": 4005,
    "originalRank": 6566
  },
  {
    "word": "valientes",
    "rank": 6416,
    "frequency": 4004,
    "originalRank": 6567
  },
  {
    "word": "sebastian",
    "rank": 6417,
    "frequency": 4004,
    "originalRank": 6568
  },
  {
    "word": "mcgee",
    "rank": 6418,
    "frequency": 4003,
    "originalRank": 6569
  },
  {
    "word": "hockey",
    "rank": 6419,
    "frequency": 4001,
    "originalRank": 6570
  },
  {
    "word": "vendré",
    "rank": 6420,
    "frequency": 4001,
    "originalRank": 6571
  },
  {
    "word": "vicepresidente",
    "rank": 6421,
    "frequency": 4001,
    "originalRank": 6572
  },
  {
    "word": "transferencia",
    "rank": 6422,
    "frequency": 4000,
    "originalRank": 6573
  },
  {
    "word": "garantía",
    "rank": 6423,
    "frequency": 3999,
    "originalRank": 6574
  },
  {
    "word": "torta",
    "rank": 6424,
    "frequency": 3999,
    "originalRank": 6575
  },
  {
    "word": "tremendo",
    "rank": 6425,
    "frequency": 3999,
    "originalRank": 6576
  },
  {
    "word": "entremos",
    "rank": 6426,
    "frequency": 3998,
    "originalRank": 6577
  },
  {
    "word": "devolveré",
    "rank": 6427,
    "frequency": 3998,
    "originalRank": 6578
  },
  {
    "word": "barata",
    "rank": 6428,
    "frequency": 3998,
    "originalRank": 6579
  },
  {
    "word": "alfred",
    "rank": 6429,
    "frequency": 3997,
    "originalRank": 6580
  },
  {
    "word": "extraterrestres",
    "rank": 6430,
    "frequency": 3995,
    "originalRank": 6581
  },
  {
    "word": "pegar",
    "rank": 6431,
    "frequency": 3993,
    "originalRank": 6582
  },
  {
    "word": "comprobado",
    "rank": 6432,
    "frequency": 3993,
    "originalRank": 6583
  },
  {
    "word": "isaac",
    "rank": 6433,
    "frequency": 3992,
    "originalRank": 6584
  },
  {
    "word": "esperaremos",
    "rank": 6434,
    "frequency": 3992,
    "originalRank": 6585
  },
  {
    "word": "stark",
    "rank": 6435,
    "frequency": 3991,
    "originalRank": 6586
  },
  {
    "word": "costará",
    "rank": 6436,
    "frequency": 3990,
    "originalRank": 6587
  },
  {
    "word": "descanse",
    "rank": 6437,
    "frequency": 3990,
    "originalRank": 6588
  },
  {
    "word": "dulzura",
    "rank": 6438,
    "frequency": 3987,
    "originalRank": 6589
  },
  {
    "word": "escondidas",
    "rank": 6439,
    "frequency": 3986,
    "originalRank": 6590
  },
  {
    "word": "lastimar",
    "rank": 6440,
    "frequency": 3985,
    "originalRank": 6591
  },
  {
    "word": "pasaje",
    "rank": 6441,
    "frequency": 3984,
    "originalRank": 6592
  },
  {
    "word": "acercó",
    "rank": 6442,
    "frequency": 3984,
    "originalRank": 6593
  },
  {
    "word": "encontrarse",
    "rank": 6443,
    "frequency": 3983,
    "originalRank": 6594
  },
  {
    "word": "negar",
    "rank": 6444,
    "frequency": 3983,
    "originalRank": 6595
  },
  {
    "word": "pensaron",
    "rank": 6445,
    "frequency": 3983,
    "originalRank": 6596
  },
  {
    "word": "vulnerable",
    "rank": 6446,
    "frequency": 3982,
    "originalRank": 6597
  },
  {
    "word": "lenta",
    "rank": 6447,
    "frequency": 3981,
    "originalRank": 6598
  },
  {
    "word": "atacaron",
    "rank": 6448,
    "frequency": 3980,
    "originalRank": 6599
  },
  {
    "word": "quite",
    "rank": 6449,
    "frequency": 3979,
    "originalRank": 6600
  },
  {
    "word": "suéltalo",
    "rank": 6450,
    "frequency": 3979,
    "originalRank": 6601
  },
  {
    "word": "manny",
    "rank": 6451,
    "frequency": 3979,
    "originalRank": 6602
  },
  {
    "word": "mercedes",
    "rank": 6452,
    "frequency": 3979,
    "originalRank": 6603
  },
  {
    "word": "portal",
    "rank": 6453,
    "frequency": 3978,
    "originalRank": 6604
  },
  {
    "word": "necesitarás",
    "rank": 6454,
    "frequency": 3978,
    "originalRank": 6605
  },
  {
    "word": "pudiese",
    "rank": 6455,
    "frequency": 3978,
    "originalRank": 6606
  },
  {
    "word": "linterna",
    "rank": 6456,
    "frequency": 3976,
    "originalRank": 6607
  },
  {
    "word": "alemana",
    "rank": 6457,
    "frequency": 3975,
    "originalRank": 6608
  },
  {
    "word": "lindos",
    "rank": 6458,
    "frequency": 3975,
    "originalRank": 6609
  },
  {
    "word": "zorro",
    "rank": 6459,
    "frequency": 3974,
    "originalRank": 6610
  },
  {
    "word": "vestuario",
    "rank": 6460,
    "frequency": 3973,
    "originalRank": 6611
  },
  {
    "word": "evidencias",
    "rank": 6461,
    "frequency": 3973,
    "originalRank": 6612
  },
  {
    "word": "garantizo",
    "rank": 6462,
    "frequency": 3972,
    "originalRank": 6613
  },
  {
    "word": "criar",
    "rank": 6463,
    "frequency": 3972,
    "originalRank": 6614
  },
  {
    "word": "colocar",
    "rank": 6464,
    "frequency": 3971,
    "originalRank": 6615
  },
  {
    "word": "auténtica",
    "rank": 6465,
    "frequency": 3971,
    "originalRank": 6616
  },
  {
    "word": "pendejo",
    "rank": 6466,
    "frequency": 3970,
    "originalRank": 6617
  },
  {
    "word": "ordenar",
    "rank": 6467,
    "frequency": 3969,
    "originalRank": 6618
  },
  {
    "word": "debimos",
    "rank": 6468,
    "frequency": 3968,
    "originalRank": 6619
  },
  {
    "word": "cabe",
    "rank": 6469,
    "frequency": 3968,
    "originalRank": 6620
  },
  {
    "word": "alimento",
    "rank": 6470,
    "frequency": 3967,
    "originalRank": 6621
  },
  {
    "word": "pilotos",
    "rank": 6471,
    "frequency": 3966,
    "originalRank": 6622
  },
  {
    "word": "amiguito",
    "rank": 6472,
    "frequency": 3965,
    "originalRank": 6623
  },
  {
    "word": "gorra",
    "rank": 6473,
    "frequency": 3964,
    "originalRank": 6624
  },
  {
    "word": "revisión",
    "rank": 6474,
    "frequency": 3964,
    "originalRank": 6625
  },
  {
    "word": "exacta",
    "rank": 6475,
    "frequency": 3964,
    "originalRank": 6626
  },
  {
    "word": "hanna",
    "rank": 6476,
    "frequency": 3964,
    "originalRank": 6627
  },
  {
    "word": "dong",
    "rank": 6477,
    "frequency": 3964,
    "originalRank": 6628
  },
  {
    "word": "vehículos",
    "rank": 6478,
    "frequency": 3963,
    "originalRank": 6629
  },
  {
    "word": "presentarte",
    "rank": 6479,
    "frequency": 3962,
    "originalRank": 6630
  },
  {
    "word": "recibirá",
    "rank": 6480,
    "frequency": 3961,
    "originalRank": 6631
  },
  {
    "word": "khan",
    "rank": 6481,
    "frequency": 3961,
    "originalRank": 6632
  },
  {
    "word": "evidentemente",
    "rank": 6482,
    "frequency": 3960,
    "originalRank": 6633
  },
  {
    "word": "joel",
    "rank": 6483,
    "frequency": 3959,
    "originalRank": 6634
  },
  {
    "word": "senado",
    "rank": 6484,
    "frequency": 3959,
    "originalRank": 6635
  },
  {
    "word": "atras",
    "rank": 6485,
    "frequency": 3958,
    "originalRank": 6636
  },
  {
    "word": "caramelos",
    "rank": 6486,
    "frequency": 3958,
    "originalRank": 6637
  },
  {
    "word": "ofrezco",
    "rank": 6487,
    "frequency": 3957,
    "originalRank": 6638
  },
  {
    "word": "trataré",
    "rank": 6488,
    "frequency": 3956,
    "originalRank": 6639
  },
  {
    "word": "usaste",
    "rank": 6489,
    "frequency": 3956,
    "originalRank": 6641
  },
  {
    "word": "déme",
    "rank": 6490,
    "frequency": 3956,
    "originalRank": 6642
  },
  {
    "word": "salvación",
    "rank": 6491,
    "frequency": 3956,
    "originalRank": 6643
  },
  {
    "word": "cobra",
    "rank": 6492,
    "frequency": 3955,
    "originalRank": 6644
  },
  {
    "word": "baloncesto",
    "rank": 6493,
    "frequency": 3955,
    "originalRank": 6645
  },
  {
    "word": "pacto",
    "rank": 6494,
    "frequency": 3954,
    "originalRank": 6646
  },
  {
    "word": "aceptó",
    "rank": 6495,
    "frequency": 3952,
    "originalRank": 6647
  },
  {
    "word": "vientre",
    "rank": 6496,
    "frequency": 3950,
    "originalRank": 6648
  },
  {
    "word": "jessie",
    "rank": 6497,
    "frequency": 3949,
    "originalRank": 6649
  },
  {
    "word": "yang",
    "rank": 6498,
    "frequency": 3948,
    "originalRank": 6650
  },
  {
    "word": "tuviéramos",
    "rank": 6499,
    "frequency": 3948,
    "originalRank": 6651
  },
  {
    "word": "callar",
    "rank": 6500,
    "frequency": 3947,
    "originalRank": 6652
  },
  {
    "word": "deliciosa",
    "rank": 6501,
    "frequency": 3946,
    "originalRank": 6653
  },
  {
    "word": "mirarme",
    "rank": 6502,
    "frequency": 3944,
    "originalRank": 6654
  },
  {
    "word": "opina",
    "rank": 6503,
    "frequency": 3943,
    "originalRank": 6655
  },
  {
    "word": "roll",
    "rank": 6504,
    "frequency": 3942,
    "originalRank": 6656
  },
  {
    "word": "negó",
    "rank": 6505,
    "frequency": 3942,
    "originalRank": 6657
  },
  {
    "word": "rubio",
    "rank": 6506,
    "frequency": 3941,
    "originalRank": 6658
  },
  {
    "word": "boyd",
    "rank": 6507,
    "frequency": 3940,
    "originalRank": 6659
  },
  {
    "word": "tomate",
    "rank": 6508,
    "frequency": 3940,
    "originalRank": 6660
  },
  {
    "word": "césped",
    "rank": 6509,
    "frequency": 3938,
    "originalRank": 6661
  },
  {
    "word": "inicial",
    "rank": 6510,
    "frequency": 3938,
    "originalRank": 6662
  },
  {
    "word": "aplauso",
    "rank": 6511,
    "frequency": 3936,
    "originalRank": 6663
  },
  {
    "word": "centímetros",
    "rank": 6512,
    "frequency": 3935,
    "originalRank": 6664
  },
  {
    "word": "ordenes",
    "rank": 6513,
    "frequency": 3935,
    "originalRank": 6665
  },
  {
    "word": "peggy",
    "rank": 6514,
    "frequency": 3934,
    "originalRank": 6666
  },
  {
    "word": "ingresos",
    "rank": 6515,
    "frequency": 3934,
    "originalRank": 6667
  },
  {
    "word": "homero",
    "rank": 6516,
    "frequency": 3934,
    "originalRank": 6668
  },
  {
    "word": "accidentes",
    "rank": 6517,
    "frequency": 3934,
    "originalRank": 6669
  },
  {
    "word": "declarar",
    "rank": 6518,
    "frequency": 3933,
    "originalRank": 6670
  },
  {
    "word": "canalla",
    "rank": 6519,
    "frequency": 3933,
    "originalRank": 6671
  },
  {
    "word": "oyeron",
    "rank": 6520,
    "frequency": 3932,
    "originalRank": 6672
  },
  {
    "word": "douglas",
    "rank": 6521,
    "frequency": 3932,
    "originalRank": 6673
  },
  {
    "word": "ordeno",
    "rank": 6522,
    "frequency": 3931,
    "originalRank": 6674
  },
  {
    "word": "jovencito",
    "rank": 6523,
    "frequency": 3931,
    "originalRank": 6675
  },
  {
    "word": "hospitales",
    "rank": 6524,
    "frequency": 3930,
    "originalRank": 6676
  },
  {
    "word": "engañó",
    "rank": 6525,
    "frequency": 3928,
    "originalRank": 6677
  },
  {
    "word": "esperes",
    "rank": 6526,
    "frequency": 3927,
    "originalRank": 6678
  },
  {
    "word": "respetar",
    "rank": 6527,
    "frequency": 3926,
    "originalRank": 6679
  },
  {
    "word": "filmar",
    "rank": 6528,
    "frequency": 3926,
    "originalRank": 6680
  },
  {
    "word": "rana",
    "rank": 6529,
    "frequency": 3924,
    "originalRank": 6681
  },
  {
    "word": "mosca",
    "rank": 6530,
    "frequency": 3924,
    "originalRank": 6682
  },
  {
    "word": "vecina",
    "rank": 6531,
    "frequency": 3923,
    "originalRank": 6683
  },
  {
    "word": "ansiedad",
    "rank": 6532,
    "frequency": 3920,
    "originalRank": 6684
  },
  {
    "word": "puño",
    "rank": 6533,
    "frequency": 3920,
    "originalRank": 6685
  },
  {
    "word": "veis",
    "rank": 6534,
    "frequency": 3919,
    "originalRank": 6686
  },
  {
    "word": "premios",
    "rank": 6535,
    "frequency": 3919,
    "originalRank": 6687
  },
  {
    "word": "leerlo",
    "rank": 6536,
    "frequency": 3919,
    "originalRank": 6688
  },
  {
    "word": "rama",
    "rank": 6537,
    "frequency": 3919,
    "originalRank": 6689
  },
  {
    "word": "perderte",
    "rank": 6538,
    "frequency": 3918,
    "originalRank": 6690
  },
  {
    "word": "envíe",
    "rank": 6539,
    "frequency": 3917,
    "originalRank": 6691
  },
  {
    "word": "retirada",
    "rank": 6540,
    "frequency": 3916,
    "originalRank": 6692
  },
  {
    "word": "averigua",
    "rank": 6541,
    "frequency": 3916,
    "originalRank": 6693
  },
  {
    "word": "curva",
    "rank": 6542,
    "frequency": 3915,
    "originalRank": 6694
  },
  {
    "word": "brilla",
    "rank": 6543,
    "frequency": 3914,
    "originalRank": 6695
  },
  {
    "word": "debas",
    "rank": 6544,
    "frequency": 3912,
    "originalRank": 6696
  },
  {
    "word": "aventuras",
    "rank": 6545,
    "frequency": 3911,
    "originalRank": 6697
  },
  {
    "word": "ofrecido",
    "rank": 6546,
    "frequency": 3910,
    "originalRank": 6698
  },
  {
    "word": "considero",
    "rank": 6547,
    "frequency": 3909,
    "originalRank": 6699
  },
  {
    "word": "romano",
    "rank": 6548,
    "frequency": 3909,
    "originalRank": 6700
  },
  {
    "word": "portero",
    "rank": 6549,
    "frequency": 3908,
    "originalRank": 6701
  },
  {
    "word": "sospechas",
    "rank": 6550,
    "frequency": 3908,
    "originalRank": 6702
  },
  {
    "word": "elaine",
    "rank": 6551,
    "frequency": 3908,
    "originalRank": 6703
  },
  {
    "word": "sepamos",
    "rank": 6552,
    "frequency": 3908,
    "originalRank": 6704
  },
  {
    "word": "bobo",
    "rank": 6553,
    "frequency": 3907,
    "originalRank": 6705
  },
  {
    "word": "algodón",
    "rank": 6554,
    "frequency": 3906,
    "originalRank": 6706
  },
  {
    "word": "sexto",
    "rank": 6555,
    "frequency": 3906,
    "originalRank": 6707
  },
  {
    "word": "bajó",
    "rank": 6556,
    "frequency": 3906,
    "originalRank": 6708
  },
  {
    "word": "crítico",
    "rank": 6557,
    "frequency": 3905,
    "originalRank": 6709
  },
  {
    "word": "soñé",
    "rank": 6558,
    "frequency": 3904,
    "originalRank": 6710
  },
  {
    "word": "eterno",
    "rank": 6559,
    "frequency": 3903,
    "originalRank": 6711
  },
  {
    "word": "entusiasmo",
    "rank": 6560,
    "frequency": 3902,
    "originalRank": 6712
  },
  {
    "word": "instalaciones",
    "rank": 6561,
    "frequency": 3901,
    "originalRank": 6713
  },
  {
    "word": "manejo",
    "rank": 6562,
    "frequency": 3900,
    "originalRank": 6714
  },
  {
    "word": "saludo",
    "rank": 6563,
    "frequency": 3898,
    "originalRank": 6715
  },
  {
    "word": "compramos",
    "rank": 6564,
    "frequency": 3898,
    "originalRank": 6716
  },
  {
    "word": "ultimo",
    "rank": 6565,
    "frequency": 3897,
    "originalRank": 6717
  },
  {
    "word": "posee",
    "rank": 6566,
    "frequency": 3897,
    "originalRank": 6718
  },
  {
    "word": "castigado",
    "rank": 6567,
    "frequency": 3896,
    "originalRank": 6719
  },
  {
    "word": "cohete",
    "rank": 6568,
    "frequency": 3896,
    "originalRank": 6720
  },
  {
    "word": "gps",
    "rank": 6569,
    "frequency": 3896,
    "originalRank": 6721
  },
  {
    "word": "disculpo",
    "rank": 6570,
    "frequency": 3895,
    "originalRank": 6722
  },
  {
    "word": "extrañar",
    "rank": 6571,
    "frequency": 3894,
    "originalRank": 6723
  },
  {
    "word": "salvarme",
    "rank": 6572,
    "frequency": 3892,
    "originalRank": 6724
  },
  {
    "word": "nazi",
    "rank": 6573,
    "frequency": 3892,
    "originalRank": 6725
  },
  {
    "word": "sostén",
    "rank": 6574,
    "frequency": 3892,
    "originalRank": 6726
  },
  {
    "word": "fórmula",
    "rank": 6575,
    "frequency": 3891,
    "originalRank": 6727
  },
  {
    "word": "limón",
    "rank": 6576,
    "frequency": 3890,
    "originalRank": 6728
  },
  {
    "word": "erica",
    "rank": 6577,
    "frequency": 3890,
    "originalRank": 6729
  },
  {
    "word": "jamón",
    "rank": 6578,
    "frequency": 3889,
    "originalRank": 6730
  },
  {
    "word": "boom",
    "rank": 6579,
    "frequency": 3889,
    "originalRank": 6731
  },
  {
    "word": "sensores",
    "rank": 6580,
    "frequency": 3888,
    "originalRank": 6732
  },
  {
    "word": "esencia",
    "rank": 6581,
    "frequency": 3887,
    "originalRank": 6733
  },
  {
    "word": "instrumento",
    "rank": 6582,
    "frequency": 3887,
    "originalRank": 6734
  },
  {
    "word": "renuncia",
    "rank": 6583,
    "frequency": 3886,
    "originalRank": 6735
  },
  {
    "word": "elegí",
    "rank": 6584,
    "frequency": 3885,
    "originalRank": 6736
  },
  {
    "word": "fusión",
    "rank": 6585,
    "frequency": 3885,
    "originalRank": 6737
  },
  {
    "word": "atrevas",
    "rank": 6586,
    "frequency": 3885,
    "originalRank": 6738
  },
  {
    "word": "intentaste",
    "rank": 6587,
    "frequency": 3885,
    "originalRank": 6739
  },
  {
    "word": "suicida",
    "rank": 6588,
    "frequency": 3883,
    "originalRank": 6740
  },
  {
    "word": "rebelde",
    "rank": 6589,
    "frequency": 3879,
    "originalRank": 6741
  },
  {
    "word": "vago",
    "rank": 6590,
    "frequency": 3878,
    "originalRank": 6742
  },
  {
    "word": "vías",
    "rank": 6591,
    "frequency": 3878,
    "originalRank": 6743
  },
  {
    "word": "samuel",
    "rank": 6592,
    "frequency": 3878,
    "originalRank": 6744
  },
  {
    "word": "camaradas",
    "rank": 6593,
    "frequency": 3876,
    "originalRank": 6745
  },
  {
    "word": "winston",
    "rank": 6594,
    "frequency": 3875,
    "originalRank": 6746
  },
  {
    "word": "asustó",
    "rank": 6595,
    "frequency": 3874,
    "originalRank": 6747
  },
  {
    "word": "revelar",
    "rank": 6596,
    "frequency": 3874,
    "originalRank": 6748
  },
  {
    "word": "sugerencia",
    "rank": 6597,
    "frequency": 3874,
    "originalRank": 6749
  },
  {
    "word": "srta",
    "rank": 6598,
    "frequency": 3874,
    "originalRank": 6750
  },
  {
    "word": "echas",
    "rank": 6599,
    "frequency": 3873,
    "originalRank": 6751
  },
  {
    "word": "caca",
    "rank": 6600,
    "frequency": 3873,
    "originalRank": 6752
  },
  {
    "word": "shirley",
    "rank": 6601,
    "frequency": 3873,
    "originalRank": 6753
  },
  {
    "word": "legales",
    "rank": 6602,
    "frequency": 3872,
    "originalRank": 6754
  },
  {
    "word": "legalmente",
    "rank": 6603,
    "frequency": 3871,
    "originalRank": 6755
  },
  {
    "word": "clyde",
    "rank": 6604,
    "frequency": 3871,
    "originalRank": 6756
  },
  {
    "word": "won",
    "rank": 6605,
    "frequency": 3870,
    "originalRank": 6757
  },
  {
    "word": "prostitutas",
    "rank": 6606,
    "frequency": 3870,
    "originalRank": 6758
  },
  {
    "word": "promedio",
    "rank": 6607,
    "frequency": 3869,
    "originalRank": 6759
  },
  {
    "word": "tela",
    "rank": 6608,
    "frequency": 3868,
    "originalRank": 6760
  },
  {
    "word": "kathy",
    "rank": 6609,
    "frequency": 3865,
    "originalRank": 6761
  },
  {
    "word": "superado",
    "rank": 6610,
    "frequency": 3865,
    "originalRank": 6762
  },
  {
    "word": "aires",
    "rank": 6611,
    "frequency": 3865,
    "originalRank": 6763
  },
  {
    "word": "ardiendo",
    "rank": 6612,
    "frequency": 3865,
    "originalRank": 6764
  },
  {
    "word": "alturas",
    "rank": 6613,
    "frequency": 3864,
    "originalRank": 6765
  },
  {
    "word": "preferido",
    "rank": 6614,
    "frequency": 3863,
    "originalRank": 6766
  },
  {
    "word": "arrestar",
    "rank": 6615,
    "frequency": 3863,
    "originalRank": 6767
  },
  {
    "word": "respirando",
    "rank": 6616,
    "frequency": 3863,
    "originalRank": 6768
  },
  {
    "word": "sonaba",
    "rank": 6617,
    "frequency": 3863,
    "originalRank": 6769
  },
  {
    "word": "especialidad",
    "rank": 6618,
    "frequency": 3861,
    "originalRank": 6770
  },
  {
    "word": "rocky",
    "rank": 6619,
    "frequency": 3861,
    "originalRank": 6771
  },
  {
    "word": "griego",
    "rank": 6620,
    "frequency": 3859,
    "originalRank": 6772
  },
  {
    "word": "conservar",
    "rank": 6621,
    "frequency": 3859,
    "originalRank": 6773
  },
  {
    "word": "huelo",
    "rank": 6622,
    "frequency": 3857,
    "originalRank": 6774
  },
  {
    "word": "crucero",
    "rank": 6623,
    "frequency": 3856,
    "originalRank": 6775
  },
  {
    "word": "esencial",
    "rank": 6624,
    "frequency": 3856,
    "originalRank": 6776
  },
  {
    "word": "diviértete",
    "rank": 6625,
    "frequency": 3856,
    "originalRank": 6777
  },
  {
    "word": "pendientes",
    "rank": 6626,
    "frequency": 3854,
    "originalRank": 6778
  },
  {
    "word": "cerradura",
    "rank": 6627,
    "frequency": 3852,
    "originalRank": 6779
  },
  {
    "word": "récord",
    "rank": 6628,
    "frequency": 3852,
    "originalRank": 6780
  },
  {
    "word": "aparecen",
    "rank": 6629,
    "frequency": 3850,
    "originalRank": 6781
  },
  {
    "word": "atascado",
    "rank": 6630,
    "frequency": 3847,
    "originalRank": 6782
  },
  {
    "word": "distracción",
    "rank": 6631,
    "frequency": 3847,
    "originalRank": 6783
  },
  {
    "word": "camas",
    "rank": 6632,
    "frequency": 3847,
    "originalRank": 6784
  },
  {
    "word": "acordamos",
    "rank": 6633,
    "frequency": 3846,
    "originalRank": 6785
  },
  {
    "word": "supermercado",
    "rank": 6634,
    "frequency": 3845,
    "originalRank": 6786
  },
  {
    "word": "tucker",
    "rank": 6635,
    "frequency": 3843,
    "originalRank": 6787
  },
  {
    "word": "echaron",
    "rank": 6636,
    "frequency": 3843,
    "originalRank": 6788
  },
  {
    "word": "tomarme",
    "rank": 6637,
    "frequency": 3843,
    "originalRank": 6789
  },
  {
    "word": "caramelo",
    "rank": 6638,
    "frequency": 3843,
    "originalRank": 6790
  },
  {
    "word": "bastantes",
    "rank": 6639,
    "frequency": 3842,
    "originalRank": 6791
  },
  {
    "word": "liras",
    "rank": 6640,
    "frequency": 3840,
    "originalRank": 6792
  },
  {
    "word": "lees",
    "rank": 6641,
    "frequency": 3840,
    "originalRank": 6793
  },
  {
    "word": "extraordinaria",
    "rank": 6642,
    "frequency": 3839,
    "originalRank": 6794
  },
  {
    "word": "arranca",
    "rank": 6643,
    "frequency": 3839,
    "originalRank": 6795
  },
  {
    "word": "manejando",
    "rank": 6644,
    "frequency": 3836,
    "originalRank": 6796
  },
  {
    "word": "vendrías",
    "rank": 6645,
    "frequency": 3835,
    "originalRank": 6797
  },
  {
    "word": "enviaste",
    "rank": 6646,
    "frequency": 3834,
    "originalRank": 6798
  },
  {
    "word": "barnes",
    "rank": 6647,
    "frequency": 3833,
    "originalRank": 6799
  },
  {
    "word": "manada",
    "rank": 6648,
    "frequency": 3833,
    "originalRank": 6800
  },
  {
    "word": "llamaban",
    "rank": 6649,
    "frequency": 3832,
    "originalRank": 6801
  },
  {
    "word": "bienestar",
    "rank": 6650,
    "frequency": 3831,
    "originalRank": 6802
  },
  {
    "word": "hugo",
    "rank": 6651,
    "frequency": 3831,
    "originalRank": 6803
  },
  {
    "word": "galleta",
    "rank": 6652,
    "frequency": 3831,
    "originalRank": 6804
  },
  {
    "word": "encantar",
    "rank": 6653,
    "frequency": 3831,
    "originalRank": 6805
  },
  {
    "word": "fiscalía",
    "rank": 6654,
    "frequency": 3830,
    "originalRank": 6806
  },
  {
    "word": "reunido",
    "rank": 6655,
    "frequency": 3830,
    "originalRank": 6807
  },
  {
    "word": "lola",
    "rank": 6656,
    "frequency": 3830,
    "originalRank": 6808
  },
  {
    "word": "fumando",
    "rank": 6657,
    "frequency": 3829,
    "originalRank": 6809
  },
  {
    "word": "ríes",
    "rank": 6658,
    "frequency": 3828,
    "originalRank": 6810
  },
  {
    "word": "enrique",
    "rank": 6659,
    "frequency": 3828,
    "originalRank": 6811
  },
  {
    "word": "mediante",
    "rank": 6660,
    "frequency": 3827,
    "originalRank": 6812
  },
  {
    "word": "bishop",
    "rank": 6661,
    "frequency": 3826,
    "originalRank": 6813
  },
  {
    "word": "expresar",
    "rank": 6662,
    "frequency": 3826,
    "originalRank": 6814
  },
  {
    "word": "sientan",
    "rank": 6663,
    "frequency": 3825,
    "originalRank": 6815
  },
  {
    "word": "tierno",
    "rank": 6664,
    "frequency": 3824,
    "originalRank": 6816
  },
  {
    "word": "llamaremos",
    "rank": 6665,
    "frequency": 3823,
    "originalRank": 6817
  },
  {
    "word": "valen",
    "rank": 6666,
    "frequency": 3823,
    "originalRank": 6818
  },
  {
    "word": "ginebra",
    "rank": 6667,
    "frequency": 3821,
    "originalRank": 6819
  },
  {
    "word": "levantó",
    "rank": 6668,
    "frequency": 3820,
    "originalRank": 6820
  },
  {
    "word": "políticas",
    "rank": 6669,
    "frequency": 3819,
    "originalRank": 6821
  },
  {
    "word": "interesan",
    "rank": 6670,
    "frequency": 3817,
    "originalRank": 6822
  },
  {
    "word": "deberias",
    "rank": 6671,
    "frequency": 3816,
    "originalRank": 6823
  },
  {
    "word": "pistolas",
    "rank": 6672,
    "frequency": 3815,
    "originalRank": 6824
  },
  {
    "word": "agotado",
    "rank": 6673,
    "frequency": 3815,
    "originalRank": 6825
  },
  {
    "word": "especies",
    "rank": 6674,
    "frequency": 3815,
    "originalRank": 6826
  },
  {
    "word": "científica",
    "rank": 6675,
    "frequency": 3814,
    "originalRank": 6827
  },
  {
    "word": "llamará",
    "rank": 6676,
    "frequency": 3812,
    "originalRank": 6828
  },
  {
    "word": "oscuras",
    "rank": 6677,
    "frequency": 3812,
    "originalRank": 6829
  },
  {
    "word": "herir",
    "rank": 6678,
    "frequency": 3812,
    "originalRank": 6830
  },
  {
    "word": "entrevistas",
    "rank": 6679,
    "frequency": 3812,
    "originalRank": 6831
  },
  {
    "word": "competición",
    "rank": 6680,
    "frequency": 3811,
    "originalRank": 6832
  },
  {
    "word": "materiales",
    "rank": 6681,
    "frequency": 3811,
    "originalRank": 6833
  },
  {
    "word": "acostarse",
    "rank": 6682,
    "frequency": 3810,
    "originalRank": 6834
  },
  {
    "word": "arruinó",
    "rank": 6683,
    "frequency": 3810,
    "originalRank": 6835
  },
  {
    "word": "brutal",
    "rank": 6684,
    "frequency": 3810,
    "originalRank": 6836
  },
  {
    "word": "responsabilidades",
    "rank": 6685,
    "frequency": 3809,
    "originalRank": 6837
  },
  {
    "word": "glenn",
    "rank": 6686,
    "frequency": 3809,
    "originalRank": 6838
  },
  {
    "word": "guardaespaldas",
    "rank": 6687,
    "frequency": 3809,
    "originalRank": 6839
  },
  {
    "word": "pretende",
    "rank": 6688,
    "frequency": 3809,
    "originalRank": 6840
  },
  {
    "word": "inyección",
    "rank": 6689,
    "frequency": 3809,
    "originalRank": 6841
  },
  {
    "word": "adora",
    "rank": 6690,
    "frequency": 3808,
    "originalRank": 6842
  },
  {
    "word": "arregla",
    "rank": 6691,
    "frequency": 3807,
    "originalRank": 6843
  },
  {
    "word": "flecha",
    "rank": 6692,
    "frequency": 3807,
    "originalRank": 6844
  },
  {
    "word": "mudó",
    "rank": 6693,
    "frequency": 3806,
    "originalRank": 6845
  },
  {
    "word": "armadura",
    "rank": 6694,
    "frequency": 3804,
    "originalRank": 6846
  },
  {
    "word": "advertí",
    "rank": 6695,
    "frequency": 3803,
    "originalRank": 6847
  },
  {
    "word": "necesaria",
    "rank": 6696,
    "frequency": 3802,
    "originalRank": 6848
  },
  {
    "word": "mañanas",
    "rank": 6697,
    "frequency": 3801,
    "originalRank": 6849
  },
  {
    "word": "cortinas",
    "rank": 6698,
    "frequency": 3801,
    "originalRank": 6850
  },
  {
    "word": "cruce",
    "rank": 6699,
    "frequency": 3800,
    "originalRank": 6851
  },
  {
    "word": "músico",
    "rank": 6700,
    "frequency": 3800,
    "originalRank": 6852
  },
  {
    "word": "tire",
    "rank": 6701,
    "frequency": 3800,
    "originalRank": 6853
  },
  {
    "word": "parecían",
    "rank": 6702,
    "frequency": 3799,
    "originalRank": 6854
  },
  {
    "word": "serios",
    "rank": 6703,
    "frequency": 3799,
    "originalRank": 6855
  },
  {
    "word": "escoria",
    "rank": 6704,
    "frequency": 3798,
    "originalRank": 6856
  },
  {
    "word": "morirán",
    "rank": 6705,
    "frequency": 3798,
    "originalRank": 6857
  },
  {
    "word": "coco",
    "rank": 6706,
    "frequency": 3796,
    "originalRank": 6858
  },
  {
    "word": "sullivan",
    "rank": 6707,
    "frequency": 3796,
    "originalRank": 6859
  },
  {
    "word": "encontraría",
    "rank": 6708,
    "frequency": 3794,
    "originalRank": 6860
  },
  {
    "word": "marta",
    "rank": 6709,
    "frequency": 3794,
    "originalRank": 6861
  },
  {
    "word": "nevera",
    "rank": 6710,
    "frequency": 3794,
    "originalRank": 6862
  },
  {
    "word": "sonriendo",
    "rank": 6711,
    "frequency": 3793,
    "originalRank": 6863
  },
  {
    "word": "beach",
    "rank": 6712,
    "frequency": 3792,
    "originalRank": 6864
  },
  {
    "word": "decides",
    "rank": 6713,
    "frequency": 3791,
    "originalRank": 6865
  },
  {
    "word": "pagarle",
    "rank": 6714,
    "frequency": 3791,
    "originalRank": 6866
  },
  {
    "word": "sorprendida",
    "rank": 6715,
    "frequency": 3790,
    "originalRank": 6867
  },
  {
    "word": "dejarlos",
    "rank": 6716,
    "frequency": 3790,
    "originalRank": 6868
  },
  {
    "word": "usualmente",
    "rank": 6717,
    "frequency": 3790,
    "originalRank": 6869
  },
  {
    "word": "aceptas",
    "rank": 6718,
    "frequency": 3788,
    "originalRank": 6870
  },
  {
    "word": "culpables",
    "rank": 6719,
    "frequency": 3788,
    "originalRank": 6871
  },
  {
    "word": "sacarla",
    "rank": 6720,
    "frequency": 3788,
    "originalRank": 6872
  },
  {
    "word": "cigarro",
    "rank": 6721,
    "frequency": 3788,
    "originalRank": 6873
  },
  {
    "word": "lindas",
    "rank": 6722,
    "frequency": 3788,
    "originalRank": 6874
  },
  {
    "word": "declaraciones",
    "rank": 6723,
    "frequency": 3787,
    "originalRank": 6875
  },
  {
    "word": "honrado",
    "rank": 6724,
    "frequency": 3787,
    "originalRank": 6876
  },
  {
    "word": "farmacia",
    "rank": 6725,
    "frequency": 3785,
    "originalRank": 6877
  },
  {
    "word": "bretaña",
    "rank": 6726,
    "frequency": 3785,
    "originalRank": 6878
  },
  {
    "word": "sentirás",
    "rank": 6727,
    "frequency": 3785,
    "originalRank": 6879
  },
  {
    "word": "gwen",
    "rank": 6728,
    "frequency": 3784,
    "originalRank": 6880
  },
  {
    "word": "obispo",
    "rank": 6729,
    "frequency": 3784,
    "originalRank": 6881
  },
  {
    "word": "agradecer",
    "rank": 6730,
    "frequency": 3784,
    "originalRank": 6882
  },
  {
    "word": "maletero",
    "rank": 6731,
    "frequency": 3781,
    "originalRank": 6883
  },
  {
    "word": "tocaba",
    "rank": 6732,
    "frequency": 3781,
    "originalRank": 6884
  },
  {
    "word": "dallas",
    "rank": 6733,
    "frequency": 3780,
    "originalRank": 6885
  },
  {
    "word": "lamentablemente",
    "rank": 6734,
    "frequency": 3779,
    "originalRank": 6886
  },
  {
    "word": "tenias",
    "rank": 6735,
    "frequency": 3778,
    "originalRank": 6887
  },
  {
    "word": "vivas",
    "rank": 6736,
    "frequency": 3777,
    "originalRank": 6888
  },
  {
    "word": "queden",
    "rank": 6737,
    "frequency": 3777,
    "originalRank": 6889
  },
  {
    "word": "tess",
    "rank": 6738,
    "frequency": 3775,
    "originalRank": 6890
  },
  {
    "word": "murray",
    "rank": 6739,
    "frequency": 3774,
    "originalRank": 6891
  },
  {
    "word": "ilegales",
    "rank": 6740,
    "frequency": 3774,
    "originalRank": 6892
  },
  {
    "word": "específico",
    "rank": 6741,
    "frequency": 3774,
    "originalRank": 6893
  },
  {
    "word": "salchicha",
    "rank": 6742,
    "frequency": 3774,
    "originalRank": 6894
  },
  {
    "word": "maravillas",
    "rank": 6743,
    "frequency": 3772,
    "originalRank": 6895
  },
  {
    "word": "empezaste",
    "rank": 6744,
    "frequency": 3772,
    "originalRank": 6896
  },
  {
    "word": "previsto",
    "rank": 6745,
    "frequency": 3771,
    "originalRank": 6897
  },
  {
    "word": "poderosos",
    "rank": 6746,
    "frequency": 3771,
    "originalRank": 6898
  },
  {
    "word": "electrónico",
    "rank": 6747,
    "frequency": 3771,
    "originalRank": 6899
  },
  {
    "word": "delincuente",
    "rank": 6748,
    "frequency": 3770,
    "originalRank": 6900
  },
  {
    "word": "cogeré",
    "rank": 6749,
    "frequency": 3770,
    "originalRank": 6901
  },
  {
    "word": "trabaje",
    "rank": 6750,
    "frequency": 3769,
    "originalRank": 6902
  },
  {
    "word": "raj",
    "rank": 6751,
    "frequency": 3769,
    "originalRank": 6903
  },
  {
    "word": "cruzando",
    "rank": 6752,
    "frequency": 3769,
    "originalRank": 6904
  },
  {
    "word": "vendo",
    "rank": 6753,
    "frequency": 3768,
    "originalRank": 6905
  },
  {
    "word": "fotógrafo",
    "rank": 6754,
    "frequency": 3767,
    "originalRank": 6906
  },
  {
    "word": "leon",
    "rank": 6755,
    "frequency": 3766,
    "originalRank": 6907
  },
  {
    "word": "compartimos",
    "rank": 6756,
    "frequency": 3766,
    "originalRank": 6908
  },
  {
    "word": "crecimiento",
    "rank": 6757,
    "frequency": 3765,
    "originalRank": 6909
  },
  {
    "word": "próximas",
    "rank": 6758,
    "frequency": 3765,
    "originalRank": 6910
  },
  {
    "word": "fracasado",
    "rank": 6759,
    "frequency": 3765,
    "originalRank": 6911
  },
  {
    "word": "serena",
    "rank": 6760,
    "frequency": 3764,
    "originalRank": 6912
  },
  {
    "word": "mantenimiento",
    "rank": 6761,
    "frequency": 3764,
    "originalRank": 6913
  },
  {
    "word": "ardiente",
    "rank": 6762,
    "frequency": 3763,
    "originalRank": 6914
  },
  {
    "word": "acompañe",
    "rank": 6763,
    "frequency": 3763,
    "originalRank": 6915
  },
  {
    "word": "protector",
    "rank": 6764,
    "frequency": 3763,
    "originalRank": 6916
  },
  {
    "word": "abiertas",
    "rank": 6765,
    "frequency": 3762,
    "originalRank": 6917
  },
  {
    "word": "portada",
    "rank": 6766,
    "frequency": 3762,
    "originalRank": 6918
  },
  {
    "word": "expulsado",
    "rank": 6767,
    "frequency": 3760,
    "originalRank": 6919
  },
  {
    "word": "comprendido",
    "rank": 6768,
    "frequency": 3758,
    "originalRank": 6920
  },
  {
    "word": "est",
    "rank": 6769,
    "frequency": 3757,
    "originalRank": 6921
  },
  {
    "word": "bandeja",
    "rank": 6770,
    "frequency": 3753,
    "originalRank": 6922
  },
  {
    "word": "comunes",
    "rank": 6771,
    "frequency": 3753,
    "originalRank": 6923
  },
  {
    "word": "envidia",
    "rank": 6772,
    "frequency": 3752,
    "originalRank": 6924
  },
  {
    "word": "marcado",
    "rank": 6773,
    "frequency": 3752,
    "originalRank": 6925
  },
  {
    "word": "vacías",
    "rank": 6774,
    "frequency": 3751,
    "originalRank": 6926
  },
  {
    "word": "evans",
    "rank": 6775,
    "frequency": 3751,
    "originalRank": 6927
  },
  {
    "word": "ballet",
    "rank": 6776,
    "frequency": 3750,
    "originalRank": 6928
  },
  {
    "word": "traerte",
    "rank": 6777,
    "frequency": 3750,
    "originalRank": 6929
  },
  {
    "word": "literatura",
    "rank": 6778,
    "frequency": 3749,
    "originalRank": 6930
  },
  {
    "word": "alcanza",
    "rank": 6779,
    "frequency": 3749,
    "originalRank": 6931
  },
  {
    "word": "bajado",
    "rank": 6780,
    "frequency": 3749,
    "originalRank": 6932
  },
  {
    "word": "ahh",
    "rank": 6781,
    "frequency": 3749,
    "originalRank": 6933
  },
  {
    "word": "carson",
    "rank": 6782,
    "frequency": 3748,
    "originalRank": 6934
  },
  {
    "word": "fisher",
    "rank": 6783,
    "frequency": 3748,
    "originalRank": 6935
  },
  {
    "word": "década",
    "rank": 6784,
    "frequency": 3747,
    "originalRank": 6936
  },
  {
    "word": "órbita",
    "rank": 6785,
    "frequency": 3746,
    "originalRank": 6937
  },
  {
    "word": "eventualmente",
    "rank": 6786,
    "frequency": 3744,
    "originalRank": 6938
  },
  {
    "word": "ocupa",
    "rank": 6787,
    "frequency": 3744,
    "originalRank": 6939
  },
  {
    "word": "helena",
    "rank": 6788,
    "frequency": 3744,
    "originalRank": 6940
  },
  {
    "word": "tardará",
    "rank": 6789,
    "frequency": 3743,
    "originalRank": 6941
  },
  {
    "word": "fiona",
    "rank": 6790,
    "frequency": 3742,
    "originalRank": 6942
  },
  {
    "word": "flujo",
    "rank": 6791,
    "frequency": 3742,
    "originalRank": 6943
  },
  {
    "word": "toni",
    "rank": 6792,
    "frequency": 3742,
    "originalRank": 6944
  },
  {
    "word": "imagínate",
    "rank": 6793,
    "frequency": 3742,
    "originalRank": 6945
  },
  {
    "word": "esconderse",
    "rank": 6794,
    "frequency": 3741,
    "originalRank": 6946
  },
  {
    "word": "sonny",
    "rank": 6795,
    "frequency": 3741,
    "originalRank": 6947
  },
  {
    "word": "suyas",
    "rank": 6796,
    "frequency": 3740,
    "originalRank": 6948
  },
  {
    "word": "kansas",
    "rank": 6797,
    "frequency": 3739,
    "originalRank": 6949
  },
  {
    "word": "llegarán",
    "rank": 6798,
    "frequency": 3739,
    "originalRank": 6950
  },
  {
    "word": "presta",
    "rank": 6799,
    "frequency": 3738,
    "originalRank": 6951
  },
  {
    "word": "jungla",
    "rank": 6800,
    "frequency": 3737,
    "originalRank": 6952
  },
  {
    "word": "ayudé",
    "rank": 6801,
    "frequency": 3734,
    "originalRank": 6953
  },
  {
    "word": "destinado",
    "rank": 6802,
    "frequency": 3733,
    "originalRank": 6954
  },
  {
    "word": "triple",
    "rank": 6803,
    "frequency": 3733,
    "originalRank": 6955
  },
  {
    "word": "colinas",
    "rank": 6804,
    "frequency": 3732,
    "originalRank": 6956
  },
  {
    "word": "ofrecerle",
    "rank": 6805,
    "frequency": 3732,
    "originalRank": 6957
  },
  {
    "word": "pantano",
    "rank": 6806,
    "frequency": 3731,
    "originalRank": 6958
  },
  {
    "word": "mantienen",
    "rank": 6807,
    "frequency": 3730,
    "originalRank": 6959
  },
  {
    "word": "rex",
    "rank": 6808,
    "frequency": 3730,
    "originalRank": 6960
  },
  {
    "word": "broadway",
    "rank": 6809,
    "frequency": 3730,
    "originalRank": 6961
  },
  {
    "word": "misericordia",
    "rank": 6810,
    "frequency": 3729,
    "originalRank": 6962
  },
  {
    "word": "cometa",
    "rank": 6811,
    "frequency": 3729,
    "originalRank": 6963
  },
  {
    "word": "particularmente",
    "rank": 6812,
    "frequency": 3728,
    "originalRank": 6964
  },
  {
    "word": "morgue",
    "rank": 6813,
    "frequency": 3728,
    "originalRank": 6965
  },
  {
    "word": "implica",
    "rank": 6814,
    "frequency": 3726,
    "originalRank": 6966
  },
  {
    "word": "set",
    "rank": 6815,
    "frequency": 3726,
    "originalRank": 6967
  },
  {
    "word": "stefan",
    "rank": 6816,
    "frequency": 3726,
    "originalRank": 6968
  },
  {
    "word": "drogado",
    "rank": 6817,
    "frequency": 3724,
    "originalRank": 6969
  },
  {
    "word": "divina",
    "rank": 6818,
    "frequency": 3722,
    "originalRank": 6971
  },
  {
    "word": "lenny",
    "rank": 6819,
    "frequency": 3721,
    "originalRank": 6972
  },
  {
    "word": "empezaremos",
    "rank": 6820,
    "frequency": 3719,
    "originalRank": 6973
  },
  {
    "word": "detesto",
    "rank": 6821,
    "frequency": 3719,
    "originalRank": 6974
  },
  {
    "word": "granjero",
    "rank": 6822,
    "frequency": 3718,
    "originalRank": 6975
  },
  {
    "word": "admitirlo",
    "rank": 6823,
    "frequency": 3717,
    "originalRank": 6976
  },
  {
    "word": "malvada",
    "rank": 6824,
    "frequency": 3717,
    "originalRank": 6977
  },
  {
    "word": "códigos",
    "rank": 6825,
    "frequency": 3716,
    "originalRank": 6978
  },
  {
    "word": "mueven",
    "rank": 6826,
    "frequency": 3716,
    "originalRank": 6979
  },
  {
    "word": "orleans",
    "rank": 6827,
    "frequency": 3713,
    "originalRank": 6980
  },
  {
    "word": "femenino",
    "rank": 6828,
    "frequency": 3712,
    "originalRank": 6981
  },
  {
    "word": "misteriosa",
    "rank": 6829,
    "frequency": 3712,
    "originalRank": 6982
  },
  {
    "word": "dueña",
    "rank": 6830,
    "frequency": 3711,
    "originalRank": 6983
  },
  {
    "word": "cercanos",
    "rank": 6831,
    "frequency": 3711,
    "originalRank": 6984
  },
  {
    "word": "salchichas",
    "rank": 6832,
    "frequency": 3711,
    "originalRank": 6985
  },
  {
    "word": "madrid",
    "rank": 6833,
    "frequency": 3711,
    "originalRank": 6986
  },
  {
    "word": "niñita",
    "rank": 6834,
    "frequency": 3710,
    "originalRank": 6987
  },
  {
    "word": "basada",
    "rank": 6835,
    "frequency": 3710,
    "originalRank": 6988
  },
  {
    "word": "marge",
    "rank": 6836,
    "frequency": 3709,
    "originalRank": 6989
  },
  {
    "word": "operar",
    "rank": 6837,
    "frequency": 3709,
    "originalRank": 6990
  },
  {
    "word": "yo-",
    "rank": 6838,
    "frequency": 3709,
    "originalRank": 6991
  },
  {
    "word": "invita",
    "rank": 6839,
    "frequency": 3707,
    "originalRank": 6992
  },
  {
    "word": "pausa",
    "rank": 6840,
    "frequency": 3707,
    "originalRank": 6993
  },
  {
    "word": "asilo",
    "rank": 6841,
    "frequency": 3707,
    "originalRank": 6994
  },
  {
    "word": "equivocados",
    "rank": 6842,
    "frequency": 3707,
    "originalRank": 6995
  },
  {
    "word": "grey",
    "rank": 6843,
    "frequency": 3707,
    "originalRank": 6996
  },
  {
    "word": "póngase",
    "rank": 6844,
    "frequency": 3706,
    "originalRank": 6997
  },
  {
    "word": "pertenecen",
    "rank": 6845,
    "frequency": 3706,
    "originalRank": 6998
  },
  {
    "word": "rompiste",
    "rank": 6846,
    "frequency": 3704,
    "originalRank": 6999
  },
  {
    "word": "invitada",
    "rank": 6847,
    "frequency": 3703,
    "originalRank": 7000
  },
  {
    "word": "cambiaron",
    "rank": 6848,
    "frequency": 3702,
    "originalRank": 7001
  },
  {
    "word": "meredith",
    "rank": 6849,
    "frequency": 3702,
    "originalRank": 7002
  },
  {
    "word": "anuncios",
    "rank": 6850,
    "frequency": 3701,
    "originalRank": 7003
  },
  {
    "word": "montones",
    "rank": 6851,
    "frequency": 3701,
    "originalRank": 7004
  },
  {
    "word": "mesas",
    "rank": 6852,
    "frequency": 3699,
    "originalRank": 7005
  },
  {
    "word": "convirtiendo",
    "rank": 6853,
    "frequency": 3698,
    "originalRank": 7006
  },
  {
    "word": "avery",
    "rank": 6854,
    "frequency": 3697,
    "originalRank": 7007
  },
  {
    "word": "bárbara",
    "rank": 6855,
    "frequency": 3696,
    "originalRank": 7008
  },
  {
    "word": "queriendo",
    "rank": 6856,
    "frequency": 3696,
    "originalRank": 7009
  },
  {
    "word": "síganme",
    "rank": 6857,
    "frequency": 3696,
    "originalRank": 7010
  },
  {
    "word": "comencemos",
    "rank": 6858,
    "frequency": 3695,
    "originalRank": 7011
  },
  {
    "word": "sentimental",
    "rank": 6859,
    "frequency": 3694,
    "originalRank": 7012
  },
  {
    "word": "alienígena",
    "rank": 6860,
    "frequency": 3693,
    "originalRank": 7013
  },
  {
    "word": "gentil",
    "rank": 6861,
    "frequency": 3693,
    "originalRank": 7014
  },
  {
    "word": "tardar",
    "rank": 6862,
    "frequency": 3691,
    "originalRank": 7015
  },
  {
    "word": "abejas",
    "rank": 6863,
    "frequency": 3690,
    "originalRank": 7016
  },
  {
    "word": "cuna",
    "rank": 6864,
    "frequency": 3690,
    "originalRank": 7017
  },
  {
    "word": "anteriores",
    "rank": 6865,
    "frequency": 3689,
    "originalRank": 7018
  },
  {
    "word": "permita",
    "rank": 6866,
    "frequency": 3688,
    "originalRank": 7019
  },
  {
    "word": "piper",
    "rank": 6867,
    "frequency": 3688,
    "originalRank": 7020
  },
  {
    "word": "durará",
    "rank": 6868,
    "frequency": 3686,
    "originalRank": 7021
  },
  {
    "word": "cuidadosamente",
    "rank": 6869,
    "frequency": 3686,
    "originalRank": 7022
  },
  {
    "word": "únicas",
    "rank": 6870,
    "frequency": 3686,
    "originalRank": 7023
  },
  {
    "word": "monk",
    "rank": 6871,
    "frequency": 3685,
    "originalRank": 7024
  },
  {
    "word": "dormía",
    "rank": 6872,
    "frequency": 3685,
    "originalRank": 7025
  },
  {
    "word": "diagnóstico",
    "rank": 6873,
    "frequency": 3684,
    "originalRank": 7026
  },
  {
    "word": "buck",
    "rank": 6874,
    "frequency": 3684,
    "originalRank": 7027
  },
  {
    "word": "enlace",
    "rank": 6875,
    "frequency": 3683,
    "originalRank": 7028
  },
  {
    "word": "completar",
    "rank": 6876,
    "frequency": 3683,
    "originalRank": 7029
  },
  {
    "word": "benjamin",
    "rank": 6877,
    "frequency": 3681,
    "originalRank": 7030
  },
  {
    "word": "síndrome",
    "rank": 6878,
    "frequency": 3680,
    "originalRank": 7031
  },
  {
    "word": "stevie",
    "rank": 6879,
    "frequency": 3680,
    "originalRank": 7032
  },
  {
    "word": "normalidad",
    "rank": 6880,
    "frequency": 3679,
    "originalRank": 7033
  },
  {
    "word": "quitarte",
    "rank": 6881,
    "frequency": 3679,
    "originalRank": 7034
  },
  {
    "word": "haley",
    "rank": 6882,
    "frequency": 3678,
    "originalRank": 7035
  },
  {
    "word": "legado",
    "rank": 6883,
    "frequency": 3677,
    "originalRank": 7036
  },
  {
    "word": "disparé",
    "rank": 6884,
    "frequency": 3677,
    "originalRank": 7037
  },
  {
    "word": "testificar",
    "rank": 6885,
    "frequency": 3676,
    "originalRank": 7038
  },
  {
    "word": "ingeniería",
    "rank": 6886,
    "frequency": 3675,
    "originalRank": 7039
  },
  {
    "word": "acostarme",
    "rank": 6887,
    "frequency": 3675,
    "originalRank": 7040
  },
  {
    "word": "mandé",
    "rank": 6888,
    "frequency": 3674,
    "originalRank": 7041
  },
  {
    "word": "rincón",
    "rank": 6889,
    "frequency": 3673,
    "originalRank": 7042
  },
  {
    "word": "sun",
    "rank": 6890,
    "frequency": 3673,
    "originalRank": 7043
  },
  {
    "word": "artificiales",
    "rank": 6891,
    "frequency": 3672,
    "originalRank": 7044
  },
  {
    "word": "milord",
    "rank": 6892,
    "frequency": 3671,
    "originalRank": 7045
  },
  {
    "word": "dee",
    "rank": 6893,
    "frequency": 3671,
    "originalRank": 7046
  },
  {
    "word": "jeffrey",
    "rank": 6894,
    "frequency": 3670,
    "originalRank": 7047
  },
  {
    "word": "significan",
    "rank": 6895,
    "frequency": 3670,
    "originalRank": 7048
  },
  {
    "word": "sonó",
    "rank": 6896,
    "frequency": 3670,
    "originalRank": 7049
  },
  {
    "word": "foster",
    "rank": 6897,
    "frequency": 3669,
    "originalRank": 7050
  },
  {
    "word": "chaleco",
    "rank": 6898,
    "frequency": 3669,
    "originalRank": 7051
  },
  {
    "word": "encontrarle",
    "rank": 6899,
    "frequency": 3668,
    "originalRank": 7052
  },
  {
    "word": "sobrevivió",
    "rank": 6900,
    "frequency": 3668,
    "originalRank": 7053
  },
  {
    "word": "subasta",
    "rank": 6901,
    "frequency": 3667,
    "originalRank": 7054
  },
  {
    "word": "pasaremos",
    "rank": 6902,
    "frequency": 3667,
    "originalRank": 7055
  },
  {
    "word": "talvez",
    "rank": 6903,
    "frequency": 3667,
    "originalRank": 7056
  },
  {
    "word": "cam",
    "rank": 6904,
    "frequency": 3667,
    "originalRank": 7057
  },
  {
    "word": "naturales",
    "rank": 6905,
    "frequency": 3667,
    "originalRank": 7058
  },
  {
    "word": "scotty",
    "rank": 6906,
    "frequency": 3666,
    "originalRank": 7059
  },
  {
    "word": "corrección",
    "rank": 6907,
    "frequency": 3665,
    "originalRank": 7060
  },
  {
    "word": "entiendas",
    "rank": 6908,
    "frequency": 3665,
    "originalRank": 7061
  },
  {
    "word": "estate",
    "rank": 6909,
    "frequency": 3663,
    "originalRank": 7062
  },
  {
    "word": "caes",
    "rank": 6910,
    "frequency": 3663,
    "originalRank": 7063
  },
  {
    "word": "dándole",
    "rank": 6911,
    "frequency": 3663,
    "originalRank": 7064
  },
  {
    "word": "líos",
    "rank": 6912,
    "frequency": 3662,
    "originalRank": 7065
  },
  {
    "word": "jodiendo",
    "rank": 6913,
    "frequency": 3662,
    "originalRank": 7066
  },
  {
    "word": "hablaron",
    "rank": 6914,
    "frequency": 3662,
    "originalRank": 7067
  },
  {
    "word": "soltar",
    "rank": 6915,
    "frequency": 3661,
    "originalRank": 7068
  },
  {
    "word": "llevarle",
    "rank": 6916,
    "frequency": 3661,
    "originalRank": 7069
  },
  {
    "word": "marcar",
    "rank": 6917,
    "frequency": 3660,
    "originalRank": 7070
  },
  {
    "word": "quedaste",
    "rank": 6918,
    "frequency": 3659,
    "originalRank": 7071
  },
  {
    "word": "déjate",
    "rank": 6919,
    "frequency": 3659,
    "originalRank": 7072
  },
  {
    "word": "proyectos",
    "rank": 6920,
    "frequency": 3658,
    "originalRank": 7073
  },
  {
    "word": "educado",
    "rank": 6921,
    "frequency": 3658,
    "originalRank": 7074
  },
  {
    "word": "guardado",
    "rank": 6922,
    "frequency": 3658,
    "originalRank": 7075
  },
  {
    "word": "zonas",
    "rank": 6923,
    "frequency": 3654,
    "originalRank": 7076
  },
  {
    "word": "repite",
    "rank": 6924,
    "frequency": 3653,
    "originalRank": 7077
  },
  {
    "word": "hermanito",
    "rank": 6925,
    "frequency": 3653,
    "originalRank": 7078
  },
  {
    "word": "tobillo",
    "rank": 6926,
    "frequency": 3652,
    "originalRank": 7079
  },
  {
    "word": "insiste",
    "rank": 6927,
    "frequency": 3652,
    "originalRank": 7080
  },
  {
    "word": "categoría",
    "rank": 6928,
    "frequency": 3651,
    "originalRank": 7081
  },
  {
    "word": "dimensión",
    "rank": 6929,
    "frequency": 3651,
    "originalRank": 7082
  },
  {
    "word": "ayudes",
    "rank": 6930,
    "frequency": 3650,
    "originalRank": 7083
  },
  {
    "word": "domingos",
    "rank": 6931,
    "frequency": 3648,
    "originalRank": 7084
  },
  {
    "word": "confundida",
    "rank": 6932,
    "frequency": 3647,
    "originalRank": 7085
  },
  {
    "word": "romanos",
    "rank": 6933,
    "frequency": 3646,
    "originalRank": 7087
  },
  {
    "word": "bloque",
    "rank": 6934,
    "frequency": 3646,
    "originalRank": 7088
  },
  {
    "word": "producir",
    "rank": 6935,
    "frequency": 3645,
    "originalRank": 7089
  },
  {
    "word": "pasarme",
    "rank": 6936,
    "frequency": 3643,
    "originalRank": 7090
  },
  {
    "word": "aplausos",
    "rank": 6937,
    "frequency": 3643,
    "originalRank": 7091
  },
  {
    "word": "vaqueros",
    "rank": 6938,
    "frequency": 3642,
    "originalRank": 7092
  },
  {
    "word": "ciclo",
    "rank": 6939,
    "frequency": 3642,
    "originalRank": 7093
  },
  {
    "word": "enterrar",
    "rank": 6940,
    "frequency": 3642,
    "originalRank": 7094
  },
  {
    "word": "elvis",
    "rank": 6941,
    "frequency": 3641,
    "originalRank": 7095
  },
  {
    "word": "charlar",
    "rank": 6942,
    "frequency": 3641,
    "originalRank": 7096
  },
  {
    "word": "inventó",
    "rank": 6943,
    "frequency": 3640,
    "originalRank": 7097
  },
  {
    "word": "sentarnos",
    "rank": 6944,
    "frequency": 3640,
    "originalRank": 7098
  },
  {
    "word": "bata",
    "rank": 6945,
    "frequency": 3639,
    "originalRank": 7099
  },
  {
    "word": "aparecido",
    "rank": 6946,
    "frequency": 3638,
    "originalRank": 7100
  },
  {
    "word": "robos",
    "rank": 6947,
    "frequency": 3638,
    "originalRank": 7101
  },
  {
    "word": "duras",
    "rank": 6948,
    "frequency": 3637,
    "originalRank": 7102
  },
  {
    "word": "descuento",
    "rank": 6949,
    "frequency": 3637,
    "originalRank": 7103
  },
  {
    "word": "cardíaco",
    "rank": 6950,
    "frequency": 3636,
    "originalRank": 7104
  },
  {
    "word": "randall",
    "rank": 6951,
    "frequency": 3635,
    "originalRank": 7105
  },
  {
    "word": "recto",
    "rank": 6952,
    "frequency": 3635,
    "originalRank": 7106
  },
  {
    "word": "valerie",
    "rank": 6953,
    "frequency": 3634,
    "originalRank": 7107
  },
  {
    "word": "unir",
    "rank": 6954,
    "frequency": 3633,
    "originalRank": 7108
  },
  {
    "word": "buddy",
    "rank": 6955,
    "frequency": 3631,
    "originalRank": 7109
  },
  {
    "word": "angie",
    "rank": 6956,
    "frequency": 3630,
    "originalRank": 7110
  },
  {
    "word": "infarto",
    "rank": 6957,
    "frequency": 3630,
    "originalRank": 7111
  },
  {
    "word": "echando",
    "rank": 6958,
    "frequency": 3630,
    "originalRank": 7113
  },
  {
    "word": "filadelfia",
    "rank": 6959,
    "frequency": 3630,
    "originalRank": 7114
  },
  {
    "word": "plumas",
    "rank": 6960,
    "frequency": 3630,
    "originalRank": 7115
  },
  {
    "word": "escrita",
    "rank": 6961,
    "frequency": 3628,
    "originalRank": 7116
  },
  {
    "word": "tomaría",
    "rank": 6962,
    "frequency": 3626,
    "originalRank": 7117
  },
  {
    "word": "creando",
    "rank": 6963,
    "frequency": 3626,
    "originalRank": 7118
  },
  {
    "word": "hammond",
    "rank": 6964,
    "frequency": 3625,
    "originalRank": 7119
  },
  {
    "word": "gusanos",
    "rank": 6965,
    "frequency": 3624,
    "originalRank": 7120
  },
  {
    "word": "detengan",
    "rank": 6966,
    "frequency": 3623,
    "originalRank": 7121
  },
  {
    "word": "refrigerador",
    "rank": 6967,
    "frequency": 3622,
    "originalRank": 7122
  },
  {
    "word": "abrí",
    "rank": 6968,
    "frequency": 3620,
    "originalRank": 7123
  },
  {
    "word": "entres",
    "rank": 6969,
    "frequency": 3620,
    "originalRank": 7124
  },
  {
    "word": "sida",
    "rank": 6970,
    "frequency": 3620,
    "originalRank": 7125
  },
  {
    "word": "déjelo",
    "rank": 6971,
    "frequency": 3618,
    "originalRank": 7126
  },
  {
    "word": "obligó",
    "rank": 6972,
    "frequency": 3617,
    "originalRank": 7127
  },
  {
    "word": "magnífica",
    "rank": 6973,
    "frequency": 3617,
    "originalRank": 7128
  },
  {
    "word": "sobrio",
    "rank": 6974,
    "frequency": 3615,
    "originalRank": 7130
  },
  {
    "word": "felix",
    "rank": 6975,
    "frequency": 3614,
    "originalRank": 7131
  },
  {
    "word": "italianos",
    "rank": 6976,
    "frequency": 3614,
    "originalRank": 7132
  },
  {
    "word": "saquen",
    "rank": 6977,
    "frequency": 3614,
    "originalRank": 7133
  },
  {
    "word": "obsesión",
    "rank": 6978,
    "frequency": 3612,
    "originalRank": 7134
  },
  {
    "word": "sasha",
    "rank": 6979,
    "frequency": 3610,
    "originalRank": 7135
  },
  {
    "word": "entregó",
    "rank": 6980,
    "frequency": 3610,
    "originalRank": 7136
  },
  {
    "word": "acerque",
    "rank": 6981,
    "frequency": 3609,
    "originalRank": 7137
  },
  {
    "word": "mírala",
    "rank": 6982,
    "frequency": 3607,
    "originalRank": 7138
  },
  {
    "word": "calendario",
    "rank": 6983,
    "frequency": 3606,
    "originalRank": 7139
  },
  {
    "word": "ayudan",
    "rank": 6984,
    "frequency": 3606,
    "originalRank": 7140
  },
  {
    "word": "llevaban",
    "rank": 6985,
    "frequency": 3602,
    "originalRank": 7141
  },
  {
    "word": "deprimido",
    "rank": 6986,
    "frequency": 3601,
    "originalRank": 7142
  },
  {
    "word": "robots",
    "rank": 6987,
    "frequency": 3600,
    "originalRank": 7143
  },
  {
    "word": "rudo",
    "rank": 6988,
    "frequency": 3599,
    "originalRank": 7144
  },
  {
    "word": "partidos",
    "rank": 6989,
    "frequency": 3599,
    "originalRank": 7145
  },
  {
    "word": "cuidadoso",
    "rank": 6990,
    "frequency": 3598,
    "originalRank": 7146
  },
  {
    "word": "ayudarles",
    "rank": 6991,
    "frequency": 3597,
    "originalRank": 7147
  },
  {
    "word": "necesitábamos",
    "rank": 6992,
    "frequency": 3596,
    "originalRank": 7148
  },
  {
    "word": "arreglos",
    "rank": 6993,
    "frequency": 3596,
    "originalRank": 7149
  },
  {
    "word": "supervisor",
    "rank": 6994,
    "frequency": 3596,
    "originalRank": 7150
  },
  {
    "word": "austin",
    "rank": 6995,
    "frequency": 3594,
    "originalRank": 7151
  },
  {
    "word": "zapatillas",
    "rank": 6996,
    "frequency": 3594,
    "originalRank": 7152
  },
  {
    "word": "experiencias",
    "rank": 6997,
    "frequency": 3594,
    "originalRank": 7153
  },
  {
    "word": "sobrevivido",
    "rank": 6998,
    "frequency": 3593,
    "originalRank": 7154
  },
  {
    "word": "fijo",
    "rank": 6999,
    "frequency": 3593,
    "originalRank": 7155
  },
  {
    "word": "servidor",
    "rank": 7000,
    "frequency": 3592,
    "originalRank": 7156
  },
  {
    "word": "solían",
    "rank": 7001,
    "frequency": 3591,
    "originalRank": 7157
  },
  {
    "word": "estimado",
    "rank": 7002,
    "frequency": 3591,
    "originalRank": 7158
  },
  {
    "word": "bases",
    "rank": 7003,
    "frequency": 3591,
    "originalRank": 7159
  },
  {
    "word": "mónica",
    "rank": 7004,
    "frequency": 3590,
    "originalRank": 7160
  },
  {
    "word": "cristianos",
    "rank": 7005,
    "frequency": 3590,
    "originalRank": 7161
  },
  {
    "word": "propongo",
    "rank": 7006,
    "frequency": 3589,
    "originalRank": 7162
  },
  {
    "word": "bendito",
    "rank": 7007,
    "frequency": 3589,
    "originalRank": 7163
  },
  {
    "word": "get",
    "rank": 7008,
    "frequency": 3589,
    "originalRank": 7164
  },
  {
    "word": "caerá",
    "rank": 7009,
    "frequency": 3588,
    "originalRank": 7165
  },
  {
    "word": "marilyn",
    "rank": 7010,
    "frequency": 3588,
    "originalRank": 7166
  },
  {
    "word": "altar",
    "rank": 7011,
    "frequency": 3587,
    "originalRank": 7167
  },
  {
    "word": "disfruten",
    "rank": 7012,
    "frequency": 3587,
    "originalRank": 7168
  },
  {
    "word": "luchador",
    "rank": 7013,
    "frequency": 3586,
    "originalRank": 7169
  },
  {
    "word": "cierren",
    "rank": 7014,
    "frequency": 3585,
    "originalRank": 7170
  },
  {
    "word": "alboroto",
    "rank": 7015,
    "frequency": 3584,
    "originalRank": 7171
  },
  {
    "word": "extrañé",
    "rank": 7016,
    "frequency": 3583,
    "originalRank": 7172
  },
  {
    "word": "formal",
    "rank": 7017,
    "frequency": 3583,
    "originalRank": 7173
  },
  {
    "word": "hermandad",
    "rank": 7018,
    "frequency": 3582,
    "originalRank": 7174
  },
  {
    "word": "rompiendo",
    "rank": 7019,
    "frequency": 3581,
    "originalRank": 7175
  },
  {
    "word": "facebook",
    "rank": 7020,
    "frequency": 3581,
    "originalRank": 7176
  },
  {
    "word": "arriesgar",
    "rank": 7021,
    "frequency": 3580,
    "originalRank": 7177
  },
  {
    "word": "vestíbulo",
    "rank": 7022,
    "frequency": 3579,
    "originalRank": 7178
  },
  {
    "word": "cobardes",
    "rank": 7023,
    "frequency": 3579,
    "originalRank": 7179
  },
  {
    "word": "racista",
    "rank": 7024,
    "frequency": 3578,
    "originalRank": 7180
  },
  {
    "word": "cuadra",
    "rank": 7025,
    "frequency": 3578,
    "originalRank": 7181
  },
  {
    "word": "explique",
    "rank": 7026,
    "frequency": 3578,
    "originalRank": 7182
  },
  {
    "word": "significar",
    "rank": 7027,
    "frequency": 3576,
    "originalRank": 7183
  },
  {
    "word": "rio",
    "rank": 7028,
    "frequency": 3574,
    "originalRank": 7184
  },
  {
    "word": "claus",
    "rank": 7029,
    "frequency": 3574,
    "originalRank": 7185
  },
  {
    "word": "láser",
    "rank": 7030,
    "frequency": 3573,
    "originalRank": 7186
  },
  {
    "word": "alienígenas",
    "rank": 7031,
    "frequency": 3573,
    "originalRank": 7187
  },
  {
    "word": "tribal",
    "rank": 7032,
    "frequency": 3573,
    "originalRank": 7188
  },
  {
    "word": "dedicado",
    "rank": 7033,
    "frequency": 3572,
    "originalRank": 7189
  },
  {
    "word": "rudy",
    "rank": 7034,
    "frequency": 3572,
    "originalRank": 7190
  },
  {
    "word": "habitantes",
    "rank": 7035,
    "frequency": 3571,
    "originalRank": 7191
  },
  {
    "word": "divino",
    "rank": 7036,
    "frequency": 3570,
    "originalRank": 7192
  },
  {
    "word": "campbell",
    "rank": 7037,
    "frequency": 3570,
    "originalRank": 7193
  },
  {
    "word": "tomaba",
    "rank": 7038,
    "frequency": 3569,
    "originalRank": 7194
  },
  {
    "word": "conseguirás",
    "rank": 7039,
    "frequency": 3568,
    "originalRank": 7195
  },
  {
    "word": "pobreza",
    "rank": 7040,
    "frequency": 3568,
    "originalRank": 7196
  },
  {
    "word": "ebrio",
    "rank": 7041,
    "frequency": 3567,
    "originalRank": 7197
  },
  {
    "word": "griffin",
    "rank": 7042,
    "frequency": 3567,
    "originalRank": 7198
  },
  {
    "word": "ambición",
    "rank": 7043,
    "frequency": 3567,
    "originalRank": 7199
  },
  {
    "word": "visitantes",
    "rank": 7044,
    "frequency": 3566,
    "originalRank": 7200
  },
  {
    "word": "sirvo",
    "rank": 7045,
    "frequency": 3566,
    "originalRank": 7201
  },
  {
    "word": "tenés",
    "rank": 7046,
    "frequency": 3565,
    "originalRank": 7202
  },
  {
    "word": "enseñarme",
    "rank": 7047,
    "frequency": 3564,
    "originalRank": 7203
  },
  {
    "word": "rival",
    "rank": 7048,
    "frequency": 3563,
    "originalRank": 7204
  },
  {
    "word": "tarda",
    "rank": 7049,
    "frequency": 3562,
    "originalRank": 7205
  },
  {
    "word": "marcho",
    "rank": 7050,
    "frequency": 3562,
    "originalRank": 7206
  },
  {
    "word": "violet",
    "rank": 7051,
    "frequency": 3562,
    "originalRank": 7207
  },
  {
    "word": "comisionado",
    "rank": 7052,
    "frequency": 3561,
    "originalRank": 7208
  },
  {
    "word": "christina",
    "rank": 7053,
    "frequency": 3561,
    "originalRank": 7209
  },
  {
    "word": "out",
    "rank": 7054,
    "frequency": 3561,
    "originalRank": 7210
  },
  {
    "word": "terminan",
    "rank": 7055,
    "frequency": 3558,
    "originalRank": 7211
  },
  {
    "word": "captura",
    "rank": 7056,
    "frequency": 3557,
    "originalRank": 7212
  },
  {
    "word": "parad",
    "rank": 7057,
    "frequency": 3557,
    "originalRank": 7213
  },
  {
    "word": "persecución",
    "rank": 7058,
    "frequency": 3556,
    "originalRank": 7214
  },
  {
    "word": "específicamente",
    "rank": 7059,
    "frequency": 3556,
    "originalRank": 7215
  },
  {
    "word": "aparezca",
    "rank": 7060,
    "frequency": 3556,
    "originalRank": 7216
  },
  {
    "word": "agradecimiento",
    "rank": 7061,
    "frequency": 3555,
    "originalRank": 7217
  },
  {
    "word": "acercando",
    "rank": 7062,
    "frequency": 3555,
    "originalRank": 7218
  },
  {
    "word": "tomarte",
    "rank": 7063,
    "frequency": 3555,
    "originalRank": 7219
  },
  {
    "word": "usaré",
    "rank": 7064,
    "frequency": 3555,
    "originalRank": 7220
  },
  {
    "word": "debieron",
    "rank": 7065,
    "frequency": 3554,
    "originalRank": 7221
  },
  {
    "word": "bici",
    "rank": 7066,
    "frequency": 3554,
    "originalRank": 7222
  },
  {
    "word": "bush",
    "rank": 7067,
    "frequency": 3554,
    "originalRank": 7223
  },
  {
    "word": "frágil",
    "rank": 7068,
    "frequency": 3554,
    "originalRank": 7224
  },
  {
    "word": "pensará",
    "rank": 7069,
    "frequency": 3553,
    "originalRank": 7225
  },
  {
    "word": "regresamos",
    "rank": 7070,
    "frequency": 3553,
    "originalRank": 7226
  },
  {
    "word": "mejora",
    "rank": 7071,
    "frequency": 3552,
    "originalRank": 7227
  },
  {
    "word": "tinta",
    "rank": 7072,
    "frequency": 3551,
    "originalRank": 7229
  },
  {
    "word": "nieta",
    "rank": 7073,
    "frequency": 3551,
    "originalRank": 7230
  },
  {
    "word": "silver",
    "rank": 7074,
    "frequency": 3550,
    "originalRank": 7231
  },
  {
    "word": "inventado",
    "rank": 7075,
    "frequency": 3550,
    "originalRank": 7232
  },
  {
    "word": "dejaras",
    "rank": 7076,
    "frequency": 3550,
    "originalRank": 7233
  },
  {
    "word": "cuchillos",
    "rank": 7077,
    "frequency": 3548,
    "originalRank": 7234
  },
  {
    "word": "ruptura",
    "rank": 7078,
    "frequency": 3548,
    "originalRank": 7235
  },
  {
    "word": "preocupan",
    "rank": 7079,
    "frequency": 3548,
    "originalRank": 7236
  },
  {
    "word": "debéis",
    "rank": 7080,
    "frequency": 3548,
    "originalRank": 7237
  },
  {
    "word": "viaja",
    "rank": 7081,
    "frequency": 3547,
    "originalRank": 7238
  },
  {
    "word": "cepillo",
    "rank": 7082,
    "frequency": 3547,
    "originalRank": 7239
  },
  {
    "word": "velada",
    "rank": 7083,
    "frequency": 3545,
    "originalRank": 7240
  },
  {
    "word": "propina",
    "rank": 7084,
    "frequency": 3543,
    "originalRank": 7241
  },
  {
    "word": "escribes",
    "rank": 7085,
    "frequency": 3543,
    "originalRank": 7242
  },
  {
    "word": "activa",
    "rank": 7086,
    "frequency": 3542,
    "originalRank": 7243
  },
  {
    "word": "toqué",
    "rank": 7087,
    "frequency": 3542,
    "originalRank": 7244
  },
  {
    "word": "cathy",
    "rank": 7088,
    "frequency": 3541,
    "originalRank": 7245
  },
  {
    "word": "levantarme",
    "rank": 7089,
    "frequency": 3540,
    "originalRank": 7246
  },
  {
    "word": "tiré",
    "rank": 7090,
    "frequency": 3540,
    "originalRank": 7247
  },
  {
    "word": "caravana",
    "rank": 7091,
    "frequency": 3540,
    "originalRank": 7248
  },
  {
    "word": "callate",
    "rank": 7092,
    "frequency": 3539,
    "originalRank": 7249
  },
  {
    "word": "sherlock",
    "rank": 7093,
    "frequency": 3538,
    "originalRank": 7250
  },
  {
    "word": "gustaban",
    "rank": 7094,
    "frequency": 3538,
    "originalRank": 7251
  },
  {
    "word": "wes",
    "rank": 7095,
    "frequency": 3536,
    "originalRank": 7252
  },
  {
    "word": "meto",
    "rank": 7096,
    "frequency": 3535,
    "originalRank": 7253
  },
  {
    "word": "traseros",
    "rank": 7097,
    "frequency": 3535,
    "originalRank": 7254
  },
  {
    "word": "atracción",
    "rank": 7098,
    "frequency": 3534,
    "originalRank": 7255
  },
  {
    "word": "noté",
    "rank": 7099,
    "frequency": 3533,
    "originalRank": 7256
  },
  {
    "word": "revisé",
    "rank": 7100,
    "frequency": 3532,
    "originalRank": 7257
  },
  {
    "word": "atrae",
    "rank": 7101,
    "frequency": 3532,
    "originalRank": 7258
  },
  {
    "word": "grabando",
    "rank": 7102,
    "frequency": 3532,
    "originalRank": 7259
  },
  {
    "word": "reportero",
    "rank": 7103,
    "frequency": 3529,
    "originalRank": 7260
  },
  {
    "word": "explorar",
    "rank": 7104,
    "frequency": 3529,
    "originalRank": 7261
  },
  {
    "word": "perfección",
    "rank": 7105,
    "frequency": 3529,
    "originalRank": 7262
  },
  {
    "word": "consentimiento",
    "rank": 7106,
    "frequency": 3529,
    "originalRank": 7263
  },
  {
    "word": "tiburones",
    "rank": 7107,
    "frequency": 3529,
    "originalRank": 7264
  },
  {
    "word": "denny",
    "rank": 7108,
    "frequency": 3528,
    "originalRank": 7265
  },
  {
    "word": "acepte",
    "rank": 7109,
    "frequency": 3527,
    "originalRank": 7266
  },
  {
    "word": "agradecerte",
    "rank": 7110,
    "frequency": 3525,
    "originalRank": 7267
  },
  {
    "word": "chad",
    "rank": 7111,
    "frequency": 3525,
    "originalRank": 7268
  },
  {
    "word": "yoon",
    "rank": 7112,
    "frequency": 3525,
    "originalRank": 7269
  },
  {
    "word": "gil",
    "rank": 7113,
    "frequency": 3524,
    "originalRank": 7270
  },
  {
    "word": "postura",
    "rank": 7114,
    "frequency": 3524,
    "originalRank": 7271
  },
  {
    "word": "concreto",
    "rank": 7115,
    "frequency": 3524,
    "originalRank": 7272
  },
  {
    "word": "desnudos",
    "rank": 7116,
    "frequency": 3523,
    "originalRank": 7273
  },
  {
    "word": "gastado",
    "rank": 7117,
    "frequency": 3523,
    "originalRank": 7274
  },
  {
    "word": "apertura",
    "rank": 7118,
    "frequency": 3522,
    "originalRank": 7275
  },
  {
    "word": "hurra",
    "rank": 7119,
    "frequency": 3521,
    "originalRank": 7276
  },
  {
    "word": "enterprise",
    "rank": 7120,
    "frequency": 3521,
    "originalRank": 7277
  },
  {
    "word": "trates",
    "rank": 7121,
    "frequency": 3519,
    "originalRank": 7278
  },
  {
    "word": "ahorrar",
    "rank": 7122,
    "frequency": 3519,
    "originalRank": 7279
  },
  {
    "word": "divertirnos",
    "rank": 7123,
    "frequency": 3519,
    "originalRank": 7280
  },
  {
    "word": "autorizado",
    "rank": 7124,
    "frequency": 3517,
    "originalRank": 7281
  },
  {
    "word": "decida",
    "rank": 7125,
    "frequency": 3517,
    "originalRank": 7282
  },
  {
    "word": "regular",
    "rank": 7126,
    "frequency": 3517,
    "originalRank": 7283
  },
  {
    "word": "homosexual",
    "rank": 7127,
    "frequency": 3516,
    "originalRank": 7284
  },
  {
    "word": "mutuamente",
    "rank": 7128,
    "frequency": 3515,
    "originalRank": 7285
  },
  {
    "word": "ruidos",
    "rank": 7129,
    "frequency": 3515,
    "originalRank": 7286
  },
  {
    "word": "film",
    "rank": 7130,
    "frequency": 3514,
    "originalRank": 7287
  },
  {
    "word": "bate",
    "rank": 7131,
    "frequency": 3513,
    "originalRank": 7288
  },
  {
    "word": "suenas",
    "rank": 7132,
    "frequency": 3513,
    "originalRank": 7289
  },
  {
    "word": "bennett",
    "rank": 7133,
    "frequency": 3511,
    "originalRank": 7290
  },
  {
    "word": "lunar",
    "rank": 7134,
    "frequency": 3511,
    "originalRank": 7291
  },
  {
    "word": "delta",
    "rank": 7135,
    "frequency": 3510,
    "originalRank": 7292
  },
  {
    "word": "pongamos",
    "rank": 7136,
    "frequency": 3509,
    "originalRank": 7293
  },
  {
    "word": "erik",
    "rank": 7137,
    "frequency": 3509,
    "originalRank": 7294
  },
  {
    "word": "cógelo",
    "rank": 7138,
    "frequency": 3508,
    "originalRank": 7295
  },
  {
    "word": "vestir",
    "rank": 7139,
    "frequency": 3508,
    "originalRank": 7296
  },
  {
    "word": "venas",
    "rank": 7140,
    "frequency": 3508,
    "originalRank": 7297
  },
  {
    "word": "evaluación",
    "rank": 7141,
    "frequency": 3508,
    "originalRank": 7298
  },
  {
    "word": "reservas",
    "rank": 7142,
    "frequency": 3507,
    "originalRank": 7299
  },
  {
    "word": "opiniones",
    "rank": 7143,
    "frequency": 3507,
    "originalRank": 7300
  },
  {
    "word": "pagamos",
    "rank": 7144,
    "frequency": 3506,
    "originalRank": 7301
  },
  {
    "word": "reagan",
    "rank": 7145,
    "frequency": 3506,
    "originalRank": 7302
  },
  {
    "word": "edgar",
    "rank": 7146,
    "frequency": 3506,
    "originalRank": 7303
  },
  {
    "word": "capturar",
    "rank": 7147,
    "frequency": 3505,
    "originalRank": 7304
  },
  {
    "word": "espadas",
    "rank": 7148,
    "frequency": 3505,
    "originalRank": 7305
  },
  {
    "word": "marino",
    "rank": 7149,
    "frequency": 3505,
    "originalRank": 7306
  },
  {
    "word": "singh",
    "rank": 7150,
    "frequency": 3504,
    "originalRank": 7307
  },
  {
    "word": "lejano",
    "rank": 7151,
    "frequency": 3503,
    "originalRank": 7308
  },
  {
    "word": "altamente",
    "rank": 7152,
    "frequency": 3503,
    "originalRank": 7309
  },
  {
    "word": "solías",
    "rank": 7153,
    "frequency": 3503,
    "originalRank": 7310
  },
  {
    "word": "ocuparme",
    "rank": 7154,
    "frequency": 3503,
    "originalRank": 7311
  },
  {
    "word": "creerá",
    "rank": 7155,
    "frequency": 3501,
    "originalRank": 7312
  },
  {
    "word": "vulgar",
    "rank": 7156,
    "frequency": 3501,
    "originalRank": 7313
  },
  {
    "word": "oímos",
    "rank": 7157,
    "frequency": 3500,
    "originalRank": 7314
  },
  {
    "word": "estafa",
    "rank": 7158,
    "frequency": 3500,
    "originalRank": 7315
  },
  {
    "word": "describir",
    "rank": 7159,
    "frequency": 3499,
    "originalRank": 7316
  },
  {
    "word": "escopeta",
    "rank": 7160,
    "frequency": 3498,
    "originalRank": 7317
  },
  {
    "word": "orquesta",
    "rank": 7161,
    "frequency": 3497,
    "originalRank": 7318
  },
  {
    "word": "sentiste",
    "rank": 7162,
    "frequency": 3497,
    "originalRank": 7319
  },
  {
    "word": "sabias",
    "rank": 7163,
    "frequency": 3496,
    "originalRank": 7320
  },
  {
    "word": "llámeme",
    "rank": 7164,
    "frequency": 3495,
    "originalRank": 7321
  },
  {
    "word": "volvimos",
    "rank": 7165,
    "frequency": 3495,
    "originalRank": 7322
  },
  {
    "word": "cassie",
    "rank": 7166,
    "frequency": 3495,
    "originalRank": 7323
  },
  {
    "word": "cool",
    "rank": 7167,
    "frequency": 3495,
    "originalRank": 7324
  },
  {
    "word": "like",
    "rank": 7168,
    "frequency": 3495,
    "originalRank": 7325
  },
  {
    "word": "lester",
    "rank": 7169,
    "frequency": 3494,
    "originalRank": 7326
  },
  {
    "word": "hábito",
    "rank": 7170,
    "frequency": 3493,
    "originalRank": 7327
  },
  {
    "word": "perdono",
    "rank": 7171,
    "frequency": 3493,
    "originalRank": 7328
  },
  {
    "word": "integridad",
    "rank": 7172,
    "frequency": 3492,
    "originalRank": 7329
  },
  {
    "word": "melanie",
    "rank": 7173,
    "frequency": 3492,
    "originalRank": 7330
  },
  {
    "word": "orinar",
    "rank": 7174,
    "frequency": 3492,
    "originalRank": 7331
  },
  {
    "word": "rodar",
    "rank": 7175,
    "frequency": 3491,
    "originalRank": 7332
  },
  {
    "word": "décadas",
    "rank": 7176,
    "frequency": 3491,
    "originalRank": 7333
  },
  {
    "word": "cardenal",
    "rank": 7177,
    "frequency": 3491,
    "originalRank": 7334
  },
  {
    "word": "sospecho",
    "rank": 7178,
    "frequency": 3489,
    "originalRank": 7335
  },
  {
    "word": "amarilla",
    "rank": 7179,
    "frequency": 3488,
    "originalRank": 7336
  },
  {
    "word": "reese",
    "rank": 7180,
    "frequency": 3488,
    "originalRank": 7337
  },
  {
    "word": "entretenimiento",
    "rank": 7181,
    "frequency": 3487,
    "originalRank": 7338
  },
  {
    "word": "arizona",
    "rank": 7182,
    "frequency": 3486,
    "originalRank": 7339
  },
  {
    "word": "escriba",
    "rank": 7183,
    "frequency": 3485,
    "originalRank": 7340
  },
  {
    "word": "dwight",
    "rank": 7184,
    "frequency": 3484,
    "originalRank": 7341
  },
  {
    "word": "hembra",
    "rank": 7185,
    "frequency": 3484,
    "originalRank": 7342
  },
  {
    "word": "pruebe",
    "rank": 7186,
    "frequency": 3481,
    "originalRank": 7344
  },
  {
    "word": "restaurantes",
    "rank": 7187,
    "frequency": 3480,
    "originalRank": 7346
  },
  {
    "word": "primaria",
    "rank": 7188,
    "frequency": 3480,
    "originalRank": 7347
  },
  {
    "word": "convención",
    "rank": 7189,
    "frequency": 3479,
    "originalRank": 7348
  },
  {
    "word": "debían",
    "rank": 7190,
    "frequency": 3479,
    "originalRank": 7349
  },
  {
    "word": "cago",
    "rank": 7191,
    "frequency": 3478,
    "originalRank": 7350
  },
  {
    "word": "tiras",
    "rank": 7192,
    "frequency": 3477,
    "originalRank": 7351
  },
  {
    "word": "firmes",
    "rank": 7193,
    "frequency": 3477,
    "originalRank": 7352
  },
  {
    "word": "ignorar",
    "rank": 7194,
    "frequency": 3476,
    "originalRank": 7353
  },
  {
    "word": "seguidores",
    "rank": 7195,
    "frequency": 3475,
    "originalRank": 7354
  },
  {
    "word": "falleció",
    "rank": 7196,
    "frequency": 3473,
    "originalRank": 7355
  },
  {
    "word": "quemó",
    "rank": 7197,
    "frequency": 3473,
    "originalRank": 7356
  },
  {
    "word": "bésame",
    "rank": 7198,
    "frequency": 3473,
    "originalRank": 7357
  },
  {
    "word": "corrió",
    "rank": 7199,
    "frequency": 3472,
    "originalRank": 7358
  },
  {
    "word": "picante",
    "rank": 7200,
    "frequency": 3471,
    "originalRank": 7359
  },
  {
    "word": "déjale",
    "rank": 7201,
    "frequency": 3469,
    "originalRank": 7360
  },
  {
    "word": "destruyó",
    "rank": 7202,
    "frequency": 3469,
    "originalRank": 7361
  },
  {
    "word": "marc",
    "rank": 7203,
    "frequency": 3468,
    "originalRank": 7362
  },
  {
    "word": "permitió",
    "rank": 7204,
    "frequency": 3467,
    "originalRank": 7363
  },
  {
    "word": "cambiarme",
    "rank": 7205,
    "frequency": 3467,
    "originalRank": 7364
  },
  {
    "word": "árabe",
    "rank": 7206,
    "frequency": 3467,
    "originalRank": 7365
  },
  {
    "word": "voló",
    "rank": 7207,
    "frequency": 3465,
    "originalRank": 7366
  },
  {
    "word": "stewart",
    "rank": 7208,
    "frequency": 3464,
    "originalRank": 7367
  },
  {
    "word": "contrabando",
    "rank": 7209,
    "frequency": 3464,
    "originalRank": 7368
  },
  {
    "word": "boxeo",
    "rank": 7210,
    "frequency": 3464,
    "originalRank": 7369
  },
  {
    "word": "pintor",
    "rank": 7211,
    "frequency": 3462,
    "originalRank": 7370
  },
  {
    "word": "ejercito",
    "rank": 7212,
    "frequency": 3462,
    "originalRank": 7371
  },
  {
    "word": "conocieron",
    "rank": 7213,
    "frequency": 3462,
    "originalRank": 7372
  },
  {
    "word": "delantera",
    "rank": 7214,
    "frequency": 3461,
    "originalRank": 7373
  },
  {
    "word": "yoga",
    "rank": 7215,
    "frequency": 3461,
    "originalRank": 7374
  },
  {
    "word": "time",
    "rank": 7216,
    "frequency": 3461,
    "originalRank": 7375
  },
  {
    "word": "forman",
    "rank": 7217,
    "frequency": 3459,
    "originalRank": 7376
  },
  {
    "word": "disfrute",
    "rank": 7218,
    "frequency": 3459,
    "originalRank": 7377
  },
  {
    "word": "reggie",
    "rank": 7219,
    "frequency": 3459,
    "originalRank": 7378
  },
  {
    "word": "mulder",
    "rank": 7220,
    "frequency": 3459,
    "originalRank": 7379
  },
  {
    "word": "hope",
    "rank": 7221,
    "frequency": 3458,
    "originalRank": 7380
  },
  {
    "word": "chi",
    "rank": 7222,
    "frequency": 3458,
    "originalRank": 7381
  },
  {
    "word": "ríen",
    "rank": 7223,
    "frequency": 3456,
    "originalRank": 7382
  },
  {
    "word": "vicky",
    "rank": 7224,
    "frequency": 3454,
    "originalRank": 7383
  },
  {
    "word": "campanas",
    "rank": 7225,
    "frequency": 3454,
    "originalRank": 7384
  },
  {
    "word": "dijeras",
    "rank": 7226,
    "frequency": 3454,
    "originalRank": 7385
  },
  {
    "word": "fallar",
    "rank": 7227,
    "frequency": 3453,
    "originalRank": 7386
  },
  {
    "word": "intentaron",
    "rank": 7228,
    "frequency": 3452,
    "originalRank": 7387
  },
  {
    "word": "raíz",
    "rank": 7229,
    "frequency": 3451,
    "originalRank": 7388
  },
  {
    "word": "sheldon",
    "rank": 7230,
    "frequency": 3451,
    "originalRank": 7389
  },
  {
    "word": "marea",
    "rank": 7231,
    "frequency": 3451,
    "originalRank": 7390
  },
  {
    "word": "buzón",
    "rank": 7232,
    "frequency": 3449,
    "originalRank": 7391
  },
  {
    "word": "monroe",
    "rank": 7233,
    "frequency": 3449,
    "originalRank": 7392
  },
  {
    "word": "pareciera",
    "rank": 7234,
    "frequency": 3447,
    "originalRank": 7393
  },
  {
    "word": "hicieran",
    "rank": 7235,
    "frequency": 3447,
    "originalRank": 7394
  },
  {
    "word": "eliminado",
    "rank": 7236,
    "frequency": 3446,
    "originalRank": 7395
  },
  {
    "word": "rechazado",
    "rank": 7237,
    "frequency": 3446,
    "originalRank": 7396
  },
  {
    "word": "turistas",
    "rank": 7238,
    "frequency": 3445,
    "originalRank": 7397
  },
  {
    "word": "inútiles",
    "rank": 7239,
    "frequency": 3445,
    "originalRank": 7398
  },
  {
    "word": "facturas",
    "rank": 7240,
    "frequency": 3445,
    "originalRank": 7399
  },
  {
    "word": "cortos",
    "rank": 7241,
    "frequency": 3445,
    "originalRank": 7400
  },
  {
    "word": "visiones",
    "rank": 7242,
    "frequency": 3443,
    "originalRank": 7401
  },
  {
    "word": "habernos",
    "rank": 7243,
    "frequency": 3442,
    "originalRank": 7402
  },
  {
    "word": "lena",
    "rank": 7244,
    "frequency": 3442,
    "originalRank": 7403
  },
  {
    "word": "comparado",
    "rank": 7245,
    "frequency": 3442,
    "originalRank": 7404
  },
  {
    "word": "ponme",
    "rank": 7246,
    "frequency": 3442,
    "originalRank": 7405
  },
  {
    "word": "matarle",
    "rank": 7247,
    "frequency": 3441,
    "originalRank": 7406
  },
  {
    "word": "lesiones",
    "rank": 7248,
    "frequency": 3441,
    "originalRank": 7407
  },
  {
    "word": "desear",
    "rank": 7249,
    "frequency": 3440,
    "originalRank": 7408
  },
  {
    "word": "cerebros",
    "rank": 7250,
    "frequency": 3440,
    "originalRank": 7409
  },
  {
    "word": "jorge",
    "rank": 7251,
    "frequency": 3438,
    "originalRank": 7411
  },
  {
    "word": "indican",
    "rank": 7252,
    "frequency": 3438,
    "originalRank": 7412
  },
  {
    "word": "tuviese",
    "rank": 7253,
    "frequency": 3436,
    "originalRank": 7413
  },
  {
    "word": "oyen",
    "rank": 7254,
    "frequency": 3435,
    "originalRank": 7414
  },
  {
    "word": "desaparecieron",
    "rank": 7255,
    "frequency": 3435,
    "originalRank": 7415
  },
  {
    "word": "hermanita",
    "rank": 7256,
    "frequency": 3435,
    "originalRank": 7416
  },
  {
    "word": "estallar",
    "rank": 7257,
    "frequency": 3433,
    "originalRank": 7417
  },
  {
    "word": "paró",
    "rank": 7258,
    "frequency": 3433,
    "originalRank": 7418
  },
  {
    "word": "know",
    "rank": 7259,
    "frequency": 3432,
    "originalRank": 7419
  },
  {
    "word": "ejercicios",
    "rank": 7260,
    "frequency": 3432,
    "originalRank": 7420
  },
  {
    "word": "flynn",
    "rank": 7261,
    "frequency": 3431,
    "originalRank": 7421
  },
  {
    "word": "extras",
    "rank": 7262,
    "frequency": 3430,
    "originalRank": 7422
  },
  {
    "word": "temes",
    "rank": 7263,
    "frequency": 3429,
    "originalRank": 7423
  },
  {
    "word": "bromeo",
    "rank": 7264,
    "frequency": 3429,
    "originalRank": 7424
  },
  {
    "word": "atraer",
    "rank": 7265,
    "frequency": 3429,
    "originalRank": 7425
  },
  {
    "word": "mear",
    "rank": 7266,
    "frequency": 3428,
    "originalRank": 7426
  },
  {
    "word": "anunciar",
    "rank": 7267,
    "frequency": 3428,
    "originalRank": 7427
  },
  {
    "word": "tae",
    "rank": 7268,
    "frequency": 3424,
    "originalRank": 7428
  },
  {
    "word": "eléctrico",
    "rank": 7269,
    "frequency": 3423,
    "originalRank": 7429
  },
  {
    "word": "sujetos",
    "rank": 7270,
    "frequency": 3422,
    "originalRank": 7430
  },
  {
    "word": "litros",
    "rank": 7271,
    "frequency": 3422,
    "originalRank": 7431
  },
  {
    "word": "judía",
    "rank": 7272,
    "frequency": 3421,
    "originalRank": 7432
  },
  {
    "word": "dawn",
    "rank": 7273,
    "frequency": 3421,
    "originalRank": 7433
  },
  {
    "word": "pensábamos",
    "rank": 7274,
    "frequency": 3419,
    "originalRank": 7434
  },
  {
    "word": "cañones",
    "rank": 7275,
    "frequency": 3419,
    "originalRank": 7435
  },
  {
    "word": "golpeando",
    "rank": 7276,
    "frequency": 3418,
    "originalRank": 7436
  },
  {
    "word": "acoso",
    "rank": 7277,
    "frequency": 3418,
    "originalRank": 7437
  },
  {
    "word": "explicarte",
    "rank": 7278,
    "frequency": 3417,
    "originalRank": 7438
  },
  {
    "word": "placas",
    "rank": 7279,
    "frequency": 3416,
    "originalRank": 7439
  },
  {
    "word": "remoto",
    "rank": 7280,
    "frequency": 3416,
    "originalRank": 7440
  },
  {
    "word": "asesinaron",
    "rank": 7281,
    "frequency": 3415,
    "originalRank": 7441
  },
  {
    "word": "voluntarios",
    "rank": 7282,
    "frequency": 3414,
    "originalRank": 7442
  },
  {
    "word": "conectar",
    "rank": 7283,
    "frequency": 3414,
    "originalRank": 7443
  },
  {
    "word": "enojar",
    "rank": 7284,
    "frequency": 3414,
    "originalRank": 7444
  },
  {
    "word": "cuelga",
    "rank": 7285,
    "frequency": 3412,
    "originalRank": 7445
  },
  {
    "word": "cuernos",
    "rank": 7286,
    "frequency": 3411,
    "originalRank": 7446
  },
  {
    "word": "nietos",
    "rank": 7287,
    "frequency": 3411,
    "originalRank": 7447
  },
  {
    "word": "gallo",
    "rank": 7288,
    "frequency": 3410,
    "originalRank": 7448
  },
  {
    "word": "mojado",
    "rank": 7289,
    "frequency": 3410,
    "originalRank": 7449
  },
  {
    "word": "obtiene",
    "rank": 7290,
    "frequency": 3410,
    "originalRank": 7450
  },
  {
    "word": "monica",
    "rank": 7291,
    "frequency": 3409,
    "originalRank": 7451
  },
  {
    "word": "aprendió",
    "rank": 7292,
    "frequency": 3409,
    "originalRank": 7452
  },
  {
    "word": "hubieses",
    "rank": 7293,
    "frequency": 3409,
    "originalRank": 7453
  },
  {
    "word": "moore",
    "rank": 7294,
    "frequency": 3409,
    "originalRank": 7454
  },
  {
    "word": "reid",
    "rank": 7295,
    "frequency": 3408,
    "originalRank": 7455
  },
  {
    "word": "entrenado",
    "rank": 7296,
    "frequency": 3408,
    "originalRank": 7456
  },
  {
    "word": "cuidaré",
    "rank": 7297,
    "frequency": 3408,
    "originalRank": 7457
  },
  {
    "word": "escucharon",
    "rank": 7298,
    "frequency": 3406,
    "originalRank": 7458
  },
  {
    "word": "reynolds",
    "rank": 7299,
    "frequency": 3406,
    "originalRank": 7459
  },
  {
    "word": "convertirte",
    "rank": 7300,
    "frequency": 3406,
    "originalRank": 7460
  },
  {
    "word": "naciste",
    "rank": 7301,
    "frequency": 3405,
    "originalRank": 7461
  },
  {
    "word": "escudos",
    "rank": 7302,
    "frequency": 3405,
    "originalRank": 7462
  },
  {
    "word": "cerradas",
    "rank": 7303,
    "frequency": 3403,
    "originalRank": 7463
  },
  {
    "word": "palos",
    "rank": 7304,
    "frequency": 3403,
    "originalRank": 7464
  },
  {
    "word": "vínculo",
    "rank": 7305,
    "frequency": 3402,
    "originalRank": 7465
  },
  {
    "word": "básico",
    "rank": 7306,
    "frequency": 3398,
    "originalRank": 7466
  },
  {
    "word": "kay",
    "rank": 7307,
    "frequency": 3398,
    "originalRank": 7467
  },
  {
    "word": "arrestaron",
    "rank": 7308,
    "frequency": 3397,
    "originalRank": 7468
  },
  {
    "word": "limpias",
    "rank": 7309,
    "frequency": 3397,
    "originalRank": 7469
  },
  {
    "word": "municiones",
    "rank": 7310,
    "frequency": 3396,
    "originalRank": 7470
  },
  {
    "word": "evolución",
    "rank": 7311,
    "frequency": 3395,
    "originalRank": 7471
  },
  {
    "word": "olviden",
    "rank": 7312,
    "frequency": 3395,
    "originalRank": 7472
  },
  {
    "word": "convincente",
    "rank": 7313,
    "frequency": 3395,
    "originalRank": 7473
  },
  {
    "word": "pelotón",
    "rank": 7314,
    "frequency": 3394,
    "originalRank": 7474
  },
  {
    "word": "comprometida",
    "rank": 7315,
    "frequency": 3394,
    "originalRank": 7475
  },
  {
    "word": "suene",
    "rank": 7316,
    "frequency": 3393,
    "originalRank": 7476
  },
  {
    "word": "debíamos",
    "rank": 7317,
    "frequency": 3393,
    "originalRank": 7477
  },
  {
    "word": "agarró",
    "rank": 7318,
    "frequency": 3392,
    "originalRank": 7478
  },
  {
    "word": "irlandés",
    "rank": 7319,
    "frequency": 3391,
    "originalRank": 7479
  },
  {
    "word": "sudor",
    "rank": 7320,
    "frequency": 3391,
    "originalRank": 7480
  },
  {
    "word": "conociera",
    "rank": 7321,
    "frequency": 3390,
    "originalRank": 7481
  },
  {
    "word": "desesperación",
    "rank": 7322,
    "frequency": 3390,
    "originalRank": 7482
  },
  {
    "word": "muchachas",
    "rank": 7323,
    "frequency": 3389,
    "originalRank": 7483
  },
  {
    "word": "huye",
    "rank": 7324,
    "frequency": 3389,
    "originalRank": 7484
  },
  {
    "word": "nucleares",
    "rank": 7325,
    "frequency": 3388,
    "originalRank": 7485
  },
  {
    "word": "hada",
    "rank": 7326,
    "frequency": 3387,
    "originalRank": 7486
  },
  {
    "word": "marcharme",
    "rank": 7327,
    "frequency": 3386,
    "originalRank": 7487
  },
  {
    "word": "convertí",
    "rank": 7328,
    "frequency": 3385,
    "originalRank": 7488
  },
  {
    "word": "haríamos",
    "rank": 7329,
    "frequency": 3385,
    "originalRank": 7489
  },
  {
    "word": "similares",
    "rank": 7330,
    "frequency": 3384,
    "originalRank": 7490
  },
  {
    "word": "comienzan",
    "rank": 7331,
    "frequency": 3383,
    "originalRank": 7491
  },
  {
    "word": "concierne",
    "rank": 7332,
    "frequency": 3383,
    "originalRank": 7492
  },
  {
    "word": "valga",
    "rank": 7333,
    "frequency": 3383,
    "originalRank": 7493
  },
  {
    "word": "eché",
    "rank": 7334,
    "frequency": 3383,
    "originalRank": 7494
  },
  {
    "word": "mito",
    "rank": 7335,
    "frequency": 3382,
    "originalRank": 7495
  },
  {
    "word": "claras",
    "rank": 7336,
    "frequency": 3381,
    "originalRank": 7496
  },
  {
    "word": "duró",
    "rank": 7337,
    "frequency": 3380,
    "originalRank": 7497
  },
  {
    "word": "rencor",
    "rank": 7338,
    "frequency": 3380,
    "originalRank": 7498
  },
  {
    "word": "persigue",
    "rank": 7339,
    "frequency": 3379,
    "originalRank": 7499
  },
  {
    "word": "trágico",
    "rank": 7340,
    "frequency": 3377,
    "originalRank": 7500
  },
  {
    "word": "brandy",
    "rank": 7341,
    "frequency": 3377,
    "originalRank": 7501
  },
  {
    "word": "desgraciadamente",
    "rank": 7342,
    "frequency": 3376,
    "originalRank": 7502
  },
  {
    "word": "violó",
    "rank": 7343,
    "frequency": 3373,
    "originalRank": 7503
  },
  {
    "word": "practicando",
    "rank": 7344,
    "frequency": 3373,
    "originalRank": 7504
  },
  {
    "word": "volverse",
    "rank": 7345,
    "frequency": 3372,
    "originalRank": 7505
  },
  {
    "word": "road",
    "rank": 7346,
    "frequency": 3371,
    "originalRank": 7506
  },
  {
    "word": "wells",
    "rank": 7347,
    "frequency": 3371,
    "originalRank": 7507
  },
  {
    "word": "escucharte",
    "rank": 7348,
    "frequency": 3370,
    "originalRank": 7508
  },
  {
    "word": "discúlpenme",
    "rank": 7349,
    "frequency": 3370,
    "originalRank": 7509
  },
  {
    "word": "poirot",
    "rank": 7350,
    "frequency": 3369,
    "originalRank": 7510
  },
  {
    "word": "generador",
    "rank": 7351,
    "frequency": 3369,
    "originalRank": 7511
  },
  {
    "word": "aguanto",
    "rank": 7352,
    "frequency": 3369,
    "originalRank": 7512
  },
  {
    "word": "amelia",
    "rank": 7353,
    "frequency": 3368,
    "originalRank": 7513
  },
  {
    "word": "riñón",
    "rank": 7354,
    "frequency": 3368,
    "originalRank": 7514
  },
  {
    "word": "navaja",
    "rank": 7355,
    "frequency": 3368,
    "originalRank": 7515
  },
  {
    "word": "dedica",
    "rank": 7356,
    "frequency": 3367,
    "originalRank": 7516
  },
  {
    "word": "muñeco",
    "rank": 7357,
    "frequency": 3366,
    "originalRank": 7517
  },
  {
    "word": "matty",
    "rank": 7358,
    "frequency": 3366,
    "originalRank": 7518
  },
  {
    "word": "usaron",
    "rank": 7359,
    "frequency": 3365,
    "originalRank": 7519
  },
  {
    "word": "delincuentes",
    "rank": 7360,
    "frequency": 3364,
    "originalRank": 7521
  },
  {
    "word": "oscuros",
    "rank": 7361,
    "frequency": 3364,
    "originalRank": 7522
  },
  {
    "word": "niles",
    "rank": 7362,
    "frequency": 3364,
    "originalRank": 7523
  },
  {
    "word": "cliff",
    "rank": 7363,
    "frequency": 3364,
    "originalRank": 7524
  },
  {
    "word": "ocultando",
    "rank": 7364,
    "frequency": 3363,
    "originalRank": 7525
  },
  {
    "word": "hara",
    "rank": 7365,
    "frequency": 3363,
    "originalRank": 7526
  },
  {
    "word": "comerciales",
    "rank": 7366,
    "frequency": 3362,
    "originalRank": 7527
  },
  {
    "word": "polly",
    "rank": 7367,
    "frequency": 3361,
    "originalRank": 7528
  },
  {
    "word": "descubrimos",
    "rank": 7368,
    "frequency": 3361,
    "originalRank": 7529
  },
  {
    "word": "saint",
    "rank": 7369,
    "frequency": 3360,
    "originalRank": 7530
  },
  {
    "word": "cometiendo",
    "rank": 7370,
    "frequency": 3359,
    "originalRank": 7531
  },
  {
    "word": "protesta",
    "rank": 7371,
    "frequency": 3359,
    "originalRank": 7532
  },
  {
    "word": "hudson",
    "rank": 7372,
    "frequency": 3358,
    "originalRank": 7533
  },
  {
    "word": "llevarán",
    "rank": 7373,
    "frequency": 3357,
    "originalRank": 7534
  },
  {
    "word": "ruina",
    "rank": 7374,
    "frequency": 3356,
    "originalRank": 7535
  },
  {
    "word": "mátalo",
    "rank": 7375,
    "frequency": 3355,
    "originalRank": 7536
  },
  {
    "word": "involucrada",
    "rank": 7376,
    "frequency": 3355,
    "originalRank": 7537
  },
  {
    "word": "gratitud",
    "rank": 7377,
    "frequency": 3354,
    "originalRank": 7538
  },
  {
    "word": "andan",
    "rank": 7378,
    "frequency": 3354,
    "originalRank": 7539
  },
  {
    "word": "oraciones",
    "rank": 7379,
    "frequency": 3353,
    "originalRank": 7540
  },
  {
    "word": "círculos",
    "rank": 7380,
    "frequency": 3353,
    "originalRank": 7541
  },
  {
    "word": "decidiste",
    "rank": 7381,
    "frequency": 3352,
    "originalRank": 7542
  },
  {
    "word": "plaga",
    "rank": 7382,
    "frequency": 3351,
    "originalRank": 7543
  },
  {
    "word": "sobredosis",
    "rank": 7383,
    "frequency": 3350,
    "originalRank": 7544
  },
  {
    "word": "uses",
    "rank": 7384,
    "frequency": 3350,
    "originalRank": 7545
  },
  {
    "word": "corazon",
    "rank": 7385,
    "frequency": 3350,
    "originalRank": 7546
  },
  {
    "word": "revólver",
    "rank": 7386,
    "frequency": 3350,
    "originalRank": 7547
  },
  {
    "word": "andre",
    "rank": 7387,
    "frequency": 3350,
    "originalRank": 7548
  },
  {
    "word": "independencia",
    "rank": 7388,
    "frequency": 3350,
    "originalRank": 7549
  },
  {
    "word": "exceso",
    "rank": 7389,
    "frequency": 3349,
    "originalRank": 7550
  },
  {
    "word": "conexiones",
    "rank": 7390,
    "frequency": 3348,
    "originalRank": 7551
  },
  {
    "word": "barras",
    "rank": 7391,
    "frequency": 3348,
    "originalRank": 7552
  },
  {
    "word": "santuario",
    "rank": 7392,
    "frequency": 3347,
    "originalRank": 7553
  },
  {
    "word": "estrado",
    "rank": 7393,
    "frequency": 3346,
    "originalRank": 7554
  },
  {
    "word": "insisto",
    "rank": 7394,
    "frequency": 3344,
    "originalRank": 7555
  },
  {
    "word": "sirena",
    "rank": 7395,
    "frequency": 3344,
    "originalRank": 7556
  },
  {
    "word": "are",
    "rank": 7396,
    "frequency": 3344,
    "originalRank": 7557
  },
  {
    "word": "héctor",
    "rank": 7397,
    "frequency": 3343,
    "originalRank": 7558
  },
  {
    "word": "áreas",
    "rank": 7398,
    "frequency": 3342,
    "originalRank": 7559
  },
  {
    "word": "frito",
    "rank": 7399,
    "frequency": 3342,
    "originalRank": 7560
  },
  {
    "word": "absoluta",
    "rank": 7400,
    "frequency": 3342,
    "originalRank": 7561
  },
  {
    "word": "convertirá",
    "rank": 7401,
    "frequency": 3341,
    "originalRank": 7562
  },
  {
    "word": "barrera",
    "rank": 7402,
    "frequency": 3341,
    "originalRank": 7563
  },
  {
    "word": "estándar",
    "rank": 7403,
    "frequency": 3340,
    "originalRank": 7564
  },
  {
    "word": "cargando",
    "rank": 7404,
    "frequency": 3338,
    "originalRank": 7565
  },
  {
    "word": "públicas",
    "rank": 7405,
    "frequency": 3338,
    "originalRank": 7566
  },
  {
    "word": "primos",
    "rank": 7406,
    "frequency": 3338,
    "originalRank": 7567
  },
  {
    "word": "perseguir",
    "rank": 7407,
    "frequency": 3337,
    "originalRank": 7568
  },
  {
    "word": "favores",
    "rank": 7408,
    "frequency": 3337,
    "originalRank": 7569
  },
  {
    "word": "cuan",
    "rank": 7409,
    "frequency": 3337,
    "originalRank": 7570
  },
  {
    "word": "lizzie",
    "rank": 7410,
    "frequency": 3337,
    "originalRank": 7571
  },
  {
    "word": "interesados",
    "rank": 7411,
    "frequency": 3337,
    "originalRank": 7572
  },
  {
    "word": "mierdas",
    "rank": 7412,
    "frequency": 3336,
    "originalRank": 7573
  },
  {
    "word": "supremo",
    "rank": 7413,
    "frequency": 3336,
    "originalRank": 7574
  },
  {
    "word": "matara",
    "rank": 7414,
    "frequency": 3336,
    "originalRank": 7575
  },
  {
    "word": "lavandería",
    "rank": 7415,
    "frequency": 3336,
    "originalRank": 7576
  },
  {
    "word": "une",
    "rank": 7416,
    "frequency": 3335,
    "originalRank": 7577
  },
  {
    "word": "ohio",
    "rank": 7417,
    "frequency": 3335,
    "originalRank": 7578
  },
  {
    "word": "llamados",
    "rank": 7418,
    "frequency": 3334,
    "originalRank": 7579
  },
  {
    "word": "farsa",
    "rank": 7419,
    "frequency": 3333,
    "originalRank": 7580
  },
  {
    "word": "automático",
    "rank": 7420,
    "frequency": 3333,
    "originalRank": 7581
  },
  {
    "word": "terminal",
    "rank": 7421,
    "frequency": 3333,
    "originalRank": 7582
  },
  {
    "word": "kira",
    "rank": 7422,
    "frequency": 3332,
    "originalRank": 7583
  },
  {
    "word": "moriremos",
    "rank": 7423,
    "frequency": 3332,
    "originalRank": 7584
  },
  {
    "word": "val",
    "rank": 7424,
    "frequency": 3332,
    "originalRank": 7585
  },
  {
    "word": "erin",
    "rank": 7425,
    "frequency": 3331,
    "originalRank": 7586
  },
  {
    "word": "protegerme",
    "rank": 7426,
    "frequency": 3331,
    "originalRank": 7587
  },
  {
    "word": "químicos",
    "rank": 7427,
    "frequency": 3330,
    "originalRank": 7588
  },
  {
    "word": "oyendo",
    "rank": 7428,
    "frequency": 3330,
    "originalRank": 7589
  },
  {
    "word": "técnicas",
    "rank": 7429,
    "frequency": 3330,
    "originalRank": 7590
  },
  {
    "word": "adulta",
    "rank": 7430,
    "frequency": 3329,
    "originalRank": 7591
  },
  {
    "word": "venían",
    "rank": 7431,
    "frequency": 3328,
    "originalRank": 7592
  },
  {
    "word": "empiecen",
    "rank": 7432,
    "frequency": 3328,
    "originalRank": 7593
  },
  {
    "word": "permites",
    "rank": 7433,
    "frequency": 3328,
    "originalRank": 7594
  },
  {
    "word": "ocupar",
    "rank": 7434,
    "frequency": 3327,
    "originalRank": 7595
  },
  {
    "word": "tijeras",
    "rank": 7435,
    "frequency": 3326,
    "originalRank": 7596
  },
  {
    "word": "senos",
    "rank": 7436,
    "frequency": 3326,
    "originalRank": 7597
  },
  {
    "word": "calibre",
    "rank": 7437,
    "frequency": 3326,
    "originalRank": 7598
  },
  {
    "word": "dominio",
    "rank": 7438,
    "frequency": 3324,
    "originalRank": 7599
  },
  {
    "word": "instrumentos",
    "rank": 7439,
    "frequency": 3323,
    "originalRank": 7600
  },
  {
    "word": "demostración",
    "rank": 7440,
    "frequency": 3321,
    "originalRank": 7601
  },
  {
    "word": "rompecabezas",
    "rank": 7441,
    "frequency": 3321,
    "originalRank": 7602
  },
  {
    "word": "asustaste",
    "rank": 7442,
    "frequency": 3321,
    "originalRank": 7603
  },
  {
    "word": "separación",
    "rank": 7443,
    "frequency": 3318,
    "originalRank": 7604
  },
  {
    "word": "sostener",
    "rank": 7444,
    "frequency": 3317,
    "originalRank": 7605
  },
  {
    "word": "esperma",
    "rank": 7445,
    "frequency": 3316,
    "originalRank": 7606
  },
  {
    "word": "porter",
    "rank": 7446,
    "frequency": 3316,
    "originalRank": 7607
  },
  {
    "word": "dados",
    "rank": 7447,
    "frequency": 3316,
    "originalRank": 7608
  },
  {
    "word": "bién",
    "rank": 7448,
    "frequency": 3316,
    "originalRank": 7609
  },
  {
    "word": "firmó",
    "rank": 7449,
    "frequency": 3316,
    "originalRank": 7610
  },
  {
    "word": "alias",
    "rank": 7450,
    "frequency": 3314,
    "originalRank": 7612
  },
  {
    "word": "atento",
    "rank": 7451,
    "frequency": 3314,
    "originalRank": 7613
  },
  {
    "word": "inesperado",
    "rank": 7452,
    "frequency": 3314,
    "originalRank": 7614
  },
  {
    "word": "indicado",
    "rank": 7453,
    "frequency": 3313,
    "originalRank": 7615
  },
  {
    "word": "unidas",
    "rank": 7454,
    "frequency": 3313,
    "originalRank": 7616
  },
  {
    "word": "movido",
    "rank": 7455,
    "frequency": 3312,
    "originalRank": 7617
  },
  {
    "word": "lanzó",
    "rank": 7456,
    "frequency": 3310,
    "originalRank": 7618
  },
  {
    "word": "rápidos",
    "rank": 7457,
    "frequency": 3310,
    "originalRank": 7619
  },
  {
    "word": "toallas",
    "rank": 7458,
    "frequency": 3309,
    "originalRank": 7620
  },
  {
    "word": "carnicero",
    "rank": 7459,
    "frequency": 3309,
    "originalRank": 7621
  },
  {
    "word": "hunt",
    "rank": 7460,
    "frequency": 3309,
    "originalRank": 7622
  },
  {
    "word": "colgando",
    "rank": 7461,
    "frequency": 3308,
    "originalRank": 7623
  },
  {
    "word": "positiva",
    "rank": 7462,
    "frequency": 3307,
    "originalRank": 7624
  },
  {
    "word": "ari",
    "rank": 7463,
    "frequency": 3307,
    "originalRank": 7625
  },
  {
    "word": "triunfo",
    "rank": 7464,
    "frequency": 3307,
    "originalRank": 7626
  },
  {
    "word": "vendí",
    "rank": 7465,
    "frequency": 3307,
    "originalRank": 7627
  },
  {
    "word": "ballena",
    "rank": 7466,
    "frequency": 3306,
    "originalRank": 7628
  },
  {
    "word": "cállense",
    "rank": 7467,
    "frequency": 3306,
    "originalRank": 7629
  },
  {
    "word": "corrupción",
    "rank": 7468,
    "frequency": 3306,
    "originalRank": 7630
  },
  {
    "word": "cayeron",
    "rank": 7469,
    "frequency": 3305,
    "originalRank": 7632
  },
  {
    "word": "regreses",
    "rank": 7470,
    "frequency": 3304,
    "originalRank": 7633
  },
  {
    "word": "regresemos",
    "rank": 7471,
    "frequency": 3303,
    "originalRank": 7634
  },
  {
    "word": "uds",
    "rank": 7472,
    "frequency": 3303,
    "originalRank": 7635
  },
  {
    "word": "moriría",
    "rank": 7473,
    "frequency": 3303,
    "originalRank": 7636
  },
  {
    "word": "cheryl",
    "rank": 7474,
    "frequency": 3302,
    "originalRank": 7637
  },
  {
    "word": "extraterrestre",
    "rank": 7475,
    "frequency": 3301,
    "originalRank": 7638
  },
  {
    "word": "terremoto",
    "rank": 7476,
    "frequency": 3301,
    "originalRank": 7639
  },
  {
    "word": "salvé",
    "rank": 7477,
    "frequency": 3301,
    "originalRank": 7640
  },
  {
    "word": "habré",
    "rank": 7478,
    "frequency": 3301,
    "originalRank": 7641
  },
  {
    "word": "aparcamiento",
    "rank": 7479,
    "frequency": 3298,
    "originalRank": 7642
  },
  {
    "word": "frutas",
    "rank": 7480,
    "frequency": 3297,
    "originalRank": 7643
  },
  {
    "word": "resumen",
    "rank": 7481,
    "frequency": 3297,
    "originalRank": 7644
  },
  {
    "word": "llevarás",
    "rank": 7482,
    "frequency": 3296,
    "originalRank": 7645
  },
  {
    "word": "ricardo",
    "rank": 7483,
    "frequency": 3296,
    "originalRank": 7646
  },
  {
    "word": "chiflado",
    "rank": 7484,
    "frequency": 3295,
    "originalRank": 7647
  },
  {
    "word": "planea",
    "rank": 7485,
    "frequency": 3295,
    "originalRank": 7648
  },
  {
    "word": "ahorros",
    "rank": 7486,
    "frequency": 3294,
    "originalRank": 7650
  },
  {
    "word": "omar",
    "rank": 7487,
    "frequency": 3294,
    "originalRank": 7651
  },
  {
    "word": "tuvieran",
    "rank": 7488,
    "frequency": 3294,
    "originalRank": 7652
  },
  {
    "word": "nolan",
    "rank": 7489,
    "frequency": 3294,
    "originalRank": 7653
  },
  {
    "word": "explotó",
    "rank": 7490,
    "frequency": 3294,
    "originalRank": 7654
  },
  {
    "word": "flotando",
    "rank": 7491,
    "frequency": 3293,
    "originalRank": 7655
  },
  {
    "word": "andaba",
    "rank": 7492,
    "frequency": 3293,
    "originalRank": 7656
  },
  {
    "word": "demente",
    "rank": 7493,
    "frequency": 3293,
    "originalRank": 7657
  },
  {
    "word": "automóvil",
    "rank": 7494,
    "frequency": 3292,
    "originalRank": 7658
  },
  {
    "word": "acostumbrada",
    "rank": 7495,
    "frequency": 3291,
    "originalRank": 7659
  },
  {
    "word": "bellas",
    "rank": 7496,
    "frequency": 3290,
    "originalRank": 7660
  },
  {
    "word": "doler",
    "rank": 7497,
    "frequency": 3290,
    "originalRank": 7661
  },
  {
    "word": "jonas",
    "rank": 7498,
    "frequency": 3289,
    "originalRank": 7662
  },
  {
    "word": "contenedor",
    "rank": 7499,
    "frequency": 3289,
    "originalRank": 7663
  },
  {
    "word": "saldrás",
    "rank": 7500,
    "frequency": 3288,
    "originalRank": 7664
  },
  {
    "word": "ondas",
    "rank": 7501,
    "frequency": 3288,
    "originalRank": 7665
  },
  {
    "word": "barril",
    "rank": 7502,
    "frequency": 3288,
    "originalRank": 7666
  },
  {
    "word": "adopción",
    "rank": 7503,
    "frequency": 3287,
    "originalRank": 7667
  },
  {
    "word": "instintos",
    "rank": 7504,
    "frequency": 3287,
    "originalRank": 7668
  },
  {
    "word": "patadas",
    "rank": 7505,
    "frequency": 3287,
    "originalRank": 7669
  },
  {
    "word": "acostarte",
    "rank": 7506,
    "frequency": 3286,
    "originalRank": 7670
  },
  {
    "word": "satisfacción",
    "rank": 7507,
    "frequency": 3286,
    "originalRank": 7671
  },
  {
    "word": "moscas",
    "rank": 7508,
    "frequency": 3286,
    "originalRank": 7672
  },
  {
    "word": "sirvió",
    "rank": 7509,
    "frequency": 3285,
    "originalRank": 7673
  },
  {
    "word": "huésped",
    "rank": 7510,
    "frequency": 3285,
    "originalRank": 7674
  },
  {
    "word": "existía",
    "rank": 7511,
    "frequency": 3284,
    "originalRank": 7675
  },
  {
    "word": "have",
    "rank": 7512,
    "frequency": 3283,
    "originalRank": 7676
  },
  {
    "word": "asia",
    "rank": 7513,
    "frequency": 3282,
    "originalRank": 7677
  },
  {
    "word": "inmortal",
    "rank": 7514,
    "frequency": 3282,
    "originalRank": 7678
  },
  {
    "word": "comeré",
    "rank": 7515,
    "frequency": 3281,
    "originalRank": 7679
  },
  {
    "word": "cambiaste",
    "rank": 7516,
    "frequency": 3281,
    "originalRank": 7680
  },
  {
    "word": "abro",
    "rank": 7517,
    "frequency": 3281,
    "originalRank": 7681
  },
  {
    "word": "varón",
    "rank": 7518,
    "frequency": 3281,
    "originalRank": 7682
  },
  {
    "word": "cooperación",
    "rank": 7519,
    "frequency": 3281,
    "originalRank": 7683
  },
  {
    "word": "resiste",
    "rank": 7520,
    "frequency": 3280,
    "originalRank": 7684
  },
  {
    "word": "músicos",
    "rank": 7521,
    "frequency": 3280,
    "originalRank": 7685
  },
  {
    "word": "patear",
    "rank": 7522,
    "frequency": 3280,
    "originalRank": 7686
  },
  {
    "word": "sácame",
    "rank": 7523,
    "frequency": 3279,
    "originalRank": 7687
  },
  {
    "word": "grayson",
    "rank": 7524,
    "frequency": 3278,
    "originalRank": 7688
  },
  {
    "word": "cueste",
    "rank": 7525,
    "frequency": 3277,
    "originalRank": 7689
  },
  {
    "word": "combatir",
    "rank": 7526,
    "frequency": 3276,
    "originalRank": 7690
  },
  {
    "word": "accidentalmente",
    "rank": 7527,
    "frequency": 3276,
    "originalRank": 7691
  },
  {
    "word": "ponerla",
    "rank": 7528,
    "frequency": 3276,
    "originalRank": 7692
  },
  {
    "word": "insoportable",
    "rank": 7529,
    "frequency": 3275,
    "originalRank": 7693
  },
  {
    "word": "tour",
    "rank": 7530,
    "frequency": 3274,
    "originalRank": 7694
  },
  {
    "word": "contaba",
    "rank": 7531,
    "frequency": 3274,
    "originalRank": 7695
  },
  {
    "word": "hoteles",
    "rank": 7532,
    "frequency": 3274,
    "originalRank": 7696
  },
  {
    "word": "guardo",
    "rank": 7533,
    "frequency": 3274,
    "originalRank": 7697
  },
  {
    "word": "iniciativa",
    "rank": 7534,
    "frequency": 3274,
    "originalRank": 7698
  },
  {
    "word": "denme",
    "rank": 7535,
    "frequency": 3273,
    "originalRank": 7699
  },
  {
    "word": "avergonzada",
    "rank": 7536,
    "frequency": 3272,
    "originalRank": 7700
  },
  {
    "word": "cambiarlo",
    "rank": 7537,
    "frequency": 3271,
    "originalRank": 7701
  },
  {
    "word": "comunistas",
    "rank": 7538,
    "frequency": 3269,
    "originalRank": 7702
  },
  {
    "word": "decidieron",
    "rank": 7539,
    "frequency": 3268,
    "originalRank": 7703
  },
  {
    "word": "mejorando",
    "rank": 7540,
    "frequency": 3268,
    "originalRank": 7704
  },
  {
    "word": "regimiento",
    "rank": 7541,
    "frequency": 3268,
    "originalRank": 7705
  },
  {
    "word": "avísame",
    "rank": 7542,
    "frequency": 3267,
    "originalRank": 7706
  },
  {
    "word": "orfanato",
    "rank": 7543,
    "frequency": 3267,
    "originalRank": 7707
  },
  {
    "word": "enseñando",
    "rank": 7544,
    "frequency": 3267,
    "originalRank": 7708
  },
  {
    "word": "contratos",
    "rank": 7545,
    "frequency": 3266,
    "originalRank": 7709
  },
  {
    "word": "beba",
    "rank": 7546,
    "frequency": 3265,
    "originalRank": 7710
  },
  {
    "word": "vistas",
    "rank": 7547,
    "frequency": 3265,
    "originalRank": 7711
  },
  {
    "word": "dixon",
    "rank": 7548,
    "frequency": 3265,
    "originalRank": 7712
  },
  {
    "word": "anual",
    "rank": 7549,
    "frequency": 3263,
    "originalRank": 7713
  },
  {
    "word": "declarado",
    "rank": 7550,
    "frequency": 3262,
    "originalRank": 7714
  },
  {
    "word": "encubierto",
    "rank": 7551,
    "frequency": 3262,
    "originalRank": 7715
  },
  {
    "word": "aborto",
    "rank": 7552,
    "frequency": 3261,
    "originalRank": 7716
  },
  {
    "word": "paquetes",
    "rank": 7553,
    "frequency": 3256,
    "originalRank": 7717
  },
  {
    "word": "sospechosa",
    "rank": 7554,
    "frequency": 3256,
    "originalRank": 7718
  },
  {
    "word": "dámela",
    "rank": 7555,
    "frequency": 3256,
    "originalRank": 7719
  },
  {
    "word": "diseñado",
    "rank": 7556,
    "frequency": 3255,
    "originalRank": 7720
  },
  {
    "word": "solitaria",
    "rank": 7557,
    "frequency": 3255,
    "originalRank": 7721
  },
  {
    "word": "prepare",
    "rank": 7558,
    "frequency": 3255,
    "originalRank": 7722
  },
  {
    "word": "salvarla",
    "rank": 7559,
    "frequency": 3254,
    "originalRank": 7723
  },
  {
    "word": "facil",
    "rank": 7560,
    "frequency": 3253,
    "originalRank": 7724
  },
  {
    "word": "atraparon",
    "rank": 7561,
    "frequency": 3253,
    "originalRank": 7725
  },
  {
    "word": "venda",
    "rank": 7562,
    "frequency": 3249,
    "originalRank": 7726
  },
  {
    "word": "cacería",
    "rank": 7563,
    "frequency": 3248,
    "originalRank": 7728
  },
  {
    "word": "e-mail",
    "rank": 7564,
    "frequency": 3248,
    "originalRank": 7729
  },
  {
    "word": "penas",
    "rank": 7565,
    "frequency": 3248,
    "originalRank": 7730
  },
  {
    "word": "británica",
    "rank": 7566,
    "frequency": 3248,
    "originalRank": 7731
  },
  {
    "word": "selección",
    "rank": 7567,
    "frequency": 3248,
    "originalRank": 7732
  },
  {
    "word": "honestidad",
    "rank": 7568,
    "frequency": 3247,
    "originalRank": 7733
  },
  {
    "word": "culto",
    "rank": 7569,
    "frequency": 3247,
    "originalRank": 7734
  },
  {
    "word": "joyce",
    "rank": 7570,
    "frequency": 3247,
    "originalRank": 7735
  },
  {
    "word": "telefono",
    "rank": 7571,
    "frequency": 3246,
    "originalRank": 7736
  },
  {
    "word": "dormiste",
    "rank": 7572,
    "frequency": 3246,
    "originalRank": 7737
  },
  {
    "word": "amabilidad",
    "rank": 7573,
    "frequency": 3246,
    "originalRank": 7738
  },
  {
    "word": "entendió",
    "rank": 7574,
    "frequency": 3245,
    "originalRank": 7739
  },
  {
    "word": "notar",
    "rank": 7575,
    "frequency": 3245,
    "originalRank": 7740
  },
  {
    "word": "inestable",
    "rank": 7576,
    "frequency": 3244,
    "originalRank": 7741
  },
  {
    "word": "manga",
    "rank": 7577,
    "frequency": 3244,
    "originalRank": 7742
  },
  {
    "word": "mademoiselle",
    "rank": 7578,
    "frequency": 3244,
    "originalRank": 7743
  },
  {
    "word": "lava",
    "rank": 7579,
    "frequency": 3243,
    "originalRank": 7744
  },
  {
    "word": "delicada",
    "rank": 7580,
    "frequency": 3243,
    "originalRank": 7745
  },
  {
    "word": "cambias",
    "rank": 7581,
    "frequency": 3242,
    "originalRank": 7746
  },
  {
    "word": "generales",
    "rank": 7582,
    "frequency": 3242,
    "originalRank": 7747
  },
  {
    "word": "bay",
    "rank": 7583,
    "frequency": 3242,
    "originalRank": 7748
  },
  {
    "word": "jugaba",
    "rank": 7584,
    "frequency": 3241,
    "originalRank": 7749
  },
  {
    "word": "molestaría",
    "rank": 7585,
    "frequency": 3240,
    "originalRank": 7750
  },
  {
    "word": "mandy",
    "rank": 7586,
    "frequency": 3240,
    "originalRank": 7751
  },
  {
    "word": "congelado",
    "rank": 7587,
    "frequency": 3238,
    "originalRank": 7752
  },
  {
    "word": "nocturna",
    "rank": 7588,
    "frequency": 3237,
    "originalRank": 7753
  },
  {
    "word": "marines",
    "rank": 7589,
    "frequency": 3237,
    "originalRank": 7754
  },
  {
    "word": "estuviéramos",
    "rank": 7590,
    "frequency": 3237,
    "originalRank": 7755
  },
  {
    "word": "einstein",
    "rank": 7591,
    "frequency": 3237,
    "originalRank": 7756
  },
  {
    "word": "ruinas",
    "rank": 7592,
    "frequency": 3236,
    "originalRank": 7757
  },
  {
    "word": "madrugada",
    "rank": 7593,
    "frequency": 3236,
    "originalRank": 7758
  },
  {
    "word": "mostrado",
    "rank": 7594,
    "frequency": 3236,
    "originalRank": 7759
  },
  {
    "word": "bichos",
    "rank": 7595,
    "frequency": 3235,
    "originalRank": 7760
  },
  {
    "word": "sácalo",
    "rank": 7596,
    "frequency": 3235,
    "originalRank": 7761
  },
  {
    "word": "boris",
    "rank": 7597,
    "frequency": 3235,
    "originalRank": 7762
  },
  {
    "word": "celebrando",
    "rank": 7598,
    "frequency": 3235,
    "originalRank": 7763
  },
  {
    "word": "residentes",
    "rank": 7599,
    "frequency": 3234,
    "originalRank": 7764
  },
  {
    "word": "suponer",
    "rank": 7600,
    "frequency": 3232,
    "originalRank": 7765
  },
  {
    "word": "unico",
    "rank": 7601,
    "frequency": 3232,
    "originalRank": 7766
  },
  {
    "word": "conseguirá",
    "rank": 7602,
    "frequency": 3232,
    "originalRank": 7767
  },
  {
    "word": "ordena",
    "rank": 7603,
    "frequency": 3231,
    "originalRank": 7768
  },
  {
    "word": "vivirá",
    "rank": 7604,
    "frequency": 3231,
    "originalRank": 7769
  },
  {
    "word": "champagne",
    "rank": 7605,
    "frequency": 3230,
    "originalRank": 7770
  },
  {
    "word": "derrotar",
    "rank": 7606,
    "frequency": 3229,
    "originalRank": 7771
  },
  {
    "word": "cavar",
    "rank": 7607,
    "frequency": 3229,
    "originalRank": 7772
  },
  {
    "word": "sólido",
    "rank": 7608,
    "frequency": 3229,
    "originalRank": 7773
  },
  {
    "word": "mariposa",
    "rank": 7609,
    "frequency": 3229,
    "originalRank": 7774
  },
  {
    "word": "provocar",
    "rank": 7610,
    "frequency": 3229,
    "originalRank": 7775
  },
  {
    "word": "salvarlo",
    "rank": 7611,
    "frequency": 3228,
    "originalRank": 7776
  },
  {
    "word": "asquerosa",
    "rank": 7612,
    "frequency": 3227,
    "originalRank": 7777
  },
  {
    "word": "sorprendería",
    "rank": 7613,
    "frequency": 3227,
    "originalRank": 7778
  },
  {
    "word": "recomiendo",
    "rank": 7614,
    "frequency": 3227,
    "originalRank": 7779
  },
  {
    "word": "mantendré",
    "rank": 7615,
    "frequency": 3225,
    "originalRank": 7780
  },
  {
    "word": "provisiones",
    "rank": 7616,
    "frequency": 3225,
    "originalRank": 7781
  },
  {
    "word": "parecerá",
    "rank": 7617,
    "frequency": 3224,
    "originalRank": 7782
  },
  {
    "word": "batallas",
    "rank": 7618,
    "frequency": 3224,
    "originalRank": 7783
  },
  {
    "word": "temblando",
    "rank": 7619,
    "frequency": 3223,
    "originalRank": 7784
  },
  {
    "word": "dragones",
    "rank": 7620,
    "frequency": 3222,
    "originalRank": 7785
  },
  {
    "word": "but",
    "rank": 7621,
    "frequency": 3222,
    "originalRank": 7786
  },
  {
    "word": "ferrocarril",
    "rank": 7622,
    "frequency": 3222,
    "originalRank": 7787
  },
  {
    "word": "súbete",
    "rank": 7623,
    "frequency": 3222,
    "originalRank": 7788
  },
  {
    "word": "leíste",
    "rank": 7624,
    "frequency": 3221,
    "originalRank": 7789
  },
  {
    "word": "agradecerle",
    "rank": 7625,
    "frequency": 3221,
    "originalRank": 7790
  },
  {
    "word": "woody",
    "rank": 7626,
    "frequency": 3220,
    "originalRank": 7791
  },
  {
    "word": "asustar",
    "rank": 7627,
    "frequency": 3219,
    "originalRank": 7792
  },
  {
    "word": "mantengo",
    "rank": 7628,
    "frequency": 3218,
    "originalRank": 7793
  },
  {
    "word": "querrán",
    "rank": 7629,
    "frequency": 3218,
    "originalRank": 7794
  },
  {
    "word": "trofeo",
    "rank": 7630,
    "frequency": 3217,
    "originalRank": 7795
  },
  {
    "word": "espeluznante",
    "rank": 7631,
    "frequency": 3217,
    "originalRank": 7796
  },
  {
    "word": "crecen",
    "rank": 7632,
    "frequency": 3217,
    "originalRank": 7797
  },
  {
    "word": "prácticas",
    "rank": 7633,
    "frequency": 3217,
    "originalRank": 7798
  },
  {
    "word": "bares",
    "rank": 7634,
    "frequency": 3217,
    "originalRank": 7799
  },
  {
    "word": "stevens",
    "rank": 7635,
    "frequency": 3217,
    "originalRank": 7800
  },
  {
    "word": "causando",
    "rank": 7636,
    "frequency": 3216,
    "originalRank": 7801
  },
  {
    "word": "sonia",
    "rank": 7637,
    "frequency": 3216,
    "originalRank": 7802
  },
  {
    "word": "echarme",
    "rank": 7638,
    "frequency": 3215,
    "originalRank": 7803
  },
  {
    "word": "cifras",
    "rank": 7639,
    "frequency": 3214,
    "originalRank": 7804
  },
  {
    "word": "enséñame",
    "rank": 7640,
    "frequency": 3214,
    "originalRank": 7805
  },
  {
    "word": "polonia",
    "rank": 7641,
    "frequency": 3214,
    "originalRank": 7806
  },
  {
    "word": "cachorro",
    "rank": 7642,
    "frequency": 3213,
    "originalRank": 7807
  },
  {
    "word": "aumenta",
    "rank": 7643,
    "frequency": 3212,
    "originalRank": 7808
  },
  {
    "word": "fractura",
    "rank": 7644,
    "frequency": 3211,
    "originalRank": 7809
  },
  {
    "word": "revisado",
    "rank": 7645,
    "frequency": 3211,
    "originalRank": 7810
  },
  {
    "word": "roberts",
    "rank": 7646,
    "frequency": 3211,
    "originalRank": 7811
  },
  {
    "word": "guante",
    "rank": 7647,
    "frequency": 3211,
    "originalRank": 7812
  },
  {
    "word": "muros",
    "rank": 7648,
    "frequency": 3211,
    "originalRank": 7813
  },
  {
    "word": "uniformes",
    "rank": 7649,
    "frequency": 3209,
    "originalRank": 7815
  },
  {
    "word": "confiado",
    "rank": 7650,
    "frequency": 3209,
    "originalRank": 7816
  },
  {
    "word": "recordarlo",
    "rank": 7651,
    "frequency": 3208,
    "originalRank": 7817
  },
  {
    "word": "rotos",
    "rank": 7652,
    "frequency": 3207,
    "originalRank": 7818
  },
  {
    "word": "leyó",
    "rank": 7653,
    "frequency": 3207,
    "originalRank": 7819
  },
  {
    "word": "mostrando",
    "rank": 7654,
    "frequency": 3205,
    "originalRank": 7820
  },
  {
    "word": "acompañarme",
    "rank": 7655,
    "frequency": 3205,
    "originalRank": 7821
  },
  {
    "word": "toquen",
    "rank": 7656,
    "frequency": 3205,
    "originalRank": 7822
  },
  {
    "word": "acordado",
    "rank": 7657,
    "frequency": 3204,
    "originalRank": 7823
  },
  {
    "word": "apuro",
    "rank": 7658,
    "frequency": 3203,
    "originalRank": 7824
  },
  {
    "word": "pañales",
    "rank": 7659,
    "frequency": 3203,
    "originalRank": 7825
  },
  {
    "word": "sonando",
    "rank": 7660,
    "frequency": 3202,
    "originalRank": 7826
  },
  {
    "word": "comiste",
    "rank": 7661,
    "frequency": 3202,
    "originalRank": 7827
  },
  {
    "word": "presos",
    "rank": 7662,
    "frequency": 3202,
    "originalRank": 7828
  },
  {
    "word": "otto",
    "rank": 7663,
    "frequency": 3202,
    "originalRank": 7829
  },
  {
    "word": "tomada",
    "rank": 7664,
    "frequency": 3199,
    "originalRank": 7830
  },
  {
    "word": "mínima",
    "rank": 7665,
    "frequency": 3198,
    "originalRank": 7831
  },
  {
    "word": "contárselo",
    "rank": 7666,
    "frequency": 3198,
    "originalRank": 7832
  },
  {
    "word": "incluido",
    "rank": 7667,
    "frequency": 3197,
    "originalRank": 7833
  },
  {
    "word": "rindo",
    "rank": 7668,
    "frequency": 3197,
    "originalRank": 7834
  },
  {
    "word": "enseñé",
    "rank": 7669,
    "frequency": 3196,
    "originalRank": 7835
  },
  {
    "word": "opuesto",
    "rank": 7670,
    "frequency": 3195,
    "originalRank": 7836
  },
  {
    "word": "parecería",
    "rank": 7671,
    "frequency": 3195,
    "originalRank": 7837
  },
  {
    "word": "necesitaría",
    "rank": 7672,
    "frequency": 3194,
    "originalRank": 7838
  },
  {
    "word": "catalina",
    "rank": 7673,
    "frequency": 3194,
    "originalRank": 7839
  },
  {
    "word": "pito",
    "rank": 7674,
    "frequency": 3194,
    "originalRank": 7840
  },
  {
    "word": "follar",
    "rank": 7675,
    "frequency": 3194,
    "originalRank": 7841
  },
  {
    "word": "hamilton",
    "rank": 7676,
    "frequency": 3192,
    "originalRank": 7842
  },
  {
    "word": "sesenta",
    "rank": 7677,
    "frequency": 3191,
    "originalRank": 7843
  },
  {
    "word": "balcón",
    "rank": 7678,
    "frequency": 3191,
    "originalRank": 7844
  },
  {
    "word": "jefferson",
    "rank": 7679,
    "frequency": 3190,
    "originalRank": 7845
  },
  {
    "word": "camilla",
    "rank": 7680,
    "frequency": 3190,
    "originalRank": 7846
  },
  {
    "word": "bauer",
    "rank": 7681,
    "frequency": 3189,
    "originalRank": 7847
  },
  {
    "word": "sirva",
    "rank": 7682,
    "frequency": 3189,
    "originalRank": 7848
  },
  {
    "word": "llueve",
    "rank": 7683,
    "frequency": 3189,
    "originalRank": 7849
  },
  {
    "word": "paloma",
    "rank": 7684,
    "frequency": 3189,
    "originalRank": 7850
  },
  {
    "word": "irlanda",
    "rank": 7685,
    "frequency": 3188,
    "originalRank": 7851
  },
  {
    "word": "ático",
    "rank": 7686,
    "frequency": 3188,
    "originalRank": 7852
  },
  {
    "word": "homicida",
    "rank": 7687,
    "frequency": 3187,
    "originalRank": 7853
  },
  {
    "word": "dañado",
    "rank": 7688,
    "frequency": 3187,
    "originalRank": 7854
  },
  {
    "word": "preparen",
    "rank": 7689,
    "frequency": 3187,
    "originalRank": 7855
  },
  {
    "word": "cálculos",
    "rank": 7690,
    "frequency": 3186,
    "originalRank": 7856
  },
  {
    "word": "sinvergüenza",
    "rank": 7691,
    "frequency": 3185,
    "originalRank": 7857
  },
  {
    "word": "rusty",
    "rank": 7692,
    "frequency": 3184,
    "originalRank": 7858
  },
  {
    "word": "hablábamos",
    "rank": 7693,
    "frequency": 3184,
    "originalRank": 7859
  },
  {
    "word": "calvin",
    "rank": 7694,
    "frequency": 3183,
    "originalRank": 7860
  },
  {
    "word": "trozos",
    "rank": 7695,
    "frequency": 3183,
    "originalRank": 7861
  },
  {
    "word": "granada",
    "rank": 7696,
    "frequency": 3183,
    "originalRank": 7862
  },
  {
    "word": "filas",
    "rank": 7697,
    "frequency": 3182,
    "originalRank": 7863
  },
  {
    "word": "baúl",
    "rank": 7698,
    "frequency": 3181,
    "originalRank": 7864
  },
  {
    "word": "inventar",
    "rank": 7699,
    "frequency": 3181,
    "originalRank": 7865
  },
  {
    "word": "impide",
    "rank": 7700,
    "frequency": 3180,
    "originalRank": 7866
  },
  {
    "word": "not",
    "rank": 7701,
    "frequency": 3179,
    "originalRank": 7867
  },
  {
    "word": "llover",
    "rank": 7702,
    "frequency": 3179,
    "originalRank": 7868
  },
  {
    "word": "falló",
    "rank": 7703,
    "frequency": 3178,
    "originalRank": 7869
  },
  {
    "word": "tanner",
    "rank": 7704,
    "frequency": 3177,
    "originalRank": 7870
  },
  {
    "word": "cody",
    "rank": 7705,
    "frequency": 3176,
    "originalRank": 7871
  },
  {
    "word": "sirviente",
    "rank": 7706,
    "frequency": 3176,
    "originalRank": 7872
  },
  {
    "word": "rechazar",
    "rank": 7707,
    "frequency": 3175,
    "originalRank": 7873
  },
  {
    "word": "funciones",
    "rank": 7708,
    "frequency": 3175,
    "originalRank": 7874
  },
  {
    "word": "june",
    "rank": 7709,
    "frequency": 3175,
    "originalRank": 7875
  },
  {
    "word": "ocurren",
    "rank": 7710,
    "frequency": 3175,
    "originalRank": 7876
  },
  {
    "word": "instalación",
    "rank": 7711,
    "frequency": 3174,
    "originalRank": 7877
  },
  {
    "word": "llegaría",
    "rank": 7712,
    "frequency": 3174,
    "originalRank": 7878
  },
  {
    "word": "verificar",
    "rank": 7713,
    "frequency": 3173,
    "originalRank": 7879
  },
  {
    "word": "abuelos",
    "rank": 7714,
    "frequency": 3173,
    "originalRank": 7880
  },
  {
    "word": "bruto",
    "rank": 7715,
    "frequency": 3172,
    "originalRank": 7881
  },
  {
    "word": "teorías",
    "rank": 7716,
    "frequency": 3172,
    "originalRank": 7882
  },
  {
    "word": "separar",
    "rank": 7717,
    "frequency": 3172,
    "originalRank": 7883
  },
  {
    "word": "crío",
    "rank": 7718,
    "frequency": 3172,
    "originalRank": 7884
  },
  {
    "word": "publicar",
    "rank": 7719,
    "frequency": 3171,
    "originalRank": 7885
  },
  {
    "word": "afectado",
    "rank": 7720,
    "frequency": 3170,
    "originalRank": 7886
  },
  {
    "word": "alcanzado",
    "rank": 7721,
    "frequency": 3170,
    "originalRank": 7887
  },
  {
    "word": "estabais",
    "rank": 7722,
    "frequency": 3170,
    "originalRank": 7888
  },
  {
    "word": "vivian",
    "rank": 7723,
    "frequency": 3170,
    "originalRank": 7889
  },
  {
    "word": "tatuajes",
    "rank": 7724,
    "frequency": 3169,
    "originalRank": 7890
  },
  {
    "word": "clásica",
    "rank": 7725,
    "frequency": 3168,
    "originalRank": 7891
  },
  {
    "word": "prestar",
    "rank": 7726,
    "frequency": 3168,
    "originalRank": 7892
  },
  {
    "word": "consiguen",
    "rank": 7727,
    "frequency": 3168,
    "originalRank": 7893
  },
  {
    "word": "deténganse",
    "rank": 7728,
    "frequency": 3168,
    "originalRank": 7894
  },
  {
    "word": "acondicionado",
    "rank": 7729,
    "frequency": 3167,
    "originalRank": 7895
  },
  {
    "word": "verduras",
    "rank": 7730,
    "frequency": 3167,
    "originalRank": 7896
  },
  {
    "word": "digital",
    "rank": 7731,
    "frequency": 3167,
    "originalRank": 7897
  },
  {
    "word": "dirigen",
    "rank": 7732,
    "frequency": 3165,
    "originalRank": 7898
  },
  {
    "word": "archer",
    "rank": 7733,
    "frequency": 3164,
    "originalRank": 7899
  },
  {
    "word": "imperial",
    "rank": 7734,
    "frequency": 3164,
    "originalRank": 7900
  },
  {
    "word": "comprobarlo",
    "rank": 7735,
    "frequency": 3163,
    "originalRank": 7902
  },
  {
    "word": "emboscada",
    "rank": 7736,
    "frequency": 3162,
    "originalRank": 7903
  },
  {
    "word": "finanzas",
    "rank": 7737,
    "frequency": 3162,
    "originalRank": 7904
  },
  {
    "word": "recta",
    "rank": 7738,
    "frequency": 3162,
    "originalRank": 7905
  },
  {
    "word": "enviamos",
    "rank": 7739,
    "frequency": 3162,
    "originalRank": 7906
  },
  {
    "word": "disponibles",
    "rank": 7740,
    "frequency": 3162,
    "originalRank": 7907
  },
  {
    "word": "agradecería",
    "rank": 7741,
    "frequency": 3161,
    "originalRank": 7908
  },
  {
    "word": "llévalo",
    "rank": 7742,
    "frequency": 3161,
    "originalRank": 7909
  },
  {
    "word": "soga",
    "rank": 7743,
    "frequency": 3160,
    "originalRank": 7910
  },
  {
    "word": "mudo",
    "rank": 7744,
    "frequency": 3160,
    "originalRank": 7911
  },
  {
    "word": "apodo",
    "rank": 7745,
    "frequency": 3160,
    "originalRank": 7912
  },
  {
    "word": "intelectual",
    "rank": 7746,
    "frequency": 3158,
    "originalRank": 7913
  },
  {
    "word": "stephanie",
    "rank": 7747,
    "frequency": 3158,
    "originalRank": 7914
  },
  {
    "word": "courtney",
    "rank": 7748,
    "frequency": 3158,
    "originalRank": 7915
  },
  {
    "word": "paisaje",
    "rank": 7749,
    "frequency": 3156,
    "originalRank": 7916
  },
  {
    "word": "surgió",
    "rank": 7750,
    "frequency": 3154,
    "originalRank": 7917
  },
  {
    "word": "excepcional",
    "rank": 7751,
    "frequency": 3153,
    "originalRank": 7918
  },
  {
    "word": "brennan",
    "rank": 7752,
    "frequency": 3153,
    "originalRank": 7919
  },
  {
    "word": "fletcher",
    "rank": 7753,
    "frequency": 3153,
    "originalRank": 7920
  },
  {
    "word": "pub",
    "rank": 7754,
    "frequency": 3152,
    "originalRank": 7921
  },
  {
    "word": "dirijo",
    "rank": 7755,
    "frequency": 3151,
    "originalRank": 7922
  },
  {
    "word": "lesión",
    "rank": 7756,
    "frequency": 3150,
    "originalRank": 7923
  },
  {
    "word": "marvin",
    "rank": 7757,
    "frequency": 3150,
    "originalRank": 7924
  },
  {
    "word": "empujar",
    "rank": 7758,
    "frequency": 3149,
    "originalRank": 7925
  },
  {
    "word": "acabemos",
    "rank": 7759,
    "frequency": 3148,
    "originalRank": 7926
  },
  {
    "word": "fuma",
    "rank": 7760,
    "frequency": 3146,
    "originalRank": 7927
  },
  {
    "word": "suicidarse",
    "rank": 7761,
    "frequency": 3146,
    "originalRank": 7928
  },
  {
    "word": "regina",
    "rank": 7762,
    "frequency": 3145,
    "originalRank": 7929
  },
  {
    "word": "novias",
    "rank": 7763,
    "frequency": 3145,
    "originalRank": 7930
  },
  {
    "word": "matones",
    "rank": 7764,
    "frequency": 3145,
    "originalRank": 7931
  },
  {
    "word": "redes",
    "rank": 7765,
    "frequency": 3145,
    "originalRank": 7932
  },
  {
    "word": "encendida",
    "rank": 7766,
    "frequency": 3145,
    "originalRank": 7933
  },
  {
    "word": "mátame",
    "rank": 7767,
    "frequency": 3144,
    "originalRank": 7934
  },
  {
    "word": "entorno",
    "rank": 7768,
    "frequency": 3144,
    "originalRank": 7935
  },
  {
    "word": "expectativas",
    "rank": 7769,
    "frequency": 3144,
    "originalRank": 7936
  },
  {
    "word": "hablabas",
    "rank": 7770,
    "frequency": 3144,
    "originalRank": 7937
  },
  {
    "word": "burt",
    "rank": 7771,
    "frequency": 3143,
    "originalRank": 7938
  },
  {
    "word": "cambiaría",
    "rank": 7772,
    "frequency": 3142,
    "originalRank": 7939
  },
  {
    "word": "conseguirte",
    "rank": 7773,
    "frequency": 3142,
    "originalRank": 7940
  },
  {
    "word": "explicarle",
    "rank": 7774,
    "frequency": 3141,
    "originalRank": 7941
  },
  {
    "word": "theo",
    "rank": 7775,
    "frequency": 3141,
    "originalRank": 7942
  },
  {
    "word": "bastón",
    "rank": 7776,
    "frequency": 3141,
    "originalRank": 7943
  },
  {
    "word": "explico",
    "rank": 7777,
    "frequency": 3141,
    "originalRank": 7944
  },
  {
    "word": "canales",
    "rank": 7778,
    "frequency": 3141,
    "originalRank": 7945
  },
  {
    "word": "armar",
    "rank": 7779,
    "frequency": 3140,
    "originalRank": 7946
  },
  {
    "word": "preparación",
    "rank": 7780,
    "frequency": 3140,
    "originalRank": 7947
  },
  {
    "word": "carlo",
    "rank": 7781,
    "frequency": 3139,
    "originalRank": 7948
  },
  {
    "word": "garcía",
    "rank": 7782,
    "frequency": 3139,
    "originalRank": 7949
  },
  {
    "word": "neumáticos",
    "rank": 7783,
    "frequency": 3139,
    "originalRank": 7950
  },
  {
    "word": "pedirme",
    "rank": 7784,
    "frequency": 3138,
    "originalRank": 7951
  },
  {
    "word": "alá",
    "rank": 7785,
    "frequency": 3138,
    "originalRank": 7952
  },
  {
    "word": "participación",
    "rank": 7786,
    "frequency": 3137,
    "originalRank": 7953
  },
  {
    "word": "atacando",
    "rank": 7787,
    "frequency": 3137,
    "originalRank": 7954
  },
  {
    "word": "vientos",
    "rank": 7788,
    "frequency": 3137,
    "originalRank": 7955
  },
  {
    "word": "usada",
    "rank": 7789,
    "frequency": 3136,
    "originalRank": 7956
  },
  {
    "word": "hablara",
    "rank": 7790,
    "frequency": 3136,
    "originalRank": 7957
  },
  {
    "word": "verga",
    "rank": 7791,
    "frequency": 3136,
    "originalRank": 7958
  },
  {
    "word": "estudiado",
    "rank": 7792,
    "frequency": 3135,
    "originalRank": 7959
  },
  {
    "word": "llamara",
    "rank": 7793,
    "frequency": 3135,
    "originalRank": 7960
  },
  {
    "word": "cha",
    "rank": 7794,
    "frequency": 3134,
    "originalRank": 7961
  },
  {
    "word": "avanzando",
    "rank": 7795,
    "frequency": 3133,
    "originalRank": 7963
  },
  {
    "word": "botes",
    "rank": 7796,
    "frequency": 3132,
    "originalRank": 7964
  },
  {
    "word": "encerrada",
    "rank": 7797,
    "frequency": 3132,
    "originalRank": 7965
  },
  {
    "word": "ayudaste",
    "rank": 7798,
    "frequency": 3132,
    "originalRank": 7966
  },
  {
    "word": "escondida",
    "rank": 7799,
    "frequency": 3131,
    "originalRank": 7967
  },
  {
    "word": "gordos",
    "rank": 7800,
    "frequency": 3131,
    "originalRank": 7968
  },
  {
    "word": "salidas",
    "rank": 7801,
    "frequency": 3130,
    "originalRank": 7969
  },
  {
    "word": "leones",
    "rank": 7802,
    "frequency": 3130,
    "originalRank": 7970
  },
  {
    "word": "garras",
    "rank": 7803,
    "frequency": 3129,
    "originalRank": 7971
  },
  {
    "word": "pleno",
    "rank": 7804,
    "frequency": 3129,
    "originalRank": 7972
  },
  {
    "word": "lamentable",
    "rank": 7805,
    "frequency": 3128,
    "originalRank": 7973
  },
  {
    "word": "perfectos",
    "rank": 7806,
    "frequency": 3127,
    "originalRank": 7974
  },
  {
    "word": "acompaña",
    "rank": 7807,
    "frequency": 3126,
    "originalRank": 7975
  },
  {
    "word": "promoción",
    "rank": 7808,
    "frequency": 3125,
    "originalRank": 7976
  },
  {
    "word": "televisor",
    "rank": 7809,
    "frequency": 3124,
    "originalRank": 7977
  },
  {
    "word": "masacre",
    "rank": 7810,
    "frequency": 3124,
    "originalRank": 7978
  },
  {
    "word": "moveos",
    "rank": 7811,
    "frequency": 3124,
    "originalRank": 7979
  },
  {
    "word": "llegaba",
    "rank": 7812,
    "frequency": 3123,
    "originalRank": 7980
  },
  {
    "word": "jet",
    "rank": 7813,
    "frequency": 3123,
    "originalRank": 7981
  },
  {
    "word": "desperdicio",
    "rank": 7814,
    "frequency": 3122,
    "originalRank": 7982
  },
  {
    "word": "queen",
    "rank": 7815,
    "frequency": 3122,
    "originalRank": 7983
  },
  {
    "word": "detendrá",
    "rank": 7816,
    "frequency": 3121,
    "originalRank": 7984
  },
  {
    "word": "quedarán",
    "rank": 7817,
    "frequency": 3121,
    "originalRank": 7985
  },
  {
    "word": "importará",
    "rank": 7818,
    "frequency": 3120,
    "originalRank": 7986
  },
  {
    "word": "margarita",
    "rank": 7819,
    "frequency": 3119,
    "originalRank": 7987
  },
  {
    "word": "chau",
    "rank": 7820,
    "frequency": 3119,
    "originalRank": 7988
  },
  {
    "word": "devuelve",
    "rank": 7821,
    "frequency": 3119,
    "originalRank": 7989
  },
  {
    "word": "peluca",
    "rank": 7822,
    "frequency": 3119,
    "originalRank": 7990
  },
  {
    "word": "inspección",
    "rank": 7823,
    "frequency": 3118,
    "originalRank": 7991
  },
  {
    "word": "cansados",
    "rank": 7824,
    "frequency": 3118,
    "originalRank": 7992
  },
  {
    "word": "cosquillas",
    "rank": 7825,
    "frequency": 3117,
    "originalRank": 7993
  },
  {
    "word": "factor",
    "rank": 7826,
    "frequency": 3117,
    "originalRank": 7994
  },
  {
    "word": "recientes",
    "rank": 7827,
    "frequency": 3115,
    "originalRank": 7995
  },
  {
    "word": "trece",
    "rank": 7828,
    "frequency": 3115,
    "originalRank": 7996
  },
  {
    "word": "violín",
    "rank": 7829,
    "frequency": 3114,
    "originalRank": 7997
  },
  {
    "word": "navegar",
    "rank": 7830,
    "frequency": 3114,
    "originalRank": 7998
  },
  {
    "word": "picnic",
    "rank": 7831,
    "frequency": 3114,
    "originalRank": 7999
  },
  {
    "word": "beckett",
    "rank": 7832,
    "frequency": 3113,
    "originalRank": 8000
  },
  {
    "word": "incómoda",
    "rank": 7833,
    "frequency": 3113,
    "originalRank": 8001
  },
  {
    "word": "patrones",
    "rank": 7834,
    "frequency": 3112,
    "originalRank": 8002
  },
  {
    "word": "examinar",
    "rank": 7835,
    "frequency": 3112,
    "originalRank": 8003
  },
  {
    "word": "lazos",
    "rank": 7836,
    "frequency": 3111,
    "originalRank": 8004
  },
  {
    "word": "mrs",
    "rank": 7837,
    "frequency": 3111,
    "originalRank": 8005
  },
  {
    "word": "chantaje",
    "rank": 7838,
    "frequency": 3111,
    "originalRank": 8006
  },
  {
    "word": "alquilar",
    "rank": 7839,
    "frequency": 3110,
    "originalRank": 8007
  },
  {
    "word": "durmió",
    "rank": 7840,
    "frequency": 3110,
    "originalRank": 8008
  },
  {
    "word": "artie",
    "rank": 7841,
    "frequency": 3110,
    "originalRank": 8009
  },
  {
    "word": "enseñe",
    "rank": 7842,
    "frequency": 3110,
    "originalRank": 8010
  },
  {
    "word": "humanas",
    "rank": 7843,
    "frequency": 3109,
    "originalRank": 8011
  },
  {
    "word": "negativa",
    "rank": 7844,
    "frequency": 3109,
    "originalRank": 8012
  },
  {
    "word": "talentos",
    "rank": 7845,
    "frequency": 3108,
    "originalRank": 8013
  },
  {
    "word": "cory",
    "rank": 7846,
    "frequency": 3108,
    "originalRank": 8014
  },
  {
    "word": "futura",
    "rank": 7847,
    "frequency": 3104,
    "originalRank": 8015
  },
  {
    "word": "melodía",
    "rank": 7848,
    "frequency": 3104,
    "originalRank": 8016
  },
  {
    "word": "entierro",
    "rank": 7849,
    "frequency": 3102,
    "originalRank": 8017
  },
  {
    "word": "sentirá",
    "rank": 7850,
    "frequency": 3102,
    "originalRank": 8018
  },
  {
    "word": "permitirá",
    "rank": 7851,
    "frequency": 3102,
    "originalRank": 8019
  },
  {
    "word": "reza",
    "rank": 7852,
    "frequency": 3101,
    "originalRank": 8020
  },
  {
    "word": "cambiamos",
    "rank": 7853,
    "frequency": 3101,
    "originalRank": 8021
  },
  {
    "word": "carajos",
    "rank": 7854,
    "frequency": 3100,
    "originalRank": 8022
  },
  {
    "word": "fijado",
    "rank": 7855,
    "frequency": 3099,
    "originalRank": 8024
  },
  {
    "word": "urgencia",
    "rank": 7856,
    "frequency": 3098,
    "originalRank": 8025
  },
  {
    "word": "milla",
    "rank": 7857,
    "frequency": 3098,
    "originalRank": 8026
  },
  {
    "word": "plomo",
    "rank": 7858,
    "frequency": 3098,
    "originalRank": 8027
  },
  {
    "word": "deb",
    "rank": 7859,
    "frequency": 3098,
    "originalRank": 8028
  },
  {
    "word": "destruye",
    "rank": 7860,
    "frequency": 3096,
    "originalRank": 8029
  },
  {
    "word": "únicamente",
    "rank": 7861,
    "frequency": 3096,
    "originalRank": 8030
  },
  {
    "word": "bufete",
    "rank": 7862,
    "frequency": 3094,
    "originalRank": 8031
  },
  {
    "word": "detroit",
    "rank": 7863,
    "frequency": 3094,
    "originalRank": 8032
  },
  {
    "word": "aparta",
    "rank": 7864,
    "frequency": 3094,
    "originalRank": 8033
  },
  {
    "word": "evelyn",
    "rank": 7865,
    "frequency": 3093,
    "originalRank": 8034
  },
  {
    "word": "conrad",
    "rank": 7866,
    "frequency": 3093,
    "originalRank": 8035
  },
  {
    "word": "creería",
    "rank": 7867,
    "frequency": 3091,
    "originalRank": 8036
  },
  {
    "word": "localización",
    "rank": 7868,
    "frequency": 3091,
    "originalRank": 8037
  },
  {
    "word": "hogares",
    "rank": 7869,
    "frequency": 3091,
    "originalRank": 8038
  },
  {
    "word": "klaus",
    "rank": 7870,
    "frequency": 3090,
    "originalRank": 8039
  },
  {
    "word": "casaste",
    "rank": 7871,
    "frequency": 3090,
    "originalRank": 8040
  },
  {
    "word": "envuelto",
    "rank": 7872,
    "frequency": 3090,
    "originalRank": 8041
  },
  {
    "word": "dexter",
    "rank": 7873,
    "frequency": 3090,
    "originalRank": 8042
  },
  {
    "word": "dinamita",
    "rank": 7874,
    "frequency": 3089,
    "originalRank": 8043
  },
  {
    "word": "avanza",
    "rank": 7875,
    "frequency": 3089,
    "originalRank": 8044
  },
  {
    "word": "porfavor",
    "rank": 7876,
    "frequency": 3087,
    "originalRank": 8045
  },
  {
    "word": "madura",
    "rank": 7877,
    "frequency": 3086,
    "originalRank": 8046
  },
  {
    "word": "constitución",
    "rank": 7878,
    "frequency": 3086,
    "originalRank": 8047
  },
  {
    "word": "cuñada",
    "rank": 7879,
    "frequency": 3086,
    "originalRank": 8048
  },
  {
    "word": "disparaste",
    "rank": 7880,
    "frequency": 3085,
    "originalRank": 8049
  },
  {
    "word": "sabés",
    "rank": 7881,
    "frequency": 3085,
    "originalRank": 8050
  },
  {
    "word": "arturo",
    "rank": 7882,
    "frequency": 3085,
    "originalRank": 8051
  },
  {
    "word": "convenció",
    "rank": 7883,
    "frequency": 3084,
    "originalRank": 8052
  },
  {
    "word": "hee",
    "rank": 7884,
    "frequency": 3084,
    "originalRank": 8053
  },
  {
    "word": "tronco",
    "rank": 7885,
    "frequency": 3084,
    "originalRank": 8054
  },
  {
    "word": "there",
    "rank": 7886,
    "frequency": 3083,
    "originalRank": 8055
  },
  {
    "word": "empezaré",
    "rank": 7887,
    "frequency": 3083,
    "originalRank": 8056
  },
  {
    "word": "aplicación",
    "rank": 7888,
    "frequency": 3082,
    "originalRank": 8057
  },
  {
    "word": "todopoderoso",
    "rank": 7889,
    "frequency": 3082,
    "originalRank": 8058
  },
  {
    "word": "gray",
    "rank": 7890,
    "frequency": 3082,
    "originalRank": 8059
  },
  {
    "word": "monja",
    "rank": 7891,
    "frequency": 3081,
    "originalRank": 8060
  },
  {
    "word": "encontrada",
    "rank": 7892,
    "frequency": 3081,
    "originalRank": 8061
  },
  {
    "word": "campesinos",
    "rank": 7893,
    "frequency": 3081,
    "originalRank": 8062
  },
  {
    "word": "herramienta",
    "rank": 7894,
    "frequency": 3080,
    "originalRank": 8063
  },
  {
    "word": "lake",
    "rank": 7895,
    "frequency": 3080,
    "originalRank": 8064
  },
  {
    "word": "zoológico",
    "rank": 7896,
    "frequency": 3080,
    "originalRank": 8065
  },
  {
    "word": "kane",
    "rank": 7897,
    "frequency": 3079,
    "originalRank": 8066
  },
  {
    "word": "insistió",
    "rank": 7898,
    "frequency": 3079,
    "originalRank": 8067
  },
  {
    "word": "creador",
    "rank": 7899,
    "frequency": 3079,
    "originalRank": 8068
  },
  {
    "word": "monje",
    "rank": 7900,
    "frequency": 3079,
    "originalRank": 8069
  },
  {
    "word": "convierta",
    "rank": 7901,
    "frequency": 3078,
    "originalRank": 8070
  },
  {
    "word": "spock",
    "rank": 7902,
    "frequency": 3077,
    "originalRank": 8071
  },
  {
    "word": "pertenecía",
    "rank": 7903,
    "frequency": 3077,
    "originalRank": 8072
  },
  {
    "word": "presentarme",
    "rank": 7904,
    "frequency": 3076,
    "originalRank": 8073
  },
  {
    "word": "perdería",
    "rank": 7905,
    "frequency": 3075,
    "originalRank": 8075
  },
  {
    "word": "cagar",
    "rank": 7906,
    "frequency": 3075,
    "originalRank": 8076
  },
  {
    "word": "ganará",
    "rank": 7907,
    "frequency": 3075,
    "originalRank": 8077
  },
  {
    "word": "burns",
    "rank": 7908,
    "frequency": 3074,
    "originalRank": 8078
  },
  {
    "word": "roman",
    "rank": 7909,
    "frequency": 3074,
    "originalRank": 8079
  },
  {
    "word": "logra",
    "rank": 7910,
    "frequency": 3074,
    "originalRank": 8080
  },
  {
    "word": "controles",
    "rank": 7911,
    "frequency": 3074,
    "originalRank": 8081
  },
  {
    "word": "parlamento",
    "rank": 7912,
    "frequency": 3072,
    "originalRank": 8082
  },
  {
    "word": "clavo",
    "rank": 7913,
    "frequency": 3072,
    "originalRank": 8083
  },
  {
    "word": "utilizó",
    "rank": 7914,
    "frequency": 3071,
    "originalRank": 8084
  },
  {
    "word": "alumno",
    "rank": 7915,
    "frequency": 3071,
    "originalRank": 8085
  },
  {
    "word": "informante",
    "rank": 7916,
    "frequency": 3071,
    "originalRank": 8086
  },
  {
    "word": "perderé",
    "rank": 7917,
    "frequency": 3070,
    "originalRank": 8087
  },
  {
    "word": "ponle",
    "rank": 7918,
    "frequency": 3070,
    "originalRank": 8088
  },
  {
    "word": "down",
    "rank": 7919,
    "frequency": 3070,
    "originalRank": 8089
  },
  {
    "word": "túneles",
    "rank": 7920,
    "frequency": 3069,
    "originalRank": 8090
  },
  {
    "word": "furiosa",
    "rank": 7921,
    "frequency": 3069,
    "originalRank": 8091
  },
  {
    "word": "ivan",
    "rank": 7922,
    "frequency": 3069,
    "originalRank": 8092
  },
  {
    "word": "xena",
    "rank": 7923,
    "frequency": 3069,
    "originalRank": 8093
  },
  {
    "word": "apunto",
    "rank": 7924,
    "frequency": 3069,
    "originalRank": 8094
  },
  {
    "word": "esperándote",
    "rank": 7925,
    "frequency": 3068,
    "originalRank": 8095
  },
  {
    "word": "artificial",
    "rank": 7926,
    "frequency": 3068,
    "originalRank": 8096
  },
  {
    "word": "cortas",
    "rank": 7927,
    "frequency": 3068,
    "originalRank": 8097
  },
  {
    "word": "abandona",
    "rank": 7928,
    "frequency": 3067,
    "originalRank": 8098
  },
  {
    "word": "cuidados",
    "rank": 7929,
    "frequency": 3067,
    "originalRank": 8099
  },
  {
    "word": "hills",
    "rank": 7930,
    "frequency": 3067,
    "originalRank": 8100
  },
  {
    "word": "terrorismo",
    "rank": 7931,
    "frequency": 3066,
    "originalRank": 8101
  },
  {
    "word": "arrancar",
    "rank": 7932,
    "frequency": 3066,
    "originalRank": 8102
  },
  {
    "word": "carolina",
    "rank": 7933,
    "frequency": 3066,
    "originalRank": 8103
  },
  {
    "word": "elegiste",
    "rank": 7934,
    "frequency": 3065,
    "originalRank": 8104
  },
  {
    "word": "misiones",
    "rank": 7935,
    "frequency": 3064,
    "originalRank": 8105
  },
  {
    "word": "masculino",
    "rank": 7936,
    "frequency": 3064,
    "originalRank": 8106
  },
  {
    "word": "crack",
    "rank": 7937,
    "frequency": 3064,
    "originalRank": 8107
  },
  {
    "word": "soporte",
    "rank": 7938,
    "frequency": 3064,
    "originalRank": 8108
  },
  {
    "word": "pólvora",
    "rank": 7939,
    "frequency": 3063,
    "originalRank": 8109
  },
  {
    "word": "perderás",
    "rank": 7940,
    "frequency": 3062,
    "originalRank": 8110
  },
  {
    "word": "documental",
    "rank": 7941,
    "frequency": 3062,
    "originalRank": 8111
  },
  {
    "word": "lazo",
    "rank": 7942,
    "frequency": 3061,
    "originalRank": 8112
  },
  {
    "word": "jae",
    "rank": 7943,
    "frequency": 3061,
    "originalRank": 8113
  },
  {
    "word": "mortales",
    "rank": 7944,
    "frequency": 3061,
    "originalRank": 8114
  },
  {
    "word": "nicholas",
    "rank": 7945,
    "frequency": 3060,
    "originalRank": 8115
  },
  {
    "word": "tocan",
    "rank": 7946,
    "frequency": 3059,
    "originalRank": 8116
  },
  {
    "word": "corrí",
    "rank": 7947,
    "frequency": 3059,
    "originalRank": 8117
  },
  {
    "word": "hallamos",
    "rank": 7948,
    "frequency": 3059,
    "originalRank": 8118
  },
  {
    "word": "gol",
    "rank": 7949,
    "frequency": 3057,
    "originalRank": 8119
  },
  {
    "word": "dificultad",
    "rank": 7950,
    "frequency": 3057,
    "originalRank": 8120
  },
  {
    "word": "institución",
    "rank": 7951,
    "frequency": 3057,
    "originalRank": 8121
  },
  {
    "word": "lemon",
    "rank": 7952,
    "frequency": 3057,
    "originalRank": 8122
  },
  {
    "word": "intimidad",
    "rank": 7953,
    "frequency": 3056,
    "originalRank": 8123
  },
  {
    "word": "hacerlos",
    "rank": 7954,
    "frequency": 3056,
    "originalRank": 8124
  },
  {
    "word": "rescatar",
    "rank": 7955,
    "frequency": 3055,
    "originalRank": 8125
  },
  {
    "word": "podrias",
    "rank": 7956,
    "frequency": 3054,
    "originalRank": 8126
  },
  {
    "word": "recuerdes",
    "rank": 7957,
    "frequency": 3054,
    "originalRank": 8127
  },
  {
    "word": "mascotas",
    "rank": 7958,
    "frequency": 3053,
    "originalRank": 8128
  },
  {
    "word": "just",
    "rank": 7959,
    "frequency": 3053,
    "originalRank": 8129
  },
  {
    "word": "avanzada",
    "rank": 7960,
    "frequency": 3053,
    "originalRank": 8130
  },
  {
    "word": "incorrecto",
    "rank": 7961,
    "frequency": 3052,
    "originalRank": 8131
  },
  {
    "word": "invertir",
    "rank": 7962,
    "frequency": 3051,
    "originalRank": 8132
  },
  {
    "word": "costar",
    "rank": 7963,
    "frequency": 3050,
    "originalRank": 8133
  },
  {
    "word": "morfina",
    "rank": 7964,
    "frequency": 3050,
    "originalRank": 8134
  },
  {
    "word": "creencias",
    "rank": 7965,
    "frequency": 3049,
    "originalRank": 8135
  },
  {
    "word": "banquete",
    "rank": 7966,
    "frequency": 3048,
    "originalRank": 8136
  },
  {
    "word": "llamarle",
    "rank": 7967,
    "frequency": 3048,
    "originalRank": 8137
  },
  {
    "word": "pearl",
    "rank": 7968,
    "frequency": 3048,
    "originalRank": 8138
  },
  {
    "word": "hastings",
    "rank": 7969,
    "frequency": 3048,
    "originalRank": 8139
  },
  {
    "word": "enfoque",
    "rank": 7970,
    "frequency": 3047,
    "originalRank": 8140
  },
  {
    "word": "enamoré",
    "rank": 7971,
    "frequency": 3046,
    "originalRank": 8141
  },
  {
    "word": "spike",
    "rank": 7972,
    "frequency": 3046,
    "originalRank": 8142
  },
  {
    "word": "joya",
    "rank": 7973,
    "frequency": 3046,
    "originalRank": 8143
  },
  {
    "word": "gancho",
    "rank": 7974,
    "frequency": 3045,
    "originalRank": 8144
  },
  {
    "word": "escribiré",
    "rank": 7975,
    "frequency": 3042,
    "originalRank": 8145
  },
  {
    "word": "causas",
    "rank": 7976,
    "frequency": 3042,
    "originalRank": 8146
  },
  {
    "word": "gallinas",
    "rank": 7977,
    "frequency": 3042,
    "originalRank": 8147
  },
  {
    "word": "pretendía",
    "rank": 7978,
    "frequency": 3040,
    "originalRank": 8148
  },
  {
    "word": "deseado",
    "rank": 7979,
    "frequency": 3040,
    "originalRank": 8149
  },
  {
    "word": "descubrieron",
    "rank": 7980,
    "frequency": 3040,
    "originalRank": 8150
  },
  {
    "word": "sugiriendo",
    "rank": 7981,
    "frequency": 3040,
    "originalRank": 8151
  },
  {
    "word": "perdonado",
    "rank": 7982,
    "frequency": 3039,
    "originalRank": 8152
  },
  {
    "word": "intervención",
    "rank": 7983,
    "frequency": 3037,
    "originalRank": 8153
  },
  {
    "word": "brady",
    "rank": 7984,
    "frequency": 3037,
    "originalRank": 8154
  },
  {
    "word": "conquistar",
    "rank": 7985,
    "frequency": 3037,
    "originalRank": 8155
  },
  {
    "word": "valía",
    "rank": 7986,
    "frequency": 3036,
    "originalRank": 8156
  },
  {
    "word": "billones",
    "rank": 7987,
    "frequency": 3036,
    "originalRank": 8157
  },
  {
    "word": "colorado",
    "rank": 7988,
    "frequency": 3036,
    "originalRank": 8158
  },
  {
    "word": "post",
    "rank": 7989,
    "frequency": 3036,
    "originalRank": 8159
  },
  {
    "word": "east",
    "rank": 7990,
    "frequency": 3034,
    "originalRank": 8160
  },
  {
    "word": "capilla",
    "rank": 7991,
    "frequency": 3033,
    "originalRank": 8161
  },
  {
    "word": "ofreciendo",
    "rank": 7992,
    "frequency": 3033,
    "originalRank": 8162
  },
  {
    "word": "espléndido",
    "rank": 7993,
    "frequency": 3033,
    "originalRank": 8163
  },
  {
    "word": "lucky",
    "rank": 7994,
    "frequency": 3032,
    "originalRank": 8164
  },
  {
    "word": "reflejo",
    "rank": 7995,
    "frequency": 3031,
    "originalRank": 8165
  },
  {
    "word": "suavemente",
    "rank": 7996,
    "frequency": 3030,
    "originalRank": 8166
  },
  {
    "word": "avanzado",
    "rank": 7997,
    "frequency": 3030,
    "originalRank": 8167
  },
  {
    "word": "deberíais",
    "rank": 7998,
    "frequency": 3030,
    "originalRank": 8168
  },
  {
    "word": "creyendo",
    "rank": 7999,
    "frequency": 3028,
    "originalRank": 8169
  },
  {
    "word": "reciben",
    "rank": 8000,
    "frequency": 3027,
    "originalRank": 8170
  },
  {
    "word": "subo",
    "rank": 8001,
    "frequency": 3027,
    "originalRank": 8171
  },
  {
    "word": "manuel",
    "rank": 8002,
    "frequency": 3027,
    "originalRank": 8172
  },
  {
    "word": "duerma",
    "rank": 8003,
    "frequency": 3025,
    "originalRank": 8173
  },
  {
    "word": "contador",
    "rank": 8004,
    "frequency": 3025,
    "originalRank": 8174
  },
  {
    "word": "sexualmente",
    "rank": 8005,
    "frequency": 3025,
    "originalRank": 8175
  },
  {
    "word": "necesitaban",
    "rank": 8006,
    "frequency": 3025,
    "originalRank": 8176
  },
  {
    "word": "carruaje",
    "rank": 8007,
    "frequency": 3024,
    "originalRank": 8177
  },
  {
    "word": "terminando",
    "rank": 8008,
    "frequency": 3024,
    "originalRank": 8178
  },
  {
    "word": "lote",
    "rank": 8009,
    "frequency": 3023,
    "originalRank": 8179
  },
  {
    "word": "champaña",
    "rank": 8010,
    "frequency": 3023,
    "originalRank": 8180
  },
  {
    "word": "palomitas",
    "rank": 8011,
    "frequency": 3023,
    "originalRank": 8181
  },
  {
    "word": "registrar",
    "rank": 8012,
    "frequency": 3023,
    "originalRank": 8182
  },
  {
    "word": "quedate",
    "rank": 8013,
    "frequency": 3022,
    "originalRank": 8183
  },
  {
    "word": "detenerlos",
    "rank": 8014,
    "frequency": 3022,
    "originalRank": 8184
  },
  {
    "word": "agresivo",
    "rank": 8015,
    "frequency": 3021,
    "originalRank": 8185
  },
  {
    "word": "grites",
    "rank": 8016,
    "frequency": 3021,
    "originalRank": 8186
  },
  {
    "word": "mariscal",
    "rank": 8017,
    "frequency": 3021,
    "originalRank": 8187
  },
  {
    "word": "gavin",
    "rank": 8018,
    "frequency": 3021,
    "originalRank": 8188
  },
  {
    "word": "brick",
    "rank": 8019,
    "frequency": 3020,
    "originalRank": 8189
  },
  {
    "word": "zumo",
    "rank": 8020,
    "frequency": 3020,
    "originalRank": 8190
  },
  {
    "word": "velo",
    "rank": 8021,
    "frequency": 3019,
    "originalRank": 8191
  },
  {
    "word": "invité",
    "rank": 8022,
    "frequency": 3019,
    "originalRank": 8192
  },
  {
    "word": "virtud",
    "rank": 8023,
    "frequency": 3018,
    "originalRank": 8193
  },
  {
    "word": "chandler",
    "rank": 8024,
    "frequency": 3018,
    "originalRank": 8194
  },
  {
    "word": "afortunados",
    "rank": 8025,
    "frequency": 3017,
    "originalRank": 8195
  },
  {
    "word": "nueces",
    "rank": 8026,
    "frequency": 3016,
    "originalRank": 8196
  },
  {
    "word": "soda",
    "rank": 8027,
    "frequency": 3016,
    "originalRank": 8197
  },
  {
    "word": "bájate",
    "rank": 8028,
    "frequency": 3016,
    "originalRank": 8198
  },
  {
    "word": "matón",
    "rank": 8029,
    "frequency": 3015,
    "originalRank": 8199
  },
  {
    "word": "continente",
    "rank": 8030,
    "frequency": 3014,
    "originalRank": 8200
  },
  {
    "word": "congresista",
    "rank": 8031,
    "frequency": 3013,
    "originalRank": 8201
  },
  {
    "word": "financiero",
    "rank": 8032,
    "frequency": 3013,
    "originalRank": 8202
  },
  {
    "word": "brody",
    "rank": 8033,
    "frequency": 3013,
    "originalRank": 8203
  },
  {
    "word": "pretendo",
    "rank": 8034,
    "frequency": 3012,
    "originalRank": 8204
  },
  {
    "word": "colocado",
    "rank": 8035,
    "frequency": 3011,
    "originalRank": 8205
  },
  {
    "word": "mantenerla",
    "rank": 8036,
    "frequency": 3011,
    "originalRank": 8206
  },
  {
    "word": "eco",
    "rank": 8037,
    "frequency": 3010,
    "originalRank": 8207
  },
  {
    "word": "oriental",
    "rank": 8038,
    "frequency": 3010,
    "originalRank": 8208
  },
  {
    "word": "llevarlos",
    "rank": 8039,
    "frequency": 3009,
    "originalRank": 8209
  },
  {
    "word": "valiosa",
    "rank": 8040,
    "frequency": 3009,
    "originalRank": 8210
  },
  {
    "word": "quito",
    "rank": 8041,
    "frequency": 3007,
    "originalRank": 8211
  },
  {
    "word": "ernie",
    "rank": 8042,
    "frequency": 3007,
    "originalRank": 8212
  },
  {
    "word": "pelicula",
    "rank": 8043,
    "frequency": 3005,
    "originalRank": 8213
  },
  {
    "word": "karma",
    "rank": 8044,
    "frequency": 3005,
    "originalRank": 8214
  },
  {
    "word": "descuida",
    "rank": 8045,
    "frequency": 3005,
    "originalRank": 8215
  },
  {
    "word": "probabilidad",
    "rank": 8046,
    "frequency": 3005,
    "originalRank": 8216
  },
  {
    "word": "fraternidad",
    "rank": 8047,
    "frequency": 3004,
    "originalRank": 8217
  },
  {
    "word": "dirigido",
    "rank": 8048,
    "frequency": 3004,
    "originalRank": 8218
  },
  {
    "word": "expedición",
    "rank": 8049,
    "frequency": 3004,
    "originalRank": 8219
  },
  {
    "word": "bestias",
    "rank": 8050,
    "frequency": 3004,
    "originalRank": 8220
  },
  {
    "word": "encargarme",
    "rank": 8051,
    "frequency": 3003,
    "originalRank": 8221
  },
  {
    "word": "comprueba",
    "rank": 8052,
    "frequency": 3003,
    "originalRank": 8222
  },
  {
    "word": "explicaciones",
    "rank": 8053,
    "frequency": 3002,
    "originalRank": 8223
  },
  {
    "word": "tumbas",
    "rank": 8054,
    "frequency": 3002,
    "originalRank": 8224
  },
  {
    "word": "industrial",
    "rank": 8055,
    "frequency": 3002,
    "originalRank": 8225
  },
  {
    "word": "agnes",
    "rank": 8056,
    "frequency": 3002,
    "originalRank": 8226
  },
  {
    "word": "amos",
    "rank": 8057,
    "frequency": 3001,
    "originalRank": 8227
  },
  {
    "word": "estupido",
    "rank": 8058,
    "frequency": 3000,
    "originalRank": 8228
  },
  {
    "word": "napoleón",
    "rank": 8059,
    "frequency": 2999,
    "originalRank": 8229
  },
  {
    "word": "dudar",
    "rank": 8060,
    "frequency": 2999,
    "originalRank": 8230
  },
  {
    "word": "cómico",
    "rank": 8061,
    "frequency": 2999,
    "originalRank": 8231
  },
  {
    "word": "limpios",
    "rank": 8062,
    "frequency": 2998,
    "originalRank": 8232
  },
  {
    "word": "unirte",
    "rank": 8063,
    "frequency": 2998,
    "originalRank": 8233
  },
  {
    "word": "chicle",
    "rank": 8064,
    "frequency": 2997,
    "originalRank": 8234
  },
  {
    "word": "tocino",
    "rank": 8065,
    "frequency": 2997,
    "originalRank": 8236
  },
  {
    "word": "respetable",
    "rank": 8066,
    "frequency": 2996,
    "originalRank": 8237
  },
  {
    "word": "brett",
    "rank": 8067,
    "frequency": 2996,
    "originalRank": 8238
  },
  {
    "word": "encontrarlos",
    "rank": 8068,
    "frequency": 2995,
    "originalRank": 8239
  },
  {
    "word": "federación",
    "rank": 8069,
    "frequency": 2994,
    "originalRank": 8240
  },
  {
    "word": "obliga",
    "rank": 8070,
    "frequency": 2994,
    "originalRank": 8241
  },
  {
    "word": "miento",
    "rank": 8071,
    "frequency": 2994,
    "originalRank": 8242
  },
  {
    "word": "descarga",
    "rank": 8072,
    "frequency": 2994,
    "originalRank": 8243
  },
  {
    "word": "corren",
    "rank": 8073,
    "frequency": 2994,
    "originalRank": 8244
  },
  {
    "word": "wang",
    "rank": 8074,
    "frequency": 2994,
    "originalRank": 8245
  },
  {
    "word": "encontrara",
    "rank": 8075,
    "frequency": 2993,
    "originalRank": 8246
  },
  {
    "word": "leña",
    "rank": 8076,
    "frequency": 2993,
    "originalRank": 8247
  },
  {
    "word": "bond",
    "rank": 8077,
    "frequency": 2993,
    "originalRank": 8248
  },
  {
    "word": "sylvia",
    "rank": 8078,
    "frequency": 2991,
    "originalRank": 8249
  },
  {
    "word": "abraham",
    "rank": 8079,
    "frequency": 2991,
    "originalRank": 8250
  },
  {
    "word": "religiosa",
    "rank": 8080,
    "frequency": 2990,
    "originalRank": 8251
  },
  {
    "word": "perderá",
    "rank": 8081,
    "frequency": 2990,
    "originalRank": 8252
  },
  {
    "word": "ilusiones",
    "rank": 8082,
    "frequency": 2990,
    "originalRank": 8253
  },
  {
    "word": "saldría",
    "rank": 8083,
    "frequency": 2990,
    "originalRank": 8254
  },
  {
    "word": "analizar",
    "rank": 8084,
    "frequency": 2990,
    "originalRank": 8255
  },
  {
    "word": "perdidas",
    "rank": 8085,
    "frequency": 2989,
    "originalRank": 8256
  },
  {
    "word": "chelsea",
    "rank": 8086,
    "frequency": 2989,
    "originalRank": 8257
  },
  {
    "word": "conocimientos",
    "rank": 8087,
    "frequency": 2988,
    "originalRank": 8258
  },
  {
    "word": "estreno",
    "rank": 8088,
    "frequency": 2988,
    "originalRank": 8259
  },
  {
    "word": "manteniendo",
    "rank": 8089,
    "frequency": 2987,
    "originalRank": 8260
  },
  {
    "word": "cosita",
    "rank": 8090,
    "frequency": 2987,
    "originalRank": 8261
  },
  {
    "word": "peste",
    "rank": 8091,
    "frequency": 2986,
    "originalRank": 8262
  },
  {
    "word": "podia",
    "rank": 8092,
    "frequency": 2986,
    "originalRank": 8263
  },
  {
    "word": "software",
    "rank": 8093,
    "frequency": 2983,
    "originalRank": 8264
  },
  {
    "word": "pasajero",
    "rank": 8094,
    "frequency": 2983,
    "originalRank": 8265
  },
  {
    "word": "frenos",
    "rank": 8095,
    "frequency": 2982,
    "originalRank": 8266
  },
  {
    "word": "experimentar",
    "rank": 8096,
    "frequency": 2982,
    "originalRank": 8267
  },
  {
    "word": "perderemos",
    "rank": 8097,
    "frequency": 2982,
    "originalRank": 8268
  },
  {
    "word": "paja",
    "rank": 8098,
    "frequency": 2980,
    "originalRank": 8269
  },
  {
    "word": "caballería",
    "rank": 8099,
    "frequency": 2980,
    "originalRank": 8270
  },
  {
    "word": "aquél",
    "rank": 8100,
    "frequency": 2979,
    "originalRank": 8271
  },
  {
    "word": "arruinaste",
    "rank": 8101,
    "frequency": 2979,
    "originalRank": 8272
  },
  {
    "word": "herr",
    "rank": 8102,
    "frequency": 2979,
    "originalRank": 8273
  },
  {
    "word": "cortina",
    "rank": 8103,
    "frequency": 2979,
    "originalRank": 8274
  },
  {
    "word": "queramos",
    "rank": 8104,
    "frequency": 2978,
    "originalRank": 8275
  },
  {
    "word": "puñetazo",
    "rank": 8105,
    "frequency": 2976,
    "originalRank": 8276
  },
  {
    "word": "habiendo",
    "rank": 8106,
    "frequency": 2976,
    "originalRank": 8277
  },
  {
    "word": "rodney",
    "rank": 8107,
    "frequency": 2976,
    "originalRank": 8278
  },
  {
    "word": "odiar",
    "rank": 8108,
    "frequency": 2976,
    "originalRank": 8279
  },
  {
    "word": "hugh",
    "rank": 8109,
    "frequency": 2975,
    "originalRank": 8280
  },
  {
    "word": "hostia",
    "rank": 8110,
    "frequency": 2975,
    "originalRank": 8281
  },
  {
    "word": "termines",
    "rank": 8111,
    "frequency": 2974,
    "originalRank": 8282
  },
  {
    "word": "frasier",
    "rank": 8112,
    "frequency": 2974,
    "originalRank": 8283
  },
  {
    "word": "confirma",
    "rank": 8113,
    "frequency": 2974,
    "originalRank": 8284
  },
  {
    "word": "psicología",
    "rank": 8114,
    "frequency": 2974,
    "originalRank": 8285
  },
  {
    "word": "finch",
    "rank": 8115,
    "frequency": 2974,
    "originalRank": 8286
  },
  {
    "word": "schmidt",
    "rank": 8116,
    "frequency": 2973,
    "originalRank": 8287
  },
  {
    "word": "delgada",
    "rank": 8117,
    "frequency": 2972,
    "originalRank": 8288
  },
  {
    "word": "honestos",
    "rank": 8118,
    "frequency": 2972,
    "originalRank": 8289
  },
  {
    "word": "prepararé",
    "rank": 8119,
    "frequency": 2972,
    "originalRank": 8290
  },
  {
    "word": "tomarse",
    "rank": 8120,
    "frequency": 2971,
    "originalRank": 8291
  },
  {
    "word": "calzoncillos",
    "rank": 8121,
    "frequency": 2971,
    "originalRank": 8292
  },
  {
    "word": "despidieron",
    "rank": 8122,
    "frequency": 2970,
    "originalRank": 8293
  },
  {
    "word": "sidney",
    "rank": 8123,
    "frequency": 2970,
    "originalRank": 8294
  },
  {
    "word": "definición",
    "rank": 8124,
    "frequency": 2970,
    "originalRank": 8295
  },
  {
    "word": "anton",
    "rank": 8125,
    "frequency": 2969,
    "originalRank": 8296
  },
  {
    "word": "cocinando",
    "rank": 8126,
    "frequency": 2969,
    "originalRank": 8297
  },
  {
    "word": "difunto",
    "rank": 8127,
    "frequency": 2969,
    "originalRank": 8298
  },
  {
    "word": "fugitivo",
    "rank": 8128,
    "frequency": 2968,
    "originalRank": 8299
  },
  {
    "word": "violenta",
    "rank": 8129,
    "frequency": 2967,
    "originalRank": 8300
  },
  {
    "word": "cerrando",
    "rank": 8130,
    "frequency": 2966,
    "originalRank": 8301
  },
  {
    "word": "cicatrices",
    "rank": 8131,
    "frequency": 2966,
    "originalRank": 8302
  },
  {
    "word": "donovan",
    "rank": 8132,
    "frequency": 2966,
    "originalRank": 8303
  },
  {
    "word": "excelentes",
    "rank": 8133,
    "frequency": 2965,
    "originalRank": 8304
  },
  {
    "word": "danielle",
    "rank": 8134,
    "frequency": 2964,
    "originalRank": 8305
  },
  {
    "word": "enfrentarse",
    "rank": 8135,
    "frequency": 2964,
    "originalRank": 8306
  },
  {
    "word": "conejos",
    "rank": 8136,
    "frequency": 2964,
    "originalRank": 8307
  },
  {
    "word": "preciosas",
    "rank": 8137,
    "frequency": 2963,
    "originalRank": 8308
  },
  {
    "word": "eramos",
    "rank": 8138,
    "frequency": 2961,
    "originalRank": 8309
  },
  {
    "word": "grecia",
    "rank": 8139,
    "frequency": 2960,
    "originalRank": 8310
  },
  {
    "word": "asegurado",
    "rank": 8140,
    "frequency": 2959,
    "originalRank": 8311
  },
  {
    "word": "actúas",
    "rank": 8141,
    "frequency": 2959,
    "originalRank": 8312
  },
  {
    "word": "artillería",
    "rank": 8142,
    "frequency": 2957,
    "originalRank": 8313
  },
  {
    "word": "panel",
    "rank": 8143,
    "frequency": 2956,
    "originalRank": 8314
  },
  {
    "word": "desarrollar",
    "rank": 8144,
    "frequency": 2956,
    "originalRank": 8315
  },
  {
    "word": "asesor",
    "rank": 8145,
    "frequency": 2956,
    "originalRank": 8316
  },
  {
    "word": "séptimo",
    "rank": 8146,
    "frequency": 2956,
    "originalRank": 8317
  },
  {
    "word": "bando",
    "rank": 8147,
    "frequency": 2956,
    "originalRank": 8318
  },
  {
    "word": "declaro",
    "rank": 8148,
    "frequency": 2956,
    "originalRank": 8319
  },
  {
    "word": "south",
    "rank": 8149,
    "frequency": 2955,
    "originalRank": 8320
  },
  {
    "word": "resfriado",
    "rank": 8150,
    "frequency": 2954,
    "originalRank": 8321
  },
  {
    "word": "devuelto",
    "rank": 8151,
    "frequency": 2954,
    "originalRank": 8322
  },
  {
    "word": "tablero",
    "rank": 8152,
    "frequency": 2953,
    "originalRank": 8323
  },
  {
    "word": "bradley",
    "rank": 8153,
    "frequency": 2953,
    "originalRank": 8324
  },
  {
    "word": "abandonada",
    "rank": 8154,
    "frequency": 2952,
    "originalRank": 8325
  },
  {
    "word": "archie",
    "rank": 8155,
    "frequency": 2952,
    "originalRank": 8326
  },
  {
    "word": "turnos",
    "rank": 8156,
    "frequency": 2951,
    "originalRank": 8327
  },
  {
    "word": "sesos",
    "rank": 8157,
    "frequency": 2950,
    "originalRank": 8328
  },
  {
    "word": "movernos",
    "rank": 8158,
    "frequency": 2950,
    "originalRank": 8329
  },
  {
    "word": "viena",
    "rank": 8159,
    "frequency": 2949,
    "originalRank": 8330
  },
  {
    "word": "quitaron",
    "rank": 8160,
    "frequency": 2948,
    "originalRank": 8331
  },
  {
    "word": "confíe",
    "rank": 8161,
    "frequency": 2948,
    "originalRank": 8332
  },
  {
    "word": "atraparlo",
    "rank": 8162,
    "frequency": 2947,
    "originalRank": 8333
  },
  {
    "word": "sombreros",
    "rank": 8163,
    "frequency": 2947,
    "originalRank": 8334
  },
  {
    "word": "oxford",
    "rank": 8164,
    "frequency": 2947,
    "originalRank": 8335
  },
  {
    "word": "relajarte",
    "rank": 8165,
    "frequency": 2947,
    "originalRank": 8336
  },
  {
    "word": "michel",
    "rank": 8166,
    "frequency": 2946,
    "originalRank": 8337
  },
  {
    "word": "nobles",
    "rank": 8167,
    "frequency": 2946,
    "originalRank": 8338
  },
  {
    "word": "ética",
    "rank": 8168,
    "frequency": 2945,
    "originalRank": 8339
  },
  {
    "word": "apoya",
    "rank": 8169,
    "frequency": 2945,
    "originalRank": 8340
  },
  {
    "word": "munición",
    "rank": 8170,
    "frequency": 2945,
    "originalRank": 8341
  },
  {
    "word": "táctica",
    "rank": 8171,
    "frequency": 2944,
    "originalRank": 8342
  },
  {
    "word": "perderlo",
    "rank": 8172,
    "frequency": 2943,
    "originalRank": 8343
  },
  {
    "word": "atacan",
    "rank": 8173,
    "frequency": 2943,
    "originalRank": 8344
  },
  {
    "word": "recordaba",
    "rank": 8174,
    "frequency": 2942,
    "originalRank": 8345
  },
  {
    "word": "admite",
    "rank": 8175,
    "frequency": 2942,
    "originalRank": 8346
  },
  {
    "word": "comas",
    "rank": 8176,
    "frequency": 2942,
    "originalRank": 8347
  },
  {
    "word": "millonario",
    "rank": 8177,
    "frequency": 2941,
    "originalRank": 8348
  },
  {
    "word": "sobrevivientes",
    "rank": 8178,
    "frequency": 2941,
    "originalRank": 8349
  },
  {
    "word": "éso",
    "rank": 8179,
    "frequency": 2940,
    "originalRank": 8350
  },
  {
    "word": "frio",
    "rank": 8180,
    "frequency": 2940,
    "originalRank": 8351
  },
  {
    "word": "involucrados",
    "rank": 8181,
    "frequency": 2940,
    "originalRank": 8352
  },
  {
    "word": "fumo",
    "rank": 8182,
    "frequency": 2939,
    "originalRank": 8353
  },
  {
    "word": "establecido",
    "rank": 8183,
    "frequency": 2938,
    "originalRank": 8354
  },
  {
    "word": "aprieta",
    "rank": 8184,
    "frequency": 2938,
    "originalRank": 8355
  },
  {
    "word": "destruida",
    "rank": 8185,
    "frequency": 2937,
    "originalRank": 8356
  },
  {
    "word": "payasos",
    "rank": 8186,
    "frequency": 2936,
    "originalRank": 8357
  },
  {
    "word": "amenazando",
    "rank": 8187,
    "frequency": 2935,
    "originalRank": 8358
  },
  {
    "word": "bandidos",
    "rank": 8188,
    "frequency": 2935,
    "originalRank": 8359
  },
  {
    "word": "whoo",
    "rank": 8189,
    "frequency": 2934,
    "originalRank": 8360
  },
  {
    "word": "estupideces",
    "rank": 8190,
    "frequency": 2933,
    "originalRank": 8361
  },
  {
    "word": "cruza",
    "rank": 8191,
    "frequency": 2933,
    "originalRank": 8362
  },
  {
    "word": "llámalo",
    "rank": 8192,
    "frequency": 2932,
    "originalRank": 8363
  },
  {
    "word": "sofía",
    "rank": 8193,
    "frequency": 2932,
    "originalRank": 8364
  },
  {
    "word": "provecho",
    "rank": 8194,
    "frequency": 2931,
    "originalRank": 8365
  },
  {
    "word": "trataron",
    "rank": 8195,
    "frequency": 2931,
    "originalRank": 8366
  },
  {
    "word": "envían",
    "rank": 8196,
    "frequency": 2931,
    "originalRank": 8367
  },
  {
    "word": "day",
    "rank": 8197,
    "frequency": 2930,
    "originalRank": 8368
  },
  {
    "word": "perras",
    "rank": 8198,
    "frequency": 2930,
    "originalRank": 8369
  },
  {
    "word": "botín",
    "rank": 8199,
    "frequency": 2928,
    "originalRank": 8370
  },
  {
    "word": "rechazo",
    "rank": 8200,
    "frequency": 2928,
    "originalRank": 8371
  },
  {
    "word": "entenderá",
    "rank": 8201,
    "frequency": 2927,
    "originalRank": 8372
  },
  {
    "word": "donante",
    "rank": 8202,
    "frequency": 2927,
    "originalRank": 8373
  },
  {
    "word": "avisado",
    "rank": 8203,
    "frequency": 2927,
    "originalRank": 8374
  },
  {
    "word": "exhibición",
    "rank": 8204,
    "frequency": 2926,
    "originalRank": 8375
  },
  {
    "word": "consiguieron",
    "rank": 8205,
    "frequency": 2926,
    "originalRank": 8376
  },
  {
    "word": "candidatos",
    "rank": 8206,
    "frequency": 2926,
    "originalRank": 8377
  },
  {
    "word": "maravillosos",
    "rank": 8207,
    "frequency": 2926,
    "originalRank": 8378
  },
  {
    "word": "vitales",
    "rank": 8208,
    "frequency": 2925,
    "originalRank": 8379
  },
  {
    "word": "genética",
    "rank": 8209,
    "frequency": 2925,
    "originalRank": 8380
  },
  {
    "word": "venecia",
    "rank": 8210,
    "frequency": 2925,
    "originalRank": 8381
  },
  {
    "word": "ram",
    "rank": 8211,
    "frequency": 2924,
    "originalRank": 8382
  },
  {
    "word": "muestre",
    "rank": 8212,
    "frequency": 2924,
    "originalRank": 8383
  },
  {
    "word": "paranoico",
    "rank": 8213,
    "frequency": 2923,
    "originalRank": 8384
  },
  {
    "word": "lynn",
    "rank": 8214,
    "frequency": 2923,
    "originalRank": 8385
  },
  {
    "word": "diciéndome",
    "rank": 8215,
    "frequency": 2921,
    "originalRank": 8386
  },
  {
    "word": "silencioso",
    "rank": 8216,
    "frequency": 2921,
    "originalRank": 8387
  },
  {
    "word": "casaré",
    "rank": 8217,
    "frequency": 2921,
    "originalRank": 8388
  },
  {
    "word": "sucias",
    "rank": 8218,
    "frequency": 2920,
    "originalRank": 8389
  },
  {
    "word": "hierbas",
    "rank": 8219,
    "frequency": 2920,
    "originalRank": 8390
  },
  {
    "word": "ash",
    "rank": 8220,
    "frequency": 2919,
    "originalRank": 8391
  },
  {
    "word": "empezaba",
    "rank": 8221,
    "frequency": 2919,
    "originalRank": 8392
  },
  {
    "word": "insignificante",
    "rank": 8222,
    "frequency": 2919,
    "originalRank": 8393
  },
  {
    "word": "wally",
    "rank": 8223,
    "frequency": 2919,
    "originalRank": 8394
  },
  {
    "word": "consecuencia",
    "rank": 8224,
    "frequency": 2918,
    "originalRank": 8395
  },
  {
    "word": "marchado",
    "rank": 8225,
    "frequency": 2917,
    "originalRank": 8396
  },
  {
    "word": "suspira",
    "rank": 8226,
    "frequency": 2917,
    "originalRank": 8397
  },
  {
    "word": "doncella",
    "rank": 8227,
    "frequency": 2917,
    "originalRank": 8398
  },
  {
    "word": "conocernos",
    "rank": 8228,
    "frequency": 2917,
    "originalRank": 8399
  },
  {
    "word": "aspectos",
    "rank": 8229,
    "frequency": 2916,
    "originalRank": 8400
  },
  {
    "word": "girl",
    "rank": 8230,
    "frequency": 2916,
    "originalRank": 8401
  },
  {
    "word": "discutimos",
    "rank": 8231,
    "frequency": 2915,
    "originalRank": 8402
  },
  {
    "word": "conserje",
    "rank": 8232,
    "frequency": 2915,
    "originalRank": 8403
  },
  {
    "word": "letal",
    "rank": 8233,
    "frequency": 2915,
    "originalRank": 8404
  },
  {
    "word": "arregló",
    "rank": 8234,
    "frequency": 2915,
    "originalRank": 8405
  },
  {
    "word": "explicarme",
    "rank": 8235,
    "frequency": 2914,
    "originalRank": 8406
  },
  {
    "word": "chang",
    "rank": 8236,
    "frequency": 2912,
    "originalRank": 8407
  },
  {
    "word": "chen",
    "rank": 8237,
    "frequency": 2912,
    "originalRank": 8408
  },
  {
    "word": "hormigas",
    "rank": 8238,
    "frequency": 2911,
    "originalRank": 8409
  },
  {
    "word": "fechas",
    "rank": 8239,
    "frequency": 2910,
    "originalRank": 8410
  },
  {
    "word": "dvd",
    "rank": 8240,
    "frequency": 2910,
    "originalRank": 8411
  },
  {
    "word": "escolta",
    "rank": 8241,
    "frequency": 2910,
    "originalRank": 8412
  },
  {
    "word": "laurel",
    "rank": 8242,
    "frequency": 2909,
    "originalRank": 8413
  },
  {
    "word": "valla",
    "rank": 8243,
    "frequency": 2909,
    "originalRank": 8414
  },
  {
    "word": "mayordomo",
    "rank": 8244,
    "frequency": 2908,
    "originalRank": 8415
  },
  {
    "word": "claude",
    "rank": 8245,
    "frequency": 2907,
    "originalRank": 8416
  },
  {
    "word": "deportivo",
    "rank": 8246,
    "frequency": 2906,
    "originalRank": 8417
  },
  {
    "word": "arquitecto",
    "rank": 8247,
    "frequency": 2906,
    "originalRank": 8418
  },
  {
    "word": "mordió",
    "rank": 8248,
    "frequency": 2906,
    "originalRank": 8419
  },
  {
    "word": "jacques",
    "rank": 8249,
    "frequency": 2905,
    "originalRank": 8420
  },
  {
    "word": "apuntando",
    "rank": 8250,
    "frequency": 2905,
    "originalRank": 8421
  },
  {
    "word": "guardas",
    "rank": 8251,
    "frequency": 2905,
    "originalRank": 8422
  },
  {
    "word": "establo",
    "rank": 8252,
    "frequency": 2905,
    "originalRank": 8423
  },
  {
    "word": "asombrosa",
    "rank": 8253,
    "frequency": 2905,
    "originalRank": 8424
  },
  {
    "word": "gilbert",
    "rank": 8254,
    "frequency": 2904,
    "originalRank": 8425
  },
  {
    "word": "religioso",
    "rank": 8255,
    "frequency": 2903,
    "originalRank": 8426
  },
  {
    "word": "willy",
    "rank": 8256,
    "frequency": 2901,
    "originalRank": 8427
  },
  {
    "word": "latas",
    "rank": 8257,
    "frequency": 2900,
    "originalRank": 8428
  },
  {
    "word": "traerla",
    "rank": 8258,
    "frequency": 2899,
    "originalRank": 8429
  },
  {
    "word": "suministro",
    "rank": 8259,
    "frequency": 2899,
    "originalRank": 8430
  },
  {
    "word": "aislamiento",
    "rank": 8260,
    "frequency": 2899,
    "originalRank": 8431
  },
  {
    "word": "perlas",
    "rank": 8261,
    "frequency": 2899,
    "originalRank": 8432
  },
  {
    "word": "cargamento",
    "rank": 8262,
    "frequency": 2898,
    "originalRank": 8433
  },
  {
    "word": "alrededores",
    "rank": 8263,
    "frequency": 2898,
    "originalRank": 8434
  },
  {
    "word": "entendía",
    "rank": 8264,
    "frequency": 2897,
    "originalRank": 8435
  },
  {
    "word": "cristina",
    "rank": 8265,
    "frequency": 2897,
    "originalRank": 8436
  },
  {
    "word": "saltando",
    "rank": 8266,
    "frequency": 2897,
    "originalRank": 8437
  },
  {
    "word": "pensaban",
    "rank": 8267,
    "frequency": 2897,
    "originalRank": 8438
  },
  {
    "word": "obtuve",
    "rank": 8268,
    "frequency": 2896,
    "originalRank": 8440
  },
  {
    "word": "pondrás",
    "rank": 8269,
    "frequency": 2896,
    "originalRank": 8441
  },
  {
    "word": "corporal",
    "rank": 8270,
    "frequency": 2896,
    "originalRank": 8442
  },
  {
    "word": "realista",
    "rank": 8271,
    "frequency": 2896,
    "originalRank": 8443
  },
  {
    "word": "italiana",
    "rank": 8272,
    "frequency": 2895,
    "originalRank": 8444
  },
  {
    "word": "embarazoso",
    "rank": 8273,
    "frequency": 2895,
    "originalRank": 8445
  },
  {
    "word": "incumbencia",
    "rank": 8274,
    "frequency": 2895,
    "originalRank": 8446
  },
  {
    "word": "monta",
    "rank": 8275,
    "frequency": 2895,
    "originalRank": 8447
  },
  {
    "word": "ofrecerte",
    "rank": 8276,
    "frequency": 2893,
    "originalRank": 8448
  },
  {
    "word": "helados",
    "rank": 8277,
    "frequency": 2893,
    "originalRank": 8449
  },
  {
    "word": "apos",
    "rank": 8278,
    "frequency": 2892,
    "originalRank": 8450
  },
  {
    "word": "cuestiones",
    "rank": 8279,
    "frequency": 2892,
    "originalRank": 8451
  },
  {
    "word": "admirador",
    "rank": 8280,
    "frequency": 2892,
    "originalRank": 8452
  },
  {
    "word": "ayudara",
    "rank": 8281,
    "frequency": 2892,
    "originalRank": 8453
  },
  {
    "word": "montado",
    "rank": 8282,
    "frequency": 2892,
    "originalRank": 8454
  },
  {
    "word": "prudente",
    "rank": 8283,
    "frequency": 2892,
    "originalRank": 8455
  },
  {
    "word": "generosa",
    "rank": 8284,
    "frequency": 2891,
    "originalRank": 8456
  },
  {
    "word": "fenomenal",
    "rank": 8285,
    "frequency": 2891,
    "originalRank": 8457
  },
  {
    "word": "acusa",
    "rank": 8286,
    "frequency": 2890,
    "originalRank": 8458
  },
  {
    "word": "comprarme",
    "rank": 8287,
    "frequency": 2890,
    "originalRank": 8459
  },
  {
    "word": "regresaste",
    "rank": 8288,
    "frequency": 2890,
    "originalRank": 8460
  },
  {
    "word": "barbacoa",
    "rank": 8289,
    "frequency": 2889,
    "originalRank": 8461
  },
  {
    "word": "célula",
    "rank": 8290,
    "frequency": 2888,
    "originalRank": 8462
  },
  {
    "word": "juguemos",
    "rank": 8291,
    "frequency": 2888,
    "originalRank": 8463
  },
  {
    "word": "rodando",
    "rank": 8292,
    "frequency": 2888,
    "originalRank": 8464
  },
  {
    "word": "caigo",
    "rank": 8293,
    "frequency": 2888,
    "originalRank": 8465
  },
  {
    "word": "asustando",
    "rank": 8294,
    "frequency": 2888,
    "originalRank": 8466
  },
  {
    "word": "sabrías",
    "rank": 8295,
    "frequency": 2888,
    "originalRank": 8467
  },
  {
    "word": "celebrarlo",
    "rank": 8296,
    "frequency": 2888,
    "originalRank": 8468
  },
  {
    "word": "decepción",
    "rank": 8297,
    "frequency": 2887,
    "originalRank": 8469
  },
  {
    "word": "representación",
    "rank": 8298,
    "frequency": 2886,
    "originalRank": 8470
  },
  {
    "word": "costumbres",
    "rank": 8299,
    "frequency": 2885,
    "originalRank": 8471
  },
  {
    "word": "pérdidas",
    "rank": 8300,
    "frequency": 2884,
    "originalRank": 8472
  },
  {
    "word": "gotas",
    "rank": 8301,
    "frequency": 2884,
    "originalRank": 8473
  },
  {
    "word": "carbono",
    "rank": 8302,
    "frequency": 2884,
    "originalRank": 8474
  },
  {
    "word": "moverte",
    "rank": 8303,
    "frequency": 2883,
    "originalRank": 8475
  },
  {
    "word": "arde",
    "rank": 8304,
    "frequency": 2883,
    "originalRank": 8476
  },
  {
    "word": "viví",
    "rank": 8305,
    "frequency": 2882,
    "originalRank": 8477
  },
  {
    "word": "demandas",
    "rank": 8306,
    "frequency": 2882,
    "originalRank": 8478
  },
  {
    "word": "rogers",
    "rank": 8307,
    "frequency": 2881,
    "originalRank": 8479
  },
  {
    "word": "semestre",
    "rank": 8308,
    "frequency": 2881,
    "originalRank": 8480
  },
  {
    "word": "javier",
    "rank": 8309,
    "frequency": 2880,
    "originalRank": 8481
  },
  {
    "word": "miramos",
    "rank": 8310,
    "frequency": 2880,
    "originalRank": 8482
  },
  {
    "word": "recibes",
    "rank": 8311,
    "frequency": 2879,
    "originalRank": 8483
  },
  {
    "word": "cristiana",
    "rank": 8312,
    "frequency": 2878,
    "originalRank": 8484
  },
  {
    "word": "hacienda",
    "rank": 8313,
    "frequency": 2878,
    "originalRank": 8485
  },
  {
    "word": "disparan",
    "rank": 8314,
    "frequency": 2878,
    "originalRank": 8486
  },
  {
    "word": "género",
    "rank": 8315,
    "frequency": 2878,
    "originalRank": 8487
  },
  {
    "word": "cat",
    "rank": 8316,
    "frequency": 2877,
    "originalRank": 8488
  },
  {
    "word": "wall",
    "rank": 8317,
    "frequency": 2876,
    "originalRank": 8489
  },
  {
    "word": "refresco",
    "rank": 8318,
    "frequency": 2876,
    "originalRank": 8490
  },
  {
    "word": "interruptor",
    "rank": 8319,
    "frequency": 2876,
    "originalRank": 8491
  },
  {
    "word": "conducía",
    "rank": 8320,
    "frequency": 2875,
    "originalRank": 8492
  },
  {
    "word": "halcón",
    "rank": 8321,
    "frequency": 2873,
    "originalRank": 8493
  },
  {
    "word": "mudarse",
    "rank": 8322,
    "frequency": 2873,
    "originalRank": 8494
  },
  {
    "word": "coloca",
    "rank": 8323,
    "frequency": 2873,
    "originalRank": 8495
  },
  {
    "word": "codo",
    "rank": 8324,
    "frequency": 2872,
    "originalRank": 8496
  },
  {
    "word": "valentía",
    "rank": 8325,
    "frequency": 2872,
    "originalRank": 8497
  },
  {
    "word": "promete",
    "rank": 8326,
    "frequency": 2872,
    "originalRank": 8498
  },
  {
    "word": "pipa",
    "rank": 8327,
    "frequency": 2871,
    "originalRank": 8499
  },
  {
    "word": "sustancia",
    "rank": 8328,
    "frequency": 2871,
    "originalRank": 8500
  },
  {
    "word": "posterior",
    "rank": 8329,
    "frequency": 2871,
    "originalRank": 8501
  },
  {
    "word": "was",
    "rank": 8330,
    "frequency": 2870,
    "originalRank": 8502
  },
  {
    "word": "atrapó",
    "rank": 8331,
    "frequency": 2870,
    "originalRank": 8503
  },
  {
    "word": "envíen",
    "rank": 8332,
    "frequency": 2869,
    "originalRank": 8504
  },
  {
    "word": "brisa",
    "rank": 8333,
    "frequency": 2869,
    "originalRank": 8505
  },
  {
    "word": "maravillosas",
    "rank": 8334,
    "frequency": 2869,
    "originalRank": 8506
  },
  {
    "word": "reparto",
    "rank": 8335,
    "frequency": 2867,
    "originalRank": 8507
  },
  {
    "word": "forenses",
    "rank": 8336,
    "frequency": 2867,
    "originalRank": 8508
  },
  {
    "word": "taberna",
    "rank": 8337,
    "frequency": 2866,
    "originalRank": 8509
  },
  {
    "word": "deshacerme",
    "rank": 8338,
    "frequency": 2866,
    "originalRank": 8510
  },
  {
    "word": "ratones",
    "rank": 8339,
    "frequency": 2866,
    "originalRank": 8511
  },
  {
    "word": "aleluya",
    "rank": 8340,
    "frequency": 2865,
    "originalRank": 8512
  },
  {
    "word": "comunicado",
    "rank": 8341,
    "frequency": 2864,
    "originalRank": 8513
  },
  {
    "word": "seguimiento",
    "rank": 8342,
    "frequency": 2864,
    "originalRank": 8514
  },
  {
    "word": "discreción",
    "rank": 8343,
    "frequency": 2863,
    "originalRank": 8515
  },
  {
    "word": "gritó",
    "rank": 8344,
    "frequency": 2863,
    "originalRank": 8516
  },
  {
    "word": "pulgar",
    "rank": 8345,
    "frequency": 2863,
    "originalRank": 8517
  },
  {
    "word": "comprensión",
    "rank": 8346,
    "frequency": 2862,
    "originalRank": 8518
  },
  {
    "word": "retroceder",
    "rank": 8347,
    "frequency": 2862,
    "originalRank": 8519
  },
  {
    "word": "originales",
    "rank": 8348,
    "frequency": 2861,
    "originalRank": 8520
  },
  {
    "word": "disfraces",
    "rank": 8349,
    "frequency": 2861,
    "originalRank": 8521
  },
  {
    "word": "frasco",
    "rank": 8350,
    "frequency": 2861,
    "originalRank": 8522
  },
  {
    "word": "arreglaremos",
    "rank": 8351,
    "frequency": 2860,
    "originalRank": 8523
  },
  {
    "word": "tequila",
    "rank": 8352,
    "frequency": 2859,
    "originalRank": 8524
  },
  {
    "word": "perdonen",
    "rank": 8353,
    "frequency": 2859,
    "originalRank": 8525
  },
  {
    "word": "bernie",
    "rank": 8354,
    "frequency": 2859,
    "originalRank": 8526
  },
  {
    "word": "pidas",
    "rank": 8355,
    "frequency": 2859,
    "originalRank": 8527
  },
  {
    "word": "decís",
    "rank": 8356,
    "frequency": 2859,
    "originalRank": 8528
  },
  {
    "word": "permítanme",
    "rank": 8357,
    "frequency": 2857,
    "originalRank": 8529
  },
  {
    "word": "deberiamos",
    "rank": 8358,
    "frequency": 2857,
    "originalRank": 8530
  },
  {
    "word": "planear",
    "rank": 8359,
    "frequency": 2856,
    "originalRank": 8531
  },
  {
    "word": "ocúpate",
    "rank": 8360,
    "frequency": 2856,
    "originalRank": 8532
  },
  {
    "word": "es-",
    "rank": 8361,
    "frequency": 2856,
    "originalRank": 8533
  },
  {
    "word": "volved",
    "rank": 8362,
    "frequency": 2856,
    "originalRank": 8534
  },
  {
    "word": "relojes",
    "rank": 8363,
    "frequency": 2855,
    "originalRank": 8535
  },
  {
    "word": "lider",
    "rank": 8364,
    "frequency": 2854,
    "originalRank": 8536
  },
  {
    "word": "convento",
    "rank": 8365,
    "frequency": 2854,
    "originalRank": 8537
  },
  {
    "word": "tráelo",
    "rank": 8366,
    "frequency": 2853,
    "originalRank": 8538
  },
  {
    "word": "regaló",
    "rank": 8367,
    "frequency": 2852,
    "originalRank": 8539
  },
  {
    "word": "coges",
    "rank": 8368,
    "frequency": 2852,
    "originalRank": 8540
  },
  {
    "word": "insulto",
    "rank": 8369,
    "frequency": 2851,
    "originalRank": 8541
  },
  {
    "word": "paces",
    "rank": 8370,
    "frequency": 2851,
    "originalRank": 8542
  },
  {
    "word": "cargada",
    "rank": 8371,
    "frequency": 2850,
    "originalRank": 8543
  },
  {
    "word": "jared",
    "rank": 8372,
    "frequency": 2850,
    "originalRank": 8544
  },
  {
    "word": "kid",
    "rank": 8373,
    "frequency": 2850,
    "originalRank": 8545
  },
  {
    "word": "coña",
    "rank": 8374,
    "frequency": 2850,
    "originalRank": 8546
  },
  {
    "word": "lloviendo",
    "rank": 8375,
    "frequency": 2850,
    "originalRank": 8547
  },
  {
    "word": "vigilante",
    "rank": 8376,
    "frequency": 2849,
    "originalRank": 8548
  },
  {
    "word": "metida",
    "rank": 8377,
    "frequency": 2849,
    "originalRank": 8549
  },
  {
    "word": "cálido",
    "rank": 8378,
    "frequency": 2849,
    "originalRank": 8550
  },
  {
    "word": "pero-",
    "rank": 8379,
    "frequency": 2848,
    "originalRank": 8551
  },
  {
    "word": "abras",
    "rank": 8380,
    "frequency": 2847,
    "originalRank": 8552
  },
  {
    "word": "robada",
    "rank": 8381,
    "frequency": 2847,
    "originalRank": 8553
  },
  {
    "word": "gabinete",
    "rank": 8382,
    "frequency": 2846,
    "originalRank": 8554
  },
  {
    "word": "excursión",
    "rank": 8383,
    "frequency": 2844,
    "originalRank": 8555
  },
  {
    "word": "filete",
    "rank": 8384,
    "frequency": 2843,
    "originalRank": 8556
  },
  {
    "word": "acepté",
    "rank": 8385,
    "frequency": 2843,
    "originalRank": 8557
  },
  {
    "word": "dante",
    "rank": 8386,
    "frequency": 2842,
    "originalRank": 8558
  },
  {
    "word": "rich",
    "rank": 8387,
    "frequency": 2841,
    "originalRank": 8559
  },
  {
    "word": "desconocidos",
    "rank": 8388,
    "frequency": 2841,
    "originalRank": 8560
  },
  {
    "word": "perteneces",
    "rank": 8389,
    "frequency": 2841,
    "originalRank": 8561
  },
  {
    "word": "ésas",
    "rank": 8390,
    "frequency": 2840,
    "originalRank": 8562
  },
  {
    "word": "mecanismo",
    "rank": 8391,
    "frequency": 2840,
    "originalRank": 8563
  },
  {
    "word": "atiende",
    "rank": 8392,
    "frequency": 2839,
    "originalRank": 8564
  },
  {
    "word": "liv",
    "rank": 8393,
    "frequency": 2839,
    "originalRank": 8565
  },
  {
    "word": "invento",
    "rank": 8394,
    "frequency": 2838,
    "originalRank": 8566
  },
  {
    "word": "dorada",
    "rank": 8395,
    "frequency": 2838,
    "originalRank": 8567
  },
  {
    "word": "seguirán",
    "rank": 8396,
    "frequency": 2838,
    "originalRank": 8568
  },
  {
    "word": "exitoso",
    "rank": 8397,
    "frequency": 2837,
    "originalRank": 8569
  },
  {
    "word": "fronteras",
    "rank": 8398,
    "frequency": 2837,
    "originalRank": 8570
  },
  {
    "word": "alterado",
    "rank": 8399,
    "frequency": 2837,
    "originalRank": 8571
  },
  {
    "word": "pulmón",
    "rank": 8400,
    "frequency": 2837,
    "originalRank": 8572
  },
  {
    "word": "ellis",
    "rank": 8401,
    "frequency": 2837,
    "originalRank": 8573
  },
  {
    "word": "frases",
    "rank": 8402,
    "frequency": 2836,
    "originalRank": 8574
  },
  {
    "word": "mostrador",
    "rank": 8403,
    "frequency": 2835,
    "originalRank": 8575
  },
  {
    "word": "precisión",
    "rank": 8404,
    "frequency": 2835,
    "originalRank": 8576
  },
  {
    "word": "conste",
    "rank": 8405,
    "frequency": 2834,
    "originalRank": 8578
  },
  {
    "word": "laurie",
    "rank": 8406,
    "frequency": 2834,
    "originalRank": 8579
  },
  {
    "word": "camisas",
    "rank": 8407,
    "frequency": 2834,
    "originalRank": 8580
  },
  {
    "word": "bromeaba",
    "rank": 8408,
    "frequency": 2834,
    "originalRank": 8581
  },
  {
    "word": "convierten",
    "rank": 8409,
    "frequency": 2834,
    "originalRank": 8582
  },
  {
    "word": "manicomio",
    "rank": 8410,
    "frequency": 2834,
    "originalRank": 8583
  },
  {
    "word": "freno",
    "rank": 8411,
    "frequency": 2833,
    "originalRank": 8584
  },
  {
    "word": "hondo",
    "rank": 8412,
    "frequency": 2832,
    "originalRank": 8585
  },
  {
    "word": "cynthia",
    "rank": 8413,
    "frequency": 2832,
    "originalRank": 8586
  },
  {
    "word": "america",
    "rank": 8414,
    "frequency": 2831,
    "originalRank": 8587
  },
  {
    "word": "dispares",
    "rank": 8415,
    "frequency": 2831,
    "originalRank": 8588
  },
  {
    "word": "basurero",
    "rank": 8416,
    "frequency": 2830,
    "originalRank": 8589
  },
  {
    "word": "querés",
    "rank": 8417,
    "frequency": 2830,
    "originalRank": 8590
  },
  {
    "word": "mini",
    "rank": 8418,
    "frequency": 2830,
    "originalRank": 8591
  },
  {
    "word": "abriendo",
    "rank": 8419,
    "frequency": 2830,
    "originalRank": 8592
  },
  {
    "word": "pensara",
    "rank": 8420,
    "frequency": 2830,
    "originalRank": 8593
  },
  {
    "word": "separarnos",
    "rank": 8421,
    "frequency": 2829,
    "originalRank": 8594
  },
  {
    "word": "ábrelo",
    "rank": 8422,
    "frequency": 2828,
    "originalRank": 8595
  },
  {
    "word": "retrocedan",
    "rank": 8423,
    "frequency": 2828,
    "originalRank": 8596
  },
  {
    "word": "pertenezco",
    "rank": 8424,
    "frequency": 2828,
    "originalRank": 8597
  },
  {
    "word": "infiel",
    "rank": 8425,
    "frequency": 2827,
    "originalRank": 8598
  },
  {
    "word": "cualidades",
    "rank": 8426,
    "frequency": 2826,
    "originalRank": 8599
  },
  {
    "word": "provoca",
    "rank": 8427,
    "frequency": 2825,
    "originalRank": 8600
  },
  {
    "word": "rodea",
    "rank": 8428,
    "frequency": 2825,
    "originalRank": 8601
  },
  {
    "word": "favoritas",
    "rank": 8429,
    "frequency": 2824,
    "originalRank": 8602
  },
  {
    "word": "mataran",
    "rank": 8430,
    "frequency": 2823,
    "originalRank": 8603
  },
  {
    "word": "resolverlo",
    "rank": 8431,
    "frequency": 2822,
    "originalRank": 8604
  },
  {
    "word": "respeta",
    "rank": 8432,
    "frequency": 2822,
    "originalRank": 8605
  },
  {
    "word": "comprador",
    "rank": 8433,
    "frequency": 2822,
    "originalRank": 8606
  },
  {
    "word": "domicilio",
    "rank": 8434,
    "frequency": 2821,
    "originalRank": 8607
  },
  {
    "word": "reduce",
    "rank": 8435,
    "frequency": 2821,
    "originalRank": 8608
  },
  {
    "word": "obedecer",
    "rank": 8436,
    "frequency": 2821,
    "originalRank": 8609
  },
  {
    "word": "quemaduras",
    "rank": 8437,
    "frequency": 2820,
    "originalRank": 8610
  },
  {
    "word": "levanten",
    "rank": 8438,
    "frequency": 2820,
    "originalRank": 8611
  },
  {
    "word": "antoine",
    "rank": 8439,
    "frequency": 2820,
    "originalRank": 8612
  },
  {
    "word": "juntar",
    "rank": 8440,
    "frequency": 2819,
    "originalRank": 8613
  },
  {
    "word": "arrepiento",
    "rank": 8441,
    "frequency": 2819,
    "originalRank": 8614
  },
  {
    "word": "moverme",
    "rank": 8442,
    "frequency": 2818,
    "originalRank": 8615
  },
  {
    "word": "hyun",
    "rank": 8443,
    "frequency": 2818,
    "originalRank": 8616
  },
  {
    "word": "bóveda",
    "rank": 8444,
    "frequency": 2817,
    "originalRank": 8617
  },
  {
    "word": "gimnasia",
    "rank": 8445,
    "frequency": 2817,
    "originalRank": 8618
  },
  {
    "word": "sirvientes",
    "rank": 8446,
    "frequency": 2816,
    "originalRank": 8619
  },
  {
    "word": "respecta",
    "rank": 8447,
    "frequency": 2815,
    "originalRank": 8620
  },
  {
    "word": "suéltala",
    "rank": 8448,
    "frequency": 2815,
    "originalRank": 8621
  },
  {
    "word": "baxter",
    "rank": 8449,
    "frequency": 2815,
    "originalRank": 8622
  },
  {
    "word": "presentarles",
    "rank": 8450,
    "frequency": 2815,
    "originalRank": 8623
  },
  {
    "word": "conectados",
    "rank": 8451,
    "frequency": 2814,
    "originalRank": 8624
  },
  {
    "word": "trayendo",
    "rank": 8452,
    "frequency": 2814,
    "originalRank": 8625
  },
  {
    "word": "iván",
    "rank": 8453,
    "frequency": 2814,
    "originalRank": 8626
  },
  {
    "word": "levanto",
    "rank": 8454,
    "frequency": 2813,
    "originalRank": 8627
  },
  {
    "word": "doris",
    "rank": 8455,
    "frequency": 2813,
    "originalRank": 8628
  },
  {
    "word": "privados",
    "rank": 8456,
    "frequency": 2812,
    "originalRank": 8629
  },
  {
    "word": "antepasados",
    "rank": 8457,
    "frequency": 2812,
    "originalRank": 8630
  },
  {
    "word": "sacrificios",
    "rank": 8458,
    "frequency": 2812,
    "originalRank": 8631
  },
  {
    "word": "fantasías",
    "rank": 8459,
    "frequency": 2811,
    "originalRank": 8632
  },
  {
    "word": "mantendrá",
    "rank": 8460,
    "frequency": 2811,
    "originalRank": 8633
  },
  {
    "word": "conclusiones",
    "rank": 8461,
    "frequency": 2811,
    "originalRank": 8634
  },
  {
    "word": "confirmación",
    "rank": 8462,
    "frequency": 2810,
    "originalRank": 8635
  },
  {
    "word": "traidores",
    "rank": 8463,
    "frequency": 2810,
    "originalRank": 8636
  },
  {
    "word": "residente",
    "rank": 8464,
    "frequency": 2810,
    "originalRank": 8637
  },
  {
    "word": "joshua",
    "rank": 8465,
    "frequency": 2809,
    "originalRank": 8638
  },
  {
    "word": "gemelas",
    "rank": 8466,
    "frequency": 2807,
    "originalRank": 8639
  },
  {
    "word": "dibujar",
    "rank": 8467,
    "frequency": 2806,
    "originalRank": 8640
  },
  {
    "word": "emocionalmente",
    "rank": 8468,
    "frequency": 2806,
    "originalRank": 8641
  },
  {
    "word": "violar",
    "rank": 8469,
    "frequency": 2806,
    "originalRank": 8642
  },
  {
    "word": "dirigida",
    "rank": 8470,
    "frequency": 2805,
    "originalRank": 8643
  },
  {
    "word": "cangrejo",
    "rank": 8471,
    "frequency": 2805,
    "originalRank": 8644
  },
  {
    "word": "burbuja",
    "rank": 8472,
    "frequency": 2804,
    "originalRank": 8645
  },
  {
    "word": "ignorante",
    "rank": 8473,
    "frequency": 2803,
    "originalRank": 8646
  },
  {
    "word": "sesiones",
    "rank": 8474,
    "frequency": 2801,
    "originalRank": 8647
  },
  {
    "word": "comparación",
    "rank": 8475,
    "frequency": 2801,
    "originalRank": 8648
  },
  {
    "word": "ligeramente",
    "rank": 8476,
    "frequency": 2801,
    "originalRank": 8649
  },
  {
    "word": "now",
    "rank": 8477,
    "frequency": 2801,
    "originalRank": 8650
  },
  {
    "word": "ejecutar",
    "rank": 8478,
    "frequency": 2800,
    "originalRank": 8651
  },
  {
    "word": "ciegas",
    "rank": 8479,
    "frequency": 2800,
    "originalRank": 8652
  },
  {
    "word": "alberto",
    "rank": 8480,
    "frequency": 2800,
    "originalRank": 8653
  },
  {
    "word": "proviene",
    "rank": 8481,
    "frequency": 2799,
    "originalRank": 8654
  },
  {
    "word": "dolió",
    "rank": 8482,
    "frequency": 2799,
    "originalRank": 8655
  },
  {
    "word": "parcial",
    "rank": 8483,
    "frequency": 2798,
    "originalRank": 8657
  },
  {
    "word": "empacar",
    "rank": 8484,
    "frequency": 2797,
    "originalRank": 8658
  },
  {
    "word": "victima",
    "rank": 8485,
    "frequency": 2797,
    "originalRank": 8659
  },
  {
    "word": "sentamos",
    "rank": 8486,
    "frequency": 2797,
    "originalRank": 8660
  },
  {
    "word": "católica",
    "rank": 8487,
    "frequency": 2797,
    "originalRank": 8661
  },
  {
    "word": "creían",
    "rank": 8488,
    "frequency": 2797,
    "originalRank": 8662
  },
  {
    "word": "mocoso",
    "rank": 8489,
    "frequency": 2797,
    "originalRank": 8663
  },
  {
    "word": "semilla",
    "rank": 8490,
    "frequency": 2796,
    "originalRank": 8664
  },
  {
    "word": "ring",
    "rank": 8491,
    "frequency": 2794,
    "originalRank": 8665
  },
  {
    "word": "chatarra",
    "rank": 8492,
    "frequency": 2794,
    "originalRank": 8666
  },
  {
    "word": "hablarlo",
    "rank": 8493,
    "frequency": 2792,
    "originalRank": 8667
  },
  {
    "word": "pascua",
    "rank": 8494,
    "frequency": 2792,
    "originalRank": 8668
  },
  {
    "word": "sadie",
    "rank": 8495,
    "frequency": 2792,
    "originalRank": 8669
  },
  {
    "word": "golpearon",
    "rank": 8496,
    "frequency": 2791,
    "originalRank": 8671
  },
  {
    "word": "cómodos",
    "rank": 8497,
    "frequency": 2791,
    "originalRank": 8672
  },
  {
    "word": "aceptaré",
    "rank": 8498,
    "frequency": 2791,
    "originalRank": 8673
  },
  {
    "word": "acercarme",
    "rank": 8499,
    "frequency": 2790,
    "originalRank": 8674
  },
  {
    "word": "juegues",
    "rank": 8500,
    "frequency": 2788,
    "originalRank": 8675
  },
  {
    "word": "bert",
    "rank": 8501,
    "frequency": 2787,
    "originalRank": 8676
  },
  {
    "word": "dicha",
    "rank": 8502,
    "frequency": 2787,
    "originalRank": 8677
  },
  {
    "word": "afirma",
    "rank": 8503,
    "frequency": 2787,
    "originalRank": 8678
  },
  {
    "word": "hostil",
    "rank": 8504,
    "frequency": 2787,
    "originalRank": 8679
  },
  {
    "word": "calvo",
    "rank": 8505,
    "frequency": 2786,
    "originalRank": 8680
  },
  {
    "word": "cintura",
    "rank": 8506,
    "frequency": 2786,
    "originalRank": 8681
  },
  {
    "word": "tomara",
    "rank": 8507,
    "frequency": 2785,
    "originalRank": 8682
  },
  {
    "word": "separamos",
    "rank": 8508,
    "frequency": 2785,
    "originalRank": 8683
  },
  {
    "word": "sincronización",
    "rank": 8509,
    "frequency": 2785,
    "originalRank": 8684
  },
  {
    "word": "barriga",
    "rank": 8510,
    "frequency": 2784,
    "originalRank": 8685
  },
  {
    "word": "disfruto",
    "rank": 8511,
    "frequency": 2784,
    "originalRank": 8686
  },
  {
    "word": "survivor",
    "rank": 8512,
    "frequency": 2784,
    "originalRank": 8687
  },
  {
    "word": "suprema",
    "rank": 8513,
    "frequency": 2784,
    "originalRank": 8688
  },
  {
    "word": "despegar",
    "rank": 8514,
    "frequency": 2783,
    "originalRank": 8689
  },
  {
    "word": "monitor",
    "rank": 8515,
    "frequency": 2783,
    "originalRank": 8690
  },
  {
    "word": "globos",
    "rank": 8516,
    "frequency": 2783,
    "originalRank": 8691
  },
  {
    "word": "mandaré",
    "rank": 8517,
    "frequency": 2783,
    "originalRank": 8692
  },
  {
    "word": "vagón",
    "rank": 8518,
    "frequency": 2782,
    "originalRank": 8693
  },
  {
    "word": "régimen",
    "rank": 8519,
    "frequency": 2782,
    "originalRank": 8694
  },
  {
    "word": "bates",
    "rank": 8520,
    "frequency": 2782,
    "originalRank": 8695
  },
  {
    "word": "ward",
    "rank": 8521,
    "frequency": 2782,
    "originalRank": 8696
  },
  {
    "word": "huracán",
    "rank": 8522,
    "frequency": 2781,
    "originalRank": 8697
  },
  {
    "word": "conferencias",
    "rank": 8523,
    "frequency": 2780,
    "originalRank": 8698
  },
  {
    "word": "cera",
    "rank": 8524,
    "frequency": 2780,
    "originalRank": 8699
  },
  {
    "word": "mirarte",
    "rank": 8525,
    "frequency": 2779,
    "originalRank": 8700
  },
  {
    "word": "protegerla",
    "rank": 8526,
    "frequency": 2778,
    "originalRank": 8701
  },
  {
    "word": "aroma",
    "rank": 8527,
    "frequency": 2777,
    "originalRank": 8702
  },
  {
    "word": "enfrenta",
    "rank": 8528,
    "frequency": 2777,
    "originalRank": 8703
  },
  {
    "word": "curado",
    "rank": 8529,
    "frequency": 2777,
    "originalRank": 8704
  },
  {
    "word": "interpretar",
    "rank": 8530,
    "frequency": 2776,
    "originalRank": 8705
  },
  {
    "word": "paraguas",
    "rank": 8531,
    "frequency": 2776,
    "originalRank": 8706
  },
  {
    "word": "bloqueado",
    "rank": 8532,
    "frequency": 2776,
    "originalRank": 8707
  },
  {
    "word": "misil",
    "rank": 8533,
    "frequency": 2776,
    "originalRank": 8708
  },
  {
    "word": "ensayos",
    "rank": 8534,
    "frequency": 2775,
    "originalRank": 8709
  },
  {
    "word": "peligrosas",
    "rank": 8535,
    "frequency": 2775,
    "originalRank": 8710
  },
  {
    "word": "declaró",
    "rank": 8536,
    "frequency": 2775,
    "originalRank": 8711
  },
  {
    "word": "pasemos",
    "rank": 8537,
    "frequency": 2774,
    "originalRank": 8712
  },
  {
    "word": "buffy",
    "rank": 8538,
    "frequency": 2774,
    "originalRank": 8713
  },
  {
    "word": "irónico",
    "rank": 8539,
    "frequency": 2774,
    "originalRank": 8714
  },
  {
    "word": "busquemos",
    "rank": 8540,
    "frequency": 2773,
    "originalRank": 8715
  },
  {
    "word": "paradero",
    "rank": 8541,
    "frequency": 2772,
    "originalRank": 8716
  },
  {
    "word": "esther",
    "rank": 8542,
    "frequency": 2772,
    "originalRank": 8717
  },
  {
    "word": "rechazó",
    "rank": 8543,
    "frequency": 2772,
    "originalRank": 8718
  },
  {
    "word": "aprobado",
    "rank": 8544,
    "frequency": 2771,
    "originalRank": 8719
  },
  {
    "word": "desesperadamente",
    "rank": 8545,
    "frequency": 2771,
    "originalRank": 8720
  },
  {
    "word": "iros",
    "rank": 8546,
    "frequency": 2771,
    "originalRank": 8721
  },
  {
    "word": "pagaron",
    "rank": 8547,
    "frequency": 2771,
    "originalRank": 8722
  },
  {
    "word": "cocinera",
    "rank": 8548,
    "frequency": 2770,
    "originalRank": 8723
  },
  {
    "word": "felicito",
    "rank": 8549,
    "frequency": 2769,
    "originalRank": 8724
  },
  {
    "word": "agáchate",
    "rank": 8550,
    "frequency": 2768,
    "originalRank": 8725
  },
  {
    "word": "gerald",
    "rank": 8551,
    "frequency": 2768,
    "originalRank": 8726
  },
  {
    "word": "führer",
    "rank": 8552,
    "frequency": 2767,
    "originalRank": 8727
  },
  {
    "word": "robinson",
    "rank": 8553,
    "frequency": 2767,
    "originalRank": 8728
  },
  {
    "word": "renuncio",
    "rank": 8554,
    "frequency": 2767,
    "originalRank": 8729
  },
  {
    "word": "apretado",
    "rank": 8555,
    "frequency": 2766,
    "originalRank": 8730
  },
  {
    "word": "serias",
    "rank": 8556,
    "frequency": 2766,
    "originalRank": 8731
  },
  {
    "word": "escogido",
    "rank": 8557,
    "frequency": 2766,
    "originalRank": 8732
  },
  {
    "word": "acompañante",
    "rank": 8558,
    "frequency": 2764,
    "originalRank": 8733
  },
  {
    "word": "catorce",
    "rank": 8559,
    "frequency": 2763,
    "originalRank": 8734
  },
  {
    "word": "liderazgo",
    "rank": 8560,
    "frequency": 2761,
    "originalRank": 8735
  },
  {
    "word": "atlanta",
    "rank": 8561,
    "frequency": 2761,
    "originalRank": 8736
  },
  {
    "word": "fabulosa",
    "rank": 8562,
    "frequency": 2760,
    "originalRank": 8737
  },
  {
    "word": "devuélveme",
    "rank": 8563,
    "frequency": 2760,
    "originalRank": 8738
  },
  {
    "word": "sensacional",
    "rank": 8564,
    "frequency": 2759,
    "originalRank": 8739
  },
  {
    "word": "ganadores",
    "rank": 8565,
    "frequency": 2759,
    "originalRank": 8740
  },
  {
    "word": "olla",
    "rank": 8566,
    "frequency": 2759,
    "originalRank": 8741
  },
  {
    "word": "cyrus",
    "rank": 8567,
    "frequency": 2759,
    "originalRank": 8742
  },
  {
    "word": "guarde",
    "rank": 8568,
    "frequency": 2759,
    "originalRank": 8743
  },
  {
    "word": "traicionó",
    "rank": 8569,
    "frequency": 2758,
    "originalRank": 8744
  },
  {
    "word": "ocupación",
    "rank": 8570,
    "frequency": 2758,
    "originalRank": 8745
  },
  {
    "word": "hablaban",
    "rank": 8571,
    "frequency": 2758,
    "originalRank": 8746
  },
  {
    "word": "lloras",
    "rank": 8572,
    "frequency": 2755,
    "originalRank": 8747
  },
  {
    "word": "bragas",
    "rank": 8573,
    "frequency": 2754,
    "originalRank": 8748
  },
  {
    "word": "obstáculo",
    "rank": 8574,
    "frequency": 2754,
    "originalRank": 8749
  },
  {
    "word": "inodoro",
    "rank": 8575,
    "frequency": 2754,
    "originalRank": 8750
  },
  {
    "word": "denle",
    "rank": 8576,
    "frequency": 2753,
    "originalRank": 8751
  },
  {
    "word": "terraza",
    "rank": 8577,
    "frequency": 2753,
    "originalRank": 8752
  },
  {
    "word": "eternamente",
    "rank": 8578,
    "frequency": 2752,
    "originalRank": 8753
  },
  {
    "word": "patricia",
    "rank": 8579,
    "frequency": 2752,
    "originalRank": 8754
  },
  {
    "word": "stacy",
    "rank": 8580,
    "frequency": 2752,
    "originalRank": 8755
  },
  {
    "word": "unica",
    "rank": 8581,
    "frequency": 2751,
    "originalRank": 8756
  },
  {
    "word": "estancia",
    "rank": 8582,
    "frequency": 2751,
    "originalRank": 8757
  },
  {
    "word": "confesó",
    "rank": 8583,
    "frequency": 2750,
    "originalRank": 8758
  },
  {
    "word": "molestias",
    "rank": 8584,
    "frequency": 2750,
    "originalRank": 8759
  },
  {
    "word": "desarrollado",
    "rank": 8585,
    "frequency": 2750,
    "originalRank": 8760
  },
  {
    "word": "suelte",
    "rank": 8586,
    "frequency": 2750,
    "originalRank": 8761
  },
  {
    "word": "enfades",
    "rank": 8587,
    "frequency": 2749,
    "originalRank": 8762
  },
  {
    "word": "american",
    "rank": 8588,
    "frequency": 2749,
    "originalRank": 8763
  },
  {
    "word": "éxtasis",
    "rank": 8589,
    "frequency": 2747,
    "originalRank": 8764
  },
  {
    "word": "joon",
    "rank": 8590,
    "frequency": 2747,
    "originalRank": 8765
  },
  {
    "word": "tranquilamente",
    "rank": 8591,
    "frequency": 2746,
    "originalRank": 8766
  },
  {
    "word": "elsa",
    "rank": 8592,
    "frequency": 2745,
    "originalRank": 8767
  },
  {
    "word": "colchón",
    "rank": 8593,
    "frequency": 2745,
    "originalRank": 8768
  },
  {
    "word": "escoge",
    "rank": 8594,
    "frequency": 2745,
    "originalRank": 8769
  },
  {
    "word": "formulario",
    "rank": 8595,
    "frequency": 2745,
    "originalRank": 8770
  },
  {
    "word": "profeta",
    "rank": 8596,
    "frequency": 2745,
    "originalRank": 8771
  },
  {
    "word": "camille",
    "rank": 8597,
    "frequency": 2744,
    "originalRank": 8772
  },
  {
    "word": "world",
    "rank": 8598,
    "frequency": 2744,
    "originalRank": 8773
  },
  {
    "word": "realizado",
    "rank": 8599,
    "frequency": 2744,
    "originalRank": 8774
  },
  {
    "word": "espuma",
    "rank": 8600,
    "frequency": 2744,
    "originalRank": 8775
  },
  {
    "word": "glen",
    "rank": 8601,
    "frequency": 2743,
    "originalRank": 8776
  },
  {
    "word": "huido",
    "rank": 8602,
    "frequency": 2743,
    "originalRank": 8777
  },
  {
    "word": "ramas",
    "rank": 8603,
    "frequency": 2743,
    "originalRank": 8778
  },
  {
    "word": "fija",
    "rank": 8604,
    "frequency": 2742,
    "originalRank": 8779
  },
  {
    "word": "morimos",
    "rank": 8605,
    "frequency": 2742,
    "originalRank": 8780
  },
  {
    "word": "cuarentena",
    "rank": 8606,
    "frequency": 2742,
    "originalRank": 8781
  },
  {
    "word": "informó",
    "rank": 8607,
    "frequency": 2742,
    "originalRank": 8782
  },
  {
    "word": "conocían",
    "rank": 8608,
    "frequency": 2741,
    "originalRank": 8783
  },
  {
    "word": "mostrarles",
    "rank": 8609,
    "frequency": 2740,
    "originalRank": 8784
  },
  {
    "word": "song",
    "rank": 8610,
    "frequency": 2739,
    "originalRank": 8785
  },
  {
    "word": "pala",
    "rank": 8611,
    "frequency": 2738,
    "originalRank": 8786
  },
  {
    "word": "entregas",
    "rank": 8612,
    "frequency": 2738,
    "originalRank": 8787
  },
  {
    "word": "acusada",
    "rank": 8613,
    "frequency": 2737,
    "originalRank": 8788
  },
  {
    "word": "exagerando",
    "rank": 8614,
    "frequency": 2736,
    "originalRank": 8789
  },
  {
    "word": "recorrer",
    "rank": 8615,
    "frequency": 2736,
    "originalRank": 8790
  },
  {
    "word": "acabando",
    "rank": 8616,
    "frequency": 2736,
    "originalRank": 8791
  },
  {
    "word": "interpretación",
    "rank": 8617,
    "frequency": 2736,
    "originalRank": 8792
  },
  {
    "word": "impaciente",
    "rank": 8618,
    "frequency": 2735,
    "originalRank": 8793
  },
  {
    "word": "carreteras",
    "rank": 8619,
    "frequency": 2735,
    "originalRank": 8794
  },
  {
    "word": "mostrarme",
    "rank": 8620,
    "frequency": 2735,
    "originalRank": 8795
  },
  {
    "word": "precaución",
    "rank": 8621,
    "frequency": 2734,
    "originalRank": 8796
  },
  {
    "word": "pastilla",
    "rank": 8622,
    "frequency": 2734,
    "originalRank": 8797
  },
  {
    "word": "peleamos",
    "rank": 8623,
    "frequency": 2734,
    "originalRank": 8798
  },
  {
    "word": "perdon",
    "rank": 8624,
    "frequency": 2734,
    "originalRank": 8799
  },
  {
    "word": "viajado",
    "rank": 8625,
    "frequency": 2733,
    "originalRank": 8800
  },
  {
    "word": "tardaré",
    "rank": 8626,
    "frequency": 2733,
    "originalRank": 8801
  },
  {
    "word": "metieron",
    "rank": 8627,
    "frequency": 2732,
    "originalRank": 8802
  },
  {
    "word": "administrador",
    "rank": 8628,
    "frequency": 2732,
    "originalRank": 8803
  },
  {
    "word": "eleanor",
    "rank": 8629,
    "frequency": 2732,
    "originalRank": 8804
  },
  {
    "word": "susie",
    "rank": 8630,
    "frequency": 2732,
    "originalRank": 8805
  },
  {
    "word": "bum",
    "rank": 8631,
    "frequency": 2731,
    "originalRank": 8806
  },
  {
    "word": "latín",
    "rank": 8632,
    "frequency": 2731,
    "originalRank": 8807
  },
  {
    "word": "fanny",
    "rank": 8633,
    "frequency": 2730,
    "originalRank": 8808
  },
  {
    "word": "cristales",
    "rank": 8634,
    "frequency": 2729,
    "originalRank": 8809
  },
  {
    "word": "francotirador",
    "rank": 8635,
    "frequency": 2729,
    "originalRank": 8810
  },
  {
    "word": "interferir",
    "rank": 8636,
    "frequency": 2729,
    "originalRank": 8811
  },
  {
    "word": "garantizar",
    "rank": 8637,
    "frequency": 2728,
    "originalRank": 8812
  },
  {
    "word": "callada",
    "rank": 8638,
    "frequency": 2728,
    "originalRank": 8813
  },
  {
    "word": "cuchara",
    "rank": 8639,
    "frequency": 2728,
    "originalRank": 8814
  },
  {
    "word": "casero",
    "rank": 8640,
    "frequency": 2728,
    "originalRank": 8815
  },
  {
    "word": "nasa",
    "rank": 8641,
    "frequency": 2728,
    "originalRank": 8816
  },
  {
    "word": "billar",
    "rank": 8642,
    "frequency": 2728,
    "originalRank": 8817
  },
  {
    "word": "desprecio",
    "rank": 8643,
    "frequency": 2726,
    "originalRank": 8818
  },
  {
    "word": "discursos",
    "rank": 8644,
    "frequency": 2726,
    "originalRank": 8819
  },
  {
    "word": "descansando",
    "rank": 8645,
    "frequency": 2726,
    "originalRank": 8820
  },
  {
    "word": "peinado",
    "rank": 8646,
    "frequency": 2726,
    "originalRank": 8821
  },
  {
    "word": "mola",
    "rank": 8647,
    "frequency": 2726,
    "originalRank": 8822
  },
  {
    "word": "juvenil",
    "rank": 8648,
    "frequency": 2725,
    "originalRank": 8823
  },
  {
    "word": "cogiendo",
    "rank": 8649,
    "frequency": 2725,
    "originalRank": 8824
  },
  {
    "word": "masiva",
    "rank": 8650,
    "frequency": 2725,
    "originalRank": 8825
  },
  {
    "word": "derribar",
    "rank": 8651,
    "frequency": 2725,
    "originalRank": 8826
  },
  {
    "word": "anfitrión",
    "rank": 8652,
    "frequency": 2725,
    "originalRank": 8827
  },
  {
    "word": "tutor",
    "rank": 8653,
    "frequency": 2723,
    "originalRank": 8828
  },
  {
    "word": "agujas",
    "rank": 8654,
    "frequency": 2723,
    "originalRank": 8829
  },
  {
    "word": "iniciales",
    "rank": 8655,
    "frequency": 2723,
    "originalRank": 8830
  },
  {
    "word": "fino",
    "rank": 8656,
    "frequency": 2722,
    "originalRank": 8831
  },
  {
    "word": "kilo",
    "rank": 8657,
    "frequency": 2721,
    "originalRank": 8832
  },
  {
    "word": "venus",
    "rank": 8658,
    "frequency": 2721,
    "originalRank": 8833
  },
  {
    "word": "pollos",
    "rank": 8659,
    "frequency": 2721,
    "originalRank": 8834
  },
  {
    "word": "bolos",
    "rank": 8660,
    "frequency": 2720,
    "originalRank": 8835
  },
  {
    "word": "elijo",
    "rank": 8661,
    "frequency": 2719,
    "originalRank": 8836
  },
  {
    "word": "recordaré",
    "rank": 8662,
    "frequency": 2719,
    "originalRank": 8837
  },
  {
    "word": "ingenioso",
    "rank": 8663,
    "frequency": 2719,
    "originalRank": 8838
  },
  {
    "word": "cuaderno",
    "rank": 8664,
    "frequency": 2718,
    "originalRank": 8839
  },
  {
    "word": "coinciden",
    "rank": 8665,
    "frequency": 2717,
    "originalRank": 8840
  },
  {
    "word": "medicamento",
    "rank": 8666,
    "frequency": 2717,
    "originalRank": 8841
  },
  {
    "word": "burton",
    "rank": 8667,
    "frequency": 2717,
    "originalRank": 8842
  },
  {
    "word": "comprarte",
    "rank": 8668,
    "frequency": 2717,
    "originalRank": 8843
  },
  {
    "word": "herman",
    "rank": 8669,
    "frequency": 2717,
    "originalRank": 8844
  },
  {
    "word": "walsh",
    "rank": 8670,
    "frequency": 2716,
    "originalRank": 8845
  },
  {
    "word": "públicos",
    "rank": 8671,
    "frequency": 2715,
    "originalRank": 8846
  },
  {
    "word": "oveja",
    "rank": 8672,
    "frequency": 2715,
    "originalRank": 8847
  },
  {
    "word": "resultar",
    "rank": 8673,
    "frequency": 2715,
    "originalRank": 8848
  },
  {
    "word": "mande",
    "rank": 8674,
    "frequency": 2714,
    "originalRank": 8849
  },
  {
    "word": "máscaras",
    "rank": 8675,
    "frequency": 2714,
    "originalRank": 8850
  },
  {
    "word": "impresionar",
    "rank": 8676,
    "frequency": 2714,
    "originalRank": 8851
  },
  {
    "word": "gases",
    "rank": 8677,
    "frequency": 2714,
    "originalRank": 8852
  },
  {
    "word": "acabé",
    "rank": 8678,
    "frequency": 2714,
    "originalRank": 8853
  },
  {
    "word": "kung",
    "rank": 8679,
    "frequency": 2713,
    "originalRank": 8854
  },
  {
    "word": "trabajadora",
    "rank": 8680,
    "frequency": 2713,
    "originalRank": 8855
  },
  {
    "word": "asado",
    "rank": 8681,
    "frequency": 2712,
    "originalRank": 8856
  },
  {
    "word": "tímida",
    "rank": 8682,
    "frequency": 2712,
    "originalRank": 8857
  },
  {
    "word": "inmediata",
    "rank": 8683,
    "frequency": 2711,
    "originalRank": 8858
  },
  {
    "word": "data",
    "rank": 8684,
    "frequency": 2711,
    "originalRank": 8859
  },
  {
    "word": "sátur",
    "rank": 8685,
    "frequency": 2710,
    "originalRank": 8861
  },
  {
    "word": "resaca",
    "rank": 8686,
    "frequency": 2709,
    "originalRank": 8862
  },
  {
    "word": "ángela",
    "rank": 8687,
    "frequency": 2709,
    "originalRank": 8863
  },
  {
    "word": "conocerlos",
    "rank": 8688,
    "frequency": 2708,
    "originalRank": 8864
  },
  {
    "word": "cadera",
    "rank": 8689,
    "frequency": 2707,
    "originalRank": 8865
  },
  {
    "word": "mérito",
    "rank": 8690,
    "frequency": 2707,
    "originalRank": 8866
  },
  {
    "word": "got",
    "rank": 8691,
    "frequency": 2707,
    "originalRank": 8867
  },
  {
    "word": "compañia",
    "rank": 8692,
    "frequency": 2707,
    "originalRank": 8868
  },
  {
    "word": "ventajas",
    "rank": 8693,
    "frequency": 2707,
    "originalRank": 8869
  },
  {
    "word": "santidad",
    "rank": 8694,
    "frequency": 2707,
    "originalRank": 8870
  },
  {
    "word": "cancelado",
    "rank": 8695,
    "frequency": 2706,
    "originalRank": 8871
  },
  {
    "word": "ninja",
    "rank": 8696,
    "frequency": 2706,
    "originalRank": 8872
  },
  {
    "word": "lin",
    "rank": 8697,
    "frequency": 2706,
    "originalRank": 8873
  },
  {
    "word": "seguid",
    "rank": 8698,
    "frequency": 2706,
    "originalRank": 8874
  },
  {
    "word": "deprimente",
    "rank": 8699,
    "frequency": 2705,
    "originalRank": 8875
  },
  {
    "word": "monty",
    "rank": 8700,
    "frequency": 2705,
    "originalRank": 8876
  },
  {
    "word": "blues",
    "rank": 8701,
    "frequency": 2704,
    "originalRank": 8877
  },
  {
    "word": "contamos",
    "rank": 8702,
    "frequency": 2704,
    "originalRank": 8878
  },
  {
    "word": "defensor",
    "rank": 8703,
    "frequency": 2704,
    "originalRank": 8879
  },
  {
    "word": "sentó",
    "rank": 8704,
    "frequency": 2703,
    "originalRank": 8880
  },
  {
    "word": "villano",
    "rank": 8705,
    "frequency": 2702,
    "originalRank": 8881
  },
  {
    "word": "soviética",
    "rank": 8706,
    "frequency": 2702,
    "originalRank": 8882
  },
  {
    "word": "grand",
    "rank": 8707,
    "frequency": 2702,
    "originalRank": 8883
  },
  {
    "word": "fort",
    "rank": 8708,
    "frequency": 2702,
    "originalRank": 8884
  },
  {
    "word": "perdonarme",
    "rank": 8709,
    "frequency": 2702,
    "originalRank": 8885
  },
  {
    "word": "universitario",
    "rank": 8710,
    "frequency": 2701,
    "originalRank": 8886
  },
  {
    "word": "capitan",
    "rank": 8711,
    "frequency": 2701,
    "originalRank": 8887
  },
  {
    "word": "optimista",
    "rank": 8712,
    "frequency": 2701,
    "originalRank": 8888
  },
  {
    "word": "protesto",
    "rank": 8713,
    "frequency": 2701,
    "originalRank": 8889
  },
  {
    "word": "mejorado",
    "rank": 8714,
    "frequency": 2700,
    "originalRank": 8890
  },
  {
    "word": "keller",
    "rank": 8715,
    "frequency": 2700,
    "originalRank": 8891
  },
  {
    "word": "palma",
    "rank": 8716,
    "frequency": 2699,
    "originalRank": 8892
  },
  {
    "word": "experimentado",
    "rank": 8717,
    "frequency": 2698,
    "originalRank": 8893
  },
  {
    "word": "asegúrese",
    "rank": 8718,
    "frequency": 2698,
    "originalRank": 8894
  },
  {
    "word": "reemplazar",
    "rank": 8719,
    "frequency": 2698,
    "originalRank": 8895
  },
  {
    "word": "luchado",
    "rank": 8720,
    "frequency": 2698,
    "originalRank": 8896
  },
  {
    "word": "pegarle",
    "rank": 8721,
    "frequency": 2697,
    "originalRank": 8897
  },
  {
    "word": "basa",
    "rank": 8722,
    "frequency": 2696,
    "originalRank": 8898
  },
  {
    "word": "anteojos",
    "rank": 8723,
    "frequency": 2695,
    "originalRank": 8899
  },
  {
    "word": "yate",
    "rank": 8724,
    "frequency": 2695,
    "originalRank": 8900
  },
  {
    "word": "estropeado",
    "rank": 8725,
    "frequency": 2695,
    "originalRank": 8901
  },
  {
    "word": "cobre",
    "rank": 8726,
    "frequency": 2694,
    "originalRank": 8903
  },
  {
    "word": "superarlo",
    "rank": 8727,
    "frequency": 2694,
    "originalRank": 8904
  },
  {
    "word": "mejilla",
    "rank": 8728,
    "frequency": 2694,
    "originalRank": 8905
  },
  {
    "word": "proceder",
    "rank": 8729,
    "frequency": 2693,
    "originalRank": 8906
  },
  {
    "word": "phoenix",
    "rank": 8730,
    "frequency": 2693,
    "originalRank": 8907
  },
  {
    "word": "cortando",
    "rank": 8731,
    "frequency": 2693,
    "originalRank": 8908
  },
  {
    "word": "unirme",
    "rank": 8732,
    "frequency": 2692,
    "originalRank": 8909
  },
  {
    "word": "martín",
    "rank": 8733,
    "frequency": 2692,
    "originalRank": 8910
  },
  {
    "word": "significaría",
    "rank": 8734,
    "frequency": 2691,
    "originalRank": 8911
  },
  {
    "word": "they",
    "rank": 8735,
    "frequency": 2691,
    "originalRank": 8912
  },
  {
    "word": "creerás",
    "rank": 8736,
    "frequency": 2691,
    "originalRank": 8913
  },
  {
    "word": "pica",
    "rank": 8737,
    "frequency": 2691,
    "originalRank": 8914
  },
  {
    "word": "párate",
    "rank": 8738,
    "frequency": 2690,
    "originalRank": 8915
  },
  {
    "word": "palanca",
    "rank": 8739,
    "frequency": 2690,
    "originalRank": 8916
  },
  {
    "word": "merecido",
    "rank": 8740,
    "frequency": 2690,
    "originalRank": 8917
  },
  {
    "word": "firmas",
    "rank": 8741,
    "frequency": 2690,
    "originalRank": 8918
  },
  {
    "word": "acosté",
    "rank": 8742,
    "frequency": 2689,
    "originalRank": 8919
  },
  {
    "word": "cooperar",
    "rank": 8743,
    "frequency": 2689,
    "originalRank": 8920
  },
  {
    "word": "conteste",
    "rank": 8744,
    "frequency": 2688,
    "originalRank": 8921
  },
  {
    "word": "tramando",
    "rank": 8745,
    "frequency": 2688,
    "originalRank": 8922
  },
  {
    "word": "llegarás",
    "rank": 8746,
    "frequency": 2687,
    "originalRank": 8923
  },
  {
    "word": "esclava",
    "rank": 8747,
    "frequency": 2687,
    "originalRank": 8924
  },
  {
    "word": "enterar",
    "rank": 8748,
    "frequency": 2687,
    "originalRank": 8925
  },
  {
    "word": "jerusalén",
    "rank": 8749,
    "frequency": 2686,
    "originalRank": 8926
  },
  {
    "word": "ando",
    "rank": 8750,
    "frequency": 2685,
    "originalRank": 8927
  },
  {
    "word": "look",
    "rank": 8751,
    "frequency": 2685,
    "originalRank": 8928
  },
  {
    "word": "hazle",
    "rank": 8752,
    "frequency": 2684,
    "originalRank": 8929
  },
  {
    "word": "referencias",
    "rank": 8753,
    "frequency": 2684,
    "originalRank": 8930
  },
  {
    "word": "técnicos",
    "rank": 8754,
    "frequency": 2683,
    "originalRank": 8931
  },
  {
    "word": "atrevido",
    "rank": 8755,
    "frequency": 2683,
    "originalRank": 8932
  },
  {
    "word": "investigadores",
    "rank": 8756,
    "frequency": 2683,
    "originalRank": 8933
  },
  {
    "word": "práctico",
    "rank": 8757,
    "frequency": 2682,
    "originalRank": 8934
  },
  {
    "word": "reciba",
    "rank": 8758,
    "frequency": 2681,
    "originalRank": 8935
  },
  {
    "word": "forzado",
    "rank": 8759,
    "frequency": 2681,
    "originalRank": 8936
  },
  {
    "word": "consideración",
    "rank": 8760,
    "frequency": 2680,
    "originalRank": 8937
  },
  {
    "word": "ganarse",
    "rank": 8761,
    "frequency": 2680,
    "originalRank": 8938
  },
  {
    "word": "cebolla",
    "rank": 8762,
    "frequency": 2680,
    "originalRank": 8939
  },
  {
    "word": "vivían",
    "rank": 8763,
    "frequency": 2679,
    "originalRank": 8940
  },
  {
    "word": "apropiada",
    "rank": 8764,
    "frequency": 2678,
    "originalRank": 8941
  },
  {
    "word": "levantarte",
    "rank": 8765,
    "frequency": 2677,
    "originalRank": 8942
  },
  {
    "word": "experta",
    "rank": 8766,
    "frequency": 2677,
    "originalRank": 8943
  },
  {
    "word": "cogerlo",
    "rank": 8767,
    "frequency": 2677,
    "originalRank": 8944
  },
  {
    "word": "condenados",
    "rank": 8768,
    "frequency": 2676,
    "originalRank": 8945
  },
  {
    "word": "duermas",
    "rank": 8769,
    "frequency": 2676,
    "originalRank": 8946
  },
  {
    "word": "efectivamente",
    "rank": 8770,
    "frequency": 2676,
    "originalRank": 8947
  },
  {
    "word": "limusina",
    "rank": 8771,
    "frequency": 2674,
    "originalRank": 8948
  },
  {
    "word": "ancestros",
    "rank": 8772,
    "frequency": 2674,
    "originalRank": 8949
  },
  {
    "word": "superficial",
    "rank": 8773,
    "frequency": 2674,
    "originalRank": 8950
  },
  {
    "word": "rebelión",
    "rank": 8774,
    "frequency": 2673,
    "originalRank": 8951
  },
  {
    "word": "motocicleta",
    "rank": 8775,
    "frequency": 2673,
    "originalRank": 8952
  },
  {
    "word": "tardado",
    "rank": 8776,
    "frequency": 2673,
    "originalRank": 8953
  },
  {
    "word": "sede",
    "rank": 8777,
    "frequency": 2671,
    "originalRank": 8954
  },
  {
    "word": "abrimos",
    "rank": 8778,
    "frequency": 2671,
    "originalRank": 8955
  },
  {
    "word": "ava",
    "rank": 8779,
    "frequency": 2670,
    "originalRank": 8956
  },
  {
    "word": "póquer",
    "rank": 8780,
    "frequency": 2670,
    "originalRank": 8957
  },
  {
    "word": "mide",
    "rank": 8781,
    "frequency": 2670,
    "originalRank": 8958
  },
  {
    "word": "escuchame",
    "rank": 8782,
    "frequency": 2669,
    "originalRank": 8959
  },
  {
    "word": "pagos",
    "rank": 8783,
    "frequency": 2669,
    "originalRank": 8960
  },
  {
    "word": "exclusiva",
    "rank": 8784,
    "frequency": 2669,
    "originalRank": 8961
  },
  {
    "word": "cría",
    "rank": 8785,
    "frequency": 2668,
    "originalRank": 8962
  },
  {
    "word": "mudar",
    "rank": 8786,
    "frequency": 2667,
    "originalRank": 8964
  },
  {
    "word": "culos",
    "rank": 8787,
    "frequency": 2667,
    "originalRank": 8965
  },
  {
    "word": "lesbianas",
    "rank": 8788,
    "frequency": 2667,
    "originalRank": 8966
  },
  {
    "word": "mirarlo",
    "rank": 8789,
    "frequency": 2667,
    "originalRank": 8967
  },
  {
    "word": "pusiera",
    "rank": 8790,
    "frequency": 2665,
    "originalRank": 8968
  },
  {
    "word": "està",
    "rank": 8791,
    "frequency": 2664,
    "originalRank": 8969
  },
  {
    "word": "torno",
    "rank": 8792,
    "frequency": 2664,
    "originalRank": 8970
  },
  {
    "word": "denver",
    "rank": 8793,
    "frequency": 2664,
    "originalRank": 8971
  },
  {
    "word": "sacaremos",
    "rank": 8794,
    "frequency": 2663,
    "originalRank": 8972
  },
  {
    "word": "golpeé",
    "rank": 8795,
    "frequency": 2663,
    "originalRank": 8973
  },
  {
    "word": "tentación",
    "rank": 8796,
    "frequency": 2662,
    "originalRank": 8974
  },
  {
    "word": "coman",
    "rank": 8797,
    "frequency": 2661,
    "originalRank": 8975
  },
  {
    "word": "deberás",
    "rank": 8798,
    "frequency": 2661,
    "originalRank": 8976
  },
  {
    "word": "callie",
    "rank": 8799,
    "frequency": 2661,
    "originalRank": 8977
  },
  {
    "word": "judith",
    "rank": 8800,
    "frequency": 2660,
    "originalRank": 8978
  },
  {
    "word": "sermón",
    "rank": 8801,
    "frequency": 2660,
    "originalRank": 8979
  },
  {
    "word": "dramático",
    "rank": 8802,
    "frequency": 2660,
    "originalRank": 8980
  },
  {
    "word": "sutil",
    "rank": 8803,
    "frequency": 2660,
    "originalRank": 8981
  },
  {
    "word": "localizado",
    "rank": 8804,
    "frequency": 2659,
    "originalRank": 8982
  },
  {
    "word": "fanático",
    "rank": 8805,
    "frequency": 2659,
    "originalRank": 8983
  },
  {
    "word": "cuerno",
    "rank": 8806,
    "frequency": 2659,
    "originalRank": 8984
  },
  {
    "word": "franz",
    "rank": 8807,
    "frequency": 2659,
    "originalRank": 8985
  },
  {
    "word": "sillón",
    "rank": 8808,
    "frequency": 2658,
    "originalRank": 8986
  },
  {
    "word": "eduardo",
    "rank": 8809,
    "frequency": 2658,
    "originalRank": 8987
  },
  {
    "word": "libra",
    "rank": 8810,
    "frequency": 2657,
    "originalRank": 8988
  },
  {
    "word": "suecia",
    "rank": 8811,
    "frequency": 2657,
    "originalRank": 8989
  },
  {
    "word": "confiable",
    "rank": 8812,
    "frequency": 2656,
    "originalRank": 8990
  },
  {
    "word": "detén",
    "rank": 8813,
    "frequency": 2656,
    "originalRank": 8991
  },
  {
    "word": "autobuses",
    "rank": 8814,
    "frequency": 2656,
    "originalRank": 8992
  },
  {
    "word": "copiado",
    "rank": 8815,
    "frequency": 2656,
    "originalRank": 8993
  },
  {
    "word": "buscó",
    "rank": 8816,
    "frequency": 2655,
    "originalRank": 8994
  },
  {
    "word": "cantidades",
    "rank": 8817,
    "frequency": 2654,
    "originalRank": 8995
  },
  {
    "word": "estrictamente",
    "rank": 8818,
    "frequency": 2654,
    "originalRank": 8996
  },
  {
    "word": "digitales",
    "rank": 8819,
    "frequency": 2654,
    "originalRank": 8997
  },
  {
    "word": "surf",
    "rank": 8820,
    "frequency": 2654,
    "originalRank": 8998
  },
  {
    "word": "nadia",
    "rank": 8821,
    "frequency": 2654,
    "originalRank": 8999
  },
  {
    "word": "trigo",
    "rank": 8822,
    "frequency": 2652,
    "originalRank": 9000
  },
  {
    "word": "comunicarse",
    "rank": 8823,
    "frequency": 2652,
    "originalRank": 9001
  },
  {
    "word": "precisa",
    "rank": 8824,
    "frequency": 2652,
    "originalRank": 9002
  },
  {
    "word": "acercan",
    "rank": 8825,
    "frequency": 2651,
    "originalRank": 9003
  },
  {
    "word": "recomendación",
    "rank": 8826,
    "frequency": 2651,
    "originalRank": 9004
  },
  {
    "word": "activos",
    "rank": 8827,
    "frequency": 2651,
    "originalRank": 9005
  },
  {
    "word": "siguieron",
    "rank": 8828,
    "frequency": 2650,
    "originalRank": 9006
  },
  {
    "word": "chao",
    "rank": 8829,
    "frequency": 2650,
    "originalRank": 9007
  },
  {
    "word": "timmy",
    "rank": 8830,
    "frequency": 2650,
    "originalRank": 9008
  },
  {
    "word": "tanya",
    "rank": 8831,
    "frequency": 2649,
    "originalRank": 9009
  },
  {
    "word": "detenerte",
    "rank": 8832,
    "frequency": 2648,
    "originalRank": 9010
  },
  {
    "word": "milán",
    "rank": 8833,
    "frequency": 2648,
    "originalRank": 9011
  },
  {
    "word": "trajimos",
    "rank": 8834,
    "frequency": 2648,
    "originalRank": 9012
  },
  {
    "word": "pretendes",
    "rank": 8835,
    "frequency": 2647,
    "originalRank": 9013
  },
  {
    "word": "abres",
    "rank": 8836,
    "frequency": 2646,
    "originalRank": 9015
  },
  {
    "word": "escáner",
    "rank": 8837,
    "frequency": 2646,
    "originalRank": 9016
  },
  {
    "word": "daban",
    "rank": 8838,
    "frequency": 2645,
    "originalRank": 9017
  },
  {
    "word": "joo",
    "rank": 8839,
    "frequency": 2645,
    "originalRank": 9018
  },
  {
    "word": "enseñaron",
    "rank": 8840,
    "frequency": 2644,
    "originalRank": 9019
  },
  {
    "word": "recogiendo",
    "rank": 8841,
    "frequency": 2644,
    "originalRank": 9020
  },
  {
    "word": "nudo",
    "rank": 8842,
    "frequency": 2644,
    "originalRank": 9021
  },
  {
    "word": "ingredientes",
    "rank": 8843,
    "frequency": 2643,
    "originalRank": 9022
  },
  {
    "word": "baltimore",
    "rank": 8844,
    "frequency": 2643,
    "originalRank": 9023
  },
  {
    "word": "mentales",
    "rank": 8845,
    "frequency": 2643,
    "originalRank": 9024
  },
  {
    "word": "disculpan",
    "rank": 8846,
    "frequency": 2643,
    "originalRank": 9025
  },
  {
    "word": "veros",
    "rank": 8847,
    "frequency": 2642,
    "originalRank": 9026
  },
  {
    "word": "asusté",
    "rank": 8848,
    "frequency": 2642,
    "originalRank": 9027
  },
  {
    "word": "félix",
    "rank": 8849,
    "frequency": 2642,
    "originalRank": 9028
  },
  {
    "word": "olvidemos",
    "rank": 8850,
    "frequency": 2641,
    "originalRank": 9029
  },
  {
    "word": "concejal",
    "rank": 8851,
    "frequency": 2641,
    "originalRank": 9030
  },
  {
    "word": "dental",
    "rank": 8852,
    "frequency": 2641,
    "originalRank": 9031
  },
  {
    "word": "potter",
    "rank": 8853,
    "frequency": 2640,
    "originalRank": 9032
  },
  {
    "word": "suspendido",
    "rank": 8854,
    "frequency": 2640,
    "originalRank": 9033
  },
  {
    "word": "suéter",
    "rank": 8855,
    "frequency": 2640,
    "originalRank": 9034
  },
  {
    "word": "entrenando",
    "rank": 8856,
    "frequency": 2640,
    "originalRank": 9035
  },
  {
    "word": "mudarme",
    "rank": 8857,
    "frequency": 2638,
    "originalRank": 9036
  },
  {
    "word": "comprarle",
    "rank": 8858,
    "frequency": 2638,
    "originalRank": 9037
  },
  {
    "word": "dinosaurios",
    "rank": 8859,
    "frequency": 2637,
    "originalRank": 9038
  },
  {
    "word": "dirigía",
    "rank": 8860,
    "frequency": 2636,
    "originalRank": 9039
  },
  {
    "word": "perpetua",
    "rank": 8861,
    "frequency": 2636,
    "originalRank": 9040
  },
  {
    "word": "ofrecí",
    "rank": 8862,
    "frequency": 2636,
    "originalRank": 9041
  },
  {
    "word": "punk",
    "rank": 8863,
    "frequency": 2634,
    "originalRank": 9042
  },
  {
    "word": "molestó",
    "rank": 8864,
    "frequency": 2634,
    "originalRank": 9043
  },
  {
    "word": "cuadras",
    "rank": 8865,
    "frequency": 2633,
    "originalRank": 9044
  },
  {
    "word": "traía",
    "rank": 8866,
    "frequency": 2631,
    "originalRank": 9045
  },
  {
    "word": "ríos",
    "rank": 8867,
    "frequency": 2631,
    "originalRank": 9046
  },
  {
    "word": "alaska",
    "rank": 8868,
    "frequency": 2629,
    "originalRank": 9047
  },
  {
    "word": "mexicano",
    "rank": 8869,
    "frequency": 2629,
    "originalRank": 9048
  },
  {
    "word": "arroyo",
    "rank": 8870,
    "frequency": 2628,
    "originalRank": 9049
  },
  {
    "word": "seríamos",
    "rank": 8871,
    "frequency": 2628,
    "originalRank": 9050
  },
  {
    "word": "novedades",
    "rank": 8872,
    "frequency": 2627,
    "originalRank": 9051
  },
  {
    "word": "abuelita",
    "rank": 8873,
    "frequency": 2627,
    "originalRank": 9052
  },
  {
    "word": "evacuación",
    "rank": 8874,
    "frequency": 2627,
    "originalRank": 9053
  },
  {
    "word": "suero",
    "rank": 8875,
    "frequency": 2627,
    "originalRank": 9054
  },
  {
    "word": "matthews",
    "rank": 8876,
    "frequency": 2627,
    "originalRank": 9055
  },
  {
    "word": "abren",
    "rank": 8877,
    "frequency": 2627,
    "originalRank": 9056
  },
  {
    "word": "ciegos",
    "rank": 8878,
    "frequency": 2626,
    "originalRank": 9057
  },
  {
    "word": "sopla",
    "rank": 8879,
    "frequency": 2626,
    "originalRank": 9058
  },
  {
    "word": "amorosa",
    "rank": 8880,
    "frequency": 2626,
    "originalRank": 9059
  },
  {
    "word": "quemando",
    "rank": 8881,
    "frequency": 2626,
    "originalRank": 9060
  },
  {
    "word": "confiaba",
    "rank": 8882,
    "frequency": 2625,
    "originalRank": 9061
  },
  {
    "word": "tenso",
    "rank": 8883,
    "frequency": 2625,
    "originalRank": 9062
  },
  {
    "word": "ofendido",
    "rank": 8884,
    "frequency": 2625,
    "originalRank": 9063
  },
  {
    "word": "ballenas",
    "rank": 8885,
    "frequency": 2624,
    "originalRank": 9064
  },
  {
    "word": "posada",
    "rank": 8886,
    "frequency": 2624,
    "originalRank": 9065
  },
  {
    "word": "libera",
    "rank": 8887,
    "frequency": 2623,
    "originalRank": 9066
  },
  {
    "word": "fernando",
    "rank": 8888,
    "frequency": 2622,
    "originalRank": 9067
  },
  {
    "word": "pieles",
    "rank": 8889,
    "frequency": 2621,
    "originalRank": 9068
  },
  {
    "word": "tremenda",
    "rank": 8890,
    "frequency": 2621,
    "originalRank": 9069
  },
  {
    "word": "píldora",
    "rank": 8891,
    "frequency": 2620,
    "originalRank": 9070
  },
  {
    "word": "country",
    "rank": 8892,
    "frequency": 2620,
    "originalRank": 9071
  },
  {
    "word": "unió",
    "rank": 8893,
    "frequency": 2620,
    "originalRank": 9072
  },
  {
    "word": "creativo",
    "rank": 8894,
    "frequency": 2620,
    "originalRank": 9073
  },
  {
    "word": "sacrificar",
    "rank": 8895,
    "frequency": 2619,
    "originalRank": 9074
  },
  {
    "word": "escocés",
    "rank": 8896,
    "frequency": 2619,
    "originalRank": 9075
  },
  {
    "word": "casamiento",
    "rank": 8897,
    "frequency": 2618,
    "originalRank": 9076
  },
  {
    "word": "bandido",
    "rank": 8898,
    "frequency": 2618,
    "originalRank": 9077
  },
  {
    "word": "crucial",
    "rank": 8899,
    "frequency": 2618,
    "originalRank": 9078
  },
  {
    "word": "filme",
    "rank": 8900,
    "frequency": 2616,
    "originalRank": 9080
  },
  {
    "word": "meten",
    "rank": 8901,
    "frequency": 2616,
    "originalRank": 9081
  },
  {
    "word": "pónganse",
    "rank": 8902,
    "frequency": 2615,
    "originalRank": 9082
  },
  {
    "word": "parados",
    "rank": 8903,
    "frequency": 2614,
    "originalRank": 9083
  },
  {
    "word": "summer",
    "rank": 8904,
    "frequency": 2614,
    "originalRank": 9084
  },
  {
    "word": "dominar",
    "rank": 8905,
    "frequency": 2613,
    "originalRank": 9085
  },
  {
    "word": "infinito",
    "rank": 8906,
    "frequency": 2613,
    "originalRank": 9086
  },
  {
    "word": "culpabilidad",
    "rank": 8907,
    "frequency": 2613,
    "originalRank": 9087
  },
  {
    "word": "escondió",
    "rank": 8908,
    "frequency": 2613,
    "originalRank": 9088
  },
  {
    "word": "carteles",
    "rank": 8909,
    "frequency": 2613,
    "originalRank": 9089
  },
  {
    "word": "marqués",
    "rank": 8910,
    "frequency": 2612,
    "originalRank": 9090
  },
  {
    "word": "escritores",
    "rank": 8911,
    "frequency": 2612,
    "originalRank": 9091
  },
  {
    "word": "gregory",
    "rank": 8912,
    "frequency": 2612,
    "originalRank": 9092
  },
  {
    "word": "astronauta",
    "rank": 8913,
    "frequency": 2611,
    "originalRank": 9093
  },
  {
    "word": "pimienta",
    "rank": 8914,
    "frequency": 2611,
    "originalRank": 9094
  },
  {
    "word": "mandíbula",
    "rank": 8915,
    "frequency": 2611,
    "originalRank": 9095
  },
  {
    "word": "langosta",
    "rank": 8916,
    "frequency": 2611,
    "originalRank": 9096
  },
  {
    "word": "lastima",
    "rank": 8917,
    "frequency": 2610,
    "originalRank": 9097
  },
  {
    "word": "asustes",
    "rank": 8918,
    "frequency": 2610,
    "originalRank": 9098
  },
  {
    "word": "kat",
    "rank": 8919,
    "frequency": 2610,
    "originalRank": 9099
  },
  {
    "word": "notable",
    "rank": 8920,
    "frequency": 2609,
    "originalRank": 9100
  },
  {
    "word": "cultural",
    "rank": 8921,
    "frequency": 2609,
    "originalRank": 9101
  },
  {
    "word": "previamente",
    "rank": 8922,
    "frequency": 2609,
    "originalRank": 9102
  },
  {
    "word": "fideos",
    "rank": 8923,
    "frequency": 2608,
    "originalRank": 9103
  },
  {
    "word": "preparo",
    "rank": 8924,
    "frequency": 2608,
    "originalRank": 9104
  },
  {
    "word": "shelly",
    "rank": 8925,
    "frequency": 2608,
    "originalRank": 9105
  },
  {
    "word": "rupert",
    "rank": 8926,
    "frequency": 2608,
    "originalRank": 9106
  },
  {
    "word": "desaparezca",
    "rank": 8927,
    "frequency": 2607,
    "originalRank": 9107
  },
  {
    "word": "mantenernos",
    "rank": 8928,
    "frequency": 2607,
    "originalRank": 9108
  },
  {
    "word": "sacan",
    "rank": 8929,
    "frequency": 2606,
    "originalRank": 9109
  },
  {
    "word": "relevante",
    "rank": 8930,
    "frequency": 2605,
    "originalRank": 9110
  },
  {
    "word": "musica",
    "rank": 8931,
    "frequency": 2605,
    "originalRank": 9111
  },
  {
    "word": "respetos",
    "rank": 8932,
    "frequency": 2605,
    "originalRank": 9112
  },
  {
    "word": "químico",
    "rank": 8933,
    "frequency": 2605,
    "originalRank": 9113
  },
  {
    "word": "duermen",
    "rank": 8934,
    "frequency": 2604,
    "originalRank": 9114
  },
  {
    "word": "oponente",
    "rank": 8935,
    "frequency": 2604,
    "originalRank": 9115
  },
  {
    "word": "hallado",
    "rank": 8936,
    "frequency": 2603,
    "originalRank": 9116
  },
  {
    "word": "hércules",
    "rank": 8937,
    "frequency": 2603,
    "originalRank": 9117
  },
  {
    "word": "sujeta",
    "rank": 8938,
    "frequency": 2602,
    "originalRank": 9118
  },
  {
    "word": "supongamos",
    "rank": 8939,
    "frequency": 2602,
    "originalRank": 9119
  },
  {
    "word": "decano",
    "rank": 8940,
    "frequency": 2601,
    "originalRank": 9120
  },
  {
    "word": "atrapa",
    "rank": 8941,
    "frequency": 2601,
    "originalRank": 9121
  },
  {
    "word": "louie",
    "rank": 8942,
    "frequency": 2600,
    "originalRank": 9123
  },
  {
    "word": "relajarse",
    "rank": 8943,
    "frequency": 2600,
    "originalRank": 9124
  },
  {
    "word": "asustados",
    "rank": 8944,
    "frequency": 2600,
    "originalRank": 9125
  },
  {
    "word": "hipócrita",
    "rank": 8945,
    "frequency": 2600,
    "originalRank": 9126
  },
  {
    "word": "déjenlo",
    "rank": 8946,
    "frequency": 2600,
    "originalRank": 9127
  },
  {
    "word": "unida",
    "rank": 8947,
    "frequency": 2600,
    "originalRank": 9128
  },
  {
    "word": "bailarín",
    "rank": 8948,
    "frequency": 2599,
    "originalRank": 9129
  },
  {
    "word": "apretar",
    "rank": 8949,
    "frequency": 2599,
    "originalRank": 9130
  },
  {
    "word": "evita",
    "rank": 8950,
    "frequency": 2598,
    "originalRank": 9131
  },
  {
    "word": "camisetas",
    "rank": 8951,
    "frequency": 2598,
    "originalRank": 9132
  },
  {
    "word": "ancho",
    "rank": 8952,
    "frequency": 2598,
    "originalRank": 9133
  },
  {
    "word": "temen",
    "rank": 8953,
    "frequency": 2598,
    "originalRank": 9134
  },
  {
    "word": "quitas",
    "rank": 8954,
    "frequency": 2598,
    "originalRank": 9135
  },
  {
    "word": "arruinando",
    "rank": 8955,
    "frequency": 2597,
    "originalRank": 9136
  },
  {
    "word": "natal",
    "rank": 8956,
    "frequency": 2597,
    "originalRank": 9137
  },
  {
    "word": "ajo",
    "rank": 8957,
    "frequency": 2597,
    "originalRank": 9138
  },
  {
    "word": "adoran",
    "rank": 8958,
    "frequency": 2597,
    "originalRank": 9139
  },
  {
    "word": "evitando",
    "rank": 8959,
    "frequency": 2596,
    "originalRank": 9140
  },
  {
    "word": "angustia",
    "rank": 8960,
    "frequency": 2596,
    "originalRank": 9141
  },
  {
    "word": "consiste",
    "rank": 8961,
    "frequency": 2596,
    "originalRank": 9142
  },
  {
    "word": "andré",
    "rank": 8962,
    "frequency": 2594,
    "originalRank": 9143
  },
  {
    "word": "fran",
    "rank": 8963,
    "frequency": 2594,
    "originalRank": 9144
  },
  {
    "word": "amé",
    "rank": 8964,
    "frequency": 2594,
    "originalRank": 9145
  },
  {
    "word": "shin",
    "rank": 8965,
    "frequency": 2592,
    "originalRank": 9146
  },
  {
    "word": "definitiva",
    "rank": 8966,
    "frequency": 2592,
    "originalRank": 9147
  },
  {
    "word": "nerviosos",
    "rank": 8967,
    "frequency": 2592,
    "originalRank": 9148
  },
  {
    "word": "amenazado",
    "rank": 8968,
    "frequency": 2592,
    "originalRank": 9149
  },
  {
    "word": "wesley",
    "rank": 8969,
    "frequency": 2591,
    "originalRank": 9150
  },
  {
    "word": "creamos",
    "rank": 8970,
    "frequency": 2591,
    "originalRank": 9151
  },
  {
    "word": "desaparecidos",
    "rank": 8971,
    "frequency": 2590,
    "originalRank": 9152
  },
  {
    "word": "informa",
    "rank": 8972,
    "frequency": 2589,
    "originalRank": 9153
  },
  {
    "word": "relleno",
    "rank": 8973,
    "frequency": 2589,
    "originalRank": 9154
  },
  {
    "word": "pedo",
    "rank": 8974,
    "frequency": 2588,
    "originalRank": 9155
  },
  {
    "word": "documentación",
    "rank": 8975,
    "frequency": 2588,
    "originalRank": 9156
  },
  {
    "word": "zombi",
    "rank": 8976,
    "frequency": 2587,
    "originalRank": 9157
  },
  {
    "word": "decido",
    "rank": 8977,
    "frequency": 2587,
    "originalRank": 9158
  },
  {
    "word": "quiebra",
    "rank": 8978,
    "frequency": 2587,
    "originalRank": 9159
  },
  {
    "word": "good",
    "rank": 8979,
    "frequency": 2587,
    "originalRank": 9160
  },
  {
    "word": "pagarme",
    "rank": 8980,
    "frequency": 2586,
    "originalRank": 9161
  },
  {
    "word": "marcel",
    "rank": 8981,
    "frequency": 2586,
    "originalRank": 9162
  },
  {
    "word": "peg",
    "rank": 8982,
    "frequency": 2586,
    "originalRank": 9163
  },
  {
    "word": "obreros",
    "rank": 8983,
    "frequency": 2585,
    "originalRank": 9164
  },
  {
    "word": "olvidaba",
    "rank": 8984,
    "frequency": 2585,
    "originalRank": 9165
  },
  {
    "word": "avisaré",
    "rank": 8985,
    "frequency": 2584,
    "originalRank": 9166
  },
  {
    "word": "fundamental",
    "rank": 8986,
    "frequency": 2584,
    "originalRank": 9167
  },
  {
    "word": "preparé",
    "rank": 8987,
    "frequency": 2584,
    "originalRank": 9168
  },
  {
    "word": "amen",
    "rank": 8988,
    "frequency": 2583,
    "originalRank": 9169
  },
  {
    "word": "robados",
    "rank": 8989,
    "frequency": 2582,
    "originalRank": 9170
  },
  {
    "word": "hood",
    "rank": 8990,
    "frequency": 2582,
    "originalRank": 9171
  },
  {
    "word": "ponla",
    "rank": 8991,
    "frequency": 2582,
    "originalRank": 9172
  },
  {
    "word": "universal",
    "rank": 8992,
    "frequency": 2582,
    "originalRank": 9173
  },
  {
    "word": "terrestre",
    "rank": 8993,
    "frequency": 2582,
    "originalRank": 9174
  },
  {
    "word": "price",
    "rank": 8994,
    "frequency": 2582,
    "originalRank": 9175
  },
  {
    "word": "reconoció",
    "rank": 8995,
    "frequency": 2581,
    "originalRank": 9176
  },
  {
    "word": "hipoteca",
    "rank": 8996,
    "frequency": 2581,
    "originalRank": 9177
  },
  {
    "word": "rupias",
    "rank": 8997,
    "frequency": 2581,
    "originalRank": 9178
  },
  {
    "word": "jardinero",
    "rank": 8998,
    "frequency": 2580,
    "originalRank": 9179
  },
  {
    "word": "preston",
    "rank": 8999,
    "frequency": 2580,
    "originalRank": 9180
  },
  {
    "word": "lori",
    "rank": 9000,
    "frequency": 2579,
    "originalRank": 9181
  },
  {
    "word": "condón",
    "rank": 9001,
    "frequency": 2579,
    "originalRank": 9182
  },
  {
    "word": "garrett",
    "rank": 9002,
    "frequency": 2578,
    "originalRank": 9183
  },
  {
    "word": "vuelan",
    "rank": 9003,
    "frequency": 2578,
    "originalRank": 9184
  },
  {
    "word": "facilidad",
    "rank": 9004,
    "frequency": 2578,
    "originalRank": 9185
  },
  {
    "word": "pinky",
    "rank": 9005,
    "frequency": 2578,
    "originalRank": 9186
  },
  {
    "word": "clarke",
    "rank": 9006,
    "frequency": 2576,
    "originalRank": 9187
  },
  {
    "word": "rejas",
    "rank": 9007,
    "frequency": 2576,
    "originalRank": 9188
  },
  {
    "word": "subí",
    "rank": 9008,
    "frequency": 2575,
    "originalRank": 9189
  },
  {
    "word": "harina",
    "rank": 9009,
    "frequency": 2575,
    "originalRank": 9190
  },
  {
    "word": "batallón",
    "rank": 9010,
    "frequency": 2575,
    "originalRank": 9191
  },
  {
    "word": "exteriores",
    "rank": 9011,
    "frequency": 2575,
    "originalRank": 9192
  },
  {
    "word": "histórico",
    "rank": 9012,
    "frequency": 2574,
    "originalRank": 9193
  },
  {
    "word": "baba",
    "rank": 9013,
    "frequency": 2574,
    "originalRank": 9194
  },
  {
    "word": "refugiados",
    "rank": 9014,
    "frequency": 2574,
    "originalRank": 9195
  },
  {
    "word": "here",
    "rank": 9015,
    "frequency": 2574,
    "originalRank": 9196
  },
  {
    "word": "agradables",
    "rank": 9016,
    "frequency": 2574,
    "originalRank": 9197
  },
  {
    "word": "pajarito",
    "rank": 9017,
    "frequency": 2573,
    "originalRank": 9198
  },
  {
    "word": "condones",
    "rank": 9018,
    "frequency": 2572,
    "originalRank": 9199
  },
  {
    "word": "chester",
    "rank": 9019,
    "frequency": 2572,
    "originalRank": 9200
  },
  {
    "word": "hábitos",
    "rank": 9020,
    "frequency": 2571,
    "originalRank": 9201
  },
  {
    "word": "prevenir",
    "rank": 9021,
    "frequency": 2571,
    "originalRank": 9202
  },
  {
    "word": "despido",
    "rank": 9022,
    "frequency": 2571,
    "originalRank": 9203
  },
  {
    "word": "padrastro",
    "rank": 9023,
    "frequency": 2570,
    "originalRank": 9204
  },
  {
    "word": "besarte",
    "rank": 9024,
    "frequency": 2570,
    "originalRank": 9205
  },
  {
    "word": "blusa",
    "rank": 9025,
    "frequency": 2569,
    "originalRank": 9206
  },
  {
    "word": "ugh",
    "rank": 9026,
    "frequency": 2569,
    "originalRank": 9207
  },
  {
    "word": "alimenta",
    "rank": 9027,
    "frequency": 2569,
    "originalRank": 9208
  },
  {
    "word": "estudia",
    "rank": 9028,
    "frequency": 2569,
    "originalRank": 9209
  },
  {
    "word": "inmigración",
    "rank": 9029,
    "frequency": 2568,
    "originalRank": 9210
  },
  {
    "word": "maridos",
    "rank": 9030,
    "frequency": 2568,
    "originalRank": 9211
  },
  {
    "word": "vístete",
    "rank": 9031,
    "frequency": 2568,
    "originalRank": 9212
  },
  {
    "word": "jugó",
    "rank": 9032,
    "frequency": 2568,
    "originalRank": 9213
  },
  {
    "word": "enfrentamos",
    "rank": 9033,
    "frequency": 2567,
    "originalRank": 9214
  },
  {
    "word": "disculparte",
    "rank": 9034,
    "frequency": 2567,
    "originalRank": 9215
  },
  {
    "word": "colapso",
    "rank": 9035,
    "frequency": 2566,
    "originalRank": 9216
  },
  {
    "word": "wong",
    "rank": 9036,
    "frequency": 2566,
    "originalRank": 9217
  },
  {
    "word": "pesos",
    "rank": 9037,
    "frequency": 2565,
    "originalRank": 9218
  },
  {
    "word": "cachorros",
    "rank": 9038,
    "frequency": 2565,
    "originalRank": 9219
  },
  {
    "word": "defectos",
    "rank": 9039,
    "frequency": 2565,
    "originalRank": 9220
  },
  {
    "word": "fragmentos",
    "rank": 9040,
    "frequency": 2565,
    "originalRank": 9221
  },
  {
    "word": "pondrán",
    "rank": 9041,
    "frequency": 2564,
    "originalRank": 9222
  },
  {
    "word": "menta",
    "rank": 9042,
    "frequency": 2564,
    "originalRank": 9223
  },
  {
    "word": "claros",
    "rank": 9043,
    "frequency": 2562,
    "originalRank": 9225
  },
  {
    "word": "internado",
    "rank": 9044,
    "frequency": 2562,
    "originalRank": 9226
  },
  {
    "word": "ofertas",
    "rank": 9045,
    "frequency": 2561,
    "originalRank": 9227
  },
  {
    "word": "lanzado",
    "rank": 9046,
    "frequency": 2561,
    "originalRank": 9228
  },
  {
    "word": "ganadora",
    "rank": 9047,
    "frequency": 2560,
    "originalRank": 9229
  },
  {
    "word": "japonesa",
    "rank": 9048,
    "frequency": 2560,
    "originalRank": 9230
  },
  {
    "word": "gail",
    "rank": 9049,
    "frequency": 2559,
    "originalRank": 9231
  },
  {
    "word": "aconsejo",
    "rank": 9050,
    "frequency": 2559,
    "originalRank": 9232
  },
  {
    "word": "mencioné",
    "rank": 9051,
    "frequency": 2559,
    "originalRank": 9233
  },
  {
    "word": "pagarlo",
    "rank": 9052,
    "frequency": 2558,
    "originalRank": 9235
  },
  {
    "word": "goa",
    "rank": 9053,
    "frequency": 2557,
    "originalRank": 9236
  },
  {
    "word": "cápsula",
    "rank": 9054,
    "frequency": 2557,
    "originalRank": 9237
  },
  {
    "word": "cálmense",
    "rank": 9055,
    "frequency": 2557,
    "originalRank": 9238
  },
  {
    "word": "sherman",
    "rank": 9056,
    "frequency": 2557,
    "originalRank": 9239
  },
  {
    "word": "bombero",
    "rank": 9057,
    "frequency": 2556,
    "originalRank": 9240
  },
  {
    "word": "cumplió",
    "rank": 9058,
    "frequency": 2556,
    "originalRank": 9241
  },
  {
    "word": "aparecerá",
    "rank": 9059,
    "frequency": 2555,
    "originalRank": 9242
  },
  {
    "word": "acelera",
    "rank": 9060,
    "frequency": 2555,
    "originalRank": 9243
  },
  {
    "word": "lorenzo",
    "rank": 9061,
    "frequency": 2554,
    "originalRank": 9244
  },
  {
    "word": "sólida",
    "rank": 9062,
    "frequency": 2553,
    "originalRank": 9245
  },
  {
    "word": "eugene",
    "rank": 9063,
    "frequency": 2553,
    "originalRank": 9246
  },
  {
    "word": "scully",
    "rank": 9064,
    "frequency": 2553,
    "originalRank": 9247
  },
  {
    "word": "arreglando",
    "rank": 9065,
    "frequency": 2553,
    "originalRank": 9248
  },
  {
    "word": "amarte",
    "rank": 9066,
    "frequency": 2552,
    "originalRank": 9249
  },
  {
    "word": "buda",
    "rank": 9067,
    "frequency": 2552,
    "originalRank": 9250
  },
  {
    "word": "obligaciones",
    "rank": 9068,
    "frequency": 2552,
    "originalRank": 9251
  },
  {
    "word": "girando",
    "rank": 9069,
    "frequency": 2551,
    "originalRank": 9252
  },
  {
    "word": "engaña",
    "rank": 9070,
    "frequency": 2551,
    "originalRank": 9253
  },
  {
    "word": "usaremos",
    "rank": 9071,
    "frequency": 2550,
    "originalRank": 9254
  },
  {
    "word": "ginger",
    "rank": 9072,
    "frequency": 2549,
    "originalRank": 9255
  },
  {
    "word": "lodo",
    "rank": 9073,
    "frequency": 2549,
    "originalRank": 9256
  },
  {
    "word": "sospechar",
    "rank": 9074,
    "frequency": 2549,
    "originalRank": 9257
  },
  {
    "word": "aislado",
    "rank": 9075,
    "frequency": 2549,
    "originalRank": 9258
  },
  {
    "word": "exige",
    "rank": 9076,
    "frequency": 2548,
    "originalRank": 9259
  },
  {
    "word": "ivy",
    "rank": 9077,
    "frequency": 2548,
    "originalRank": 9260
  },
  {
    "word": "ally",
    "rank": 9078,
    "frequency": 2547,
    "originalRank": 9261
  },
  {
    "word": "deshazte",
    "rank": 9079,
    "frequency": 2547,
    "originalRank": 9262
  },
  {
    "word": "calmado",
    "rank": 9080,
    "frequency": 2546,
    "originalRank": 9263
  },
  {
    "word": "piérdete",
    "rank": 9081,
    "frequency": 2546,
    "originalRank": 9264
  },
  {
    "word": "estes",
    "rank": 9082,
    "frequency": 2544,
    "originalRank": 9265
  },
  {
    "word": "fitz",
    "rank": 9083,
    "frequency": 2544,
    "originalRank": 9266
  },
  {
    "word": "enseñaste",
    "rank": 9084,
    "frequency": 2544,
    "originalRank": 9267
  },
  {
    "word": "asegura",
    "rank": 9085,
    "frequency": 2544,
    "originalRank": 9268
  },
  {
    "word": "libremente",
    "rank": 9086,
    "frequency": 2543,
    "originalRank": 9269
  },
  {
    "word": "poemas",
    "rank": 9087,
    "frequency": 2543,
    "originalRank": 9270
  },
  {
    "word": "tránsito",
    "rank": 9088,
    "frequency": 2542,
    "originalRank": 9271
  },
  {
    "word": "musulmanes",
    "rank": 9089,
    "frequency": 2542,
    "originalRank": 9272
  },
  {
    "word": "brooks",
    "rank": 9090,
    "frequency": 2541,
    "originalRank": 9273
  },
  {
    "word": "viviente",
    "rank": 9091,
    "frequency": 2541,
    "originalRank": 9274
  },
  {
    "word": "acostaste",
    "rank": 9092,
    "frequency": 2541,
    "originalRank": 9275
  },
  {
    "word": "prometer",
    "rank": 9093,
    "frequency": 2541,
    "originalRank": 9276
  },
  {
    "word": "funcionamiento",
    "rank": 9094,
    "frequency": 2541,
    "originalRank": 9277
  },
  {
    "word": "pais",
    "rank": 9095,
    "frequency": 2540,
    "originalRank": 9278
  },
  {
    "word": "tribus",
    "rank": 9096,
    "frequency": 2540,
    "originalRank": 9279
  },
  {
    "word": "adjunto",
    "rank": 9097,
    "frequency": 2540,
    "originalRank": 9280
  },
  {
    "word": "demora",
    "rank": 9098,
    "frequency": 2539,
    "originalRank": 9281
  },
  {
    "word": "joda",
    "rank": 9099,
    "frequency": 2539,
    "originalRank": 9282
  },
  {
    "word": "trabajaré",
    "rank": 9100,
    "frequency": 2539,
    "originalRank": 9283
  },
  {
    "word": "cortaron",
    "rank": 9101,
    "frequency": 2539,
    "originalRank": 9284
  },
  {
    "word": "seguirme",
    "rank": 9102,
    "frequency": 2539,
    "originalRank": 9285
  },
  {
    "word": "aficionado",
    "rank": 9103,
    "frequency": 2539,
    "originalRank": 9286
  },
  {
    "word": "investigado",
    "rank": 9104,
    "frequency": 2538,
    "originalRank": 9287
  },
  {
    "word": "vuelos",
    "rank": 9105,
    "frequency": 2538,
    "originalRank": 9288
  },
  {
    "word": "filmando",
    "rank": 9106,
    "frequency": 2538,
    "originalRank": 9289
  },
  {
    "word": "desafortunado",
    "rank": 9107,
    "frequency": 2538,
    "originalRank": 9290
  },
  {
    "word": "burla",
    "rank": 9108,
    "frequency": 2538,
    "originalRank": 9291
  },
  {
    "word": "anita",
    "rank": 9109,
    "frequency": 2538,
    "originalRank": 9292
  },
  {
    "word": "cásate",
    "rank": 9110,
    "frequency": 2537,
    "originalRank": 9293
  },
  {
    "word": "invitarte",
    "rank": 9111,
    "frequency": 2536,
    "originalRank": 9294
  },
  {
    "word": "traten",
    "rank": 9112,
    "frequency": 2536,
    "originalRank": 9295
  },
  {
    "word": "echamos",
    "rank": 9113,
    "frequency": 2536,
    "originalRank": 9296
  },
  {
    "word": "cross",
    "rank": 9114,
    "frequency": 2535,
    "originalRank": 9297
  },
  {
    "word": "mueves",
    "rank": 9115,
    "frequency": 2535,
    "originalRank": 9298
  },
  {
    "word": "pésimo",
    "rank": 9116,
    "frequency": 2535,
    "originalRank": 9299
  },
  {
    "word": "kara",
    "rank": 9117,
    "frequency": 2534,
    "originalRank": 9300
  },
  {
    "word": "directores",
    "rank": 9118,
    "frequency": 2534,
    "originalRank": 9301
  },
  {
    "word": "pagarás",
    "rank": 9119,
    "frequency": 2534,
    "originalRank": 9302
  },
  {
    "word": "toc",
    "rank": 9120,
    "frequency": 2534,
    "originalRank": 9303
  },
  {
    "word": "mapas",
    "rank": 9121,
    "frequency": 2533,
    "originalRank": 9304
  },
  {
    "word": "tenerlos",
    "rank": 9122,
    "frequency": 2533,
    "originalRank": 9305
  },
  {
    "word": "hongos",
    "rank": 9123,
    "frequency": 2533,
    "originalRank": 9306
  },
  {
    "word": "mateo",
    "rank": 9124,
    "frequency": 2533,
    "originalRank": 9307
  },
  {
    "word": "gorila",
    "rank": 9125,
    "frequency": 2532,
    "originalRank": 9308
  },
  {
    "word": "facial",
    "rank": 9126,
    "frequency": 2532,
    "originalRank": 9309
  },
  {
    "word": "sushi",
    "rank": 9127,
    "frequency": 2532,
    "originalRank": 9310
  },
  {
    "word": "gabe",
    "rank": 9128,
    "frequency": 2532,
    "originalRank": 9311
  },
  {
    "word": "jeep",
    "rank": 9129,
    "frequency": 2532,
    "originalRank": 9312
  },
  {
    "word": "shannon",
    "rank": 9130,
    "frequency": 2532,
    "originalRank": 9313
  },
  {
    "word": "cambies",
    "rank": 9131,
    "frequency": 2532,
    "originalRank": 9314
  },
  {
    "word": "calabaza",
    "rank": 9132,
    "frequency": 2531,
    "originalRank": 9315
  },
  {
    "word": "autógrafo",
    "rank": 9133,
    "frequency": 2531,
    "originalRank": 9316
  },
  {
    "word": "topo",
    "rank": 9134,
    "frequency": 2530,
    "originalRank": 9317
  },
  {
    "word": "financiera",
    "rank": 9135,
    "frequency": 2530,
    "originalRank": 9318
  },
  {
    "word": "nace",
    "rank": 9136,
    "frequency": 2529,
    "originalRank": 9319
  },
  {
    "word": "springfield",
    "rank": 9137,
    "frequency": 2529,
    "originalRank": 9320
  },
  {
    "word": "penal",
    "rank": 9138,
    "frequency": 2528,
    "originalRank": 9322
  },
  {
    "word": "noto",
    "rank": 9139,
    "frequency": 2528,
    "originalRank": 9323
  },
  {
    "word": "amabas",
    "rank": 9140,
    "frequency": 2528,
    "originalRank": 9324
  },
  {
    "word": "eliges",
    "rank": 9141,
    "frequency": 2528,
    "originalRank": 9325
  },
  {
    "word": "entregue",
    "rank": 9142,
    "frequency": 2528,
    "originalRank": 9326
  },
  {
    "word": "aceptamos",
    "rank": 9143,
    "frequency": 2528,
    "originalRank": 9327
  },
  {
    "word": "levanté",
    "rank": 9144,
    "frequency": 2528,
    "originalRank": 9328
  },
  {
    "word": "agregar",
    "rank": 9145,
    "frequency": 2528,
    "originalRank": 9329
  },
  {
    "word": "sang",
    "rank": 9146,
    "frequency": 2528,
    "originalRank": 9330
  },
  {
    "word": "nadando",
    "rank": 9147,
    "frequency": 2526,
    "originalRank": 9331
  },
  {
    "word": "atentamente",
    "rank": 9148,
    "frequency": 2526,
    "originalRank": 9332
  },
  {
    "word": "clubes",
    "rank": 9149,
    "frequency": 2526,
    "originalRank": 9333
  },
  {
    "word": "violador",
    "rank": 9150,
    "frequency": 2526,
    "originalRank": 9334
  },
  {
    "word": "suzanne",
    "rank": 9151,
    "frequency": 2526,
    "originalRank": 9335
  },
  {
    "word": "rompieron",
    "rank": 9152,
    "frequency": 2525,
    "originalRank": 9336
  },
  {
    "word": "respaldo",
    "rank": 9153,
    "frequency": 2524,
    "originalRank": 9337
  },
  {
    "word": "jenkins",
    "rank": 9154,
    "frequency": 2524,
    "originalRank": 9338
  },
  {
    "word": "simón",
    "rank": 9155,
    "frequency": 2524,
    "originalRank": 9339
  },
  {
    "word": "besado",
    "rank": 9156,
    "frequency": 2524,
    "originalRank": 9340
  },
  {
    "word": "ofensiva",
    "rank": 9157,
    "frequency": 2523,
    "originalRank": 9341
  },
  {
    "word": "continuará",
    "rank": 9158,
    "frequency": 2523,
    "originalRank": 9342
  },
  {
    "word": "planeas",
    "rank": 9159,
    "frequency": 2523,
    "originalRank": 9343
  },
  {
    "word": "apreciar",
    "rank": 9160,
    "frequency": 2523,
    "originalRank": 9344
  },
  {
    "word": "baterías",
    "rank": 9161,
    "frequency": 2523,
    "originalRank": 9345
  },
  {
    "word": "abigail",
    "rank": 9162,
    "frequency": 2522,
    "originalRank": 9346
  },
  {
    "word": "grabaciones",
    "rank": 9163,
    "frequency": 2521,
    "originalRank": 9347
  },
  {
    "word": "inconveniente",
    "rank": 9164,
    "frequency": 2521,
    "originalRank": 9348
  },
  {
    "word": "olvidamos",
    "rank": 9165,
    "frequency": 2520,
    "originalRank": 9349
  },
  {
    "word": "descubra",
    "rank": 9166,
    "frequency": 2520,
    "originalRank": 9350
  },
  {
    "word": "legítimo",
    "rank": 9167,
    "frequency": 2519,
    "originalRank": 9351
  },
  {
    "word": "calabozo",
    "rank": 9168,
    "frequency": 2519,
    "originalRank": 9352
  },
  {
    "word": "ésos",
    "rank": 9169,
    "frequency": 2519,
    "originalRank": 9353
  },
  {
    "word": "escapando",
    "rank": 9170,
    "frequency": 2518,
    "originalRank": 9354
  },
  {
    "word": "corporación",
    "rank": 9171,
    "frequency": 2518,
    "originalRank": 9355
  },
  {
    "word": "inventé",
    "rank": 9172,
    "frequency": 2518,
    "originalRank": 9356
  },
  {
    "word": "chispa",
    "rank": 9173,
    "frequency": 2517,
    "originalRank": 9357
  },
  {
    "word": "grandeza",
    "rank": 9174,
    "frequency": 2517,
    "originalRank": 9358
  },
  {
    "word": "paramos",
    "rank": 9175,
    "frequency": 2517,
    "originalRank": 9359
  },
  {
    "word": "envenenado",
    "rank": 9176,
    "frequency": 2516,
    "originalRank": 9360
  },
  {
    "word": "satanás",
    "rank": 9177,
    "frequency": 2516,
    "originalRank": 9361
  },
  {
    "word": "suélteme",
    "rank": 9178,
    "frequency": 2516,
    "originalRank": 9362
  },
  {
    "word": "abe",
    "rank": 9179,
    "frequency": 2515,
    "originalRank": 9363
  },
  {
    "word": "escondes",
    "rank": 9180,
    "frequency": 2515,
    "originalRank": 9364
  },
  {
    "word": "cantan",
    "rank": 9181,
    "frequency": 2514,
    "originalRank": 9365
  },
  {
    "word": "salvavidas",
    "rank": 9182,
    "frequency": 2512,
    "originalRank": 9366
  },
  {
    "word": "retorno",
    "rank": 9183,
    "frequency": 2511,
    "originalRank": 9367
  },
  {
    "word": "abeja",
    "rank": 9184,
    "frequency": 2511,
    "originalRank": 9368
  },
  {
    "word": "pulgadas",
    "rank": 9185,
    "frequency": 2510,
    "originalRank": 9369
  },
  {
    "word": "preciosos",
    "rank": 9186,
    "frequency": 2509,
    "originalRank": 9370
  },
  {
    "word": "cargas",
    "rank": 9187,
    "frequency": 2508,
    "originalRank": 9371
  },
  {
    "word": "fallecido",
    "rank": 9188,
    "frequency": 2507,
    "originalRank": 9372
  },
  {
    "word": "programado",
    "rank": 9189,
    "frequency": 2507,
    "originalRank": 9373
  },
  {
    "word": "preocuparnos",
    "rank": 9190,
    "frequency": 2507,
    "originalRank": 9374
  },
  {
    "word": "buzz",
    "rank": 9191,
    "frequency": 2506,
    "originalRank": 9375
  },
  {
    "word": "tacos",
    "rank": 9192,
    "frequency": 2506,
    "originalRank": 9376
  },
  {
    "word": "regresando",
    "rank": 9193,
    "frequency": 2506,
    "originalRank": 9377
  },
  {
    "word": "aliado",
    "rank": 9194,
    "frequency": 2506,
    "originalRank": 9378
  },
  {
    "word": "declara",
    "rank": 9195,
    "frequency": 2506,
    "originalRank": 9379
  },
  {
    "word": "preguntamos",
    "rank": 9196,
    "frequency": 2506,
    "originalRank": 9380
  },
  {
    "word": "mienten",
    "rank": 9197,
    "frequency": 2506,
    "originalRank": 9381
  },
  {
    "word": "marion",
    "rank": 9198,
    "frequency": 2505,
    "originalRank": 9382
  },
  {
    "word": "sirvienta",
    "rank": 9199,
    "frequency": 2505,
    "originalRank": 9383
  },
  {
    "word": "asignado",
    "rank": 9200,
    "frequency": 2505,
    "originalRank": 9384
  },
  {
    "word": "gasolinera",
    "rank": 9201,
    "frequency": 2505,
    "originalRank": 9385
  },
  {
    "word": "nevada",
    "rank": 9202,
    "frequency": 2504,
    "originalRank": 9386
  },
  {
    "word": "tasa",
    "rank": 9203,
    "frequency": 2504,
    "originalRank": 9387
  },
  {
    "word": "eminencia",
    "rank": 9204,
    "frequency": 2504,
    "originalRank": 9388
  },
  {
    "word": "dales",
    "rank": 9205,
    "frequency": 2504,
    "originalRank": 9389
  },
  {
    "word": "helada",
    "rank": 9206,
    "frequency": 2504,
    "originalRank": 9390
  },
  {
    "word": "privadas",
    "rank": 9207,
    "frequency": 2503,
    "originalRank": 9391
  },
  {
    "word": "cogiste",
    "rank": 9208,
    "frequency": 2503,
    "originalRank": 9392
  },
  {
    "word": "plana",
    "rank": 9209,
    "frequency": 2503,
    "originalRank": 9393
  },
  {
    "word": "cortada",
    "rank": 9210,
    "frequency": 2503,
    "originalRank": 9394
  },
  {
    "word": "volado",
    "rank": 9211,
    "frequency": 2502,
    "originalRank": 9395
  },
  {
    "word": "regresas",
    "rank": 9212,
    "frequency": 2502,
    "originalRank": 9396
  },
  {
    "word": "extiende",
    "rank": 9213,
    "frequency": 2502,
    "originalRank": 9397
  },
  {
    "word": "simone",
    "rank": 9214,
    "frequency": 2501,
    "originalRank": 9398
  },
  {
    "word": "movió",
    "rank": 9215,
    "frequency": 2501,
    "originalRank": 9399
  },
  {
    "word": "roberto",
    "rank": 9216,
    "frequency": 2501,
    "originalRank": 9400
  },
  {
    "word": "pijama",
    "rank": 9217,
    "frequency": 2501,
    "originalRank": 9401
  },
  {
    "word": "irías",
    "rank": 9218,
    "frequency": 2500,
    "originalRank": 9402
  },
  {
    "word": "defecto",
    "rank": 9219,
    "frequency": 2500,
    "originalRank": 9403
  },
  {
    "word": "roban",
    "rank": 9220,
    "frequency": 2500,
    "originalRank": 9404
  },
  {
    "word": "corrupto",
    "rank": 9221,
    "frequency": 2499,
    "originalRank": 9405
  },
  {
    "word": "luchamos",
    "rank": 9222,
    "frequency": 2499,
    "originalRank": 9406
  },
  {
    "word": "ausente",
    "rank": 9223,
    "frequency": 2499,
    "originalRank": 9407
  },
  {
    "word": "sensual",
    "rank": 9224,
    "frequency": 2498,
    "originalRank": 9409
  },
  {
    "word": "millie",
    "rank": 9225,
    "frequency": 2498,
    "originalRank": 9410
  },
  {
    "word": "recupere",
    "rank": 9226,
    "frequency": 2498,
    "originalRank": 9411
  },
  {
    "word": "naval",
    "rank": 9227,
    "frequency": 2498,
    "originalRank": 9412
  },
  {
    "word": "concentrarme",
    "rank": 9228,
    "frequency": 2497,
    "originalRank": 9413
  },
  {
    "word": "encárgate",
    "rank": 9229,
    "frequency": 2497,
    "originalRank": 9414
  },
  {
    "word": "distante",
    "rank": 9230,
    "frequency": 2496,
    "originalRank": 9415
  },
  {
    "word": "corra",
    "rank": 9231,
    "frequency": 2496,
    "originalRank": 9416
  },
  {
    "word": "lecho",
    "rank": 9232,
    "frequency": 2496,
    "originalRank": 9417
  },
  {
    "word": "salid",
    "rank": 9233,
    "frequency": 2495,
    "originalRank": 9418
  },
  {
    "word": "sinceridad",
    "rank": 9234,
    "frequency": 2495,
    "originalRank": 9419
  },
  {
    "word": "conocéis",
    "rank": 9235,
    "frequency": 2495,
    "originalRank": 9420
  },
  {
    "word": "roland",
    "rank": 9236,
    "frequency": 2494,
    "originalRank": 9421
  },
  {
    "word": "lastimarte",
    "rank": 9237,
    "frequency": 2493,
    "originalRank": 9422
  },
  {
    "word": "acontecimientos",
    "rank": 9238,
    "frequency": 2493,
    "originalRank": 9423
  },
  {
    "word": "milo",
    "rank": 9239,
    "frequency": 2493,
    "originalRank": 9425
  },
  {
    "word": "expuesto",
    "rank": 9240,
    "frequency": 2493,
    "originalRank": 9426
  },
  {
    "word": "square",
    "rank": 9241,
    "frequency": 2492,
    "originalRank": 9427
  },
  {
    "word": "suaves",
    "rank": 9242,
    "frequency": 2492,
    "originalRank": 9428
  },
  {
    "word": "jinete",
    "rank": 9243,
    "frequency": 2492,
    "originalRank": 9429
  },
  {
    "word": "conozcan",
    "rank": 9244,
    "frequency": 2492,
    "originalRank": 9430
  },
  {
    "word": "traslado",
    "rank": 9245,
    "frequency": 2492,
    "originalRank": 9431
  },
  {
    "word": "camello",
    "rank": 9246,
    "frequency": 2491,
    "originalRank": 9432
  },
  {
    "word": "húmedo",
    "rank": 9247,
    "frequency": 2491,
    "originalRank": 9433
  },
  {
    "word": "besa",
    "rank": 9248,
    "frequency": 2491,
    "originalRank": 9434
  },
  {
    "word": "dedicas",
    "rank": 9249,
    "frequency": 2489,
    "originalRank": 9435
  },
  {
    "word": "dele",
    "rank": 9250,
    "frequency": 2488,
    "originalRank": 9436
  },
  {
    "word": "tesoros",
    "rank": 9251,
    "frequency": 2488,
    "originalRank": 9437
  },
  {
    "word": "extrema",
    "rank": 9252,
    "frequency": 2488,
    "originalRank": 9438
  },
  {
    "word": "profundas",
    "rank": 9253,
    "frequency": 2487,
    "originalRank": 9439
  },
  {
    "word": "usen",
    "rank": 9254,
    "frequency": 2487,
    "originalRank": 9440
  },
  {
    "word": "reúne",
    "rank": 9255,
    "frequency": 2487,
    "originalRank": 9441
  },
  {
    "word": "taco",
    "rank": 9256,
    "frequency": 2486,
    "originalRank": 9442
  },
  {
    "word": "seguiría",
    "rank": 9257,
    "frequency": 2486,
    "originalRank": 9443
  },
  {
    "word": "she",
    "rank": 9258,
    "frequency": 2485,
    "originalRank": 9444
  },
  {
    "word": "tratos",
    "rank": 9259,
    "frequency": 2485,
    "originalRank": 9445
  },
  {
    "word": "cierro",
    "rank": 9260,
    "frequency": 2485,
    "originalRank": 9446
  },
  {
    "word": "expedientes",
    "rank": 9261,
    "frequency": 2484,
    "originalRank": 9447
  },
  {
    "word": "caminata",
    "rank": 9262,
    "frequency": 2484,
    "originalRank": 9448
  },
  {
    "word": "tribunales",
    "rank": 9263,
    "frequency": 2484,
    "originalRank": 9449
  },
  {
    "word": "nacionales",
    "rank": 9264,
    "frequency": 2483,
    "originalRank": 9450
  },
  {
    "word": "presentaré",
    "rank": 9265,
    "frequency": 2483,
    "originalRank": 9451
  },
  {
    "word": "mantienes",
    "rank": 9266,
    "frequency": 2483,
    "originalRank": 9452
  },
  {
    "word": "guardería",
    "rank": 9267,
    "frequency": 2483,
    "originalRank": 9453
  },
  {
    "word": "tormentas",
    "rank": 9268,
    "frequency": 2483,
    "originalRank": 9454
  },
  {
    "word": "agradecemos",
    "rank": 9269,
    "frequency": 2482,
    "originalRank": 9455
  },
  {
    "word": "juliette",
    "rank": 9270,
    "frequency": 2482,
    "originalRank": 9456
  },
  {
    "word": "tubos",
    "rank": 9271,
    "frequency": 2482,
    "originalRank": 9457
  },
  {
    "word": "vengarse",
    "rank": 9272,
    "frequency": 2482,
    "originalRank": 9458
  },
  {
    "word": "individuos",
    "rank": 9273,
    "frequency": 2481,
    "originalRank": 9459
  },
  {
    "word": "ochenta",
    "rank": 9274,
    "frequency": 2481,
    "originalRank": 9460
  },
  {
    "word": "daga",
    "rank": 9275,
    "frequency": 2481,
    "originalRank": 9461
  },
  {
    "word": "estudié",
    "rank": 9276,
    "frequency": 2480,
    "originalRank": 9462
  },
  {
    "word": "tiraste",
    "rank": 9277,
    "frequency": 2479,
    "originalRank": 9463
  },
  {
    "word": "adicción",
    "rank": 9278,
    "frequency": 2479,
    "originalRank": 9464
  },
  {
    "word": "gemela",
    "rank": 9279,
    "frequency": 2478,
    "originalRank": 9465
  },
  {
    "word": "cartero",
    "rank": 9280,
    "frequency": 2478,
    "originalRank": 9466
  },
  {
    "word": "fichas",
    "rank": 9281,
    "frequency": 2478,
    "originalRank": 9467
  },
  {
    "word": "dárselo",
    "rank": 9282,
    "frequency": 2477,
    "originalRank": 9468
  },
  {
    "word": "explosivo",
    "rank": 9283,
    "frequency": 2477,
    "originalRank": 9469
  },
  {
    "word": "árabes",
    "rank": 9284,
    "frequency": 2477,
    "originalRank": 9470
  },
  {
    "word": "labor",
    "rank": 9285,
    "frequency": 2477,
    "originalRank": 9471
  },
  {
    "word": "fina",
    "rank": 9286,
    "frequency": 2477,
    "originalRank": 9472
  },
  {
    "word": "pentágono",
    "rank": 9287,
    "frequency": 2476,
    "originalRank": 9473
  },
  {
    "word": "barb",
    "rank": 9288,
    "frequency": 2476,
    "originalRank": 9474
  },
  {
    "word": "roosevelt",
    "rank": 9289,
    "frequency": 2476,
    "originalRank": 9475
  },
  {
    "word": "guardando",
    "rank": 9290,
    "frequency": 2475,
    "originalRank": 9476
  },
  {
    "word": "ademas",
    "rank": 9291,
    "frequency": 2475,
    "originalRank": 9477
  },
  {
    "word": "natasha",
    "rank": 9292,
    "frequency": 2475,
    "originalRank": 9478
  },
  {
    "word": "matanza",
    "rank": 9293,
    "frequency": 2473,
    "originalRank": 9479
  },
  {
    "word": "consiguiendo",
    "rank": 9294,
    "frequency": 2473,
    "originalRank": 9480
  },
  {
    "word": "cubiertos",
    "rank": 9295,
    "frequency": 2472,
    "originalRank": 9481
  },
  {
    "word": "doscientos",
    "rank": 9296,
    "frequency": 2472,
    "originalRank": 9482
  },
  {
    "word": "fax",
    "rank": 9297,
    "frequency": 2471,
    "originalRank": 9483
  },
  {
    "word": "empujó",
    "rank": 9298,
    "frequency": 2471,
    "originalRank": 9484
  },
  {
    "word": "conmoción",
    "rank": 9299,
    "frequency": 2470,
    "originalRank": 9485
  },
  {
    "word": "reunirnos",
    "rank": 9300,
    "frequency": 2470,
    "originalRank": 9486
  },
  {
    "word": "traficantes",
    "rank": 9301,
    "frequency": 2469,
    "originalRank": 9487
  },
  {
    "word": "déjalos",
    "rank": 9302,
    "frequency": 2469,
    "originalRank": 9488
  },
  {
    "word": "novelas",
    "rank": 9303,
    "frequency": 2469,
    "originalRank": 9489
  },
  {
    "word": "tammy",
    "rank": 9304,
    "frequency": 2468,
    "originalRank": 9490
  },
  {
    "word": "atardecer",
    "rank": 9305,
    "frequency": 2468,
    "originalRank": 9491
  },
  {
    "word": "continuamente",
    "rank": 9306,
    "frequency": 2468,
    "originalRank": 9492
  },
  {
    "word": "provocado",
    "rank": 9307,
    "frequency": 2468,
    "originalRank": 9493
  },
  {
    "word": "jurisdicción",
    "rank": 9308,
    "frequency": 2468,
    "originalRank": 9494
  },
  {
    "word": "humillante",
    "rank": 9309,
    "frequency": 2468,
    "originalRank": 9495
  },
  {
    "word": "lacey",
    "rank": 9310,
    "frequency": 2467,
    "originalRank": 9496
  },
  {
    "word": "sumamente",
    "rank": 9311,
    "frequency": 2467,
    "originalRank": 9497
  },
  {
    "word": "misterios",
    "rank": 9312,
    "frequency": 2467,
    "originalRank": 9498
  },
  {
    "word": "residuos",
    "rank": 9313,
    "frequency": 2467,
    "originalRank": 9499
  },
  {
    "word": "verónica",
    "rank": 9314,
    "frequency": 2467,
    "originalRank": 9500
  },
  {
    "word": "rostros",
    "rank": 9315,
    "frequency": 2466,
    "originalRank": 9501
  },
  {
    "word": "frances",
    "rank": 9316,
    "frequency": 2466,
    "originalRank": 9502
  },
  {
    "word": "besó",
    "rank": 9317,
    "frequency": 2465,
    "originalRank": 9503
  },
  {
    "word": "oposición",
    "rank": 9318,
    "frequency": 2465,
    "originalRank": 9504
  },
  {
    "word": "aleja",
    "rank": 9319,
    "frequency": 2465,
    "originalRank": 9505
  },
  {
    "word": "intruso",
    "rank": 9320,
    "frequency": 2465,
    "originalRank": 9506
  },
  {
    "word": "maní",
    "rank": 9321,
    "frequency": 2464,
    "originalRank": 9508
  },
  {
    "word": "gabrielle",
    "rank": 9322,
    "frequency": 2464,
    "originalRank": 9509
  },
  {
    "word": "nikita",
    "rank": 9323,
    "frequency": 2463,
    "originalRank": 9510
  },
  {
    "word": "feas",
    "rank": 9324,
    "frequency": 2463,
    "originalRank": 9511
  },
  {
    "word": "escuchaba",
    "rank": 9325,
    "frequency": 2463,
    "originalRank": 9512
  },
  {
    "word": "masas",
    "rank": 9326,
    "frequency": 2463,
    "originalRank": 9513
  },
  {
    "word": "sendero",
    "rank": 9327,
    "frequency": 2462,
    "originalRank": 9514
  },
  {
    "word": "artefacto",
    "rank": 9328,
    "frequency": 2462,
    "originalRank": 9515
  },
  {
    "word": "cancha",
    "rank": 9329,
    "frequency": 2462,
    "originalRank": 9516
  },
  {
    "word": "moviéndose",
    "rank": 9330,
    "frequency": 2462,
    "originalRank": 9517
  },
  {
    "word": "aparecieron",
    "rank": 9331,
    "frequency": 2461,
    "originalRank": 9518
  },
  {
    "word": "limonada",
    "rank": 9332,
    "frequency": 2461,
    "originalRank": 9519
  },
  {
    "word": "laberinto",
    "rank": 9333,
    "frequency": 2461,
    "originalRank": 9520
  },
  {
    "word": "paracaídas",
    "rank": 9334,
    "frequency": 2461,
    "originalRank": 9521
  },
  {
    "word": "ardilla",
    "rank": 9335,
    "frequency": 2461,
    "originalRank": 9522
  },
  {
    "word": "horizonte",
    "rank": 9336,
    "frequency": 2460,
    "originalRank": 9523
  },
  {
    "word": "menciona",
    "rank": 9337,
    "frequency": 2460,
    "originalRank": 9524
  },
  {
    "word": "kenneth",
    "rank": 9338,
    "frequency": 2460,
    "originalRank": 9525
  },
  {
    "word": "despegue",
    "rank": 9339,
    "frequency": 2460,
    "originalRank": 9526
  },
  {
    "word": "decirse",
    "rank": 9340,
    "frequency": 2459,
    "originalRank": 9527
  },
  {
    "word": "late",
    "rank": 9341,
    "frequency": 2459,
    "originalRank": 9528
  },
  {
    "word": "representar",
    "rank": 9342,
    "frequency": 2458,
    "originalRank": 9529
  },
  {
    "word": "cajero",
    "rank": 9343,
    "frequency": 2458,
    "originalRank": 9530
  },
  {
    "word": "atún",
    "rank": 9344,
    "frequency": 2458,
    "originalRank": 9531
  },
  {
    "word": "inapropiado",
    "rank": 9345,
    "frequency": 2458,
    "originalRank": 9532
  },
  {
    "word": "deseamos",
    "rank": 9346,
    "frequency": 2457,
    "originalRank": 9533
  },
  {
    "word": "pobrecito",
    "rank": 9347,
    "frequency": 2457,
    "originalRank": 9534
  },
  {
    "word": "creíamos",
    "rank": 9348,
    "frequency": 2456,
    "originalRank": 9535
  },
  {
    "word": "explicaría",
    "rank": 9349,
    "frequency": 2456,
    "originalRank": 9536
  },
  {
    "word": "comete",
    "rank": 9350,
    "frequency": 2456,
    "originalRank": 9537
  },
  {
    "word": "explicado",
    "rank": 9351,
    "frequency": 2455,
    "originalRank": 9538
  },
  {
    "word": "tomates",
    "rank": 9352,
    "frequency": 2455,
    "originalRank": 9539
  },
  {
    "word": "river",
    "rank": 9353,
    "frequency": 2455,
    "originalRank": 9540
  },
  {
    "word": "negociaciones",
    "rank": 9354,
    "frequency": 2454,
    "originalRank": 9541
  },
  {
    "word": "haced",
    "rank": 9355,
    "frequency": 2454,
    "originalRank": 9542
  },
  {
    "word": "violada",
    "rank": 9356,
    "frequency": 2454,
    "originalRank": 9543
  },
  {
    "word": "abandono",
    "rank": 9357,
    "frequency": 2454,
    "originalRank": 9544
  },
  {
    "word": "deberán",
    "rank": 9358,
    "frequency": 2454,
    "originalRank": 9545
  },
  {
    "word": "yerno",
    "rank": 9359,
    "frequency": 2454,
    "originalRank": 9546
  },
  {
    "word": "sandwich",
    "rank": 9360,
    "frequency": 2453,
    "originalRank": 9547
  },
  {
    "word": "ingenuo",
    "rank": 9361,
    "frequency": 2453,
    "originalRank": 9548
  },
  {
    "word": "rol",
    "rank": 9362,
    "frequency": 2453,
    "originalRank": 9549
  },
  {
    "word": "coñac",
    "rank": 9363,
    "frequency": 2453,
    "originalRank": 9550
  },
  {
    "word": "fanáticos",
    "rank": 9364,
    "frequency": 2453,
    "originalRank": 9551
  },
  {
    "word": "pretender",
    "rank": 9365,
    "frequency": 2452,
    "originalRank": 9552
  },
  {
    "word": "suenan",
    "rank": 9366,
    "frequency": 2452,
    "originalRank": 9553
  },
  {
    "word": "tardis",
    "rank": 9367,
    "frequency": 2452,
    "originalRank": 9554
  },
  {
    "word": "clinton",
    "rank": 9368,
    "frequency": 2451,
    "originalRank": 9555
  },
  {
    "word": "sugerir",
    "rank": 9369,
    "frequency": 2451,
    "originalRank": 9556
  },
  {
    "word": "armonía",
    "rank": 9370,
    "frequency": 2451,
    "originalRank": 9557
  },
  {
    "word": "satisfacer",
    "rank": 9371,
    "frequency": 2450,
    "originalRank": 9558
  },
  {
    "word": "salmón",
    "rank": 9372,
    "frequency": 2450,
    "originalRank": 9559
  },
  {
    "word": "arreglé",
    "rank": 9373,
    "frequency": 2450,
    "originalRank": 9560
  },
  {
    "word": "arteria",
    "rank": 9374,
    "frequency": 2448,
    "originalRank": 9561
  },
  {
    "word": "despreciable",
    "rank": 9375,
    "frequency": 2448,
    "originalRank": 9562
  },
  {
    "word": "escalar",
    "rank": 9376,
    "frequency": 2448,
    "originalRank": 9563
  },
  {
    "word": "cazando",
    "rank": 9377,
    "frequency": 2448,
    "originalRank": 9564
  },
  {
    "word": "alabado",
    "rank": 9378,
    "frequency": 2447,
    "originalRank": 9565
  },
  {
    "word": "pasarlo",
    "rank": 9379,
    "frequency": 2447,
    "originalRank": 9566
  },
  {
    "word": "cigarros",
    "rank": 9380,
    "frequency": 2447,
    "originalRank": 9567
  },
  {
    "word": "correa",
    "rank": 9381,
    "frequency": 2447,
    "originalRank": 9568
  },
  {
    "word": "contener",
    "rank": 9382,
    "frequency": 2446,
    "originalRank": 9569
  },
  {
    "word": "feroz",
    "rank": 9383,
    "frequency": 2446,
    "originalRank": 9570
  },
  {
    "word": "averiguado",
    "rank": 9384,
    "frequency": 2446,
    "originalRank": 9571
  },
  {
    "word": "provocó",
    "rank": 9385,
    "frequency": 2446,
    "originalRank": 9572
  },
  {
    "word": "mirándome",
    "rank": 9386,
    "frequency": 2445,
    "originalRank": 9573
  },
  {
    "word": "contexto",
    "rank": 9387,
    "frequency": 2445,
    "originalRank": 9574
  },
  {
    "word": "quítame",
    "rank": 9388,
    "frequency": 2445,
    "originalRank": 9575
  },
  {
    "word": "recogió",
    "rank": 9389,
    "frequency": 2444,
    "originalRank": 9576
  },
  {
    "word": "violentos",
    "rank": 9390,
    "frequency": 2444,
    "originalRank": 9577
  },
  {
    "word": "miedos",
    "rank": 9391,
    "frequency": 2443,
    "originalRank": 9578
  },
  {
    "word": "aparición",
    "rank": 9392,
    "frequency": 2443,
    "originalRank": 9579
  },
  {
    "word": "ofrecen",
    "rank": 9393,
    "frequency": 2442,
    "originalRank": 9580
  },
  {
    "word": "haberlos",
    "rank": 9394,
    "frequency": 2442,
    "originalRank": 9581
  },
  {
    "word": "casera",
    "rank": 9395,
    "frequency": 2441,
    "originalRank": 9582
  },
  {
    "word": "racha",
    "rank": 9396,
    "frequency": 2441,
    "originalRank": 9583
  },
  {
    "word": "trent",
    "rank": 9397,
    "frequency": 2441,
    "originalRank": 9584
  },
  {
    "word": "distribución",
    "rank": 9398,
    "frequency": 2441,
    "originalRank": 9585
  },
  {
    "word": "repentino",
    "rank": 9399,
    "frequency": 2440,
    "originalRank": 9586
  },
  {
    "word": "rezo",
    "rank": 9400,
    "frequency": 2440,
    "originalRank": 9587
  },
  {
    "word": "trish",
    "rank": 9401,
    "frequency": 2440,
    "originalRank": 9588
  },
  {
    "word": "bailes",
    "rank": 9402,
    "frequency": 2440,
    "originalRank": 9589
  },
  {
    "word": "humillación",
    "rank": 9403,
    "frequency": 2440,
    "originalRank": 9590
  },
  {
    "word": "hallaron",
    "rank": 9404,
    "frequency": 2439,
    "originalRank": 9591
  },
  {
    "word": "invitarme",
    "rank": 9405,
    "frequency": 2439,
    "originalRank": 9592
  },
  {
    "word": "conduzco",
    "rank": 9406,
    "frequency": 2439,
    "originalRank": 9593
  },
  {
    "word": "ensayar",
    "rank": 9407,
    "frequency": 2438,
    "originalRank": 9594
  },
  {
    "word": "derrotado",
    "rank": 9408,
    "frequency": 2438,
    "originalRank": 9595
  },
  {
    "word": "veterinario",
    "rank": 9409,
    "frequency": 2438,
    "originalRank": 9596
  },
  {
    "word": "faro",
    "rank": 9410,
    "frequency": 2437,
    "originalRank": 9597
  },
  {
    "word": "pornografía",
    "rank": 9411,
    "frequency": 2437,
    "originalRank": 9598
  },
  {
    "word": "yale",
    "rank": 9412,
    "frequency": 2437,
    "originalRank": 9599
  },
  {
    "word": "buscaremos",
    "rank": 9413,
    "frequency": 2437,
    "originalRank": 9600
  },
  {
    "word": "semen",
    "rank": 9414,
    "frequency": 2437,
    "originalRank": 9601
  },
  {
    "word": "creerte",
    "rank": 9415,
    "frequency": 2436,
    "originalRank": 9602
  },
  {
    "word": "contestó",
    "rank": 9416,
    "frequency": 2436,
    "originalRank": 9603
  },
  {
    "word": "chulo",
    "rank": 9417,
    "frequency": 2435,
    "originalRank": 9604
  },
  {
    "word": "aceptable",
    "rank": 9418,
    "frequency": 2435,
    "originalRank": 9605
  },
  {
    "word": "nomás",
    "rank": 9419,
    "frequency": 2435,
    "originalRank": 9606
  },
  {
    "word": "cubriendo",
    "rank": 9420,
    "frequency": 2434,
    "originalRank": 9607
  },
  {
    "word": "reconstruir",
    "rank": 9421,
    "frequency": 2434,
    "originalRank": 9608
  },
  {
    "word": "damien",
    "rank": 9422,
    "frequency": 2434,
    "originalRank": 9609
  },
  {
    "word": "ayuden",
    "rank": 9423,
    "frequency": 2434,
    "originalRank": 9610
  },
  {
    "word": "brien",
    "rank": 9424,
    "frequency": 2434,
    "originalRank": 9611
  },
  {
    "word": "detuvieron",
    "rank": 9425,
    "frequency": 2433,
    "originalRank": 9612
  },
  {
    "word": "mantenlo",
    "rank": 9426,
    "frequency": 2433,
    "originalRank": 9613
  },
  {
    "word": "desgraciados",
    "rank": 9427,
    "frequency": 2433,
    "originalRank": 9614
  },
  {
    "word": "taxista",
    "rank": 9428,
    "frequency": 2432,
    "originalRank": 9615
  },
  {
    "word": "rezando",
    "rank": 9429,
    "frequency": 2431,
    "originalRank": 9616
  },
  {
    "word": "estais",
    "rank": 9430,
    "frequency": 2431,
    "originalRank": 9617
  },
  {
    "word": "tos",
    "rank": 9431,
    "frequency": 2431,
    "originalRank": 9618
  },
  {
    "word": "atentos",
    "rank": 9432,
    "frequency": 2430,
    "originalRank": 9619
  },
  {
    "word": "dondequiera",
    "rank": 9433,
    "frequency": 2430,
    "originalRank": 9620
  },
  {
    "word": "describe",
    "rank": 9434,
    "frequency": 2430,
    "originalRank": 9621
  },
  {
    "word": "jasper",
    "rank": 9435,
    "frequency": 2430,
    "originalRank": 9622
  },
  {
    "word": "insecto",
    "rank": 9436,
    "frequency": 2429,
    "originalRank": 9623
  },
  {
    "word": "propaganda",
    "rank": 9437,
    "frequency": 2428,
    "originalRank": 9625
  },
  {
    "word": "let",
    "rank": 9438,
    "frequency": 2427,
    "originalRank": 9626
  },
  {
    "word": "cantaba",
    "rank": 9439,
    "frequency": 2427,
    "originalRank": 9627
  },
  {
    "word": "carros",
    "rank": 9440,
    "frequency": 2426,
    "originalRank": 9628
  },
  {
    "word": "mudamos",
    "rank": 9441,
    "frequency": 2425,
    "originalRank": 9629
  },
  {
    "word": "iluminación",
    "rank": 9442,
    "frequency": 2425,
    "originalRank": 9630
  },
  {
    "word": "vacuna",
    "rank": 9443,
    "frequency": 2425,
    "originalRank": 9631
  },
  {
    "word": "mantenemos",
    "rank": 9444,
    "frequency": 2424,
    "originalRank": 9632
  },
  {
    "word": "deshacer",
    "rank": 9445,
    "frequency": 2424,
    "originalRank": 9633
  },
  {
    "word": "ironía",
    "rank": 9446,
    "frequency": 2424,
    "originalRank": 9634
  },
  {
    "word": "tregua",
    "rank": 9447,
    "frequency": 2424,
    "originalRank": 9635
  },
  {
    "word": "funcionaba",
    "rank": 9448,
    "frequency": 2423,
    "originalRank": 9636
  },
  {
    "word": "stalin",
    "rank": 9449,
    "frequency": 2423,
    "originalRank": 9637
  },
  {
    "word": "subterráneo",
    "rank": 9450,
    "frequency": 2422,
    "originalRank": 9638
  },
  {
    "word": "determinado",
    "rank": 9451,
    "frequency": 2422,
    "originalRank": 9639
  },
  {
    "word": "divertirme",
    "rank": 9452,
    "frequency": 2422,
    "originalRank": 9640
  },
  {
    "word": "complicaciones",
    "rank": 9453,
    "frequency": 2422,
    "originalRank": 9641
  },
  {
    "word": "devuelva",
    "rank": 9454,
    "frequency": 2421,
    "originalRank": 9642
  },
  {
    "word": "soborno",
    "rank": 9455,
    "frequency": 2421,
    "originalRank": 9643
  },
  {
    "word": "valer",
    "rank": 9456,
    "frequency": 2421,
    "originalRank": 9644
  },
  {
    "word": "alba",
    "rank": 9457,
    "frequency": 2421,
    "originalRank": 9645
  },
  {
    "word": "ame",
    "rank": 9458,
    "frequency": 2420,
    "originalRank": 9646
  },
  {
    "word": "mandaron",
    "rank": 9459,
    "frequency": 2420,
    "originalRank": 9647
  },
  {
    "word": "volcán",
    "rank": 9460,
    "frequency": 2419,
    "originalRank": 9648
  },
  {
    "word": "consumo",
    "rank": 9461,
    "frequency": 2418,
    "originalRank": 9649
  },
  {
    "word": "presionar",
    "rank": 9462,
    "frequency": 2418,
    "originalRank": 9650
  },
  {
    "word": "tontas",
    "rank": 9463,
    "frequency": 2416,
    "originalRank": 9651
  },
  {
    "word": "venderlo",
    "rank": 9464,
    "frequency": 2416,
    "originalRank": 9652
  },
  {
    "word": "antídoto",
    "rank": 9465,
    "frequency": 2415,
    "originalRank": 9653
  },
  {
    "word": "ramera",
    "rank": 9466,
    "frequency": 2415,
    "originalRank": 9654
  },
  {
    "word": "burbujas",
    "rank": 9467,
    "frequency": 2415,
    "originalRank": 9655
  },
  {
    "word": "echarte",
    "rank": 9468,
    "frequency": 2414,
    "originalRank": 9656
  },
  {
    "word": "reportes",
    "rank": 9469,
    "frequency": 2414,
    "originalRank": 9657
  },
  {
    "word": "atraco",
    "rank": 9470,
    "frequency": 2414,
    "originalRank": 9658
  },
  {
    "word": "ciervo",
    "rank": 9471,
    "frequency": 2413,
    "originalRank": 9659
  },
  {
    "word": "críticas",
    "rank": 9472,
    "frequency": 2413,
    "originalRank": 9660
  },
  {
    "word": "vieras",
    "rank": 9473,
    "frequency": 2412,
    "originalRank": 9661
  },
  {
    "word": "belle",
    "rank": 9474,
    "frequency": 2411,
    "originalRank": 9662
  },
  {
    "word": "nápoles",
    "rank": 9475,
    "frequency": 2411,
    "originalRank": 9663
  },
  {
    "word": "hulk",
    "rank": 9476,
    "frequency": 2410,
    "originalRank": 9664
  },
  {
    "word": "intervenir",
    "rank": 9477,
    "frequency": 2409,
    "originalRank": 9665
  },
  {
    "word": "generosidad",
    "rank": 9478,
    "frequency": 2409,
    "originalRank": 9666
  },
  {
    "word": "saldrán",
    "rank": 9479,
    "frequency": 2409,
    "originalRank": 9667
  },
  {
    "word": "mimi",
    "rank": 9480,
    "frequency": 2409,
    "originalRank": 9668
  },
  {
    "word": "bendita",
    "rank": 9481,
    "frequency": 2408,
    "originalRank": 9669
  },
  {
    "word": "defenderse",
    "rank": 9482,
    "frequency": 2408,
    "originalRank": 9670
  },
  {
    "word": "mandan",
    "rank": 9483,
    "frequency": 2408,
    "originalRank": 9671
  },
  {
    "word": "tías",
    "rank": 9484,
    "frequency": 2408,
    "originalRank": 9672
  },
  {
    "word": "sabrina",
    "rank": 9485,
    "frequency": 2407,
    "originalRank": 9673
  },
  {
    "word": "viviré",
    "rank": 9486,
    "frequency": 2407,
    "originalRank": 9674
  },
  {
    "word": "apúrense",
    "rank": 9487,
    "frequency": 2407,
    "originalRank": 9675
  },
  {
    "word": "griegos",
    "rank": 9488,
    "frequency": 2406,
    "originalRank": 9676
  },
  {
    "word": "hot",
    "rank": 9489,
    "frequency": 2405,
    "originalRank": 9677
  },
  {
    "word": "agárrate",
    "rank": 9490,
    "frequency": 2405,
    "originalRank": 9678
  },
  {
    "word": "alejarme",
    "rank": 9491,
    "frequency": 2405,
    "originalRank": 9679
  },
  {
    "word": "madam",
    "rank": 9492,
    "frequency": 2404,
    "originalRank": 9680
  },
  {
    "word": "caña",
    "rank": 9493,
    "frequency": 2403,
    "originalRank": 9681
  },
  {
    "word": "rodaje",
    "rank": 9494,
    "frequency": 2403,
    "originalRank": 9682
  },
  {
    "word": "jun",
    "rank": 9495,
    "frequency": 2403,
    "originalRank": 9683
  },
  {
    "word": "sígame",
    "rank": 9496,
    "frequency": 2402,
    "originalRank": 9684
  },
  {
    "word": "pamela",
    "rank": 9497,
    "frequency": 2402,
    "originalRank": 9685
  },
  {
    "word": "frutos",
    "rank": 9498,
    "frequency": 2402,
    "originalRank": 9686
  },
  {
    "word": "rené",
    "rank": 9499,
    "frequency": 2401,
    "originalRank": 9687
  },
  {
    "word": "importó",
    "rank": 9500,
    "frequency": 2401,
    "originalRank": 9688
  },
  {
    "word": "empleada",
    "rank": 9501,
    "frequency": 2399,
    "originalRank": 9689
  },
  {
    "word": "who",
    "rank": 9502,
    "frequency": 2398,
    "originalRank": 9690
  },
  {
    "word": "radical",
    "rank": 9503,
    "frequency": 2398,
    "originalRank": 9691
  },
  {
    "word": "obstante",
    "rank": 9504,
    "frequency": 2398,
    "originalRank": 9692
  },
  {
    "word": "corté",
    "rank": 9505,
    "frequency": 2397,
    "originalRank": 9693
  },
  {
    "word": "papás",
    "rank": 9506,
    "frequency": 2395,
    "originalRank": 9694
  },
  {
    "word": "hector",
    "rank": 9507,
    "frequency": 2394,
    "originalRank": 9695
  },
  {
    "word": "convirtieron",
    "rank": 9508,
    "frequency": 2394,
    "originalRank": 9696
  },
  {
    "word": "comparar",
    "rank": 9509,
    "frequency": 2394,
    "originalRank": 9697
  },
  {
    "word": "júpiter",
    "rank": 9510,
    "frequency": 2393,
    "originalRank": 9698
  },
  {
    "word": "reunirme",
    "rank": 9511,
    "frequency": 2393,
    "originalRank": 9699
  },
  {
    "word": "nat",
    "rank": 9512,
    "frequency": 2392,
    "originalRank": 9701
  },
  {
    "word": "cemento",
    "rank": 9513,
    "frequency": 2392,
    "originalRank": 9702
  },
  {
    "word": "montaje",
    "rank": 9514,
    "frequency": 2392,
    "originalRank": 9703
  },
  {
    "word": "quité",
    "rank": 9515,
    "frequency": 2391,
    "originalRank": 9704
  },
  {
    "word": "jang",
    "rank": 9516,
    "frequency": 2391,
    "originalRank": 9705
  },
  {
    "word": "espiando",
    "rank": 9517,
    "frequency": 2391,
    "originalRank": 9706
  },
  {
    "word": "pelean",
    "rank": 9518,
    "frequency": 2391,
    "originalRank": 9707
  },
  {
    "word": "tocarme",
    "rank": 9519,
    "frequency": 2390,
    "originalRank": 9708
  },
  {
    "word": "marcharte",
    "rank": 9520,
    "frequency": 2390,
    "originalRank": 9709
  },
  {
    "word": "contraté",
    "rank": 9521,
    "frequency": 2390,
    "originalRank": 9710
  },
  {
    "word": "divierte",
    "rank": 9522,
    "frequency": 2389,
    "originalRank": 9711
  },
  {
    "word": "suposición",
    "rank": 9523,
    "frequency": 2389,
    "originalRank": 9712
  },
  {
    "word": "asegurarte",
    "rank": 9524,
    "frequency": 2389,
    "originalRank": 9713
  },
  {
    "word": "donación",
    "rank": 9525,
    "frequency": 2388,
    "originalRank": 9714
  },
  {
    "word": "formidable",
    "rank": 9526,
    "frequency": 2388,
    "originalRank": 9715
  },
  {
    "word": "elefantes",
    "rank": 9527,
    "frequency": 2387,
    "originalRank": 9716
  },
  {
    "word": "leve",
    "rank": 9528,
    "frequency": 2387,
    "originalRank": 9717
  },
  {
    "word": "conforme",
    "rank": 9529,
    "frequency": 2387,
    "originalRank": 9718
  },
  {
    "word": "estanque",
    "rank": 9530,
    "frequency": 2387,
    "originalRank": 9719
  },
  {
    "word": "celulares",
    "rank": 9531,
    "frequency": 2386,
    "originalRank": 9720
  },
  {
    "word": "clarence",
    "rank": 9532,
    "frequency": 2386,
    "originalRank": 9721
  },
  {
    "word": "françois",
    "rank": 9533,
    "frequency": 2384,
    "originalRank": 9722
  },
  {
    "word": "retiró",
    "rank": 9534,
    "frequency": 2384,
    "originalRank": 9723
  },
  {
    "word": "creencia",
    "rank": 9535,
    "frequency": 2384,
    "originalRank": 9724
  },
  {
    "word": "reunimos",
    "rank": 9536,
    "frequency": 2384,
    "originalRank": 9725
  },
  {
    "word": "acudir",
    "rank": 9537,
    "frequency": 2383,
    "originalRank": 9726
  },
  {
    "word": "amablemente",
    "rank": 9538,
    "frequency": 2383,
    "originalRank": 9727
  },
  {
    "word": "bolígrafo",
    "rank": 9539,
    "frequency": 2383,
    "originalRank": 9728
  },
  {
    "word": "deshacerte",
    "rank": 9540,
    "frequency": 2383,
    "originalRank": 9729
  },
  {
    "word": "encarga",
    "rank": 9541,
    "frequency": 2382,
    "originalRank": 9730
  },
  {
    "word": "hagáis",
    "rank": 9542,
    "frequency": 2382,
    "originalRank": 9731
  },
  {
    "word": "productores",
    "rank": 9543,
    "frequency": 2382,
    "originalRank": 9732
  },
  {
    "word": "valió",
    "rank": 9544,
    "frequency": 2382,
    "originalRank": 9733
  },
  {
    "word": "capas",
    "rank": 9545,
    "frequency": 2381,
    "originalRank": 9734
  },
  {
    "word": "salvando",
    "rank": 9546,
    "frequency": 2381,
    "originalRank": 9735
  },
  {
    "word": "adrenalina",
    "rank": 9547,
    "frequency": 2381,
    "originalRank": 9736
  },
  {
    "word": "gates",
    "rank": 9548,
    "frequency": 2381,
    "originalRank": 9737
  },
  {
    "word": "echemos",
    "rank": 9549,
    "frequency": 2380,
    "originalRank": 9738
  },
  {
    "word": "cuéntanos",
    "rank": 9550,
    "frequency": 2380,
    "originalRank": 9739
  },
  {
    "word": "serviría",
    "rank": 9551,
    "frequency": 2380,
    "originalRank": 9740
  },
  {
    "word": "aléjense",
    "rank": 9552,
    "frequency": 2380,
    "originalRank": 9741
  },
  {
    "word": "respondido",
    "rank": 9553,
    "frequency": 2379,
    "originalRank": 9742
  },
  {
    "word": "hart",
    "rank": 9554,
    "frequency": 2379,
    "originalRank": 9743
  },
  {
    "word": "conciertos",
    "rank": 9555,
    "frequency": 2379,
    "originalRank": 9744
  },
  {
    "word": "publicado",
    "rank": 9556,
    "frequency": 2378,
    "originalRank": 9745
  },
  {
    "word": "extranjera",
    "rank": 9557,
    "frequency": 2378,
    "originalRank": 9746
  },
  {
    "word": "ocuparse",
    "rank": 9558,
    "frequency": 2378,
    "originalRank": 9747
  },
  {
    "word": "paguen",
    "rank": 9559,
    "frequency": 2378,
    "originalRank": 9748
  },
  {
    "word": "alojamiento",
    "rank": 9560,
    "frequency": 2378,
    "originalRank": 9749
  },
  {
    "word": "limpiado",
    "rank": 9561,
    "frequency": 2377,
    "originalRank": 9750
  },
  {
    "word": "traerle",
    "rank": 9562,
    "frequency": 2377,
    "originalRank": 9751
  },
  {
    "word": "luther",
    "rank": 9563,
    "frequency": 2376,
    "originalRank": 9752
  },
  {
    "word": "detenerla",
    "rank": 9564,
    "frequency": 2376,
    "originalRank": 9753
  },
  {
    "word": "forzar",
    "rank": 9565,
    "frequency": 2375,
    "originalRank": 9754
  },
  {
    "word": "inventario",
    "rank": 9566,
    "frequency": 2375,
    "originalRank": 9755
  },
  {
    "word": "sugirió",
    "rank": 9567,
    "frequency": 2375,
    "originalRank": 9756
  },
  {
    "word": "pediría",
    "rank": 9568,
    "frequency": 2375,
    "originalRank": 9757
  },
  {
    "word": "navegación",
    "rank": 9569,
    "frequency": 2374,
    "originalRank": 9758
  },
  {
    "word": "tia",
    "rank": 9570,
    "frequency": 2374,
    "originalRank": 9759
  },
  {
    "word": "okey",
    "rank": 9571,
    "frequency": 2374,
    "originalRank": 9760
  },
  {
    "word": "angelo",
    "rank": 9572,
    "frequency": 2374,
    "originalRank": 9761
  },
  {
    "word": "google",
    "rank": 9573,
    "frequency": 2374,
    "originalRank": 9762
  },
  {
    "word": "panda",
    "rank": 9574,
    "frequency": 2373,
    "originalRank": 9763
  },
  {
    "word": "contable",
    "rank": 9575,
    "frequency": 2373,
    "originalRank": 9764
  },
  {
    "word": "española",
    "rank": 9576,
    "frequency": 2373,
    "originalRank": 9765
  },
  {
    "word": "interrogar",
    "rank": 9577,
    "frequency": 2372,
    "originalRank": 9766
  },
  {
    "word": "ganaron",
    "rank": 9578,
    "frequency": 2371,
    "originalRank": 9767
  },
  {
    "word": "repentinamente",
    "rank": 9579,
    "frequency": 2371,
    "originalRank": 9768
  },
  {
    "word": "genes",
    "rank": 9580,
    "frequency": 2370,
    "originalRank": 9769
  },
  {
    "word": "finge",
    "rank": 9581,
    "frequency": 2370,
    "originalRank": 9770
  },
  {
    "word": "whitney",
    "rank": 9582,
    "frequency": 2370,
    "originalRank": 9771
  },
  {
    "word": "destruyendo",
    "rank": 9583,
    "frequency": 2370,
    "originalRank": 9772
  },
  {
    "word": "eficiente",
    "rank": 9584,
    "frequency": 2370,
    "originalRank": 9773
  },
  {
    "word": "arregle",
    "rank": 9585,
    "frequency": 2369,
    "originalRank": 9774
  },
  {
    "word": "seminario",
    "rank": 9586,
    "frequency": 2369,
    "originalRank": 9775
  },
  {
    "word": "shelby",
    "rank": 9587,
    "frequency": 2369,
    "originalRank": 9776
  },
  {
    "word": "pelirroja",
    "rank": 9588,
    "frequency": 2369,
    "originalRank": 9777
  },
  {
    "word": "happy",
    "rank": 9589,
    "frequency": 2369,
    "originalRank": 9778
  },
  {
    "word": "gibson",
    "rank": 9590,
    "frequency": 2369,
    "originalRank": 9779
  },
  {
    "word": "grandiosa",
    "rank": 9591,
    "frequency": 2368,
    "originalRank": 9780
  },
  {
    "word": "cohetes",
    "rank": 9592,
    "frequency": 2368,
    "originalRank": 9781
  },
  {
    "word": "hughes",
    "rank": 9593,
    "frequency": 2368,
    "originalRank": 9782
  },
  {
    "word": "pantalón",
    "rank": 9594,
    "frequency": 2368,
    "originalRank": 9783
  },
  {
    "word": "lionel",
    "rank": 9595,
    "frequency": 2367,
    "originalRank": 9784
  },
  {
    "word": "celestial",
    "rank": 9596,
    "frequency": 2367,
    "originalRank": 9785
  },
  {
    "word": "gideon",
    "rank": 9597,
    "frequency": 2367,
    "originalRank": 9786
  },
  {
    "word": "mirá",
    "rank": 9598,
    "frequency": 2367,
    "originalRank": 9787
  },
  {
    "word": "sonda",
    "rank": 9599,
    "frequency": 2367,
    "originalRank": 9788
  },
  {
    "word": "secundario",
    "rank": 9600,
    "frequency": 2366,
    "originalRank": 9789
  },
  {
    "word": "ingreso",
    "rank": 9601,
    "frequency": 2366,
    "originalRank": 9790
  },
  {
    "word": "suéltenme",
    "rank": 9602,
    "frequency": 2366,
    "originalRank": 9791
  },
  {
    "word": "maduro",
    "rank": 9603,
    "frequency": 2366,
    "originalRank": 9792
  },
  {
    "word": "apartamentos",
    "rank": 9604,
    "frequency": 2365,
    "originalRank": 9793
  },
  {
    "word": "afrontar",
    "rank": 9605,
    "frequency": 2365,
    "originalRank": 9794
  },
  {
    "word": "esclavitud",
    "rank": 9606,
    "frequency": 2365,
    "originalRank": 9795
  },
  {
    "word": "revisen",
    "rank": 9607,
    "frequency": 2365,
    "originalRank": 9796
  },
  {
    "word": "cesta",
    "rank": 9608,
    "frequency": 2365,
    "originalRank": 9797
  },
  {
    "word": "donnie",
    "rank": 9609,
    "frequency": 2364,
    "originalRank": 9798
  },
  {
    "word": "engañarme",
    "rank": 9610,
    "frequency": 2364,
    "originalRank": 9799
  },
  {
    "word": "muerde",
    "rank": 9611,
    "frequency": 2364,
    "originalRank": 9800
  },
  {
    "word": "ncis",
    "rank": 9612,
    "frequency": 2363,
    "originalRank": 9801
  },
  {
    "word": "pasaportes",
    "rank": 9613,
    "frequency": 2363,
    "originalRank": 9802
  },
  {
    "word": "retira",
    "rank": 9614,
    "frequency": 2362,
    "originalRank": 9803
  },
  {
    "word": "adoptar",
    "rank": 9615,
    "frequency": 2362,
    "originalRank": 9804
  },
  {
    "word": "cuervo",
    "rank": 9616,
    "frequency": 2362,
    "originalRank": 9805
  },
  {
    "word": "fijamente",
    "rank": 9617,
    "frequency": 2362,
    "originalRank": 9806
  },
  {
    "word": "portland",
    "rank": 9618,
    "frequency": 2362,
    "originalRank": 9807
  },
  {
    "word": "art",
    "rank": 9619,
    "frequency": 2361,
    "originalRank": 9808
  },
  {
    "word": "lastimó",
    "rank": 9620,
    "frequency": 2361,
    "originalRank": 9809
  },
  {
    "word": "narcóticos",
    "rank": 9621,
    "frequency": 2361,
    "originalRank": 9810
  },
  {
    "word": "simpática",
    "rank": 9622,
    "frequency": 2360,
    "originalRank": 9811
  },
  {
    "word": "escogió",
    "rank": 9623,
    "frequency": 2360,
    "originalRank": 9812
  },
  {
    "word": "lila",
    "rank": 9624,
    "frequency": 2360,
    "originalRank": 9813
  },
  {
    "word": "clive",
    "rank": 9625,
    "frequency": 2360,
    "originalRank": 9814
  },
  {
    "word": "orientación",
    "rank": 9626,
    "frequency": 2359,
    "originalRank": 9815
  },
  {
    "word": "moon",
    "rank": 9627,
    "frequency": 2359,
    "originalRank": 9816
  },
  {
    "word": "apocalipsis",
    "rank": 9628,
    "frequency": 2358,
    "originalRank": 9817
  },
  {
    "word": "duquesa",
    "rank": 9629,
    "frequency": 2358,
    "originalRank": 9818
  },
  {
    "word": "eun",
    "rank": 9630,
    "frequency": 2357,
    "originalRank": 9819
  },
  {
    "word": "alucinante",
    "rank": 9631,
    "frequency": 2357,
    "originalRank": 9820
  },
  {
    "word": "nombrado",
    "rank": 9632,
    "frequency": 2357,
    "originalRank": 9821
  },
  {
    "word": "paras",
    "rank": 9633,
    "frequency": 2356,
    "originalRank": 9822
  },
  {
    "word": "figuras",
    "rank": 9634,
    "frequency": 2356,
    "originalRank": 9823
  },
  {
    "word": "terminen",
    "rank": 9635,
    "frequency": 2356,
    "originalRank": 9824
  },
  {
    "word": "dom",
    "rank": 9636,
    "frequency": 2356,
    "originalRank": 9825
  },
  {
    "word": "empuje",
    "rank": 9637,
    "frequency": 2355,
    "originalRank": 9826
  },
  {
    "word": "vendes",
    "rank": 9638,
    "frequency": 2355,
    "originalRank": 9827
  },
  {
    "word": "recurso",
    "rank": 9639,
    "frequency": 2354,
    "originalRank": 9829
  },
  {
    "word": "creyeron",
    "rank": 9640,
    "frequency": 2353,
    "originalRank": 9830
  },
  {
    "word": "ramón",
    "rank": 9641,
    "frequency": 2353,
    "originalRank": 9831
  },
  {
    "word": "adicional",
    "rank": 9642,
    "frequency": 2353,
    "originalRank": 9832
  },
  {
    "word": "delhi",
    "rank": 9643,
    "frequency": 2353,
    "originalRank": 9833
  },
  {
    "word": "zombis",
    "rank": 9644,
    "frequency": 2353,
    "originalRank": 9834
  },
  {
    "word": "turco",
    "rank": 9645,
    "frequency": 2353,
    "originalRank": 9835
  },
  {
    "word": "frijoles",
    "rank": 9646,
    "frequency": 2353,
    "originalRank": 9836
  },
  {
    "word": "internacionales",
    "rank": 9647,
    "frequency": 2353,
    "originalRank": 9837
  },
  {
    "word": "discutirlo",
    "rank": 9648,
    "frequency": 2352,
    "originalRank": 9838
  },
  {
    "word": "cebo",
    "rank": 9649,
    "frequency": 2352,
    "originalRank": 9839
  },
  {
    "word": "exijo",
    "rank": 9650,
    "frequency": 2352,
    "originalRank": 9840
  },
  {
    "word": "pesados",
    "rank": 9651,
    "frequency": 2352,
    "originalRank": 9841
  },
  {
    "word": "caía",
    "rank": 9652,
    "frequency": 2352,
    "originalRank": 9842
  },
  {
    "word": "presentarle",
    "rank": 9653,
    "frequency": 2352,
    "originalRank": 9843
  },
  {
    "word": "life",
    "rank": 9654,
    "frequency": 2351,
    "originalRank": 9844
  },
  {
    "word": "echen",
    "rank": 9655,
    "frequency": 2351,
    "originalRank": 9845
  },
  {
    "word": "dobles",
    "rank": 9656,
    "frequency": 2351,
    "originalRank": 9846
  },
  {
    "word": "peyton",
    "rank": 9657,
    "frequency": 2351,
    "originalRank": 9847
  },
  {
    "word": "músculo",
    "rank": 9658,
    "frequency": 2351,
    "originalRank": 9848
  },
  {
    "word": "mack",
    "rank": 9659,
    "frequency": 2351,
    "originalRank": 9849
  },
  {
    "word": "edith",
    "rank": 9660,
    "frequency": 2350,
    "originalRank": 9850
  },
  {
    "word": "existido",
    "rank": 9661,
    "frequency": 2350,
    "originalRank": 9851
  },
  {
    "word": "harriet",
    "rank": 9662,
    "frequency": 2349,
    "originalRank": 9852
  },
  {
    "word": "trataste",
    "rank": 9663,
    "frequency": 2349,
    "originalRank": 9853
  },
  {
    "word": "apágalo",
    "rank": 9664,
    "frequency": 2349,
    "originalRank": 9854
  },
  {
    "word": "contabilidad",
    "rank": 9665,
    "frequency": 2349,
    "originalRank": 9855
  },
  {
    "word": "ganarme",
    "rank": 9666,
    "frequency": 2349,
    "originalRank": 9856
  },
  {
    "word": "deshacernos",
    "rank": 9667,
    "frequency": 2348,
    "originalRank": 9857
  },
  {
    "word": "redada",
    "rank": 9668,
    "frequency": 2348,
    "originalRank": 9858
  },
  {
    "word": "oportuno",
    "rank": 9669,
    "frequency": 2348,
    "originalRank": 9859
  },
  {
    "word": "jardines",
    "rank": 9670,
    "frequency": 2347,
    "originalRank": 9860
  },
  {
    "word": "vega",
    "rank": 9671,
    "frequency": 2346,
    "originalRank": 9861
  },
  {
    "word": "preguntaron",
    "rank": 9672,
    "frequency": 2346,
    "originalRank": 9862
  },
  {
    "word": "tate",
    "rank": 9673,
    "frequency": 2345,
    "originalRank": 9863
  },
  {
    "word": "ordenadores",
    "rank": 9674,
    "frequency": 2345,
    "originalRank": 9864
  },
  {
    "word": "chile",
    "rank": 9675,
    "frequency": 2345,
    "originalRank": 9865
  },
  {
    "word": "janice",
    "rank": 9676,
    "frequency": 2345,
    "originalRank": 9866
  },
  {
    "word": "aceptan",
    "rank": 9677,
    "frequency": 2345,
    "originalRank": 9867
  },
  {
    "word": "henri",
    "rank": 9678,
    "frequency": 2345,
    "originalRank": 9868
  },
  {
    "word": "caros",
    "rank": 9679,
    "frequency": 2345,
    "originalRank": 9869
  },
  {
    "word": "sophia",
    "rank": 9680,
    "frequency": 2344,
    "originalRank": 9870
  },
  {
    "word": "locuras",
    "rank": 9681,
    "frequency": 2344,
    "originalRank": 9871
  },
  {
    "word": "setenta",
    "rank": 9682,
    "frequency": 2344,
    "originalRank": 9872
  },
  {
    "word": "alf",
    "rank": 9683,
    "frequency": 2343,
    "originalRank": 9873
  },
  {
    "word": "suceden",
    "rank": 9684,
    "frequency": 2343,
    "originalRank": 9874
  },
  {
    "word": "caderas",
    "rank": 9685,
    "frequency": 2343,
    "originalRank": 9875
  },
  {
    "word": "hayes",
    "rank": 9686,
    "frequency": 2343,
    "originalRank": 9876
  },
  {
    "word": "buque",
    "rank": 9687,
    "frequency": 2343,
    "originalRank": 9877
  },
  {
    "word": "nana",
    "rank": 9688,
    "frequency": 2342,
    "originalRank": 9878
  },
  {
    "word": "reconocí",
    "rank": 9689,
    "frequency": 2342,
    "originalRank": 9879
  },
  {
    "word": "suegra",
    "rank": 9690,
    "frequency": 2342,
    "originalRank": 9880
  },
  {
    "word": "apuntar",
    "rank": 9691,
    "frequency": 2342,
    "originalRank": 9881
  },
  {
    "word": "alejarse",
    "rank": 9692,
    "frequency": 2341,
    "originalRank": 9882
  },
  {
    "word": "ceder",
    "rank": 9693,
    "frequency": 2341,
    "originalRank": 9883
  },
  {
    "word": "encerrados",
    "rank": 9694,
    "frequency": 2340,
    "originalRank": 9884
  },
  {
    "word": "pintado",
    "rank": 9695,
    "frequency": 2340,
    "originalRank": 9885
  },
  {
    "word": "crezca",
    "rank": 9696,
    "frequency": 2340,
    "originalRank": 9886
  },
  {
    "word": "hospitalidad",
    "rank": 9697,
    "frequency": 2340,
    "originalRank": 9887
  },
  {
    "word": "henderson",
    "rank": 9698,
    "frequency": 2339,
    "originalRank": 9888
  },
  {
    "word": "atleta",
    "rank": 9699,
    "frequency": 2339,
    "originalRank": 9889
  },
  {
    "word": "arruiné",
    "rank": 9700,
    "frequency": 2339,
    "originalRank": 9890
  },
  {
    "word": "convencerme",
    "rank": 9701,
    "frequency": 2338,
    "originalRank": 9891
  },
  {
    "word": "escritora",
    "rank": 9702,
    "frequency": 2338,
    "originalRank": 9892
  },
  {
    "word": "devon",
    "rank": 9703,
    "frequency": 2337,
    "originalRank": 9893
  },
  {
    "word": "poste",
    "rank": 9704,
    "frequency": 2337,
    "originalRank": 9894
  },
  {
    "word": "bryan",
    "rank": 9705,
    "frequency": 2337,
    "originalRank": 9895
  },
  {
    "word": "acogida",
    "rank": 9706,
    "frequency": 2336,
    "originalRank": 9896
  },
  {
    "word": "mermelada",
    "rank": 9707,
    "frequency": 2336,
    "originalRank": 9897
  },
  {
    "word": "injusticia",
    "rank": 9708,
    "frequency": 2336,
    "originalRank": 9898
  },
  {
    "word": "ficha",
    "rank": 9709,
    "frequency": 2336,
    "originalRank": 9899
  },
  {
    "word": "reno",
    "rank": 9710,
    "frequency": 2336,
    "originalRank": 9900
  },
  {
    "word": "granos",
    "rank": 9711,
    "frequency": 2335,
    "originalRank": 9901
  },
  {
    "word": "tendréis",
    "rank": 9712,
    "frequency": 2334,
    "originalRank": 9902
  },
  {
    "word": "obstáculos",
    "rank": 9713,
    "frequency": 2333,
    "originalRank": 9903
  },
  {
    "word": "golpeaste",
    "rank": 9714,
    "frequency": 2333,
    "originalRank": 9904
  },
  {
    "word": "gobernar",
    "rank": 9715,
    "frequency": 2333,
    "originalRank": 9905
  },
  {
    "word": "peligros",
    "rank": 9716,
    "frequency": 2333,
    "originalRank": 9906
  },
  {
    "word": "intensa",
    "rank": 9717,
    "frequency": 2333,
    "originalRank": 9907
  },
  {
    "word": "lema",
    "rank": 9718,
    "frequency": 2331,
    "originalRank": 9908
  },
  {
    "word": "despejen",
    "rank": 9719,
    "frequency": 2331,
    "originalRank": 9909
  },
  {
    "word": "intentándolo",
    "rank": 9720,
    "frequency": 2331,
    "originalRank": 9910
  },
  {
    "word": "alejada",
    "rank": 9721,
    "frequency": 2330,
    "originalRank": 9911
  },
  {
    "word": "reducido",
    "rank": 9722,
    "frequency": 2330,
    "originalRank": 9912
  },
  {
    "word": "inauguración",
    "rank": 9723,
    "frequency": 2330,
    "originalRank": 9913
  },
  {
    "word": "muda",
    "rank": 9724,
    "frequency": 2330,
    "originalRank": 9914
  },
  {
    "word": "tope",
    "rank": 9725,
    "frequency": 2330,
    "originalRank": 9915
  },
  {
    "word": "terminas",
    "rank": 9726,
    "frequency": 2330,
    "originalRank": 9916
  },
  {
    "word": "móviles",
    "rank": 9727,
    "frequency": 2330,
    "originalRank": 9917
  },
  {
    "word": "dirigiendo",
    "rank": 9728,
    "frequency": 2329,
    "originalRank": 9918
  },
  {
    "word": "pagaste",
    "rank": 9729,
    "frequency": 2329,
    "originalRank": 9919
  },
  {
    "word": "podrido",
    "rank": 9730,
    "frequency": 2329,
    "originalRank": 9920
  },
  {
    "word": "mula",
    "rank": 9731,
    "frequency": 2327,
    "originalRank": 9921
  },
  {
    "word": "necesitáis",
    "rank": 9732,
    "frequency": 2327,
    "originalRank": 9922
  },
  {
    "word": "powell",
    "rank": 9733,
    "frequency": 2326,
    "originalRank": 9923
  },
  {
    "word": "variedad",
    "rank": 9734,
    "frequency": 2326,
    "originalRank": 9924
  },
  {
    "word": "hubiesen",
    "rank": 9735,
    "frequency": 2326,
    "originalRank": 9925
  },
  {
    "word": "llévala",
    "rank": 9736,
    "frequency": 2326,
    "originalRank": 9926
  },
  {
    "word": "azotea",
    "rank": 9737,
    "frequency": 2326,
    "originalRank": 9927
  },
  {
    "word": "cóctel",
    "rank": 9738,
    "frequency": 2325,
    "originalRank": 9928
  },
  {
    "word": "tripas",
    "rank": 9739,
    "frequency": 2325,
    "originalRank": 9929
  },
  {
    "word": "tocarlo",
    "rank": 9740,
    "frequency": 2325,
    "originalRank": 9930
  },
  {
    "word": "díganme",
    "rank": 9741,
    "frequency": 2325,
    "originalRank": 9931
  },
  {
    "word": "regresaremos",
    "rank": 9742,
    "frequency": 2324,
    "originalRank": 9932
  },
  {
    "word": "biología",
    "rank": 9743,
    "frequency": 2324,
    "originalRank": 9933
  },
  {
    "word": "julien",
    "rank": 9744,
    "frequency": 2324,
    "originalRank": 9934
  },
  {
    "word": "galaxias",
    "rank": 9745,
    "frequency": 2324,
    "originalRank": 9935
  },
  {
    "word": "correctas",
    "rank": 9746,
    "frequency": 2322,
    "originalRank": 9936
  },
  {
    "word": "atrapamos",
    "rank": 9747,
    "frequency": 2322,
    "originalRank": 9937
  },
  {
    "word": "pillar",
    "rank": 9748,
    "frequency": 2322,
    "originalRank": 9938
  },
  {
    "word": "lecturas",
    "rank": 9749,
    "frequency": 2322,
    "originalRank": 9939
  },
  {
    "word": "populares",
    "rank": 9750,
    "frequency": 2322,
    "originalRank": 9940
  },
  {
    "word": "luchó",
    "rank": 9751,
    "frequency": 2321,
    "originalRank": 9941
  },
  {
    "word": "luto",
    "rank": 9752,
    "frequency": 2321,
    "originalRank": 9942
  },
  {
    "word": "rafael",
    "rank": 9753,
    "frequency": 2321,
    "originalRank": 9943
  },
  {
    "word": "thor",
    "rank": 9754,
    "frequency": 2320,
    "originalRank": 9944
  },
  {
    "word": "terminaré",
    "rank": 9755,
    "frequency": 2320,
    "originalRank": 9945
  },
  {
    "word": "ayudarás",
    "rank": 9756,
    "frequency": 2319,
    "originalRank": 9946
  },
  {
    "word": "agarre",
    "rank": 9757,
    "frequency": 2319,
    "originalRank": 9947
  },
  {
    "word": "corres",
    "rank": 9758,
    "frequency": 2317,
    "originalRank": 9948
  },
  {
    "word": "reactor",
    "rank": 9759,
    "frequency": 2316,
    "originalRank": 9949
  },
  {
    "word": "kilómetro",
    "rank": 9760,
    "frequency": 2316,
    "originalRank": 9950
  },
  {
    "word": "demostrarlo",
    "rank": 9761,
    "frequency": 2316,
    "originalRank": 9951
  },
  {
    "word": "háganlo",
    "rank": 9762,
    "frequency": 2316,
    "originalRank": 9952
  },
  {
    "word": "dígales",
    "rank": 9763,
    "frequency": 2315,
    "originalRank": 9953
  },
  {
    "word": "gerry",
    "rank": 9764,
    "frequency": 2315,
    "originalRank": 9954
  },
  {
    "word": "comiencen",
    "rank": 9765,
    "frequency": 2313,
    "originalRank": 9955
  },
  {
    "word": "entrará",
    "rank": 9766,
    "frequency": 2313,
    "originalRank": 9956
  },
  {
    "word": "bonos",
    "rank": 9767,
    "frequency": 2312,
    "originalRank": 9957
  },
  {
    "word": "veronica",
    "rank": 9768,
    "frequency": 2312,
    "originalRank": 9958
  },
  {
    "word": "edwards",
    "rank": 9769,
    "frequency": 2311,
    "originalRank": 9959
  },
  {
    "word": "despidió",
    "rank": 9770,
    "frequency": 2311,
    "originalRank": 9960
  },
  {
    "word": "spa",
    "rank": 9771,
    "frequency": 2310,
    "originalRank": 9961
  },
  {
    "word": "centros",
    "rank": 9772,
    "frequency": 2310,
    "originalRank": 9962
  },
  {
    "word": "puños",
    "rank": 9773,
    "frequency": 2310,
    "originalRank": 9963
  },
  {
    "word": "martini",
    "rank": 9774,
    "frequency": 2309,
    "originalRank": 9964
  },
  {
    "word": "holt",
    "rank": 9775,
    "frequency": 2309,
    "originalRank": 9965
  },
  {
    "word": "cuidarte",
    "rank": 9776,
    "frequency": 2309,
    "originalRank": 9966
  },
  {
    "word": "visitante",
    "rank": 9777,
    "frequency": 2309,
    "originalRank": 9967
  },
  {
    "word": "newton",
    "rank": 9778,
    "frequency": 2309,
    "originalRank": 9968
  },
  {
    "word": "enteras",
    "rank": 9779,
    "frequency": 2308,
    "originalRank": 9969
  },
  {
    "word": "patos",
    "rank": 9780,
    "frequency": 2308,
    "originalRank": 9970
  },
  {
    "word": "laboral",
    "rank": 9781,
    "frequency": 2308,
    "originalRank": 9971
  },
  {
    "word": "molestarme",
    "rank": 9782,
    "frequency": 2307,
    "originalRank": 9972
  },
  {
    "word": "apestoso",
    "rank": 9783,
    "frequency": 2307,
    "originalRank": 9973
  },
  {
    "word": "agradecidos",
    "rank": 9784,
    "frequency": 2307,
    "originalRank": 9974
  },
  {
    "word": "acera",
    "rank": 9785,
    "frequency": 2307,
    "originalRank": 9975
  },
  {
    "word": "hombrecito",
    "rank": 9786,
    "frequency": 2307,
    "originalRank": 9976
  },
  {
    "word": "potente",
    "rank": 9787,
    "frequency": 2307,
    "originalRank": 9977
  },
  {
    "word": "bombardeo",
    "rank": 9788,
    "frequency": 2307,
    "originalRank": 9978
  },
  {
    "word": "gritaba",
    "rank": 9789,
    "frequency": 2306,
    "originalRank": 9979
  },
  {
    "word": "borrado",
    "rank": 9790,
    "frequency": 2306,
    "originalRank": 9980
  },
  {
    "word": "enterarse",
    "rank": 9791,
    "frequency": 2305,
    "originalRank": 9981
  },
  {
    "word": "becca",
    "rank": 9792,
    "frequency": 2305,
    "originalRank": 9982
  },
  {
    "word": "irrelevante",
    "rank": 9793,
    "frequency": 2305,
    "originalRank": 9983
  },
  {
    "word": "pakistán",
    "rank": 9794,
    "frequency": 2305,
    "originalRank": 9984
  },
  {
    "word": "guarida",
    "rank": 9795,
    "frequency": 2305,
    "originalRank": 9985
  },
  {
    "word": "acompañar",
    "rank": 9796,
    "frequency": 2305,
    "originalRank": 9986
  },
  {
    "word": "tendencia",
    "rank": 9797,
    "frequency": 2305,
    "originalRank": 9987
  },
  {
    "word": "vacíos",
    "rank": 9798,
    "frequency": 2304,
    "originalRank": 9988
  },
  {
    "word": "pasarán",
    "rank": 9799,
    "frequency": 2304,
    "originalRank": 9989
  },
  {
    "word": "católico",
    "rank": 9800,
    "frequency": 2304,
    "originalRank": 9990
  },
  {
    "word": "comenzará",
    "rank": 9801,
    "frequency": 2303,
    "originalRank": 9991
  },
  {
    "word": "descifrar",
    "rank": 9802,
    "frequency": 2302,
    "originalRank": 9992
  },
  {
    "word": "brazalete",
    "rank": 9803,
    "frequency": 2301,
    "originalRank": 9993
  },
  {
    "word": "profecía",
    "rank": 9804,
    "frequency": 2300,
    "originalRank": 9994
  },
  {
    "word": "paseando",
    "rank": 9805,
    "frequency": 2300,
    "originalRank": 9995
  },
  {
    "word": "briggs",
    "rank": 9806,
    "frequency": 2300,
    "originalRank": 9996
  },
  {
    "word": "intentaremos",
    "rank": 9807,
    "frequency": 2299,
    "originalRank": 9997
  },
  {
    "word": "protegerlo",
    "rank": 9808,
    "frequency": 2298,
    "originalRank": 9998
  },
  {
    "word": "insensible",
    "rank": 9809,
    "frequency": 2298,
    "originalRank": 9999
  },
  {
    "word": "pruébalo",
    "rank": 9810,
    "frequency": 2298,
    "originalRank": 10000
  },
  {
    "word": "obligados",
    "rank": 9811,
    "frequency": 2298,
    "originalRank": 10001
  },
  {
    "word": "seguirás",
    "rank": 9812,
    "frequency": 2297,
    "originalRank": 10002
  },
  {
    "word": "consigas",
    "rank": 9813,
    "frequency": 2297,
    "originalRank": 10003
  },
  {
    "word": "extensión",
    "rank": 9814,
    "frequency": 2297,
    "originalRank": 10004
  },
  {
    "word": "niñez",
    "rank": 9815,
    "frequency": 2295,
    "originalRank": 10005
  },
  {
    "word": "voluntariamente",
    "rank": 9816,
    "frequency": 2294,
    "originalRank": 10006
  },
  {
    "word": "parrilla",
    "rank": 9817,
    "frequency": 2294,
    "originalRank": 10007
  },
  {
    "word": "marineros",
    "rank": 9818,
    "frequency": 2294,
    "originalRank": 10008
  },
  {
    "word": "benson",
    "rank": 9819,
    "frequency": 2294,
    "originalRank": 10009
  },
  {
    "word": "jura",
    "rank": 9820,
    "frequency": 2294,
    "originalRank": 10010
  },
  {
    "word": "pegamento",
    "rank": 9821,
    "frequency": 2294,
    "originalRank": 10011
  },
  {
    "word": "supieran",
    "rank": 9822,
    "frequency": 2294,
    "originalRank": 10012
  },
  {
    "word": "cuestan",
    "rank": 9823,
    "frequency": 2293,
    "originalRank": 10013
  },
  {
    "word": "georgie",
    "rank": 9824,
    "frequency": 2293,
    "originalRank": 10014
  },
  {
    "word": "anochecer",
    "rank": 9825,
    "frequency": 2293,
    "originalRank": 10015
  },
  {
    "word": "ronald",
    "rank": 9826,
    "frequency": 2293,
    "originalRank": 10016
  },
  {
    "word": "volverme",
    "rank": 9827,
    "frequency": 2292,
    "originalRank": 10017
  },
  {
    "word": "porcentaje",
    "rank": 9828,
    "frequency": 2291,
    "originalRank": 10018
  },
  {
    "word": "stu",
    "rank": 9829,
    "frequency": 2291,
    "originalRank": 10019
  },
  {
    "word": "dañar",
    "rank": 9830,
    "frequency": 2291,
    "originalRank": 10020
  },
  {
    "word": "pálido",
    "rank": 9831,
    "frequency": 2291,
    "originalRank": 10021
  },
  {
    "word": "cuido",
    "rank": 9832,
    "frequency": 2290,
    "originalRank": 10022
  },
  {
    "word": "impuesto",
    "rank": 9833,
    "frequency": 2290,
    "originalRank": 10023
  },
  {
    "word": "lucía",
    "rank": 9834,
    "frequency": 2290,
    "originalRank": 10024
  },
  {
    "word": "veteranos",
    "rank": 9835,
    "frequency": 2289,
    "originalRank": 10025
  },
  {
    "word": "dese",
    "rank": 9836,
    "frequency": 2288,
    "originalRank": 10026
  },
  {
    "word": "justos",
    "rank": 9837,
    "frequency": 2288,
    "originalRank": 10027
  },
  {
    "word": "besarme",
    "rank": 9838,
    "frequency": 2288,
    "originalRank": 10028
  },
  {
    "word": "sensibilidad",
    "rank": 9839,
    "frequency": 2288,
    "originalRank": 10029
  },
  {
    "word": "prefieren",
    "rank": 9840,
    "frequency": 2286,
    "originalRank": 10030
  },
  {
    "word": "diciéndole",
    "rank": 9841,
    "frequency": 2286,
    "originalRank": 10031
  },
  {
    "word": "golfo",
    "rank": 9842,
    "frequency": 2285,
    "originalRank": 10032
  },
  {
    "word": "mills",
    "rank": 9843,
    "frequency": 2284,
    "originalRank": 10035
  },
  {
    "word": "tiren",
    "rank": 9844,
    "frequency": 2284,
    "originalRank": 10036
  },
  {
    "word": "negociación",
    "rank": 9845,
    "frequency": 2284,
    "originalRank": 10037
  },
  {
    "word": "presionando",
    "rank": 9846,
    "frequency": 2283,
    "originalRank": 10038
  },
  {
    "word": "calmarte",
    "rank": 9847,
    "frequency": 2283,
    "originalRank": 10039
  },
  {
    "word": "prepararme",
    "rank": 9848,
    "frequency": 2283,
    "originalRank": 10040
  },
  {
    "word": "darren",
    "rank": 9849,
    "frequency": 2282,
    "originalRank": 10041
  },
  {
    "word": "disfrutado",
    "rank": 9850,
    "frequency": 2282,
    "originalRank": 10042
  },
  {
    "word": "apresúrate",
    "rank": 9851,
    "frequency": 2281,
    "originalRank": 10043
  },
  {
    "word": "desacuerdo",
    "rank": 9852,
    "frequency": 2281,
    "originalRank": 10044
  },
  {
    "word": "hallé",
    "rank": 9853,
    "frequency": 2281,
    "originalRank": 10045
  },
  {
    "word": "modesto",
    "rank": 9854,
    "frequency": 2280,
    "originalRank": 10046
  },
  {
    "word": "atajo",
    "rank": 9855,
    "frequency": 2280,
    "originalRank": 10047
  },
  {
    "word": "recogido",
    "rank": 9856,
    "frequency": 2280,
    "originalRank": 10048
  },
  {
    "word": "cambiaré",
    "rank": 9857,
    "frequency": 2279,
    "originalRank": 10049
  },
  {
    "word": "flechas",
    "rank": 9858,
    "frequency": 2279,
    "originalRank": 10050
  },
  {
    "word": "rapidez",
    "rank": 9859,
    "frequency": 2279,
    "originalRank": 10051
  },
  {
    "word": "enseñan",
    "rank": 9860,
    "frequency": 2279,
    "originalRank": 10052
  },
  {
    "word": "sucediera",
    "rank": 9861,
    "frequency": 2279,
    "originalRank": 10053
  },
  {
    "word": "fibra",
    "rank": 9862,
    "frequency": 2278,
    "originalRank": 10054
  },
  {
    "word": "granjeros",
    "rank": 9863,
    "frequency": 2278,
    "originalRank": 10055
  },
  {
    "word": "giovanni",
    "rank": 9864,
    "frequency": 2278,
    "originalRank": 10056
  },
  {
    "word": "julieta",
    "rank": 9865,
    "frequency": 2278,
    "originalRank": 10057
  },
  {
    "word": "suciedad",
    "rank": 9866,
    "frequency": 2278,
    "originalRank": 10058
  },
  {
    "word": "peterson",
    "rank": 9867,
    "frequency": 2278,
    "originalRank": 10059
  },
  {
    "word": "abrirlo",
    "rank": 9868,
    "frequency": 2278,
    "originalRank": 10060
  },
  {
    "word": "rendirse",
    "rank": 9869,
    "frequency": 2278,
    "originalRank": 10061
  },
  {
    "word": "stop",
    "rank": 9870,
    "frequency": 2277,
    "originalRank": 10062
  },
  {
    "word": "obama",
    "rank": 9871,
    "frequency": 2277,
    "originalRank": 10063
  },
  {
    "word": "deliberadamente",
    "rank": 9872,
    "frequency": 2277,
    "originalRank": 10064
  },
  {
    "word": "esconderte",
    "rank": 9873,
    "frequency": 2277,
    "originalRank": 10065
  },
  {
    "word": "olvídelo",
    "rank": 9874,
    "frequency": 2277,
    "originalRank": 10066
  },
  {
    "word": "ingenieros",
    "rank": 9875,
    "frequency": 2277,
    "originalRank": 10067
  },
  {
    "word": "relacionados",
    "rank": 9876,
    "frequency": 2276,
    "originalRank": 10068
  },
  {
    "word": "plasma",
    "rank": 9877,
    "frequency": 2276,
    "originalRank": 10069
  },
  {
    "word": "puros",
    "rank": 9878,
    "frequency": 2276,
    "originalRank": 10070
  },
  {
    "word": "demandar",
    "rank": 9879,
    "frequency": 2275,
    "originalRank": 10071
  },
  {
    "word": "llanto",
    "rank": 9880,
    "frequency": 2275,
    "originalRank": 10072
  },
  {
    "word": "tarado",
    "rank": 9881,
    "frequency": 2275,
    "originalRank": 10073
  },
  {
    "word": "necesarios",
    "rank": 9882,
    "frequency": 2275,
    "originalRank": 10074
  },
  {
    "word": "mae",
    "rank": 9883,
    "frequency": 2275,
    "originalRank": 10075
  },
  {
    "word": "suponiendo",
    "rank": 9884,
    "frequency": 2275,
    "originalRank": 10076
  },
  {
    "word": "sustituto",
    "rank": 9885,
    "frequency": 2274,
    "originalRank": 10077
  },
  {
    "word": "ansiosa",
    "rank": 9886,
    "frequency": 2274,
    "originalRank": 10078
  },
  {
    "word": "dejarías",
    "rank": 9887,
    "frequency": 2273,
    "originalRank": 10079
  },
  {
    "word": "soplón",
    "rank": 9888,
    "frequency": 2273,
    "originalRank": 10080
  },
  {
    "word": "jade",
    "rank": 9889,
    "frequency": 2273,
    "originalRank": 10081
  },
  {
    "word": "cohen",
    "rank": 9890,
    "frequency": 2272,
    "originalRank": 10082
  },
  {
    "word": "remolque",
    "rank": 9891,
    "frequency": 2272,
    "originalRank": 10083
  },
  {
    "word": "peleado",
    "rank": 9892,
    "frequency": 2272,
    "originalRank": 10084
  },
  {
    "word": "adelanto",
    "rank": 9893,
    "frequency": 2272,
    "originalRank": 10085
  },
  {
    "word": "pasados",
    "rank": 9894,
    "frequency": 2271,
    "originalRank": 10086
  },
  {
    "word": "envidio",
    "rank": 9895,
    "frequency": 2271,
    "originalRank": 10087
  },
  {
    "word": "relájese",
    "rank": 9896,
    "frequency": 2271,
    "originalRank": 10088
  },
  {
    "word": "presiona",
    "rank": 9897,
    "frequency": 2270,
    "originalRank": 10089
  },
  {
    "word": "reclamar",
    "rank": 9898,
    "frequency": 2270,
    "originalRank": 10090
  },
  {
    "word": "supera",
    "rank": 9899,
    "frequency": 2269,
    "originalRank": 10091
  },
  {
    "word": "importara",
    "rank": 9900,
    "frequency": 2269,
    "originalRank": 10092
  },
  {
    "word": "condujo",
    "rank": 9901,
    "frequency": 2269,
    "originalRank": 10093
  },
  {
    "word": "infantería",
    "rank": 9902,
    "frequency": 2269,
    "originalRank": 10094
  },
  {
    "word": "presentarse",
    "rank": 9903,
    "frequency": 2269,
    "originalRank": 10095
  },
  {
    "word": "nuca",
    "rank": 9904,
    "frequency": 2268,
    "originalRank": 10096
  },
  {
    "word": "ayúdanos",
    "rank": 9905,
    "frequency": 2268,
    "originalRank": 10097
  },
  {
    "word": "aprendiz",
    "rank": 9906,
    "frequency": 2268,
    "originalRank": 10098
  },
  {
    "word": "trueno",
    "rank": 9907,
    "frequency": 2268,
    "originalRank": 10099
  },
  {
    "word": "operativo",
    "rank": 9908,
    "frequency": 2268,
    "originalRank": 10100
  },
  {
    "word": "adán",
    "rank": 9909,
    "frequency": 2268,
    "originalRank": 10101
  },
  {
    "word": "discreto",
    "rank": 9910,
    "frequency": 2268,
    "originalRank": 10102
  },
  {
    "word": "procedimientos",
    "rank": 9911,
    "frequency": 2268,
    "originalRank": 10103
  },
  {
    "word": "típica",
    "rank": 9912,
    "frequency": 2268,
    "originalRank": 10104
  },
  {
    "word": "anónimo",
    "rank": 9913,
    "frequency": 2267,
    "originalRank": 10105
  },
  {
    "word": "enviados",
    "rank": 9914,
    "frequency": 2267,
    "originalRank": 10106
  },
  {
    "word": "molino",
    "rank": 9915,
    "frequency": 2267,
    "originalRank": 10107
  },
  {
    "word": "senor",
    "rank": 9916,
    "frequency": 2267,
    "originalRank": 10108
  },
  {
    "word": "despedirte",
    "rank": 9917,
    "frequency": 2267,
    "originalRank": 10109
  },
  {
    "word": "alcohólico",
    "rank": 9918,
    "frequency": 2266,
    "originalRank": 10110
  },
  {
    "word": "dispárale",
    "rank": 9919,
    "frequency": 2266,
    "originalRank": 10111
  },
  {
    "word": "desaparecen",
    "rank": 9920,
    "frequency": 2265,
    "originalRank": 10112
  },
  {
    "word": "night",
    "rank": 9921,
    "frequency": 2265,
    "originalRank": 10113
  },
  {
    "word": "corrientes",
    "rank": 9922,
    "frequency": 2264,
    "originalRank": 10114
  },
  {
    "word": "hábil",
    "rank": 9923,
    "frequency": 2264,
    "originalRank": 10115
  },
  {
    "word": "sacerdotes",
    "rank": 9924,
    "frequency": 2264,
    "originalRank": 10116
  },
  {
    "word": "borda",
    "rank": 9925,
    "frequency": 2263,
    "originalRank": 10117
  },
  {
    "word": "vendemos",
    "rank": 9926,
    "frequency": 2263,
    "originalRank": 10118
  },
  {
    "word": "suspensión",
    "rank": 9927,
    "frequency": 2262,
    "originalRank": 10119
  },
  {
    "word": "echan",
    "rank": 9928,
    "frequency": 2262,
    "originalRank": 10120
  },
  {
    "word": "sutton",
    "rank": 9929,
    "frequency": 2262,
    "originalRank": 10121
  },
  {
    "word": "laboratorios",
    "rank": 9930,
    "frequency": 2262,
    "originalRank": 10122
  },
  {
    "word": "expulsar",
    "rank": 9931,
    "frequency": 2262,
    "originalRank": 10123
  },
  {
    "word": "médula",
    "rank": 9932,
    "frequency": 2261,
    "originalRank": 10124
  },
  {
    "word": "crawford",
    "rank": 9933,
    "frequency": 2261,
    "originalRank": 10125
  },
  {
    "word": "blando",
    "rank": 9934,
    "frequency": 2261,
    "originalRank": 10126
  },
  {
    "word": "opera",
    "rank": 9935,
    "frequency": 2260,
    "originalRank": 10127
  },
  {
    "word": "librería",
    "rank": 9936,
    "frequency": 2260,
    "originalRank": 10128
  },
  {
    "word": "importas",
    "rank": 9937,
    "frequency": 2260,
    "originalRank": 10129
  },
  {
    "word": "enviaremos",
    "rank": 9938,
    "frequency": 2259,
    "originalRank": 10130
  },
  {
    "word": "bam",
    "rank": 9939,
    "frequency": 2259,
    "originalRank": 10131
  },
  {
    "word": "tiffany",
    "rank": 9940,
    "frequency": 2259,
    "originalRank": 10132
  },
  {
    "word": "patética",
    "rank": 9941,
    "frequency": 2259,
    "originalRank": 10133
  },
  {
    "word": "divertirte",
    "rank": 9942,
    "frequency": 2259,
    "originalRank": 10134
  },
  {
    "word": "gustos",
    "rank": 9943,
    "frequency": 2258,
    "originalRank": 10135
  },
  {
    "word": "podriamos",
    "rank": 9944,
    "frequency": 2258,
    "originalRank": 10136
  },
  {
    "word": "trío",
    "rank": 9945,
    "frequency": 2257,
    "originalRank": 10137
  },
  {
    "word": "violado",
    "rank": 9946,
    "frequency": 2257,
    "originalRank": 10138
  },
  {
    "word": "atrapan",
    "rank": 9947,
    "frequency": 2257,
    "originalRank": 10139
  },
  {
    "word": "hambrientos",
    "rank": 9948,
    "frequency": 2257,
    "originalRank": 10140
  },
  {
    "word": "disculparse",
    "rank": 9949,
    "frequency": 2256,
    "originalRank": 10141
  },
  {
    "word": "recordé",
    "rank": 9950,
    "frequency": 2256,
    "originalRank": 10142
  },
  {
    "word": "finca",
    "rank": 9951,
    "frequency": 2256,
    "originalRank": 10143
  },
  {
    "word": "pagarte",
    "rank": 9952,
    "frequency": 2256,
    "originalRank": 10144
  },
  {
    "word": "únete",
    "rank": 9953,
    "frequency": 2256,
    "originalRank": 10145
  },
  {
    "word": "montana",
    "rank": 9954,
    "frequency": 2256,
    "originalRank": 10146
  },
  {
    "word": "dea",
    "rank": 9955,
    "frequency": 2256,
    "originalRank": 10147
  },
  {
    "word": "rompa",
    "rank": 9956,
    "frequency": 2256,
    "originalRank": 10148
  },
  {
    "word": "amigable",
    "rank": 9957,
    "frequency": 2255,
    "originalRank": 10149
  },
  {
    "word": "nombrar",
    "rank": 9958,
    "frequency": 2255,
    "originalRank": 10150
  },
  {
    "word": "blog",
    "rank": 9959,
    "frequency": 2255,
    "originalRank": 10151
  },
  {
    "word": "asamblea",
    "rank": 9960,
    "frequency": 2255,
    "originalRank": 10152
  },
  {
    "word": "jonah",
    "rank": 9961,
    "frequency": 2254,
    "originalRank": 10153
  },
  {
    "word": "ocupe",
    "rank": 9962,
    "frequency": 2254,
    "originalRank": 10154
  },
  {
    "word": "porche",
    "rank": 9963,
    "frequency": 2253,
    "originalRank": 10155
  },
  {
    "word": "náuseas",
    "rank": 9964,
    "frequency": 2252,
    "originalRank": 10156
  },
  {
    "word": "amuleto",
    "rank": 9965,
    "frequency": 2252,
    "originalRank": 10157
  },
  {
    "word": "simpatía",
    "rank": 9966,
    "frequency": 2252,
    "originalRank": 10158
  },
  {
    "word": "actualidad",
    "rank": 9967,
    "frequency": 2251,
    "originalRank": 10159
  },
  {
    "word": "púrpura",
    "rank": 9968,
    "frequency": 2249,
    "originalRank": 10160
  },
  {
    "word": "bono",
    "rank": 9969,
    "frequency": 2249,
    "originalRank": 10161
  },
  {
    "word": "corría",
    "rank": 9970,
    "frequency": 2248,
    "originalRank": 10162
  },
  {
    "word": "cumbre",
    "rank": 9971,
    "frequency": 2248,
    "originalRank": 10163
  },
  {
    "word": "concuerda",
    "rank": 9972,
    "frequency": 2248,
    "originalRank": 10164
  },
  {
    "word": "comprarlo",
    "rank": 9973,
    "frequency": 2247,
    "originalRank": 10165
  },
  {
    "word": "elija",
    "rank": 9974,
    "frequency": 2246,
    "originalRank": 10166
  },
  {
    "word": "trama",
    "rank": 9975,
    "frequency": 2246,
    "originalRank": 10167
  },
  {
    "word": "calefacción",
    "rank": 9976,
    "frequency": 2245,
    "originalRank": 10168
  },
  {
    "word": "felipe",
    "rank": 9977,
    "frequency": 2245,
    "originalRank": 10169
  },
  {
    "word": "útiles",
    "rank": 9978,
    "frequency": 2244,
    "originalRank": 10170
  },
  {
    "word": "mostaza",
    "rank": 9979,
    "frequency": 2244,
    "originalRank": 10171
  },
  {
    "word": "psiquiátrico",
    "rank": 9980,
    "frequency": 2243,
    "originalRank": 10172
  },
  {
    "word": "retire",
    "rank": 9981,
    "frequency": 2243,
    "originalRank": 10173
  },
  {
    "word": "bridget",
    "rank": 9982,
    "frequency": 2243,
    "originalRank": 10174
  },
  {
    "word": "protegida",
    "rank": 9983,
    "frequency": 2242,
    "originalRank": 10175
  },
  {
    "word": "barbie",
    "rank": 9984,
    "frequency": 2242,
    "originalRank": 10176
  },
  {
    "word": "sosteniendo",
    "rank": 9985,
    "frequency": 2242,
    "originalRank": 10177
  },
  {
    "word": "renunció",
    "rank": 9986,
    "frequency": 2242,
    "originalRank": 10178
  },
  {
    "word": "detengas",
    "rank": 9987,
    "frequency": 2242,
    "originalRank": 10179
  },
  {
    "word": "desperdiciar",
    "rank": 9988,
    "frequency": 2242,
    "originalRank": 10180
  },
  {
    "word": "sostiene",
    "rank": 9989,
    "frequency": 2242,
    "originalRank": 10181
  },
  {
    "word": "reaccionar",
    "rank": 9990,
    "frequency": 2242,
    "originalRank": 10182
  },
  {
    "word": "capitana",
    "rank": 9991,
    "frequency": 2242,
    "originalRank": 10183
  },
  {
    "word": "high",
    "rank": 9992,
    "frequency": 2241,
    "originalRank": 10184
  },
  {
    "word": "aprendes",
    "rank": 9993,
    "frequency": 2241,
    "originalRank": 10185
  },
  {
    "word": "escapé",
    "rank": 9994,
    "frequency": 2241,
    "originalRank": 10186
  },
  {
    "word": "ejecutado",
    "rank": 9995,
    "frequency": 2240,
    "originalRank": 10187
  },
  {
    "word": "besando",
    "rank": 9996,
    "frequency": 2240,
    "originalRank": 10188
  },
  {
    "word": "perderme",
    "rank": 9997,
    "frequency": 2240,
    "originalRank": 10189
  },
  {
    "word": "curiosa",
    "rank": 9998,
    "frequency": 2239,
    "originalRank": 10190
  },
  {
    "word": "imaginarme",
    "rank": 9999,
    "frequency": 2239,
    "originalRank": 10191
  },
  {
    "word": "estadísticas",
    "rank": 10000,
    "frequency": 2239,
    "originalRank": 10192
  }
];

// Analysis functions
export const analyzeVocabularyFrequency = (userWordList) => {
  const userWords = new Set(
    userWordList.map(word => 
      word.spanish.toLowerCase().trim()
        .replace(/^(el|la|los|las|un|una|unos|unas)\s+/i, '') // Remove articles
        .replace(/[\.,;:!?¡¿"'()\[\]{}]/g, '') // Remove punctuation
    )
  );
  
  let knownInTop100 = 0;
  let knownInTop500 = 0;
  let knownInTop1000 = 0;
  let knownInTop5000 = 0;
  
  const missingHighFreq = [];
  const knownWords = [];
  
  SPANISH_FREQUENCY_DATA.forEach(({ word, rank, frequency }) => {
    const isKnown = userWords.has(word);
    
    if (isKnown) {
      knownWords.push({ word, rank, frequency });
      if (rank <= 100) knownInTop100++;
      if (rank <= 500) knownInTop500++;
      if (rank <= 1000) knownInTop1000++;
      if (rank <= 5000) knownInTop5000++;
    } else if (rank <= 5000) {
      missingHighFreq.push({ word, rank, frequency });
    }
  });
  
  return {
    coverage: {
      knownInTop100,
      knownInTop500,
      knownInTop1000,
      knownInTop5000,
      percentageTop100: Math.round((knownInTop100 / 100) * 100),
      percentageTop500: Math.round((knownInTop500 / 500) * 100),
      percentageTop1000: Math.round((knownInTop1000 / 1000) * 100),
      percentageTop5000: Math.round((knownInTop5000 / 5000) * 100),
    },
    suggestions: {
      criticalGaps: missingHighFreq.filter(w => w.rank <= 500).slice(0, 20),
      importantGaps: missingHighFreq.filter(w => w.rank <= 1500).slice(0, 30),
      valuableGaps: missingHighFreq.filter(w => w.rank <= 5000).slice(0, 50),
    },
    knownWords: knownWords.slice(0, 100), // Top 100 known high-frequency words
    totalVocabularySize: userWordList.length,
    estimatedFluencyLevel: knownInTop1000 > 800 ? 'Advanced' : 
                          knownInTop1000 > 600 ? 'Intermediate' : 
                          knownInTop1000 > 300 ? 'Beginner+' : 'Beginner'
  };
};

export const getWordFrequencyRank = (word) => {
  const normalizedWord = word.toLowerCase().trim()
    .replace(/^(el|la|los|las|un|una|unos|unas)\s+/i, '')
    .replace(/[\.,;:!?¡¿"'()\[\]{}]/g, '');
    
  const found = SPANISH_FREQUENCY_DATA.find(item => item.word === normalizedWord);
  return found ? found.rank : null;
};

export const suggestHighValueWords = (userWordList, maxSuggestions = 50) => {
  const analysis = analyzeVocabularyFrequency(userWordList);
  return [
    ...analysis.suggestions.criticalGaps.slice(0, 15),
    ...analysis.suggestions.importantGaps.slice(0, 20),
    ...analysis.suggestions.valuableGaps.slice(0, 15)
  ].slice(0, maxSuggestions);
};
